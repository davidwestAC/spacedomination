import java.awt.*;
import java.applet.*;

class gsIndustry extends GameState {

//--- variables ---
	Button launch,options,repeat,send;
	Button[] build;
	Scrollbar goal;
	Builds gbuild = new Builds();

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final static Rectangle[] crect = {
/*		new Rectangle(5,205,90,90),new Rectangle(105,205,90,90),new Rectangle(205,205,90,90),
			new Rectangle(305,205,90,90),new Rectangle(405,205,90,90),
		new Rectangle(5,305,90,90),new Rectangle(105,305,90,90),new Rectangle(205,305,90,90),
			new Rectangle(305,305,90,90),new Rectangle(405,305,90,90),
*/
		new Rectangle(5,205,55,90),new Rectangle(65,205,55,90),new Rectangle(125,205,55,90),
			new Rectangle(185,205,55,90),new Rectangle(245,205,55,90),
		new Rectangle(5,305,55,90),new Rectangle(65,305,55,90),new Rectangle(125,305,55,90),
			new Rectangle(185,305,55,90),new Rectangle(245,305,55,90),	
			
	//--- orbit rects ---
/*		new Rectangle(300,40,90,15),new Rectangle(300,55,90,15),new Rectangle(300,70,90,15),
			new Rectangle(300,85,90,15),new Rectangle(300,100,90,15),new Rectangle(300,115,90,15),
*/
		new Rectangle(305,290,90,15),new Rectangle(305,305,90,15),new Rectangle(305,320,90,15),
			new Rectangle(305,335,90,15),new Rectangle(305,350,90,15),new Rectangle(305,365,90,15),

	//--- ground rects ---
/*		new Rectangle(400,40,90,15),new Rectangle(400,55,90,15),new Rectangle(400,70,90,15),
			new Rectangle(400,85,90,15),new Rectangle(400,100,90,15),new Rectangle(400,115,90,15),
*/			
		new Rectangle(405,290,90,15),new Rectangle(405,305,90,15),new Rectangle(405,320,90,15),
			new Rectangle(405,335,90,15),new Rectangle(405,350,90,15),new Rectangle(405,365,90,15),
	};
/*
	Rectangle orbit = new Rectangle(300,25,90,120);
	Rectangle ground = new Rectangle(400,25,90,120);
*/	
	Rectangle orbit = new Rectangle(305,275,90,120);
	Rectangle ground = new Rectangle(405,275,90,120);

	int select=-1,over=-1;
	Worlds wp;

//--- constructors ---
	public gsIndustry(){}

	public void init(){
	int i;

		root.add(launch = new Button("Launch"));
//		root.add(quit = new Button("Quit"));
		root.add(options = new Button("Options"));
		root.add(repeat = new Button("Repeat"));
		root.add(send = new Button("Send"));
		send.hide();

		build = new Button[Builds.BUILD_TYPES];
		for (i=0;i<Builds.BUILD_TYPES;i++) 
			root.add(build[i] = new Button(Builds.name[i]));

		root.add(goal = new Scrollbar(Scrollbar.HORIZONTAL,0,10,0,250));
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

//		g.setColor(new Color(0,128,0));
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,0,500,400);

		fp = gsFleet;
		ep = Fleets.get(fp.destID);
		wp = Worlds.get(fp.destID);

		if (wp==null) {
			g.setColor(Color.black);
			g.drawString("Waiting for Info",10,10);
			g.drawString("fleet = "+fp.fleetID,10,30);
			g.drawString("world = "+fp.destID,10,50);
			return;
		}

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals

		g.setColor(Color.white);
//		g.drawString(fp.empireName(),120,5);
		g.drawString("World: "+wp.name(),120,20);
		g.drawString("Type: "+wp.special(),120,35);
		g.drawString("Storage: "+wp.storage(),120,50);
		g.drawString("Population: "+wp.pop(),120,65);
		val = (wp.maxInd()-wp.ind());
		g.drawString("Industry: "+wp.ind()+(val>0?" ("+val+")":" (Max)"),120,80);
		g.drawString("Merchants: "+wp.Merchant()+" Max: "+wp.maxMerchant(),120,95);
		g.drawString("Beacons: "+wp.Beacon()+" Max: "+wp.maxBeacon(),120,110);
		g.drawString("Stardocks: "+wp.Stardock()+" Max: "+wp.maxStardock(),120,125);
		g.drawString("Blasters: "+wp.Blaster()+" Max: "+wp.maxBlaster(),120,140);
		
		g.drawString("Minerals",250,20);
		g.drawString("Pladesium: "+wp.pladesium(),250,35);
		g.drawString("Stenterium: "+wp.stenterium(),250,50);
		g.drawString("Calastium: "+wp.calastium(),250,65);
		g.drawString("Revidium: "+wp.revidium(),250,80);
		g.drawString("Frelenium: "+wp.frelenium(),250,95);
		g.drawString("Happiness: "+wp.happinessname(),250,125);
		g.drawString("Sector: "+wp.sector(),250,140);

		if (fp!=null) fp.drawStats(g,orbit.x,orbit.y,90,120);
		if (ep!=null) ep.drawStats(g,ground.x,ground.y,90,120);

	//--- builds ---
//		g.setColor(Color.yellow);
		g.setColor(BOX_COLOR);
		for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			g.fillRect(r.x,r.y,r.width,r.height);
		}

		if (select<0 || select>=10) send.hide();
		else {
			r = crect[select];
			g.setColor(Color.red);
			g.drawRect(r.x-1,r.y-1,r.width+2,r.height+2);

			gbuild.setGoal(goal.getValue());

			r = crect[select];
			reshape(send,r.x+5,r.y+65,45,20);
			send.show();
		}

		reshape(goal,10,150,250,16);

		g.setColor(Color.black);
		if (wp!=null) for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			bp = (i==select?gbuild:wp.builds(i));
			if (bp==null) continue;
			if ((bp.type()==bp.BUILD_NOTHING || bp.goal()==0) && i!=select) continue;
/*			g.drawString("type: "+bp.name(),r.x+5,r.y+15);
			g.drawString("build: "+bp.built()+"/"+bp.goal(),r.x+5,r.y+30);
			g.drawString("repeat: "+bp.repeat(),r.x+5,r.y+45);
			g.drawString("cost: "+bp.cost(),r.x+5,r.y+60);*/
			g.drawString(""+bp.name(),r.x+5,r.y+15);
			g.drawString(""+bp.built()+"/"+bp.goal(),r.x+5,r.y+30);
			g.drawString(""+bp.repeat(),r.x+5,r.y+45);
			g.drawString(""+bp.cost(),r.x+5,r.y+60);
		}
		
	//--- draw buttons ---
		reshape(launch,10,5,80,20);
//		reshape(quit,440,30,50,20);
//		reshape(options,240,75,50,20);
//		reshape(options,316,150,50,20);
		reshape(options,440,5,50,20);
//		reshape(repeat,270,150,80,20);
		reshape(repeat,262,150,45,20);
		for (i=0;i<Builds.BUILD_STARDOCK;i++) reshape(build[i],10+i*60,175,58,20);
		reshape(build[8],370,150,58,20);
		reshape(build[9],430,150,58,20);
		reshape(build[10],310,150,58,20);
		
		g.setColor(Color.white);
		if (over>=0) {
			r = crect[over];
			g.setColor(Color.blue);
			g.drawRect(r.x,r.y,r.width,r.height);
		}

	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(55,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,60,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}
	}

	final static int MAPW = 50;
	final static Rectangle map = new Rectangle(10,40,2*MAPW,2*MAPW);

	void drawMiniMap(Graphics g){
	int cx,cy,size,x,y,dx,dy;
	Worlds wp;
	Fleets fp;
	Color c;

		g.setColor(Color.black);
		g.fillRect(map.x,map.y,map.width,map.height);

		fp = gsFleet;
		if (fp==null) return;

		cx = fp.xloc();
		cy = fp.yloc();
		dx = map.x + MAPW;
		dy = map.y + MAPW;

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {

			switch (wp.type()) {
				case 24: g.setColor(wp.NEBULAE_COLOR); size = wp.NEBULAE_SIZE; break;
				case 25: g.setColor(wp.NEUTRON_COLOR); size = wp.NEUTRON_SIZE; break;
				case 26:
					x = StarDart.cycle;
					c = new Color(
						((x&32)==0?8*(x&31):252-8*(x&31)),
						((x&16)==0?16*(x&15):248-16*(x&15)),
						((x&64)==0?4*(x&63):253-4*(x&63))	
					); 
					size = wp.WORLD_SIZE; 
					break;
				default: g.setColor(wp.WORLD_COLOR); size = wp.WORLD_SIZE; break;
			}

			x = (wp.xloc()-cx) * MAPW / wp.scale;
			if (x+size<-MAPW || x-size>MAPW) continue;
			y = (wp.yloc()-cy) * MAPW / wp.scale;
			if (y+size<-MAPW || y-size>MAPW) continue;

			size = size * MAPW / wp.scale;
			g.fillOval(dx+x-size,dy+y-size,2*size+1,2*size+1);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {

			if (fp.ghost()) continue;

			x = (fp.xloc()-cx) * MAPW / wp.scale;
			if (x<-MAPW || x>MAPW) continue;
			y = (fp.yloc()-cy) * MAPW / wp.scale;
			if (y<-MAPW || y>MAPW) continue;

			wp = Worlds.get(fp.destID);
			if (wp!=null) {
				g.setColor(Color.blue);
				g.drawLine(dx+x,dy+y,
					dx+(wp.xloc()-cx) * MAPW / wp.scale,
					dy+(wp.yloc()-cy) * MAPW / wp.scale);
			}

			g.setColor(Color.red);
			g.fillRect(dx+x-1,dy+y-2,5,3);
		}

	//--- cut rects ---
//		g.setColor(new Color(0,128,0));
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,map.y+map.height,500,400-map.y-map.height);
		g.fillRect(map.x+map.width,0,500-map.x-map.width,map.y+map.height);
		g.fillRect(map.x,0,map.width,map.y);
		g.fillRect(0,0,map.x,map.y+map.height);
	}

//--- primary functions ---
	public void down(int x,int y){
	Fleets fp;
	int i;

		for (i=0;i<10;i++) {
			if (!crect[i].inside(x,y)) continue;
			if (i!=select) {
				select = i;
				gbuild.copy(wp.builds(i));
				goal.setValue(gbuild.goal);
			}
			break;
		}

		if (orbit.inside(x,y)) {
			fp = gsFleet;
			sendTransfer(fp,(y-orbit.y)/15,false);
		}

		if (ground.inside(x,y)) {
			fp = gsFleet.getInvade();
			sendTransfer(fp,(y-ground.y)/15,true);
		}
	}

	public void move(int x,int y){
	Fleets fp;
	int i,num;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);

		over = -1;
		for (i=0;i<10;i++) if (crect[i].inside(x,y)) {
			over = i;
			return;
		}

		if (orbit.inside(x,y)) {
			num = gsFleet.countSquads();
			i = (y-orbit.y)/15 - 1;
			if (i>=0 && i<num) over = 10 + i;
		}

		if (ground.inside(x,y)) {
			fp = gsFleet.getInvade();
			if (fp!=null) {
				num = fp.countSquads();
				i = (y-orbit.y)/15 - 1;
				if (i>=0 && i<num) over = 16 + i;
			}
		}
	}
	
	public void raise(int x,int y){}
	public void drag(int x,int y){}

	public void action(Event e){
	int id;

		super.action(e);

		if (e.target==launch) signalLaunch();
//		if (e.target==quit) setState(new gsPassword());
		if (e.target==options) setState(new gsOptions());

		if (e.target==repeat) gbuild.flipRepeat();
		for (id=0;id<Builds.BUILD_TYPES;id++) if (e.target==build[id]) gbuild.setType(id);
		if (e.target==send) sendBuildMessage();
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;

		fp=null;

		value = super.handleInput(buf);

		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		return value;
	}

//--- change build values ---
	void sendBuildMessage(){
	Buffer buf;

		if (select<0 || select>=10 || gbuild==null) return;

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,BUILD_COMMAND);
		buf.set(2,select);
		buf.set(3,(gbuild.repeat()?1:0));
		buf.set(4,gbuild.type());
		buf.set(5,gbuild.goal());
		buf.send();

		select = -1;
		send.hide();
	}
}
