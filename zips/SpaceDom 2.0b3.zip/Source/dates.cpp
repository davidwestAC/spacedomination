//********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//********************************************************************
#include "SDserver.hpp"
#include <time.h>

//********************************************************************

const int yearDays = 365;
const int leapDays = 4*yearDays + 1;


int daysPerMonth[12] = {
	31,28,31,30,31,30,
	31,31,30,31,30,31
};
int daysToMonth[12] = {
	0,31,59,90,120,151,
	181,212,243,273,304,334,
};

char todayStr[32];

//********************************************************************

void setTodaysDate(){
struct tm *date;
time_t ticks;

	time(&ticks);
	date = localtime(&ticks);
	sprintf(todayStr,"%d/%d/%d",
		date->tm_mon+1,date->tm_mday,1900+date->tm_year);
}


void setTimeString(char *buf){
struct tm *date;
time_t ticks;

	time(&ticks);
	date = localtime(&ticks);
	sprintf(todayStr,"%d/%d/%d",
		date->tm_mon+1,date->tm_mday,1900+date->tm_year);
}


int dateToDays(char *date){
int days,year,month;

	if (date==NULL) return 0;

	if (sscanf(date,"%d/%d/%d",&month,&days,&year)!=3) return 0;

	days = days-1;
	month = month-1;
	if (year<1000) year += 1900;

//--- add months & years to day ---
	days += daysToMonth[month];
	days += year * 365;
	
//--- leap year factor ---
	days += 1 + (year/4);
	if ((year&3)==0 && month<2 && days<29) days--;

	return days;
}


void daysToDate(int days,char *date){
int year,month,val;

//--- calc years ---
	val = days / leapDays;
	days -= val * leapDays;
	year = val * 4;

	if (days>yearDays+1) {	// year 0 is a leap year, kinda
		days -= yearDays+1;
		year++;
	}

	while (days>yearDays) {
		days -= yearDays;
		year++;
	}

//--- calc days ---
	for (month=0;month<12;month++) {
		val = daysPerMonth[month];
		if (val>days) break;
		days -= val;
	}
	month++;
	days++;

//--- cleanup ---
	sprintf(date,"%d/%d/%d",month,days,year);
}

//************************************************************************

int todayToDays(){
	setTodaysDate();
	return dateToDays(todayStr);
}


int secondsSinceMidnight(){
struct tm *date;
time_t ticks;

	time(&ticks);
	date = localtime(&ticks);

	return date->tm_hour * 3600 + date->tm_min * 60 + date->tm_sec;
}

int dateIndex(){
struct tm *date;
int days,year;
time_t ticks;

	time(&ticks);
	date = localtime(&ticks);

	days = date->tm_yday;
	year = 1900 + date->tm_year;

	return year * 365 + year/4 + days + 1;
}

//************************************************************************
