import java.awt.*;
import java.applet.*;

class GameState implements MessageValues {

//--- global values ---
	static StarDart root;

	static String message = "";

	public static int setRace = 0;

	final static int MAX_CHAT = 5;
	static String[] chatMsg = new String[MAX_CHAT];
	static long[] chatTime = new long[MAX_CHAT];
	boolean showChat = true;

	public static int gsEmpireID,gsFleetID;
	public static Empires gsEmpire=null;
	public static Fleets gsFleet=null;
	public static int fleetStatus=Fleets.DEAD;

	public final static Font hugeFNT = new Font("TimesRoman",Font.BOLD,116);
	public final static Font bigFNT = new Font("TimesRoman",Font.BOLD,50);
	public final static Font stoutFNT = new Font("TimesRoman",Font.BOLD,24);
	public final static Font textFNT = new Font("TimesRoman",Font.PLAIN,14);
	public final static FontMetrics hugeMET = new Button().getFontMetrics(hugeFNT);
	public final static FontMetrics bigMET = new Button().getFontMetrics(bigFNT);
	public final static FontMetrics stoutMET = new Button().getFontMetrics(stoutFNT);
	public final static FontMetrics textMET = new Button().getFontMetrics(textFNT);

	public static Color SCREEN_COLOR = new Color(0,128,0);
	public static Color BOX_COLOR = Color.yellow;

	public static Portrait chatbar = null;

	static int[] top20List = {-1,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0};
	static int channel = 0;

	Buffer statBuf = null;
	Buffer setBuf = null;

//--- constructors ---
	public GameState(){
		root.setFont(textFNT);
		//fmet = root.getFontMetrics(root.getFont());
		chatbar = new Portrait("Chatbar.jpg");
	}

	public void init(){}

	public static void setState(GameState gs){
		root.removeAll();	// kill tools
		StarDart.state = gs;
		gs.init();
		root.repaint();
		root.requestFocus();
	}

//--- primary functions ---
	public void paint(Graphics g){}

	public void action(Event e){}

	public void down(int x,int y){}
	public void raise(int x,int y){}
	public void move(int x,int y){}
	public void drag(int x,int y){}

	public boolean press(int key){
	int len;

		if (!(this instanceof gsPassword)) root.requestFocus();

		if (key==10) {	// send
			sendMessage();
			message = "";
		}
		else if (key==8) {	// backspace
			len = message.length();
			if (len>0) message = message.substring(0,len-1);
		}
		else {
			message += ""+(char)(key);
		}

		return true;
	}

	public boolean isMovingStatus(){return (fleetStatus<=Fleets.NEUTRON);}

//--- handle common inputs ---
	public boolean handleInput(Buffer buf){
		//System.out.println("Message="+buf.get(1));

		switch(buf.get(1)){
			case WORLD_SCAN: Worlds.add(buf); return true;
			case FLEET_SCAN: Fleets.add(buf); return true;
			case EMPIRE_SCAN: Empires.add(buf); return true;
			case COMBAT_SCAN: Fleets.combat(buf); return true;
			case BUILD_SCAN: Worlds.build(buf); return true;
			case TOP20_SCAN: readTop20List(buf); return true;

			case SECTOR_FLEETS: Fleets.scan(buf); return true;
			case SECTOR_WORLDS: Worlds.scan(buf); return true;

			case MESSAGE: chatAdd(buf); return true;
			case STATUS: 
				fleetStatus = buf.get(2); 
				sendPing();
				return true;

			case VICTORY:
				setState(new gsVictory(buf));
				return true;
				
			case STATS_RESULT:
				statBuf = buf;
				break;

			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}
		
		return false;
	}

//--- tool utilities ---
	void reshape(Component cp,int x,int y,int w,int h){cp.reshape(x,y,w,h);}

	void readTop20List(Buffer buf){
	int len;

		len = buf.length();
		for (int i=0;i<20 && 2+i*4<len;i++) {
			top20List[i] = buf.getInt(2+i*4);
			sendEmpireQuery(top20List[i]);
		}
	}

//--- handle chat messages ---
	public int chatCount(){
	int ix,count;
	long time;

		time = System.currentTimeMillis();

		for (count=ix=0;ix<MAX_CHAT;ix++) {
			if (chatTime[ix]>time)	count++;
			else					chatMsg[ix] = null;
		}

		return count;
	}

	public String chatLine(int i){return chatMsg[i];}

	public void chatAdd(Buffer buf){
	String msg;
	int ix;

		msg = "";
		for(ix=2;ix<buf.length();ix++) msg += (char)buf.get(ix);

		for (ix=MAX_CHAT-1;ix>0;ix--) {
			chatMsg[ix] = chatMsg[ix-1];
			chatTime[ix] = chatTime[ix-1];
		}

		chatMsg[0] = msg;
		chatTime[0] = System.currentTimeMillis() + 1000 * 20;
	}

	void drawChatMessages(Graphics g){
	int count;	
	
		chatbar.center(g,250,450,root);
	
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.setColor(Color.green);
			g.drawString(gsEmpire.name+": "+message,10,492);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(Color.white);
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),10,417+count*15);
		}
	}

	public void showGameStats(Graphics g,int h,int v){
	Empires emp;
	String name;
	Date date;
	int i;

		g.setColor(Color.white);
		g.drawString("Current Game Statistics",h,v);

		if (statBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.drawString("Total Planets = "+statBuf.getInt(4),h,v+=22);
		g.drawString("Total Empires = "+statBuf.getInt(8),h,v+=15);
		g.drawString("Total StarDarts = "+statBuf.getInt(12),h,v+=15);
		g.drawString("Players Online = "+statBuf.getInt(16),h,v+=15);

		g.drawString("Maximum Score = "+statBuf.getInt(36),h,v+=30);
		g.drawString("Winning Score = "+((int)statBuf.get(2))+"% = "+(((int)statBuf.getInt(36)) / 100) * ((int)statBuf.get(2)),h,v+=15);
//		g.drawString("Victory When High Score = "+(((int)statBuf.getInt(36)) / 100) * ((int)statBuf.get(2)),h,v+=15);
		g.drawString("Current High Score = "+((int)statBuf.get(3))+"%",h,v+=15);
		date = new Date(statBuf.getInt(28),statBuf.getInt(32));
		g.drawString("Current Time is "+date.toString(),h,v+=15);

		if (statBuf.get(44)==0) return;		// no immortal victor as yet
		g.drawString("Last Immortal Victor <"+statBuf.getString(44)+" Empire>",h,v+=30);
		date = new Date(statBuf.getInt(20),statBuf.getInt(24));
		g.drawString("Victory Occured "+date.toString(),h,v+=15);
		date = new Date(0,statBuf.getInt(40));
		g.drawString("Victory Took "+date.lengthStr(),h,v+=15);
	}

	public void showSettings(Graphics g,int h,int v){
	int i;

		g.setColor(Color.white);
		g.drawString("Server Settings",h,v);

		if (setBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.drawString("Minimum Possible Worlds = "+setBuf.getInt(4)+" Worlds",h,v+=22);
		g.drawString("Maximum Possible Worlds = "+setBuf.getInt(8)+" Worlds",h,v+=15);
		
		g.drawString("Starting Victory Percent = "+setBuf.getInt(12)+"%",h,v+=30);
		g.drawString("Victory Percent Drops One Percent Every "+setBuf.getInt(16)+" Hours",h,v+=15);
		
		g.drawString("Starting Command Build = "+setBuf.getInt(20)+" Build Points",h,v+=30);
		g.drawString("Command Build Bonus = "+setBuf.getInt(24)+" Build Points",h,v+=15);
		g.drawString("World Build Bonus = "+(float)setBuf.getInt(28) / 10F+"% Build",h,v+=15);
		
		g.drawString("Starting Speed = "+setBuf.getInt(32)+" Pixels Per Second",h,v+=30);
		g.drawString("Maximum Speed = "+setBuf.getInt(36)+" Pixels Per Second",h,v+=15);
		
		g.drawString("Starting Fleet Decay = 1/"+setBuf.getInt(40)+" Ships Per Ten Seconds",h,v+=30);
		g.drawString("Starting World Decay = 1/"+setBuf.getInt(44)+" Ships Per Ten Seconds",h,v+=15);
		
		g.drawString("Variable Updates Occur Every "+setBuf.getInt(48)+" Minutes",h,v+=30);
		
		g.drawString("1/"+setBuf.getInt(52)+" Worlds Declare For Taking Old Earth First",h,v+=30);
		g.drawString("1/"+setBuf.getInt(56)+" Phenomena Declare For Taking Old Earth First",h,v+=15);
		
		g.drawString("1/"+setBuf.getInt(60)+" Worlds Declare For Taking Old Earth Later",h,v+=30);
		g.drawString("1/"+setBuf.getInt(64)+" Phenomena Declare For Taking Old Earth Later",h,v+=15);
		
		g.drawString("1/"+setBuf.getInt(68)+" Worlds Declare For Taking Your Race's Homeworld",h,v+=30);
		g.drawString("1/"+setBuf.getInt(72)+" Phenomena Declare For Taking Your Race's Homeworld",h,v+=15);
	}

	final static int MAPW = 50;
	final static Rectangle map = new Rectangle(10,40,2*MAPW,2*MAPW);

	void drawMiniMap(Graphics g){
	int cx,cy,size,x,y,dx,dy;
	Worlds wp;
	Fleets fp;
	Color c;

		g.setColor(Color.black);
		g.fillRect(map.x,map.y,map.width,map.height);

		fp = gsFleet;
		if (fp==null) return;

		cx = fp.xloc();
		cy = fp.yloc();
		dx = map.x + MAPW;
		dy = map.y + MAPW;

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {

			switch (wp.type()) {
				case Worlds.NEBULAE: g.setColor(wp.NEBULAE_COLOR); size = wp.NEBULAE_SIZE; break;
				case Worlds.NEUTRON: g.setColor(wp.NEUTRON_COLOR); size = wp.NEUTRON_SIZE; break;
				case Worlds.GATEWAY:
					x = StarDart.cycle;
					c = new Color(
						((x&32)==0?8*(x&31):252-8*(x&31)),
						((x&16)==0?16*(x&15):248-16*(x&15)),
						((x&64)==0?4*(x&63):253-4*(x&63))	
					); 
					size = wp.WORLD_SIZE; 
					break;
				default: g.setColor(wp.WORLD_COLOR); size = wp.WORLD_SIZE; break;
			}

			x = (wp.xloc()-cx) * MAPW / wp.scale;
			if (x+size<-MAPW || x-size>MAPW) continue;
			y = (wp.yloc()-cy) * MAPW / wp.scale;
			if (y+size<-MAPW || y-size>MAPW) continue;

			size = size * MAPW / wp.scale;
			g.fillOval(dx+x-size,dy+y-size,2*size+1,2*size+1);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {

			if (fp.ghost()) continue;

			x = (fp.xloc()-cx) * MAPW / wp.scale;
			if (x<-MAPW || x>MAPW) continue;
			y = (fp.yloc()-cy) * MAPW / wp.scale;
			if (y<-MAPW || y>MAPW) continue;

			wp = Worlds.get(fp.destID);
			if (wp!=null) {
				g.setColor(Color.blue);
				g.drawLine(dx+x,dy+y,
					dx+(wp.xloc()-cx) * MAPW / wp.scale,
					dy+(wp.yloc()-cy) * MAPW / wp.scale);
			}

			g.setColor(Color.red);
			g.fillRect(dx+x-1,dy+y-2,5,3);
		}

	//--- cut rects ---
//		g.setColor(new Color(0,128,0));
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,map.y+map.height,500,400-map.y-map.height);
		g.fillRect(map.x+map.width,0,500-map.x-map.width,map.y+map.height);
		g.fillRect(map.x,0,map.width,map.y);
		g.fillRect(0,0,map.x,map.y+map.height);
	}

//--- common messages ---
	static void sendQuickMessage(int message){
	Buffer buf;

		buf = new Buffer(2);
		buf.set(0,2);
		buf.set(1,message);
		buf.send();
	}

	public static void sendSessionDone(){sendQuickMessage(SESSION_DONE);}

	public static void sendPing(){sendQuickMessage(SESSION_PING);}

	public static void sendTop20Query(){sendQuickMessage(TOP20_QUERY);}

	public static void sendRebirthRequest(){sendQuickMessage(REBIRTH_REQUEST);}

	public static void sendStatsQuery(){sendQuickMessage(STATS_QUERY);}

	public static void sendSettingsQuery(){sendQuickMessage(SETTINGS_QUERY);}

	public static void sendRestart(){sendQuickMessage(RESTART);}

	public static void signalLaunch(){sendFleetMove(-1);}

	public static void sendFleetMove(int dest){
	Buffer buf;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,SET_DESTINATION);
		buf.setShort(2,dest);
		buf.send();
	}

	public static void sendTransfer(Fleets fp,int index,boolean lift){
	Squadron sp=null;
	Buffer buf;
	int pos,ix;

		if (fp==null) return;

		for (pos=0;pos<6;pos++) {
			sp = fp.squads(pos);
			if (sp==null || sp.type==sp.SHIP_TYPES) continue;
			if (--index==0) break;
		}

		buf = new Buffer(8);
		buf.set(0,8);
		buf.set(1,FLEET_TRANSFER);
		buf.setShort(2,(sp.type()==sp.STARDART?1:sp.count()));
		buf.set(6,sp.type());
		buf.set(7,(lift?1:0));
		buf.send();
	}

	public static void sendChannel(){
	Buffer buf;

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,CHAT_CHANNEL);
		buf.setInt(2,channel);
		buf.send();
	}

	public static void sendMessage(){
	Buffer buf;
	int len;

		len = message.length();
		if (len==0) return;

		if (len>100) {
			message = message.substring(0,100);//all 253
			len = 100;
		}

		buf = new Buffer(len+2);
		buf.set(0,len+2);
		buf.set(1,CHAT_MESSAGE);
		for (int i=0;i<len;i++) buf.set(i+2,message.charAt(i));
		buf.send();
	}

	public static void sendRace(){
	Buffer buf;

		buf = new Buffer(8);
		buf.set(0,8);
		buf.set(1,RACE_CHANGE);
		buf.setInt(4,setRace);
		buf.send();
	}

	public static void sendEmpireQuery(int id){
	Buffer buf;

		if (id<0) return;
		
		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,EMPIRE_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendFleetQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,FLEET_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendWorldQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,WORLD_QUERY);
		buf.setShort(2,id);
		buf.send();
	}
}
