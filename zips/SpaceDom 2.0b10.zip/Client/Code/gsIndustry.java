import java.awt.*;
import java.applet.*;

class gsIndustry extends GameState {

//--- variables ---
	Button launch,options,repeat,send;
	Button[] build;
	Scrollbar goal;
	Builds gbuild = new Builds();

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final static Rectangle[] crect = {
/*		new Rectangle(5,205,90,90),new Rectangle(105,205,90,90),new Rectangle(205,205,90,90),
			new Rectangle(305,205,90,90),new Rectangle(405,205,90,90),
		new Rectangle(5,305,90,90),new Rectangle(105,305,90,90),new Rectangle(205,305,90,90),
			new Rectangle(305,305,90,90),new Rectangle(405,305,90,90),
*/
		new Rectangle(5,205,55,90),new Rectangle(65,205,55,90),new Rectangle(125,205,55,90),
			new Rectangle(185,205,55,90),new Rectangle(245,205,55,90),
		new Rectangle(5,305,55,90),new Rectangle(65,305,55,90),new Rectangle(125,305,55,90),
			new Rectangle(185,305,55,90),new Rectangle(245,305,55,90),	
			
	//--- orbit rects ---
/*		new Rectangle(300,40,90,15),new Rectangle(300,55,90,15),new Rectangle(300,70,90,15),
			new Rectangle(300,85,90,15),new Rectangle(300,100,90,15),new Rectangle(300,115,90,15),
*/
		new Rectangle(305,290,90,15),new Rectangle(305,305,90,15),new Rectangle(305,320,90,15),
			new Rectangle(305,335,90,15),new Rectangle(305,350,90,15),new Rectangle(305,365,90,15),

	//--- ground rects ---
/*		new Rectangle(400,40,90,15),new Rectangle(400,55,90,15),new Rectangle(400,70,90,15),
			new Rectangle(400,85,90,15),new Rectangle(400,100,90,15),new Rectangle(400,115,90,15),
*/			
		new Rectangle(405,290,90,15),new Rectangle(405,305,90,15),new Rectangle(405,320,90,15),
			new Rectangle(405,335,90,15),new Rectangle(405,350,90,15),new Rectangle(405,365,90,15),
	};
/*
	Rectangle orbit = new Rectangle(300,25,90,120);
	Rectangle ground = new Rectangle(400,25,90,120);
*/	
	Rectangle orbit = new Rectangle(305,275,90,120);
	Rectangle ground = new Rectangle(405,275,90,120);

	int select=-1,over=-1;
	Worlds wp;

//--- constructors ---
	public gsIndustry(){}

	public void init(){
	int i;

		root.add(launch = new Button("Launch"));
//		root.add(quit = new Button("Quit"));
		root.add(options = new Button("Options"));
		root.add(repeat = new Button("Repeat"));
		root.add(send = new Button("Send"));
		send.hide();

		build = new Button[Builds.BUILD_TYPES];
		for (i=0;i<Builds.BUILD_TYPES;i++) 
			root.add(build[i] = new Button(Builds.name[i]));

		root.add(goal = new Scrollbar(Scrollbar.HORIZONTAL,0,10,0,250));
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

//		g.setColor(new Color(0,128,0));
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,0,500,400);

		fp = gsFleet;
		ep = Fleets.get(fp.destID);
		wp = Worlds.get(fp.destID);

		if (wp==null) {
			g.setColor(Color.black);
			g.drawString("Waiting for Info",10,10);
			g.drawString("fleet = "+fp.fleetID,10,30);
			g.drawString("world = "+fp.destID,10,50);
			return;
		}

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals

		g.setColor(Color.white);
		g.drawString(fp.empireName(),120,20);
		g.drawString("World: "+wp.name(),120,35);
		g.drawString("Type: "+wp.special(),120,50);
		g.drawString("Sector: "+wp.sector(),120,65);
		g.drawString("Population: "+wp.pop(),120,80);
		val = (wp.maxInd()-wp.ind());
		g.drawString("Industry: "+wp.ind()+(val>0?" ("+val+")":" (Max)"),120,95);
		g.drawString("Storage: "+wp.storage(),120,110);
		g.drawString("Happiness: "+wp.happinessname(),120,125);
		g.drawString("Pollution: "+wp.pollutionname(),120,140);	
	
		g.drawString("Minerals",250,20);
		g.drawString("Pladesium: "+wp.pladesium(),250,35);
		g.drawString("Stenterium: "+wp.stenterium(),250,50);
		g.drawString("Calastium: "+wp.calastium(),250,65);
		g.drawString("Revidium: "+wp.revidium(),250,80);
		g.drawString("Frelenium: "+wp.frelenium(),250,95);

		g.drawString("Facilities",340,20);
		g.drawString("Globals:",340,35);
		g.drawString("Merchants: "+wp.Merchant()+" Max: "+wp.maxMerchant(),340,50);
		g.drawString("Beacons: "+wp.Beacon()+" Max: "+wp.maxBeacon(),340,65);
		g.drawString("Stardocks: "+wp.Stardock()+" Max: "+wp.maxStardock(),340,80);
		g.drawString("Blasters: "+wp.Blaster()+" Max: "+wp.maxBlaster(),340,95);
		g.drawString("Local: "+wp.facilityname(),340,110);

		g.drawString("Ships:",310,145);
		g.drawString("Global:",370,145);
		g.drawString("Local:",430,145);

		if (fp!=null) fp.drawStats(g,orbit.x,orbit.y,90,120);
		if (ep!=null) ep.drawStats(g,ground.x,ground.y,90,120);

	//--- builds ---
//		g.setColor(Color.yellow);
		g.setColor(BOX_COLOR);
		for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			g.fillRect(r.x,r.y,r.width,r.height);
		}

		if (select<0 || select>=10) send.hide();
		else {
			r = crect[select];
			g.setColor(Color.red);
			g.drawRect(r.x-1,r.y-1,r.width+2,r.height+2);

			gbuild.setGoal(goal.getValue());

			r = crect[select];
			reshape(send,r.x+5,r.y+65,45,20);
			send.show();
		}

		reshape(goal,10,150,250,16);

		g.setColor(Color.black);
		if (wp!=null) for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			bp = (i==select?gbuild:wp.builds(i));
			if (bp==null) continue;
			if ((bp.type()==bp.BUILD_NOTHING || bp.goal()==0) && i!=select) continue;
/*			g.drawString("type: "+bp.name(),r.x+5,r.y+15);
			g.drawString("build: "+bp.built()+"/"+bp.goal(),r.x+5,r.y+30);
			g.drawString("repeat: "+bp.repeat(),r.x+5,r.y+45);
			g.drawString("cost: "+bp.cost(),r.x+5,r.y+60);*/
			
			if (bp.type()<=bp.BUILD_BLASTER) {
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				g.drawString(""+bp.cost(),r.x+2,r.y+60);
			}
			
			if (bp.type()>=bp.BUILD_SABOTAGE && bp.type()<=bp.BUILD_AMENITY) {
				bp.goal = 1;
				bp.repeat = false;
				g.drawString(""+bp.name(),r.x+2,r.y+15);
//				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
//				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				g.drawString(""+bp.cost(),r.x+2,r.y+30);
			}
		}
		
	//--- draw buttons ---
		reshape(launch,10,5,80,20);
		reshape(options,10,175,58,20);
		reshape(repeat,262,150,45,20);
//		for (i=0;i<Builds.BUILD_MERCHANT;i++) reshape(build[i],10+i*60,175,58,20);
		reshape(build[0],310,150,58,20);
		reshape(build[1],310,175,58,20);
		reshape(build[2],310,200,58,20);
		reshape(build[3],310,225,58,20);
		reshape(build[4],310,250,58,20);
		reshape(build[5],250,175,58,20);
		reshape(build[6],370,150,58,20);
		reshape(build[7],370,175,58,20);
		reshape(build[8],370,200,58,20);
		reshape(build[9],370,225,58,20);
		reshape(build[10],430,150,58,20);
		reshape(build[11],430,175,58,20);
		reshape(build[12],430,200,58,20);
		reshape(build[13],430,225,58,20);
		reshape(build[14],190,175,58,20);
		
		g.setColor(Color.white);
		if (over>=0) {
			r = crect[over];
			g.setColor(Color.blue);
			g.drawRect(r.x,r.y,r.width,r.height);
		}
		
		drawChatMessages(g);
	}

//--- primary functions ---
	public void down(int x,int y){
	Fleets fp;
	int i;

		for (i=0;i<10;i++) {
			if (!crect[i].inside(x,y)) continue;
			if (i!=select) {
				select = i;
				gbuild.copy(wp.builds(i));
				goal.setValue(gbuild.goal);
			}
			break;
		}

		if (orbit.inside(x,y)) {
			fp = gsFleet;
			sendTransfer(fp,(y-orbit.y)/15,false);
		}

		if (ground.inside(x,y)) {
			fp = gsFleet.getInvade();
			sendTransfer(fp,(y-ground.y)/15,true);
		}
	}

	public void move(int x,int y){
	Fleets fp;
	int i,num;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);

		over = -1;
		for (i=0;i<10;i++) if (crect[i].inside(x,y)) {
			over = i;
			return;
		}

		if (orbit.inside(x,y)) {
			num = gsFleet.countSquads();
			i = (y-orbit.y)/15 - 1;
			if (i>=0 && i<num) over = 10 + i;
		}

		if (ground.inside(x,y)) {
			fp = gsFleet.getInvade();
			if (fp!=null) {
				num = fp.countSquads();
				i = (y-orbit.y)/15 - 1;
				if (i>=0 && i<num) over = 16 + i;
			}
		}
	}
	
	public void raise(int x,int y){}
	public void drag(int x,int y){}

	public void action(Event e){
	int id;

		super.action(e);

		if (e.target==launch) signalLaunch();
//		if (e.target==quit) setState(new gsPassword());
		if (e.target==options) setState(new gsOptions());

		if (e.target==repeat) gbuild.flipRepeat();
		for (id=0;id<Builds.BUILD_TYPES;id++) if (e.target==build[id]) gbuild.setType(id);
		if (e.target==send) sendBuildMessage();
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;

		fp=null;

		value = super.handleInput(buf);

		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		return value;
	}

//--- change build values ---
	void sendBuildMessage(){
	Buffer buf;

		if (select<0 || select>=10 || gbuild==null) return;

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,BUILD_COMMAND);
		buf.set(2,select);
		buf.set(3,(gbuild.repeat()?1:0));
		buf.set(4,gbuild.type());
		buf.set(5,gbuild.goal());
		buf.send();

		select = -1;
		send.hide();
	}
}
