import java.awt.*;
import java.applet.*;
import java.awt.image.*;

class gsOptions extends GameState {

	Button restart;
	Button quit,launch;
	Button top10,stats,settings;
	Button color;
	Button change[];
	CheckboxGroup selectGraphics;
	Checkbox graph,classic;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	final int[] delta = {-100,-10,-1,1,10,100};
	
	Buffer statBuf = null;
	Buffer setBuf = null;

	public gsOptions(){
		Graphics g;
	}

	public void init(){		
		sendTop20Query();
		sendStatsQuery();
		sendSettingsQuery();
		
		root.add(quit = new Button("Quit"));
		root.add(restart = new Button("Restart"));
		root.add(launch = new Button("Launch"));
		root.add(top10 = new Button("Top 10"));
		root.add(stats = new Button("Stats"));
		root.add(settings = new Button("Settings"));
		root.add(color = new Button("Colors"));
		selectGraphics = new CheckboxGroup();
		root.add(graph = new Checkbox("Graphical View",false,selectGraphics));
		root.add(classic = new Checkbox("Classical View",false,selectGraphics));
		
		change = new Button[6];
		for (int i=0;i<6;i++) root.add(change[i] = new Button(ChanStr[i]));
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

		g.setColor(new Color(0,128,0));
		g.fillRect(0,0,500,400);

		fp = gsFleet;

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals
		
//		drawEmpireStats(g,300,190);
		drawEmpireStats(g,175,190);
		showTop10List(g,120,20);
		showGameStats(g,20,190);
//		drawChannelStats(g,200,190);
		drawChannelStats(g,410,170);
		
	//--- draw buttons ---
		reshape(launch,10,5,80,20);
		if (GameState.gsEmpireID==1 || GameState.gsEmpireID==2) reshape(restart,10,150,50,20);
		reshape(top10,440,225,50,20);
		reshape(stats,440,250,50,20);
		reshape(settings,440,275,50,20);
		reshape(color,440,300,50,20);
		reshape(quit,440,325,50,20);
		reshape(graph,390,350,105,20);
		reshape(classic,390,370,105,20);
//		for (i=0;i<6;i++) reshape(change[i],10+(i%3)*25+(i/3)*5,78+(i/3)*15,25,15);
//		for (i=0;i<6;i++) reshape(change[i],200+(i%3)*25+(i/3)*5,210+(i/3)*15,25,15);
		for (i=0;i<6;i++) reshape(change[i],410+(i%3)*25+(i/3)*5,190+(i/3)*15,25,15);
		
		drawChatMessages(g);
	}

	void drawChannelStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	
		g.setColor(Color.white);
		ep = gsEmpire;
		
		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
	}

	public void drawEmpireStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	int val1,val2,val3;
	float wb1,wb2;

		if (setBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),h,v);		
		g.drawString("Race: "+ep.racename(),h,v+=15);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Total Darts: "+ep.darts(),h,v+=15);
		g.drawString("Score Darts: "+ep.scoreDarts(),h,v+=15);
		g.drawString("Score: "+ep.score(),h,v+=15);
		g.drawString("Facilities",280,190);
		g.drawString("Merchants: "+ep.Merchant(),280,205);
		val1 = setBuf.getInt(20);
		val2 = setBuf.getInt(24);
		val3 = val1 + (val2 * ep.Merchant());
		if (ep.race==1) val3 = val3 * 3 / 2;
		g.drawString("Cmd Build = "+val3,280,220);
		
		wb1 = (float)setBuf.getInt(28) / 10F;
		wb2 = wb1 * ep.Merchant();
		if (ep.race==0) wb2 = wb2 * 9 / 10;
		if (ep.race==1) wb2 = wb2 * 21 / 20;
		if (ep.race==2) wb2 = wb2 * 21 / 20;
		if (ep.race==5) wb2 = wb2 * 11 / 10;
		if (ep.race==6) wb2 = wb2 * 21 / 20;
		if (ep.race==7) wb2 = wb2 * 9 / 10;
		g.drawString("World Build = +"+wb2+"%",280,235);
		
		g.drawString("Beacons: "+ep.Beacon(),280,250);
		val1 = setBuf.getInt(32);
		val2 = val1 + ep.Beacon();
		val3 = setBuf.getInt(36);
		if (ep.race==0) {
			val2 = val2 * 9 / 10;
			val3 = val2 * 9 / 10;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==1) {
			val2 = val2 * 17 / 20;
			val3 = val3 * 17 / 20;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==2) {
			val2 = val2 * 23 / 20;
			val3 = val3 * 23 / 20;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==3) {
			val2 = val2 * 21 / 20;
			val3 = val3 * 21 / 20;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==4) {
			val2 = val2 * 11 / 10;
			val3 = val3 * 11 / 10;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==5) {
			val2 = val2 * 19 / 20;
			val3 = val3 * 19 / 20;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==6) {
			val2 = val2 * 11 / 10;
			val3 = val3 * 11 / 10;
			if (val2 > val3) val2 = val3;
		}
		else if (ep.race==7) {
			val2 = val2 * 19 / 20;
			val3 = val3 * 19 / 20;
			if (val2 > val3) val2 = val3;
		}
		g.drawString("Cmd Speed = "+val2,280,265);
		
		g.drawString("Stardocks: "+ep.Stardock(),280,280);
		val1 = setBuf.getInt(40);
		val2 = val1 + (ep.Stardock() / 2);
		if (ep.race==3) val2 = val2 * 5 / 4;
		g.drawString("Cmd Decay = 1/"+val2,280,295);
		val1 = setBuf.getInt(44);
		val2 = val1 + ep.Stardock();
		if (ep.race==3) val2 = val2 * 5 / 4;
		g.drawString("World Decay = 1/"+val2,280,310);
		g.drawString("Blasters: "+ep.Blaster()+" Level: "+ep.blasterLevel(),280,325);
		val1 = 50;
		val2 = val1 + (ep.blasterLevel() * 5);
		if (ep.race==5) val2 = val2 * 6 / 5;
		g.drawString("Attack = "+val2+"%",280,340);
	}

	void showTop10List(Graphics g,int h,int v){
	Empires emp;
	String name;
	int i;

		g.setColor(Color.white);
		g.drawString("Top 10 List",h+20,v);
		g.drawString("Score",h+130,v);
		g.drawString("Worlds",h+200,v);
		g.drawString("Darts",h+250,v);
		g.drawString("Race",h+290,v);
		v += 2;

		for (i=0;i<10;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			g.drawString(""+(i+1)+"> "+name,h,v+=14);
			emp = Empires.get(top20List[i]);
			g.drawString(""+emp.hiScore,h+130,v);
			g.drawString(""+emp.hiWorlds,h+200,v);
			g.drawString(""+emp.hiDarts,h+250,v);
			g.drawString(""+emp.racename(),h+290,v);
		}
		
		if (i==0) g.drawString("List Empty",h,v+=14);
	}
/*
	public void showGameStats(Graphics g,int h,int v){
	Empires emp;
	String name;
	Date date;
	int i;

		g.setColor(Color.white);
		g.drawString("Current Game Statistics",h,v);

		if (statBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.drawString("Total Planets = "+statBuf.getInt(4),h,v+=22);
		g.drawString("Total Empires = "+statBuf.getInt(8),h,v+=15);
		g.drawString("Total StarDarts = "+statBuf.getInt(12),h,v+=15);
		g.drawString("Players Online = "+statBuf.getInt(16),h,v+=15);

		g.drawString("Maximum Score = "+statBuf.getInt(36),h,v+=30);
		g.drawString("Victory When High Score = "+((int)statBuf.get(2))+"% = "+(((int)statBuf.getInt(36)) / 100) * ((int)statBuf.get(2)),h,v+=15);
		g.drawString("Current High Score = "+((int)statBuf.get(3))+"%",h,v+=15);
		date = new Date(statBuf.getInt(28),statBuf.getInt(32));
		g.drawString("Current Time is "+date.toString(),h,v+=15);

		if (statBuf.get(44)==0) return;		// no immortal victor as yet
		g.drawString("Last Immortal Victor <"+statBuf.getString(44)+" Empire>",h,v+=30);
		date = new Date(statBuf.getInt(20),statBuf.getInt(24));
		g.drawString("Victory Occurred "+date.toString(),h,v+=15);
		date = new Date(0,statBuf.getInt(40));
		g.drawString("Victory Took "+date.lengthStr(),h,v+=15);
	}
*/
	public void move(int x,int y){
	int mx,my;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}

	public boolean handleInput(Buffer buf){
	Empires ep;

		ep = gsEmpire;
		if (ep!=null && ep.channel!=channel) sendChannel();

		if (super.handleInput(buf)) return true;

		if (buf!=null) switch (buf.get(1)) {
			case STATS_RESULT:
				statBuf = buf;
				break;
				
			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}

		return false;
	}

	public void action(Event e){
	int id;
	int i;

		super.action(e);

		if (e.target==restart && Worlds.graphical==false) sendRestart();
		if (e.target==launch) setState(new gsMovement());
		if (e.target==quit) setState(new gsPassword());
		if (e.target==color) setState(new gsColor());
		if (e.target==top10) sendTop20Query();
		if (e.target==stats) sendStatsQuery();
		if (e.target==settings) sendSettingsQuery();
		if (e.target==graph) Worlds.graphical = true;
		if (e.target==classic) Worlds.graphical = false;
		for (i=0;i<6;i++) if (e.target==change[i]) {
			channel += delta[i];
			if (channel<0) channel = 0;
			if (channel>10000) channel = 10000;
			break;
		}
	}
}