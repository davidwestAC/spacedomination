//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"

//***************************************************************************
//***************************************************************************

bool commandManager(void);
void cmdPrompt(void);

//***************************************************************************

char commandLine[80];
int cmdIX=0;
bool managerShowChat = false;

//***************************************************************************
//***************************************************************************

bool prepareManager(){
	printf("Space Domination Text Based Manager v2.0\n");
	cmdPrompt();

	cmdIX = 0;
	return true;
}

void cleanupManager(){}

//***************************************************************************

bool operateManager(){
char c;

	if (kbhit()==0) return true;

	c = getche();

	if (c==8 && cmdIX>0) {
		cmdIX--;
		commandLine[cmdIX] = 0;
	}

	if (c==13) {
		commandLine[cmdIX] = 0;
		if (commandManager()) return false;
	}

	if (c>=32) commandLine[cmdIX++] = c;

	return true;
}

//***************************************************************************

void printHelp(){
	printf("Space Domination Server Functions:\n");
	printf("[Help] - shows this list\n");
	printf("[Quit] - exit the server\n");
	printf("[Say message] - sends 'message' to all sessions\n");
	printf("[Chat] - switch to display player chat\n");

}

bool commandManager(){
char buf[BUFFERSIZE];
int num;

	printf("\n");

	if (matchCI(commandLine,"Help")) printHelp();

	if (equalsCI(commandLine,"Quit")) {
		sendGlobalMessage("<Server> ===Server Shutting Down===");
		return true;
	}

	if (matchCI(commandLine,"Reset")) {
		sendGlobalMessage("********************************************");
		sendGlobalMessage("********************************************");
		sendGlobalMessage("============Universe Rebuilding=============");
		if (sscanf(commandLine,"%s %d",buf,&num)<2) num = minWorlds;
		resetGalaxy(num);
	}

	if (matchCI(commandLine,"Say ")) {
		sprintf(buf,"<Sysop> %s",commandLine+4);
		sendGlobalMessage(buf);
	}

	if (matchCI(commandLine,"Chat")) {
		managerShowChat = !managerShowChat;
		if (managerShowChat)	printf("Chat Display *ON*\n");
		else					printf("Chat Display *OFF*\n");
	}

	cmdIX = 0;
	commandLine[cmdIX] = 0;

	cmdPrompt();
	return false;
}

//***************************************************************************

extern	int sessionCount;

void cmdPrompt(){
	printf("\n[%d]>",sessionCount);
	if (cmdIX>0) printf(commandLine);
}


void cmdMessage(char *msg){
	printf("\n");
	printf(msg);
	cmdPrompt();
}

//***************************************************************************
