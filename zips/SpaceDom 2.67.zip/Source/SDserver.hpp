//******************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//******************************************************************************
#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>
#include <time.h>
#include <conio.h>

#include "string.hpp"
#include "fileIO.hpp"
#include "FFItypes.hpp"
#include "dates.hpp"

#include "MsgQueue.hpp"
#include "Sessions.hpp"
#include "Worlds.hpp"

//******************************************************************************
//******************************************************************************

//const int MAXSESSIONS = 200;
//const int MINWORLDS = 100;
const int BUFFERSIZE = 256;

//******************************************************************************
//******************************************************************************

//--- buffer.cpp ---
extern	char *LoadInputBuffer(void);
extern	void FreeInputBuffer(void);

//--- dates.cpp ---
extern	void setTodaysDate(void);
extern  int dateIndex(void);
extern	void tdoayToDays(void);
extern	char todayStr[];

//--- gameque.cpp ---
extern	bool prepareGameQueue(void);
extern	void cleanupGameQueue(void);
extern	void operateGameQueue(void);
extern	MsgQueue *gameQueue;

//--- initfile.cpp ---
extern	bool readInitFile(void);
extern	char dataPath[128],htmlPath[128];
extern	int portNum,maxPlayers,fleetDecayRate,worldDecayRate,victoryBase,movePixels,commandBuild,commandBonus;
extern  int merchantBonus,minWorlds,highWorlds,dropHours,firstEarthDeclarePercent,firstPhenomenaDeclarePercent;
extern  int firstNonDeclarablePhenomenaPercent,laterEarthDeclarePercent,laterPhenomenaDeclarePercent,maxSpeed;
extern  int dockFleetBonus,dockWorldBonus,beaconBonus;

//--- sendSMTP.cpp ---
extern	bool prepareSMTP(void);
extern	void cleanupSMTP(void);
extern	void operateSMTP(void);
extern	int sendSMTP(char *addr,char *msg);
extern	bool mailDone(int mailID);

//--- manager.cpp ---
extern	bool prepareManager(void);
extern	void cleanupManager(void);
extern	bool operateManager(void);
extern	void cmdPrompt(void);

//--- Sessions.cpp ---
extern	bool prepareSockets(void);
extern	void cleanupSockets(void);
extern	void operateSockets(void);

extern	Session *findEmpireSession(int empireID);
extern	void sessionSetInfo(Session *sp,int empireID,int fleetID);
extern	bool sessionGetInfo(Session *sp,int *empireID,int *fleetID);
inline	bool sessionInPlay(Session *sp){return (sp!=NULL && sp->info()!=NULL);}

//--- gameQueue.cpp ---
extern	void sendWorldScan(Session *ssn,int worldID,worldRec *worldPtr);
extern	void sendFleetScan(Session *ssn,int fleetID,fleetRec *fleetPtr);
extern	void sendEmpireScan(Session *ssn,int empireID,empireRec *empirePtr);
extern	void sendSquadScan(Session *ssn,int fleetID,int squadID,squadRec *squadPtr);
extern	void sendCombatScan(Session *ssn,int fleetID,fleetRec *fleetPtr);
extern	void sendFleetEngaged(Session *ssn,int angle,int engageID);
extern	void sendBuildScan(Session *ssn,int id,worldRec *wp);
extern	void sendStatus(Session *ssn,int status);
extern	void sendGlobalMessage(char *msg);

extern	void sendEmpireMessage(int empireID,char *msg);
extern	void sendMessage(Session *ssn,char *msg);

//--- worlds.cpp ---
extern	bool resetGalaxy(int wcount);
extern	bool prepareGalaxy(int wcount);
extern	void cleanupGalaxy(void);
extern	bool CreateEmpire(char *name,char *pass);
extern	void CreateFleet(fleetRec *fp,int empireID);
extern	void randomizeStarDart(int num);
extern	void FleetLocation(int *xloc,int *yloc);
extern	int maxEmpireScore,victoryDate,victoryTime,victoryPercent;

//--- galaxy.cpp ---
extern  void operateFacilities(void);
extern  void operateHappiness(void);
extern  void operateCapture(void);
extern	void operateWorlds(void);
extern	void operateFleets(void);
extern	void operateSessions(void);

extern	bool setSquadAction(fleetRec *fp,int squadID,int action);
extern	bool setSquadAction(fleetRec *fp,int squadID,int action,int enemy);
extern	void setFleetDestination(fleetRec *fp,int id);

extern	int addFleetShips(fleetRec *fp,int type,int num);
extern	int buildFleetShips(fleetRec *fp,int type,int num);
extern	int addSquadShips(fleetRec *fp,squadRec *sp,int num);

extern	int pullFleetShips(fleetRec *fp,int type,int num);
extern	int pullSquadShips(fleetRec *fp,squadRec *sp,int num);

//--- victory.cpp ---
extern	void RecordVictory(void);

//******************************************************************************
