//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant

//**********************************************************************************

void captureWorld(int worldID,worldRec *wp,int newEmpire);
void declareWorld(worldRec *wp,empireRec *emp,int newEmpire);
bool calculateScore(void);

void sessionScanFleets(Session *ssn);
void sessionScanWorlds(Session *ssn);

void fleetAdvance(int fleetID,fleetRec *fp);
void fleetHitsTarget(int fleetID,fleetRec *fp);
void fleetHitsZone(fleetRec *fp,int type);

void fleetBattle(int fleetID,fleetRec *fp);
void fleetAutoAction(int fleetID,fleetRec *fp);
void fleetMoveSquad(fleetRec *fp,int squadID,int action);
void fleetFireSquad(fleetRec *fp,int squadID,int action,int enemy);

inline int InverseEngage(int i){return sideCOUNT-1-i;}

//**********************************************************************************

int lastCaptureUpdate = 0;
int lastWorldUpdate = 0;

int dartCheck(worldRec *wp) {
fleetRec *fp;
int count;

	fp = (fleetRec*)fleetList->getRecord(wp->worldID);
	count = 0;

	for (int currentSquad=0; currentSquad < stCOUNT; currentSquad++) {
		if (fp->squad[currentSquad].type == stStarDart) {
			count = fp->squad[currentSquad].count;
		}
	}
	return count;
}

void operateCapture(){
int update,count,ix;
fleetRec *fp,*fleets;
worldRec *wp,*worlds;
empireRec *emp;

	update = time(NULL);
	if (lastCaptureUpdate + 1 > update) return;
	lastCaptureUpdate = update;

	count = worldList->getCount();
	worlds = (worldRec*)worldList->getList();
	fleets = (fleetRec*)fleetList->getList();

	for (ix=0;ix<count;ix++) {
		wp = &worlds[ix];
		if (!isPlanet(wp->type)) continue;

		fp = &fleets[ix];

		if (wp->empireID!=fp->empireID) {
			printf("Planet %s has been captured...\n",wp->name);
			captureWorld(ix,wp,fp->empireID);
		}
	}
}

void operateWorlds(){
int update,count,ix,i,num,val,max,wcount;
fleetRec *fp,*fleets;
worldRec *wp,*worlds;
empireRec *emp,*empires;
squadRec *sp;
buildCmd bd;
bool autoReset;
int reducedRate;

	update = time(NULL);
	if (lastWorldUpdate + 6 > update) return;
	lastWorldUpdate = update;

	count = worldList->getCount();
	worlds = (worldRec*)worldList->getList();
	fleets = (fleetRec*)fleetList->getList();

	printf("\nOperating build...\n");
	for (ix=0;ix<count;ix++) {
		wp = &worlds[ix];
		if (!isPlanet(wp->type)) continue;

		fp = &fleets[ix];

		if (fp->status==fsBattle) continue;		// no production

	//--- compress build commands ---
		for (val=num=0;num<MAXBUILD;num++) {
			if (wp->cmd[num].type>=btCOUNT || wp->cmd[num].goal==0) continue;
			if (val<num) {
				wp->cmd[val] = wp->cmd[num];
				wp->cmd[num].type = btCOUNT;
			}
			val++;
		}

	//--- produce build points ---
		if (val==0)	wp->storage = 0;
		else {
			num = wp->pop + wp->ind;

			emp = (empireRec*)empireList->getRecord(fp->empireID);
			if (emp!=NULL && fp->empireID!=0) {
				num += emp->Merchant * merchantBonus;
			}
			else if (emp!=NULL && fp->empireID==0) {
				num = wp->pop + wp->ind;
			}

			if (emp!=NULL && emp->race==rtMakluvian && fp->empireID!=0) {
				num = num * 6 / 5;
			}

			if (wp->type>=wtNewEarth && wp->type<=wtQuarethia && fp->empireID==0) {
				num = num * 4;
			}
			if (wp->type>=wtNewEarth && wp->type<=wtQuarethia && fp->empireID!=0) {
				num = num * 2;
			}

			if (wp->type==wtHome && fp->empireID==0) {
				num = num * 5;
			}
			if (wp->type==wtHome && fp->empireID!=0) {
				num = num * 5 / 2;
			}

			if (wp->type==wtCore && fp->empireID==0) {
				num = num * 3;
			}
			if (wp->type==wtCore && fp->empireID!=0) {
				num = num * 3 / 2;
			}

			if (wp->type==wtPoor) num /= 2;
			if (wp->type==wtRich) num = num * 3 / 2;

			if (wp->type==wtAquatic && wp->cmd[0].type==btPinnace) {
				num = num * 3 / 2;
			}
			if (wp->type==wtMountain && wp->cmd[0].type==btRanger) {
				num = num * 3 / 2;
			}
			if (wp->type==wtDesert && wp->cmd[0].type==btFrigate) {
				num = num * 3 / 2;
			}
			if (wp->type==wtTundra && wp->cmd[0].type==btCorsair) {
				num = num * 3 / 2;
			}
			if (wp->type==wtJungle && wp->cmd[0].type==btStation && wp->empireID!=0) {
				num = num * 3 / 2;
			}
			if (wp->type==wtMetallic && wp->cmd[0].type==btIndustry) {
				num = num * 5 / 2;
			}

		//--- fleet command bonus ---
			if (wp->empireID!=0) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				if (emp!=NULL && emp->race==rtMakluvian) {
					fp = &fleets[emp->fleetID];
					if (fp->xloc==wp->xloc && fp->yloc==wp->yloc) num += (commandBuild + emp->Merchant * commandBonus) * 11 / 10;
					fp = &fleets[ix];
				}
				else if (emp!=NULL && emp->race!=rtMakluvian) {
					fp = &fleets[emp->fleetID];
					if (fp->xloc==wp->xloc && fp->yloc==wp->yloc) num += (commandBuild + emp->Merchant * commandBonus);
					fp = &fleets[ix];
				}
			}

			wp->storage += num;
		}
		
	//--- operate build commands ---
		if (wp->storage>0) while (true) {

			bd = wp->cmd[0];
			if (bd.type==btCOUNT) break;

			num = wp->storage / cost[bd.type];
			if (num==0) break;

			if (bd.type<btMerchant || bd.type>btStardock) {
				if (num>bd.goal-bd.built) num = bd.goal - bd.built;
				bd.built += num;
			}
			if (bd.type==btIndustry) {	
				wp->ind += num;
				if (wp->type==wtHome || wp->type==wtCore || wp->type==wtLarge || wp->type>=wtNewEarth && wp->type<=wtQuarethia) {
					if (wp->ind >= wp->pop * 6) wp->cmd[0].type = btCOUNT;
				}
				if (wp->type==wtNormal || wp->type==wtPoor || wp->type==wtRich || wp->type>=wtAquatic && wp->type<=wtMetallic) {
					if (wp->ind >= wp->pop * 4) wp->cmd[0].type = btCOUNT;
				}
				if (wp->type==wtSmall) {
					if (wp->ind >= wp->pop * 2) wp->cmd[0].type = btCOUNT;
				}
			}
			else if (bd.type==btMerchant) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				fp = (fleetRec*)fleetList->getRecord(wp->empireID);
				if (wp->facility==ftCOUNT) {
					wp->facility = ftMerchant;
					emp->Merchant = emp->Merchant + 1;
				}
				else {
					if (wp->facility==ftBeacon) {
						emp->Beacon = emp->Beacon - 1;
						fp->Beacon = fp->Beacon - 1;
						wp->facility = ftMerchant;
						emp->Merchant = emp->Merchant + 1;
					}
					if (wp->facility==ftStardock) {
						emp->Stardock = emp->Stardock - 1;
						fp->Stardock = fp->Stardock - 1;
						wp->facility = ftMerchant;
						emp->Merchant = emp->Merchant + 1;
					}
					if (wp->facility==ftStellurae) {
						emp->Stellurae = emp->Stellurae - 1;
						wp->facility = ftMerchant;
						emp->Merchant = emp->Merchant +1;
					}
				}
				wp->cmd[0].type = btCOUNT;
			}
			else if (bd.type==btBeacon) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				fp = (fleetRec*)fleetList->getRecord(wp->empireID);
				if (wp->facility==ftCOUNT) {
					wp->facility = ftBeacon;
					emp->Beacon = emp->Beacon + 1;
					fp->Beacon = fp->Beacon + 1;
				}
				else {
					if (wp->facility==ftMerchant) {
						emp->Merchant = emp->Merchant - 1;
						wp->facility = ftBeacon;
						emp->Beacon = emp->Beacon + 1;
						fp->Beacon = fp->Beacon + 1;
					}
					if (wp->facility==ftStardock) {
						emp->Stardock = emp->Stardock - 1;
						fp->Stardock = fp->Stardock - 1;
						wp->facility = ftBeacon;
						emp->Beacon = emp->Beacon + 1;
						fp->Beacon = fp->Beacon + 1;
					}
					if (wp->facility==ftStellurae) {
						emp->Stellurae = emp->Stellurae - 1;
						wp->facility = ftBeacon;
						emp->Beacon = emp->Beacon + 1;
						fp->Beacon = fp->Beacon + 1;
					}
				}
				wp->cmd[0].type = btCOUNT;
			}
			else if (bd.type==btStardock) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				fp = (fleetRec*)fleetList->getRecord(wp->empireID);
				if (wp->facility==ftCOUNT) {
					wp->facility = ftStardock;
					emp->Stardock = emp->Stardock + 1;
					fp->Stardock = fp->Stardock + 1;
				}
				else {
					if (wp->facility==ftMerchant) {
						emp->Merchant = emp->Merchant - 1;
						wp->facility = ftStardock;
						emp->Stardock = emp->Stardock + 1;
						fp->Stardock = fp->Stardock + 1;
					}
					if (wp->facility==ftBeacon) {
						emp->Beacon = emp->Beacon - 1;
						fp->Beacon = fp->Beacon - 1;
						wp->facility = ftStardock;
						emp->Stardock = emp->Stardock + 1;
						fp->Stardock = fp->Stardock + 1;
					}
					if (wp->facility==ftStellurae) {
						emp->Stellurae = emp->Stellurae - 1;
						wp->facility = ftStardock;
						emp->Stardock = emp->Stardock + 1;
						fp->Stardock = fp->Stardock + 1;
					}
				}
				wp->cmd[0].type = btCOUNT;
			}
			else if (bd.type==btStellurae) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				if (wp->facility==ftCOUNT) {
					wp->facility = ftStellurae;
					emp->Stellurae = emp->Stellurae + 1;
				}
				else {
					if (wp->facility==ftMerchant) {
						emp->Merchant = emp->Merchant - 1;
						wp->facility = ftStellurae;
						emp->Stellurae = emp->Stellurae + 1;
					}
					if (wp->facility==ftBeacon) {
						emp->Beacon = emp->Beacon - 1;
						fp->Beacon = fp->Beacon - 1;
						wp->facility = ftStellurae;
						emp->Stellurae = emp->Stellurae + 1;
					}
					if (wp->facility==ftStardock) {
						emp->Stardock = emp->Stardock - 1;
						fp->Stardock = fp->Stardock - 1;
						wp->facility = ftStellurae;
						emp->Stellurae = emp->Stellurae + 1;
					}
				}
				wp->cmd[0].type = btCOUNT;
			}
			else if (bd.type>=btCOUNT) {
				if (wp->storage>cost[bd.type]);
			}
			else {
				buildFleetShips(fp,bd.type,num);
			}

			wp->storage -= num * cost[bd.type];

			if (bd.built<bd.goal) {
				wp->cmd[0].built = bd.built;
				break;
			}
			else {
				for (i=0;i<MAXBUILD-1;i++) {
					wp->cmd[i] = wp->cmd[i+1];
					if (wp->cmd[i].goal==0 || wp->cmd[i].type==btCOUNT) break;
				}

				if (!bd.repeat)	{
					wp->cmd[i].type = btCOUNT;
					wp->cmd[i].goal = 0;
				}
				else {
					bd.built = 0;
					wp->cmd[i] = bd;
				}
			}
		}

	//--- toss excess industry ---
		if (wp->type==wtHome) val = 6;
		else if (wp->type==wtCore) val = 6;
		else if (wp->type==wtLarge) val = 6;
		else if (wp->type>=wtNewEarth && wp->type<=wtQuarethia) val = 6;
		else if (wp->type==wtSmall) val = 2;
		else val = 4;
		val *= wp->pop;
		if (wp->ind>val) wp->ind = val;

	//--- decay stores ---
		wp->storage -= (wp->storage + 9) / 10;
	}

//--- decay fleets, apply ECM bonuses ---
	count = fleetList->getCount();
	wcount = worldList->getCount();
	for (ix=0;ix<=wcount;ix++) {
		fp = &fleets[ix];
		if (fp->status==fsBattle) continue;

		for (i=0;i<posCOUNT;i++) {

			sp = &fp->squad[i];
			if (sp->damage>0) sp->damage--;
			if (sp->type==stCOUNT || sp->type==stStarDart) continue;

			val = sp->count;

			emp = (empireRec*)empireList->getRecord(fp->empireID);

			if (worldDecayRate>0 && fp->empireID>0 && emp->race==rtZorestian) {
				if(fp->status==fsIndustry || fp->status==fsMoving) reducedRate = ((((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockWorldBonus) + worldDecayRate) * 23 / 20;
				else reducedRate = ((((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockWorldBonus) + worldDecayRate) * 23 / 20;
				if (reducedRate>0) val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				pullSquadShips(fp,sp,val);
			}

			else if (worldDecayRate>0 && fp->empireID>0 && emp->race!=rtZorestian) {
				if(fp->status==fsIndustry || fp->status==fsMoving) reducedRate = (((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockWorldBonus) + worldDecayRate;
				else reducedRate = (((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockWorldBonus) + worldDecayRate;
				if (reducedRate>0) val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				pullSquadShips(fp,sp,val);
			}

			else if (worldDecayRate>0) {
				val = val/worldDecayRate + (Rand(worldDecayRate)<(val%worldDecayRate)?1:0);
				pullSquadShips(fp,sp,val);			
			}
		}
	}

	for (ix>wcount;ix<=count;ix++) {
		fp = &fleets[ix];
		if (fp->status==fsBattle) continue;

		for (i=0;i<posCOUNT;i++) {

			sp = &fp->squad[i];
			if (sp->damage>0) sp->damage--;
			if (sp->type==stCOUNT || sp->type==stStarDart) continue;

			val = sp->count;

			emp = (empireRec*)empireList->getRecord(fp->empireID);

			if (fleetDecayRate>0 && fp->empireID>0 && emp->race==rtZorestian) {
				if(fp->status==fsIndustry || fp->status==fsMoving) reducedRate = ((((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockFleetBonus) + fleetDecayRate) * 23 / 20;
				else reducedRate = ((((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockFleetBonus) + fleetDecayRate) * 23 / 20;
				if (reducedRate>0) val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				pullSquadShips(fp,sp,val);
			}

			else if (fleetDecayRate>0 && fp->empireID>0 && emp->race!=rtZorestian) {
				if(fp->status==fsIndustry || fp->status==fsMoving) reducedRate = (((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockFleetBonus) + fleetDecayRate;
				else reducedRate = (((empireRec*)empireList->getRecord(fp->empireID))->Stardock * dockFleetBonus) + fleetDecayRate;
				if (reducedRate>0) val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				pullSquadShips(fp,sp,val);
			}

			else if (fleetDecayRate>0) {
				val = val/fleetDecayRate + (Rand(fleetDecayRate)<(val%fleetDecayRate)?1:0);
				pullSquadShips(fp,sp,val);			
			}
		}
	}

//--- cleanup ---
	autoReset = calculateScore();
	empireList->save();
	worldList->save();

	count = Rand(highWorlds - minWorlds) + minWorlds;
	if (autoReset)
		resetGalaxy(count);
		return;
	}

void captureWorld(int worldID,worldRec *wp,int newEmpire){
char buf[BUFFERSIZE];
empireRec *emp;
fleetRec *fp;
Session *ssn;
int oldEmpire; 
int num,count,i,ix;
int firstModifiedEarthDeclarePercent,laterModifiedEarthDeclarePercent;

	oldEmpire = wp->empireID;
	wp->empireID = newEmpire;

	printf("Reducing facilities of player losing world...");
	emp = (empireRec*)empireList->getRecord(oldEmpire);
	fp = (fleetRec*)fleetList->getRecord(oldEmpire);

	if (emp!=NULL) {
		emp->worlds--;
		if (wp->facility == ftMerchant) {
			emp->Merchant = emp->Merchant - 1;
		}
		else if (wp->facility == ftBeacon) {
			emp->Beacon = emp->Beacon - 1;
			fp->Beacon = fp->Beacon - 1;
		}
		else if (wp->facility == ftStardock) {
			emp->Stardock = emp->Stardock - 1;
			fp->Stardock = fp->Stardock - 1;
		}
		else if (wp->facility == ftStellurae) {
			emp->Stellurae = emp->Stellurae - 1;
		}
	}

	wp->ind /= 2;

	printf("Increasing facilities of player gaining world...\n");
	emp = (empireRec*)empireList->getRecord(newEmpire);
	fp = (fleetRec*)fleetList->getRecord(newEmpire);

	if (emp!=NULL) {
		emp->worlds++;
		if (wp->facility == ftMerchant) {
			emp->Merchant = emp->Merchant + 1;
		}
		else if (wp->facility == ftBeacon) {
			emp->Beacon = emp->Beacon + 1;
			fp->Beacon = fp->Beacon + 1;
		}
		else if (wp->facility == ftStardock) {
			emp->Stardock = emp->Stardock + 1;
			fp->Stardock = fp->Stardock + 1;
		}
		else if (wp->facility == ftStellurae) {
			emp->Stellurae = emp->Stellurae + 1;
		}
	}

	printf("Sending capture message...\n");
	ssn = findEmpireSession(oldEmpire);
	if (ssn!=NULL) {
		sprintf(buf,"=== %s in sector %d has been captured by %s!===",wp->name,wp->sector,emp->name);
		sendMessage(ssn,buf);
		sendWorldScan(ssn,worldID,wp);
	}

	if (worldID>0 && worldID <= CORECOUNT) {
		if (emp!=NULL) {
			sprintf(buf,"=== %s captures a Core World! ===",emp->name);
			sendGlobalMessage(buf);
		}
	}

	if (wp->type>=wtNewEarth && wp->type<=wtQuarethia) {
		if (emp!=NULL) {
			sprintf(buf,"=== %s has captured %s! ===",emp->name,wp->name);
			sendGlobalMessage(buf);
		}
	}

	ssn = findEmpireSession(newEmpire);
	if (ssn!=NULL) sendWorldScan(ssn,worldID,wp);

	count = worldList->getCount();
	worldRec *worlds = (worldRec*)worldList->getList();
	fleetRec *fleets = (fleetRec*)fleetList->getList();
	fleetRec *ep;

	if (worldID==0 && oldEmpire==0) {
		printf("Old Earth has been captured...");
		emp = (empireRec*)empireList->getRecord(newEmpire);
		sprintf(buf,"=== %s has captured Old Earth! ===",emp->name);
		sendGlobalMessage(buf);
		if (emp!=NULL) {

			int decCount = 0;
			int dartCount = 0;

			printf("Declaring worlds...");
			for (int ix=CORECOUNT+1;ix<worldList->getCount();ix++) {
				wp = &worlds[ix];
				if (emp->race==rtCestanian) {
					firstModifiedEarthDeclarePercent = firstEarthDeclarePercent * 5 / 4;
				}
				else {
					firstModifiedEarthDeclarePercent = firstEarthDeclarePercent;
				}
					if ((Rand(100)+1<=firstModifiedEarthDeclarePercent) && (wp->empireID==0) && isNormalPlanet(wp->type)) {

						decCount++;
						dartCount = 0;

						ep = &fleets[ix];
						ep->empireID=newEmpire;												
						wp->empireID=newEmpire;

						emp = (empireRec*)empireList->getRecord(0);
						fp = (fleetRec*)fleetList->getRecord(0);

						if (emp!=NULL) {
							emp->worlds--;
							if (wp->facility == ftMerchant) {
								emp->Merchant = emp->Merchant - 1;
							}
							else if (wp->facility == ftBeacon) {
								emp->Beacon = emp->Beacon - 1;
								fp->Beacon = fp->Beacon - 1;
							}
							else if (wp->facility == ftStardock) {
								emp->Stardock = emp->Stardock - 1;
								fp->Stardock = fp->Stardock - 1;
							}
							else if (wp->facility == ftStellurae) {
								emp->Stellurae = emp->Stellurae - 1;
							}
						}

						emp = (empireRec*)empireList->getRecord(newEmpire);
						fp = (fleetRec*)fleetList->getRecord(newEmpire);

						if (emp!=NULL) {
							emp->worlds++;
							if (wp->facility == ftMerchant) {
								emp->Merchant = emp->Merchant + 1;
							}
							else if (wp->facility == ftBeacon) {
								emp->Beacon = emp->Beacon + 1;
								fp->Beacon = fp->Beacon + 1;
							}
							else if (wp->facility == ftStardock) {
								emp->Stardock = emp->Stardock + 1;
								fp->Stardock = fp->Stardock + 1;
							}
							else if (wp->facility == ftStellurae) {
								emp->Stellurae = emp->Stellurae + 1;
							}
						}

						dartCount = dartCheck(wp);

						emp = (empireRec*)empireList->getRecord(0);
						if (emp!=NULL) emp->darts -= dartCount;

						emp = (empireRec*)empireList->getRecord(newEmpire);
						if (emp!=NULL) emp->darts += dartCount;											
				}
			}
			sprintf(buf,"=== %d worlds declare for %s! ===", decCount, emp->name);
			sendGlobalMessage(buf);

			decCount=0;

			printf("Declaring phenomena...\n");
			for (ix=CORECOUNT+1;ix<worldList->getCount();ix++) {
				wp = &worlds[ix];
					if ((Rand(100)+1<=firstPhenomenaDeclarePercent) && (wp->empireID==0) && isPhenomena(wp->type) && (wp->isDeclarable==true)) {

						decCount++;
						dartCount = 0;

						ep = &fleets[ix];

						ep->empireID=newEmpire;
						wp->empireID=newEmpire;
						emp = (empireRec*)empireList->getRecord(0);
						if (emp!=NULL) emp->phenomena--;
						emp = (empireRec*)empireList->getRecord(newEmpire);
						if (emp!=NULL) emp->phenomena++;

						if ((Rand(100)+1<=firstNonDeclarablePhenomenaPercent)) {
							wp->isDeclarable = false;
						}
					}
				}
			sprintf(buf,"=== %d phenomena declare for %s! ===", decCount, emp->name);
			sendGlobalMessage(buf);
		}
	}

	if (worldID==0 && oldEmpire!=0) {
		printf("Old Earth has been captured...");
		emp = (empireRec*)empireList->getRecord(newEmpire);
		sprintf(buf,"=== %s has captured Old Earth! ===",emp->name);
		sendGlobalMessage(buf);
		if (emp!=NULL) {

			int decCount = 0;
			int dartCount = 0;

			printf("Declaring worlds...");
			for (int ix=CORECOUNT+1;ix<worldList->getCount();ix++) {
				wp = &worlds[ix];
				if (emp->race==rtCestanian) {
					laterModifiedEarthDeclarePercent = laterEarthDeclarePercent * 5 / 4;
				}
				else {
					laterModifiedEarthDeclarePercent = laterEarthDeclarePercent;
				}
					if ((Rand(100)+1<=laterModifiedEarthDeclarePercent) && (wp->empireID==oldEmpire) && isNormalPlanet(wp->type)) {

						decCount++;
						dartCount = 0;

						ep = &fleets[ix];
						ep->empireID=newEmpire;												
						wp->empireID=newEmpire;

						emp = (empireRec*)empireList->getRecord(oldEmpire);
						fp = (fleetRec*)fleetList->getRecord(oldEmpire);

						if (emp!=NULL) {
							emp->worlds--;
							if (wp->facility == ftMerchant) {
								emp->Merchant = emp->Merchant - 1;
							}
							else if (wp->facility == ftBeacon) {
								emp->Beacon = emp->Beacon - 1;
								fp->Beacon = fp->Beacon - 1;
							}
							else if (wp->facility == ftStardock) {
								emp->Stardock = emp->Stardock - 1;
								fp->Stardock = fp->Stardock - 1;
							}
							else if (wp->facility == ftStellurae) {
								emp->Stellurae = emp->Stellurae - 1;
							}
						}

						emp = (empireRec*)empireList->getRecord(newEmpire);
						fp = (fleetRec*)fleetList->getRecord(newEmpire);

						if (emp!=NULL) {
							emp->worlds++;
							if (wp->facility == ftMerchant) {
								emp->Merchant = emp->Merchant + 1;
							}
							else if (wp->facility == ftBeacon) {
								emp->Beacon = emp->Beacon + 1;
								fp->Beacon = fp->Beacon + 1;
							}
							else if (wp->facility == ftStardock) {
								emp->Stardock = emp->Stardock + 1;
								fp->Stardock = fp->Stardock + 1;
							}
							else if (wp->facility == ftStellurae) {
								emp->Stellurae = emp->Stellurae + 1;
							}
						}

						dartCount = dartCheck(wp);

						emp = (empireRec*)empireList->getRecord(oldEmpire);
						if (emp!=NULL) emp->darts -= dartCount;

						emp = (empireRec*)empireList->getRecord(newEmpire);
						if (emp!=NULL) emp->darts += dartCount;											
				}
			}
			sprintf(buf,"=== %d worlds declare for %s! ===", decCount, emp->name);
			sendGlobalMessage(buf);

			decCount=0;

			printf("Declaring phenomena...\n");
			for (ix=CORECOUNT+1;ix<worldList->getCount();ix++) {
				wp = &worlds[ix];
					if ((Rand(100)+1<=laterPhenomenaDeclarePercent) && (wp->empireID==oldEmpire) && isPhenomena(wp->type) && (wp->isDeclarable==true)) {

						decCount++;
						dartCount = 0;

						ep = &fleets[ix];

						ep->empireID=newEmpire;
						wp->empireID=newEmpire;
						emp = (empireRec*)empireList->getRecord(oldEmpire);
						if (emp!=NULL) emp->phenomena--;
						emp = (empireRec*)empireList->getRecord(newEmpire);
						if (emp!=NULL) emp->phenomena++;
					}
				}
			sprintf(buf,"=== %d phenomena declare for %s! ===", decCount, emp->name);
			sendGlobalMessage(buf);
		}
	}
}

bool calculateScore(){
int top20Score[20];
int wcount,count,ix,i,num,resetScore,gameTime;
empireRec *emp;
fleetRec *fp;
worldRec *wp;
bool autoReset;

	memset(top20List,0xff,sizeof(top20List));
	memset(top20Score,0,sizeof(top20Score));

	wcount = worldList->getCount();
	count = empireList->getCount();

	gameTime = (dateIndex() - victoryDate) * 24 * 3600 + 
				(secondsSinceMidnight() - victoryTime);
	victoryPercent = victoryBase - gameTime / (dropHours * 3600);
	if (victoryPercent<1) victoryPercent = 1;

	autoReset = false;
	resetScore = (int)(maxEmpireScore * (victoryPercent / 100.0));
	printf("Calculating score...\n");
	
//--- decay score, collect non-score hi values ---
	for (ix=1;ix<count;ix++) {
		emp = (empireRec*)empireList->getRecord(ix);
		fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
		if (emp==NULL || fp==NULL) continue;
		emp->score -= emp->score / 1000;
		if (fp->status==fsDead && emp->score>0) emp->score--;
		if (emp->darts > emp->hiDarts) emp->hiDarts = emp->darts;
		if (emp->worlds > emp->hiWorlds) emp->hiWorlds = emp->worlds;
	}

//--- control earth ---
	wp = (worldRec*)worldList->getRecord(0);
	if (wp!=NULL) {
		emp = (empireRec*)empireList->getRecord(wp->empireID);
		if (emp!=NULL) {
			emp->score += EarthValue(wcount) - 1; 
		}
	}	

//--- control home worlds ---
	for (ix=13;ix<=wcount;ix++) {
		wp = (worldRec*)worldList->getRecord(ix);
		if (wp!=NULL && (wp->type>=wtNewEarth && wp->type<=wtQuarethia)) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->score += HomeValue(wcount) - 1;
			}
		}
	}

//--- control core worlds ---
	for (ix=1;ix<=CORECOUNT;ix++) {
		wp = (worldRec*)worldList->getRecord(ix);
		if (wp!=NULL) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->score += CoreValue(wcount) - 1;	
			}
		}
	}

//--- add to score ---
	for (ix=1;ix<count;ix++) {
		emp = (empireRec*)empireList->getRecord(ix);
		if (emp==NULL) continue;

		emp->score += emp->worlds;
		emp->score += emp->darts * emp->darts;
		if (emp->score > emp->hiScore) emp->hiScore = emp->score;
		if (emp->hiScore<1) continue;

	//--- check for auto-reset ---
		if (emp->hiScore >= resetScore) autoReset = true; 

	//--- sort list ---
		for (num=19;num>=0;num--) if (top20Score[num] > emp->hiScore) break;

		if (num<19) {
			for (i=19;i>=num+2;i--) {
				top20List[i] = top20List[i-1];
				top20Score[i] = top20Score[i-1];
			}
			top20List[num+1] = ix;
			top20Score[num+1] = emp->hiScore;
		}
	}

	return autoReset;
}

//**********************************************************************************

int buildPos[stCOUNT]={
	posDefendTop,posDefendBot,posInvadeTop,
	posDefendMid,posInvadeMid,posInvadeBot
};

int buildFleetShips(fleetRec *fp,int type,int num){
int pos;

	if (num<1) return 0;

	for (pos=0;pos<posCOUNT;pos++) if (fp->squad[pos].type==type) break;
	if (pos==posCOUNT) if (fp->squad[buildPos[type]].type==stCOUNT) pos = buildPos[type];
	if (pos==posCOUNT) for (pos=0;pos<posCOUNT;pos++) if (fp->squad[pos].type==stCOUNT) break;
	if (pos==posCOUNT) return 0;

	fp->squad[pos].type = type;
	return addSquadShips(fp,&fp->squad[pos],num);
}


int addFleetShips(fleetRec *fp,int type,int num){
int pos;

	if (num<1) return 0;

	for (pos=0;pos<posCOUNT;pos++) if (fp->squad[pos].type==type) break;
	if (pos==posCOUNT) for (pos=0;pos<posCOUNT;pos++) if (fp->squad[pos].type==stCOUNT) break;
	if (pos==posCOUNT) return 0;

	fp->squad[pos].type = type;
	return addSquadShips(fp,&fp->squad[pos],num);
}


int addSquadShips(fleetRec *fp,squadRec *sp,int num){
int fill;

	fill = max[sp->type] - sp->count;
	if (num>fill) num = fill;

	sp->count += num;
	fp->ecm += num * ecm[sp->type];
	fp->guns += num * guns[sp->type];

	return num;
}


int pullFleetShips(fleetRec *fp,int type,int num){		// for transfer
int pos;

	if (num<1) return 0;

	for (pos=0;pos<posCOUNT;pos++) if (fp->squad[pos].type==type) break;
	if (pos==posCOUNT) return 0;

	return pullSquadShips(fp,&fp->squad[pos],num);
}


int pullSquadShips(fleetRec *fp,squadRec *sp,int num){
int type;

	type = sp->type;

	if (num < sp->count) sp->count -= num;
	else {
		num = sp->count;
		sp->count = 0;
		sp->damage = 0;
		sp->type = stCOUNT;	// DEAD!
	}
		
	fp->ecm -= num * ecm[type];
	fp->guns -= num * guns[type];

	return num;
}

//**********************************************************************************

int lastFleetUpdate=0;

void operateFleets(){
int update,count,ix,i;
fleetRec *fp,*fleets;

	update = time(NULL);
	if (lastFleetUpdate + 1 > update) return;
	lastFleetUpdate = update;

	count = fleetList->getCount();
	fleets = (fleetRec*)fleetList->getList();

//--- scan list ---
	for (ix=0;ix<count;ix++) {
		fp = &fleets[ix];

		switch (fp->status) {
			case fsMoving: case fsNebulae: case fsNeutron:
				fleetAdvance(ix,fp); 
				break;
			case fsBattle:	
				fleetBattle(ix,fp); 
				break;
			case fsWaiting:
				for (i=0;i<posCOUNT;i++) if (fp->squad[i].type!=stCOUNT) break;
				if (i==posCOUNT) fp->status = fsDead;
				break;
		}
	}

	fleetList->save();
}

//**********************************************************************************
//**********************************************************************************
//**********************************************************************************

int lastSessionFleet=0;
int lastSessionScan=0;

void operateSessions(){
SessionList *slp;
int update;

	update = time(NULL);

//--- send fleet info ---
	if (lastSessionFleet+1 > update) return;
	lastSessionFleet = update;

	slp = sroot->next();
	while (slp!=NULL) {
		sessionScanFleets(slp->ssn());
		slp = slp->next();
	}

//--- send fleet info ---
	if (lastSessionScan+1 > update) return;
	lastSessionScan = update;

	slp = sroot->next();
	while (slp!=NULL) {
		sessionScanWorlds(slp->ssn());
		slp = slp->next();
	}
}

//**********************************************************************************
//**********************************************************************************

void fleetBattle(int fleetID,fleetRec *fp){
bool autoplay,guard,dead,retreat;
squadRec *sp;
fleetRec *ep;
empireRec *emp;
int ix,i;

	autoplay = guard = (fleetID<worldList->getCount());
	if (!autoplay && findEmpireSession(fp->empireID)==NULL) autoplay = true;
	
	emp = (empireRec*)empireList->getRecord(fp->empireID);

	if (autoplay) fleetAutoAction(fleetID,fp);

//--- check engagement ---
	for (i=0;i<sideCOUNT;i++) if (fp->engageID[i]>=0) break;
	if (i==sideCOUNT) {
		fp->status = fsMoving;
		return;
	}

//--- check status ---
	dead = retreat = true;
	for (ix=0;ix<posCOUNT && (dead || retreat);ix++) {
		sp = &fp->squad[ix];
		if (sp->type==stCOUNT) continue;
		dead = false;
		if (!isRetreatAction(sp->action) || sp->timer!=0) retreat = false;
	}

//--- fleet dead ---
	if (dead) {

		fp->status = fsDead;

		if (guard) {
			ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideDefend]);
			if (ep!=NULL) fp->empireID = ep->empireID;
		}
		else {
			setFleetDestination(fp,-1);
		}
		
		return;
	}

//--- runaway ---
	if (retreat) {
		setFleetDestination(fp,-1);
		return;
	}

//--- enemies subdued ---
	if (fp->engageID[sideDefend]<0 && fp->engageID[sideInvade]==fp->destID) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideInvade]);
		if (ep==NULL) return;

		if (ep->status==fsDead) {
			fp->status = fsIndustry;
			return;
		}
	}

//--- squadrons battle ---
	for (ix=0;ix<posCOUNT;ix++) {
		sp = &fp->squad[ix];
		if (sp->type==stCOUNT || isDefendAction(sp->action)) continue;

		if (sp->timer>0) {
			sp->timer--;
			continue;
		}

	//--- retreating ---
		if (isRetreatAction(sp->action)) continue;

	//--- timer=zero, take action ---
		if (isMoveAction(sp->action)) {
			fleetMoveSquad(fp,ix,sp->action);
			continue;
		}

	//--- fire action ---
		fleetFireSquad(fp,ix,sp->action,sp->enemy);
		if (autoplay || !setSquadAction(fp,ix,sp->action,sp->enemy)) {
			setSquadAction(fp,ix,actDefend);
		}
	}
}


int searchPosition[sideCOUNT][posCOUNT]={{0,1,2,3,4,5},{3,4,5,0,1,2},};

void fleetAutoAction(int fleetID,fleetRec *fp){
squadRec *sp;
int pos,ix,type,val,side;
fleetRec *ip,*dp,*tp;

	printf("Automatic battle commands operating...");

	dp = (fleetRec*)fleetList->getRecord(fp->engageID[sideDefend]); //dp = defending fleet
	ip = (fleetRec*)fleetList->getRecord(fp->engageID[sideInvade]); //ip = attacking fleet
	if (dp==NULL && ip==NULL) {
		fp->status = fsWaiting; //waiting for at least one fleet to show up 
		return;
	}

//--- squad actions ---
	for (pos=0;pos<posCOUNT;pos++) { //loop checks all possible squad positions
		sp = &fp->squad[pos]; //squadron record pulls position of squad from fleet record
		if (sp->type==stCOUNT || !isDefendAction(sp->action)) continue; //if no squad or defending

		side = (isDefendPosition(pos)?sideDefend:sideInvade);

	//--- move into empty slot ---
		if (side==sideDefend && (dp==NULL || isFriendlyFleet(dp,fp))) {
			val = MoveGrid[ReadHeading(actMoveRight)][pos]; //value is new position to go to
			if (val!=posCOUNT && fp->squad[val].type==stCOUNT) { //if squad is empty
				setSquadAction(fp,pos,actMoveRight); //moves the squad right
				continue;
			}
		}

		if (side==sideInvade && (ip==NULL || isFriendlyFleet(ip,fp))) {
			val = MoveGrid[ReadHeading(actMoveLeft)][pos]; //value is new position to go to
			if (val!=posCOUNT && fp->squad[val].type==stCOUNT) { //if squad is empty
				setSquadAction(fp,pos,actMoveLeft); //moves the squad left
				continue;
			}
		}

	//--- search fleet ---
		val = 0;
		type = stCOUNT;
		tp = (side==sideDefend?dp:ip); //tp becomes equal to the fleet on the right
		if (tp==NULL) {
			if (sp->type!=stFrigate && sp->type!=stStarDart) continue;

			side = (side==sideDefend?sideInvade:sideDefend);	// switch
			tp = (side==sideDefend?dp:ip);
			if (tp==NULL) continue;
		}

		for (ix=0;ix<posCOUNT;ix++) { //checks all squad positions
		int test,num;

			if (ix==posCOUNT/2 && type!=stCOUNT) break;	// stop at first detected squad

			test = tp->squad[ searchPosition[side][ix] ].type; //checks to see if a squad is there
			if (test>=stCOUNT) continue; //goes on to attack first detected squad

			num = attack[sp->type][test]; //finds attack power of squad against squad
			if (num>val || (num==val && Rand2())) {
				type = test;
				val = num;
			}
		}

	//--- set action ---
		if (type==stCOUNT)	setSquadAction(fp,pos,actDefend);
		else				setSquadAction(fp,pos,MakeFireAction(type),side);
	}
}


void fleetMoveSquad(fleetRec *fp,int squadID,int move){
squadRec swap;
int dest;

	printf("Squad moved...");

	dest = MoveGrid[ReadHeading(move)][squadID];
	if (dest==posCOUNT) return;

	swap = fp->squad[squadID];
	fp->squad[squadID] = fp->squad[dest];
	fp->squad[dest] = swap;

	setSquadAction(fp,dest,actDefend);
	setSquadAction(fp,squadID,actDefend);
}


void fleetFireSquad(fleetRec *fp,int squadID,int action,int enemy){
int percent,type,ftype,pos,dmg,kills;
char buf[BUFFERSIZE];
empireRec *emp;
fleetRec *ep;
squadRec *sp;

	printf("Squad firing...");

	ep = (fleetRec*)fleetList->getRecord(fp->engageID[enemy]);
	if (ep==NULL) return;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

	type = ReadType(action);
	for (pos=0;pos<posCOUNT;pos++) if (ep->squad[pos].type==type) break;
	if (pos==posCOUNT) return;

	sp = &ep->squad[pos];
	ftype = fp->squad[squadID].type;

	percent = attack[ftype][type];

	if (emp->race==rtNajunian) {
		percent *= guns[ftype] * 5 / 4;
	}
	else {
		percent *= guns[ftype];
	}

	if (ftype==stStarDart) percent += sp->count * guns[type];	// +1% damage per stardart
	percent *= fp->squad[squadID].count;
	percent += fp->ecm - ep->ecm;
	if (percent<=0) return;

//--- calc damage, kill ships ---
	printf("Calculating damage and destroying ships...");
	if (isDefendAction(sp->action)) percent /= 2;

	dmg = (int)sp->damage + percent / 100 + (Rand(100)<(percent%100)?1:0);

	kills = dmg / guns[type];
	sp->damage = dmg % guns[type];
	kills = pullSquadShips(ep,sp,kills);			

	if (kills>0 && type==stStarDart) {
		printf("/nStar Dart(s) destroyed, allocating to phenomena...\n");
		randomizeStarDart(kills);
		emp = (empireRec*)empireList->getRecord(ep->empireID);
		if (emp!=NULL) {
			emp->darts -= kills;
			if (kills==1) {
				sprintf(buf,"*** %s Empire loses Star Dart ***",emp->name);
				sendGlobalMessage(buf);
			}
			else if (kills>1) {
				sprintf(buf,"*** %s Empire loses %d Star Darts ***",emp->name,kills);
				sendGlobalMessage(buf);
			}
		}
	}
}

//**********************************************************************************

void fleetAdvance(int fleetID,fleetRec *fp){
int dx,dy,tx,ty,total,delta;
fleetRec *tp;
empireRec *emp;

	if (fleetID<worldList->getCount()) return;		// planetary fleet
	if (fp->destID<0) return;

	tp = (fleetRec*)fleetList->getRecord(fp->destID);
	if (tp==NULL) return;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

	dx = tp->xloc - fp->xloc;
	tx = (dx<0?-dx:dx);
	dy = tp->yloc - fp->yloc;
	ty = (dy<0?-dy:dy);

	if (tx>ty)	total = tx + ty/2;
	else		total = ty + tx/2;

	delta = (((empireRec*)empireList->getRecord(fp->empireID))->Beacon * beaconBonus) + movePixels;
	if (delta > maxSpeed) delta = maxSpeed;

	if (emp->race!=rtKaletian && fp->status==fsNebulae) delta /= 2;
	if (fp->status==fsNeutron) delta *= 2;

	if (delta >= total) {				// arrives
		fp->xloc = tp->xloc;
		fp->yloc = tp->yloc;
		fleetHitsTarget(fleetID,fp);
		return;
	}
	
	if (total!=0) {
		fp->xloc += dx * delta / total;
		fp->yloc += dy * delta / total;
	}
}


void fleetHitsTarget(int fleetID,fleetRec *fp){
int targetID,i;
fleetRec *ep;
worldRec *wp;
empireRec *emp;
char buf[BUFFERSIZE];

//--- handle special zones ---
	wp = (worldRec*)worldList->getRecord(fp->destID);
	if (wp!=NULL && !isPlanet(wp->type)) {
		printf("Fleet in phenomena...");
		fleetHitsZone(fp,wp->type);
		return;
	}

//--- find tail fleet ---
	targetID = fp->destID;
	ep = (fleetRec*)fleetList->getRecord(targetID);		// planet fleet;

	while (ep->engageID[sideDefend]>=0) {
		targetID = ep->engageID[sideDefend];
		ep = (fleetRec*)fleetList->getRecord(targetID);
	}

//--- guard fleet ---
	if (targetID==fp->destID) {
		if (isFriendlyFleet(ep,fp)) {
			fp->status = fsIndustry;	
			ep->engageID[sideDefend] = fleetID;
			fp->engageID[sideInvade] = targetID;
			return;
		}
		else if (wp!=NULL && wp->empireID>0) {
			printf("World under attack...");
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				sprintf(buf,"<<< %s in sector %d is under attack >>>",wp->name,wp->sector);
				sendEmpireMessage(wp->empireID,buf);
			}
		}
		else if (wp!=NULL && targetID==0) {
			printf("Old Earth under attack...\n");
			sendGlobalMessage("<<< Old Earth is under attack >>>");
		}
	}

//--- engage target fleet ---
	if (fp->destID>=worldList->getCount()) fp->destID = -1;

	ep->engageID[sideDefend] = fleetID;
	fp->engageID[sideInvade] = targetID;

	ep->status = fsBattle;
	fp->status = fsBattle;

	for (i=0;i<posCOUNT;i++) setSquadAction(fp,i,actDefend);
}


void fleetHitsZone(fleetRec *fp,int type){
empireRec *emp;
fleetRec *ep;
worldRec *wp=NULL;
int worldID,count,i,dest,num;
char buf[BUFFERSIZE];
Session *ssn;

	dest = fp->destID;
	fp->destID = -1;

//--- find stardarts ---
	ep = (fleetRec*)fleetList->getRecord(dest);
	if (ep!=NULL && ep->squad[0].count>0) {
		num = ep->squad[0].count;
		ep->squad[0].count = 0;

		addFleetShips(fp,stStarDart,num);

		emp = (empireRec*)empireList->getRecord(fp->empireID);
		if (emp!=NULL) emp->darts += num;
		printf("Star Dart(s) found...\n");

		if (num==1) {
			sprintf(buf,"+++ %s Empire finds Star Dart +++",emp->name);
			sendGlobalMessage(buf);
		}
		else if (num>1) {
			sprintf(buf,"+++ %s Empire finds %d Star Darts +++",emp->name,num);
			sendGlobalMessage(buf);
		}
	}

//--- gateway ---
	if (type==wtGateway) {

		count = worldList->getCount();

		for (i=1;i<count;i++) {
			printf("Player going through gate...");
			worldID = (dest + i) % count;
			wp = (worldRec*)worldList->getRecord(worldID);
			if (wp!=NULL && wp->type==wtGateway) break;
		}
		if (wp==NULL || wp->type!=wtGateway) return;

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		ssn = findEmpireSession(fp->empireID);
		if (ssn==NULL) return;

		sessionScanFleets(ssn);
		sessionScanWorlds(ssn);
	}
}

//**********************************************************************************
//**********************************************************************************

void sessionScanFleets(Session *ssn){
int count,ix,radius,x,y,engageID,len,empireID,fleetID;
fleetRec *fleets,*fp,*ep;
char buf[BUFFERSIZE];
CRect scan;

	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	fleets = (fleetRec*)fleetList->getList();
	if (fleets==NULL) return;


	fp = &fleets[fleetID];		// session fleet
	sendStatus(ssn,fp->status);

//--- engage scan ---
	if (fp->status==fsBattle) {
		printf("Battle scan...");
		sendCombatScan(ssn,fleetID,fp);	// scan self
		for (ix=0;ix<sideCOUNT;ix++) {
			engageID = fp->engageID[ix];
			if (engageID<0) continue;

			ep = &fleets[engageID];
			sendCombatScan(ssn,engageID,ep);
		}
		return;
	}

//--- region scan ---
	printf("Movement screen scan...");

	x = fp->xloc;
	y = fp->yloc;

	radius = SCAN_SIZE;
	scan.setRect(x-radius,y-radius,2*radius,2*radius);

	ix = worldList->getCount();		// skip planetary fleets
	count = fleetList->getCount();

//--- create message ---
	for (len=2;ix<count && len<BUFFERSIZE-5*sizeof(int);ix++) {
		ep = &fleets[ix];
		if (ep->status==fsDead || !scan.inside(ep->xloc,ep->yloc)) continue;

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&ep->xloc,4*sizeof(int));
		len += 4*sizeof(int);
	}
	
	buf[0] = len;
	buf[1] = mfSectorFleets;
	ssn->send(buf);
}

//***************************************************************************

void sessionScanWorlds(Session *ssn){	// every 5 seconds
CRect scan,nebulae,neutron;
int count,ix,radius,dx,dy,len,empireID,fleetID;
char buf[BUFFERSIZE];
fleetRec *fp,*ep;
worldRec *worlds,*wp;
empireRec *emp;

	printf("Scanning worlds...");

	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	worlds = (worldRec*)worldList->getList();
	if (worlds==NULL) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL || fp->status==fsBattle) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return;

//--- super scan self ---
	sendCombatScan(ssn,fleetID,fp);
	sendEmpireScan(ssn,empireID,emp);

	if (fp->status==fsIndustry) {
		ep = (fleetRec*)fleetList->getRecord(fp->destID);
		if (ep!=NULL) sendCombatScan(ssn,fp->destID,ep);
		wp = &worlds[fp->destID];
		if (wp!=NULL) sendBuildScan(ssn,fp->destID,wp);
		return;
	}

//--- build scan regions ---
	dx = fp->xloc;
	dy = fp->yloc;

	radius = SCAN_SIZE;
	scan.setRect(dx-radius,dy-radius,2*radius,2*radius);

	radius = SCAN_SIZE+NEUTRON_SIZE;
	neutron.setRect(dx-radius,dy-radius,2*radius,2*radius);

	radius = SCAN_SIZE+NEBULAE_SIZE;
	nebulae.setRect(dx-radius,dy-radius,2*radius,2*radius);

//--- build message ---
	if (isMoveState(fp->status)) fp->status = fsMoving;

	count = worldList->getCount();
	for (ix=0,len=2;ix<count && len<BUFFERSIZE-3*sizeof(int);ix++) {

		wp = &worlds[ix];

		switch (wp->type) {
			case wtNeutron:
				if (!neutron.inside(wp->xloc,wp->yloc)) continue;
				if (fp->status==fsNebulae || fp->status==fsMoving) {
					dx = wp->xloc - fp->xloc;
					dy = wp->yloc - fp->yloc;
					if (dx*dx + dy*dy < NEUTRON_SIZE*NEUTRON_SIZE) fp->status = fsNeutron;
				}
				break;
			case wtNebulae:
				if (!nebulae.inside(wp->xloc,wp->yloc)) continue;
				if (fp->status==fsMoving) {
					dx = wp->xloc - fp->xloc;
					dy = wp->yloc - fp->yloc;
					if (dx*dx + dy*dy < NEBULAE_SIZE*NEBULAE_SIZE) fp->status = fsNebulae;
				}
				break;
			default:
				if (!scan.inside(wp->xloc,wp->yloc)) continue;
				break;
		}

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&wp->empireID,2*sizeof(int));
		len += 2*sizeof(int);
	}

	buf[0] = len;
	buf[1] = mfSectorWorlds;
	ssn->send(buf);
}


void sessionHomeWorlds(Session *ssn){	// once on startup
int count,ix,len,empireID,fleetID;
char buf[BUFFERSIZE];
worldRec *worlds,*wp;

	printf("\nDisplay worlds to player just logging in...\n");
	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	worlds = (worldRec*)worldList->getList();
	if (worlds==NULL) return;

//--- build message ---
	count = worldList->getCount();

	for (ix=0,len=2;ix<count && len<BUFFERSIZE-3*sizeof(int);ix++) {

		wp = &worlds[ix];
		if (wp->empireID!=empireID || !isPlanet(wp->type)) continue;

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&wp->empireID,2*sizeof(int));
		len += 2*sizeof(int);
	}

	buf[0] = len;
	buf[1] = mfSectorWorlds;
	ssn->send(buf);
}

//***************************************************************************
//***************************************************************************

void setFleetDestination(fleetRec *fp,int id){		// players fleets only
fleetRec *ep;
squadRec *sp;
empireRec *emp;
int i;

	printf("Setting fleet destination...");
//--- legal target? ---
	if (id>=0) {
		ep = (fleetRec*)fleetList->getRecord(id);
		if (ep==NULL) return;

		i = ep->xloc - fp->xloc;
		if (i<0) i = -i;
		if (i>SCAN_SIZE) return;

		i = ep->yloc - fp->yloc;
		if (i<0) i = -i;
		if (i>SCAN_SIZE) return;
	}

//--- break engagements ---
	for (i=0;i<sideCOUNT;i++) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[i]);
		if (ep!=NULL) ep->engageID[InverseEngage(i)] = -1;

		fp->engageID[i] = -1;
	}

//--- reset squad actions ---
	for (i=0;i<posCOUNT;i++) {
		sp = &fp->squad[i];
		sp->action = actDefend;
		sp->timer = 0;
	}

//--- set status ---
	if (fp->status==fsDead) {
		emp = (empireRec*)empireList->getRecord(fp->empireID);
		if (emp!=NULL && emp->worlds>0) fp->status = fsMoving;
	}
	else if (!isMoveState(fp->status)) fp->status = fsMoving;

	fp->destID = id;
}


bool setSquadAction(fleetRec *fp,int squadID,int action){
	return setSquadAction(fp,squadID,action,sideCOUNT);
}


bool setSquadAction(fleetRec *fp,int squadID,int action,int enemy){
int pos,heading,type;
fleetRec *ep;
squadRec *sp;
empireRec *emp;

	sp= &fp->squad[squadID];

	if (illegalAction(action)) return false;

	if (isRetreatAction(action)) {
		printf("Fleet retreating from battle...");
//		if (sp->type==stStation) return false;
		if (sp->action==action) return true;
	}

//--- move action / swap squads ---
	if (isMoveAction(action)) {
		printf("Squad moving in battle...");
		heading = ReadHeading(action);
		if (MoveGrid[heading][squadID]==posCOUNT) return false;
	}

//--- firing, position prevents penetration ---
	type = sp->type;
	if (isFireAction(action) && type!=stStarDart && type!=stFrigate && type!=stStation) {

		type = ReadType(action);
		if (type>=stCOUNT) return false;

		ep = (fleetRec*)fleetList->getRecord(fp->engageID[enemy]);
		if (ep==NULL || isFriendlyFleet(ep,fp)) return false;

		for (pos=0;pos<posCOUNT;pos++) if (ep->squad[pos].type==type) break;
		if (pos==posCOUNT) return false;

		switch (enemy) {

			case sideInvade:		// target the invasion side
				if (squadID>=3 && (fp->squad[0].type!=stCOUNT ||
					fp->squad[1].type!=stCOUNT || fp->squad[2].type!=stCOUNT)) return false;
				if (pos<3 && (ep->squad[3].type!=stCOUNT ||
					ep->squad[4].type!=stCOUNT || ep->squad[5].type!=stCOUNT)) return false;
				break;

			case sideDefend:		// target the defence side
				if (squadID<3 && (fp->squad[3].type!=stCOUNT ||
					fp->squad[4].type!=stCOUNT || fp->squad[5].type!=stCOUNT)) return false;
				if (pos>=3 && (ep->squad[0].type!=stCOUNT ||
					ep->squad[1].type!=stCOUNT || ep->squad[2].type!=stCOUNT)) return false;
				break;
		}
	}

//--- action approved ---
	sp->action = action;
	sp->enemy = enemy;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

	switch (action) {
		case actDefend:
			printf("Squad defending, timer set to 0...");
			sp->timer = 0; 
			break;
		case actRetreat: 
			printf("Squad retreating, set retreat timer...");
			if (emp->race==rtQuarethian) {
				sp->timer = FastRetreatTimer[sp->type];
				break;
			}
			else if (emp->race!=rtQuarethian) {
				sp->timer = RetreatTimer[sp->type];
				break;
			}
		case actMoveUp: case actMoveDown: case actMoveLeft: case actMoveRight:
			printf("Squad moving, set move timer...");
			if (emp->race==rtQuarethian) {
				sp->timer = FastMoveTimer[sp->type]; 
				break;
			}
			else if (emp->race!=rtQuarethian) {
				sp->timer = MoveTimer[sp->type];
				break;
			}
		default:
			printf("Squad firing, set fire timer...");
			if (emp->race==rtQuarethian) {
				sp->timer = FastFireTimer[sp->type];
				break;
			}
			else {
				sp->timer = FireTimer[sp->type];
				break;
			}
	}

	return true;
}


void randomizeStarDart(int num){
char buf[BUFFERSIZE];
int ix,count;
worldRec *wp;
fleetRec *fp;
empireRec *emp;

	count = worldList->getCount();

	for (;num>0;num--) {

		while (true) {

			ix = Rand(count);

			wp = (worldRec*)worldList->getRecord(ix);
			if (wp==NULL) continue;
			if (isPlanet(wp->type) && wp->facility!=ftStellurae) continue;

			fp = (fleetRec*)fleetList->getRecord(ix);
			if (fp!=NULL) break;

		}

		printf("Star Dart(s) found...\n");
		addFleetShips(fp,stStarDart,1);

		if (fp->empireID!=0 && isPhenomena(wp->type)) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL && emp->race==rtCestanian) {
				if (Rand(3)==0) {
					printf("2 Star Darts have been scored...\n");
					emp->darts = emp->darts + 2;
					emp->scoreDarts = emp->scoreDarts + 2;
					sprintf(buf,"+++ %s scores 2 Star Darts! +++",emp->name);
					sendGlobalMessage(buf);
				}
				else {
					printf("Star Dart has been scored...\n");
					emp->darts++;
					emp->scoreDarts++;
					sprintf(buf,"+++ %s scores a Star Dart! +++",emp->name);
					sendGlobalMessage(buf);
				}
			}
			if (emp!=NULL && emp->race!=rtCestanian) {
				printf("Star Dart has been scored...\n");
				emp->darts++;
				emp->scoreDarts++;
				sprintf(buf,"+++ %s scores a Star Dart! +++",emp->name);
				sendGlobalMessage(buf);
			}
		}
		if (isPlanet(wp->type) && wp->facility==ftStellurae) {
			printf("Star Dart has been stelled...\n");
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->darts++;
				sprintf(buf,"+++ %s stells a Star Dart! +++",emp->name);
				sendGlobalMessage(buf);
			}
		}
	}
}

//***************************************************************************

