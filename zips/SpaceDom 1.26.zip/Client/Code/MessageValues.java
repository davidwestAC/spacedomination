import java.awt.*;

interface MessageValues {

	public final static int JOIN_REQUEST = 0x00;
	public final static int SESSION_GRANTED = 0x01;
	public final static int SESSION_CREATED = 0x02;
	public final static int BAD_PASSWORD = 0x03;
	public final static int EMPIRE_DEAD = 0x04;
	public final static int EMPIRE_INPLAY = 0x05;
	public final static int RECORDS_ERROR = 0x06;
	public final static int SERVER_FULL = 0x07;

	public final static int TOP20_QUERY = 0x08;
	public final static int TOP20_SCAN = 0x09;
	public final static int STATS_QUERY = 0x0a;
	public final static int STATS_RESULT = 0x0b;

	public final static int VICTORY = 0x0c;
	public final static int REBIRTH_REQUEST = 0x0d;
	public final static int SESSION_DONE = 0x0e;
	public final static int SESSION_PING = 0x0f;
	
	public final static int CHAT_MESSAGE = 0x10;
	public final static int CHAT_CHANNEL = 0x11;
	public final static int MESSAGE = 0x12;
	public final static int STATUS = 0x13;

	public final static int WORLD_SCAN = 0x20;
	public final static int FLEET_SCAN = 0x21;
	public final static int EMPIRE_SCAN = 0x22;
	public final static int COMBAT_SCAN = 0x23;
	public final static int BUILD_SCAN = 0x24;

	public final static int SECTOR_FLEETS = 0x25;
	public final static int SECTOR_WORLDS = 0x26;

	public final static int EMPIRE_QUERY = 0x28;
	public final static int WORLD_QUERY = 0x29;
	public final static int FLEET_QUERY = 0x2a;

	public final static int SET_DESTINATION = 0x40;

	public final static int SQUAD_ATTACK = 0x52;
	public final static int FLEET_DISENGAGE = 0x53;
	public final static int FLEET_DESTROYED = 0x54;

	public final static int FLEET_RETREAT = 0x58;
	public final static int SQUAD_ACTION = 0x59;

	public final static int BUILD_COMMAND = 0x60;
	public final static int FLEET_TRANSFER = 0x61;
	
	public final static int RACE_CHANGE = 0x70;
};

