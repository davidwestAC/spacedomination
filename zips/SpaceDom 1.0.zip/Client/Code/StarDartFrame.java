//******************************************************************************
//  Copyright 1998, Fred's Friends, Inc.
//******************************************************************************
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class StarDartFrame extends Frame {

	static StarDart root;

    public static String server=null;
    public static String artpath=null;
    public static int port=0;

	public StarDartFrame(String title,StarDart sd,String config){
		super(title);
		root = sd;

		System.out.println("StarDart Downloadable Version 1.0");
        System.out.println("Loading Config File=["+config+"]");

        try {
            Properties prop = new Properties();
            prop.load(new FileInputStream(config));
            server = prop.getProperty("stardart.server.address");
            artpath = prop.getProperty("stardart.artpath");
            port = Integer.parseInt(prop.getProperty("stardart.server.port"));
        }
        catch (IOException ex){System.err.println("LOAD ERROR: "+ex);}
        catch (NumberFormatException ex){System.err.println("LOAD ERROR: "+ex);}

	}

	public static void main(String args[]) {
	StarDartFrame win;
	StarDart app;
	Insets edge;

        if (args.length<1 || args[0]==null) {
            System.out.println("Need Name of Properties File as Parameter");
            return;
        }

		app = new StarDart();
		app.isApplet = false;

		win = new StarDartFrame("FFI Presents: Star Dart",app,args[0]);
		win.show();

		edge = win.insets();
		win.resize( edge.left+edge.right+StarDart.DEFAULT_WIDTH,
                    edge.top+edge.bottom+StarDart.DEFAULT_HEIGHT);
		win.setResizable(false);
		win.add("Center",app);

		app.init();
		app.start();
	}

	public boolean handleEvent(Event e){

		switch (e.id) {

			case Event.WINDOW_MOVED:
				repaint();
				break;

			case Event.WINDOW_DESTROY:
				root.closeConnection();
				dispose();
				System.exit(0);
				return true;
		}

		return super.handleEvent(e);
	}
}

