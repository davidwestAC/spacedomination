import java.awt.*;
import java.applet.*;
import java.awt.image.*;

class gsMovement extends GameState {

//--- variables ---
	public static Worlds selectWorld = null;
	public static Fleets selectFleet = null;
	public static Worlds homeWorld = null;
	public static int homeDist,cx,cy;

	Button quit,change[];

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	final int[] delta = {-100,-10,-1,1,10,100};

	public static Portrait fleetIcon = null;
	public static Portrait starsFar = null;
	public static Portrait starsNear = null;

	public static Image fieldImage = null;
	public static Graphics fieldGraph = null;

//--- constructors ---
	public gsMovement(){
	Graphics g;

		fleetIcon = new Portrait("sloop.gif");
		starsFar = new Portrait("StarsFar.gif");
		starsNear = new Portrait("StarsNear.gif");

		fieldImage = root.createImage(400,400);
		fieldGraph = fieldImage.getGraphics();

		g = root.offscreen.getGraphics();
		g.setColor(Color.black);
		g.fillRect(0,0,500,400);
	}

	public void init(){
		root.add(quit = new Button("Quit"));

		change = new Button[6];
		for (int i=0;i<6;i++) root.add(change[i] = new Button(ChanStr[i]));
	}

//--- primary functions ---
	public void paint(Graphics g){
long time = System.currentTimeMillis();
	Worlds wp;
	Fleets fp;
	Squadron sp;
	int v,count,dx,dy;

		if (gsFleet==null) cx = cy = 0;
		else {
			cx = gsFleet.xloc();
			cy = gsFleet.yloc();
		}

		if (starsFar==null) {
			g.setColor(Color.black);
			g.fillRect(0,0,500,400);
		}
		else {
			starsFar.draw(g,100,0,root);
			if (starsNear!=null) {
				dx = (cx/5) % 400;
				if (dx<0) dx += 399;
				dy = (cy/5) % 400;
				if (dy<0) dy += 399;
				starsNear.draw(g,100-dx,0-dy,root);
				starsNear.draw(g,500-dx,0-dy,root);
				starsNear.draw(g,100-dx,400-dy,root);
				starsNear.draw(g,500-dx,400-dy,root);
			}
		}

	//--- worlds & fleets ---
		homeWorld = null;

		fieldGraph.setColor(Color.black);
		fieldGraph.fillRect(0,0,400,400);
		for (wp=Worlds.start();wp!=null;wp=wp.next()) wp.drawField(fieldGraph,cx,cy);

		g.setXORMode(Color.black);
		g.drawImage(fieldImage,100,0,root);
		g.setPaintMode();

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {
			wp.draw(g,cx,cy);
			findHomeWorld(wp);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {
			drawFleet(g,fp);
		}

		markEarthDirection(g);
		markHomeDirection(g);

	//--- status region ---
		g.setColor(Color.blue);
		g.fillRect(0,0,100,400);

		drawEmpireStats(g,5,13);
		gsFleet.drawStats(g,5,115,86,120);
		drawTargetStats(g);
		drawWorldStats(g);

	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,110,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}

	//--- move tools ---
		reshape(quit,5,380,80,15);
		for (int i=0;i<6;i++) reshape(change[i],10+(i%3)*25+(i/3)*5,78+(i/3)*15,25,15);

//System.out.println("FrameTime = "+(System.currentTimeMillis()-time));
	}

	
	void findHomeWorld(Worlds wp){
	int x,y,dw;

		if (wp.empireID!=gsEmpireID) return;

		if (homeWorld==null) {
			homeWorld = wp;
			homeDist = calcDistance(wp.xloc()-cx,wp.yloc()-cy);
			return;
		}

		dw = calcDistance(wp.xloc()-cx,wp.yloc()-cy);

		if (dw<homeDist) {
			homeWorld = wp;
			homeDist = dw;
		}
	}


	int calcDistance(int dx,int dy){
		if (dx<0) dx = -dx;
		if (dy<0) dy = -dy;
		return (dx>dy?dx+dy/2:dy+dx/2);
	}


	void drawFleet(Graphics g,Fleets fp){
	Worlds wp;
	Fleets ep;
	int x,y,wx,wy,rad;
	int size;

		if (fp.ghost()) return;

		x = 300 + (fp.xloc()-cx) * 200 / Worlds.scale;
		if (x<100 || x>500) return;
		y = 200 + (fp.yloc()-cy) * 200 / Worlds.scale;
		if (y<0 || y>400) return;

		wp = Worlds.get(fp.destID);
		if (wp!=null) {
			wx = 300 + (wp.xloc()-cx) * 200 / Worlds.scale;
			wy = 200 + (wp.yloc()-cy) * 200 / Worlds.scale;
			g.setColor(Color.blue);
			g.drawLine(x,y,wx,wy);
		}
		else {
			ep = Fleets.get(fp.destID);
			if (ep!=null) {
				wx = 300 + (ep.xloc()-cx) * 200 / Worlds.scale;
				wy = 200 + (ep.yloc()-cy) * 200 / Worlds.scale;
				g.setColor(Color.blue);
				g.drawLine(x,y,wx,wy);
			}
		}

		if (fp==selectFleet) {
			g.setColor(Color.blue);
			g.fillRect(x-7,y-5,15,11);
		}

		if (fleetIcon==null) {
			g.setColor(Color.red);
			g.fillRect(x-5,y-3,11,7);
		}
		else fleetIcon.center(g,x,y,root);
	}

	void markEarthDirection(Graphics g){
	int range,dx,dy;
	String msg;

		range = Worlds.scale;
		if (cx>-range && cx<range && cy>-range && cy<range) return;

		range = calcDistance(cx,cy);
		dx = (cx<0?-cx:cx);
		dy = (cy<0?-cy:cy);

		if (dx>dy) {
			dy = cy * 196 / (1+dx);
			dx = cx * 196 / (1+dx);
		}
		else {
			dx = cx * 196 / (1+dy);
			dy = cy * 196 / (1+dy);
		}

		dx = 300 - dx;
		dy = 200 - dy;
		
		g.setColor(Color.green);
		g.drawLine(dx-4,dy,dx,dy-4);
		g.drawLine(dx,dy-4,dx+4,dy);
		g.drawLine(dx+4,dy,dx,dy+4);
		g.drawLine(dx,dy+4,dx-4,dy);

		msg = ""+range;
		if (dx>300) g.drawString(msg,dx-textMET.stringWidth(msg)-5,dy+5);
		else		g.drawString(msg,dx+5,dy+5);
	}


	void markHomeDirection(Graphics g){
	int range,hx,hy,dx,dy;
	String msg;

		if (homeWorld==null) return;

		range = Worlds.scale;
		hx = cx - homeWorld.xloc();
		hy = cy - homeWorld.yloc();
		if (hx>-range && hx<range && hy>-range && hy<range) return;

		range = calcDistance(hx,hy);
		dx = (hx<0?-hx:hx);
		dy = (hy<0?-hy:hy);


		if (dx>dy) {
			dy = hy * 196 / (1+dx);
			dx = hx * 196 / (1+dx);
		}
		else {
			dx = hx * 196 / (1+dy);
			dy = hy * 196 / (1+dy);
		}

		dx = 300 - dx;
		dy = 200 - dy;
		
		g.setColor(Color.magenta);
		g.drawLine(dx-4,dy,dx,dy-4);
		g.drawLine(dx,dy-4,dx+4,dy);
		g.drawLine(dx+4,dy,dx,dy+4);
		g.drawLine(dx,dy+4,dx-4,dy);

		msg = ""+range;
		if (dx>300) g.drawString(msg,dx-textMET.stringWidth(msg)-5,dy+5);
		else		g.drawString(msg,dx+5,dy+5);
	}


	void drawEmpireStats(Graphics g,int h,int v){
	Empires ep;
	String msg;

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),h,v);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Darts: "+ep.darts(),h,v+=15);
		g.drawString("Scr: "+ep.score(),h,v+=15);

		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
	}


	void drawTargetStats(Graphics g){
	Empires emp;
	int v;

		g.setColor(Color.orange);
		g.fillRect(5,v=240,86,60);
		if (selectFleet==null) return;

		g.setColor(Color.black);
		g.drawString(selectFleet.empireName(),7,v+=14);
		g.drawString("-->"+selectFleet.destName(),7,v+=14);

		emp = Empires.get(selectFleet.empireID);
		if (emp==null) return;

		g.drawString("Score: "+emp.score(),7,v+=14);
		g.drawString("Build: "+emp.buildBonus(),7,v+=14);

	}

	void drawWorldStats(Graphics g){
	int v;

		g.setColor(Color.cyan);
		g.fillRect(5,v=305,86,70);

		if (selectWorld!=null) {
			g.setColor(Color.black);
//			g.drawString(selectWorld.name(),7,v+=15);
			g.drawString(selectWorld.special(),7,v+=15);
			if (selectWorld.isPlanet()) {
				g.drawString(selectWorld.empireName(),7,v+=15);
				g.drawString("pop"+selectWorld.pop()+" ind"+selectWorld.ind(),7,v+=15);
				g.drawString("min"+selectWorld.minerals()+" bb"+selectWorld.bonus(),7,v+=15);
			}
		}
	}

//--- events & actions ---
	public void action(Event e){
	int i;
		super.action(e);
		if (e.target==quit) setState(new gsPassword());
		for (i=0;i<6;i++) if (e.target==change[i]) {
			channel += delta[i];
			if (channel<0) channel = 0;
			if (channel>10000) channel = 10000;
			break;
		}
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;
	Empires ep;

		fp=null;

		value = super.handleInput(buf);

		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.INDUSTRY) setState(new gsIndustry());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		ep = gsEmpire;
		if (ep!=null && ep.channel!=channel) sendChannel();
		
		return value;
	}

	public void down(int x,int y){
	Buffer buf;
	int mx,my;
	Worlds wp;
	Fleets fp;

		if (x<0 || gsFleet==null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;
		wp = Worlds.find(mx,my);

		if (wp!=null) {
			sendFleetMove(wp.worldID());
			return;
		}

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;
		fp = Fleets.find(mx,my);

		if (fp!=null) sendFleetMove(fp.fleetID());
	}

	public void move(int x,int y){
	int mx,my;

		if (x<100) return;
		if (gsFleet==null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;

		selectWorld = Worlds.find(mx,my);
		selectFleet = Fleets.find(mx,my);
		if (selectFleet!=null && selectFleet.ghost()) selectFleet = null;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}
}