//************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//************************************************************************
#include "fileIO.hpp"

//************************************************************************
//************************************************************************
#ifdef _USE_ANSI_FILECODE_
#include <stdio.h>
#include <io.h>
#include <fcntl.h>
#include <malloc.h>
#include <string.h>


FILEID openForRead(char *path){return open(path,_O_RDONLY );}

FILEID openForWrite(char *path){return open(path,_O_WRONLY );}

FILEID openForReplace(char *path){return open(path,_O_CREAT);}

FILEID openForAppend(char *path){
FILEID fd;
	fd = open(path,_O_APPEND );
	if (!badFileIndex(fd)) fileSeekEnd(fd);
	return fd;
}

void fileClose(FILEID fd){close(fd);}

int fileWrite(FILEID fd,void *buf,int size){return write(fd,buf,size);}

int fileRead(FILEID fd,void *buf,int size){return read(fd,buf,size);}

void fileDelete(char *path){unlink(path);}

void fileRename(char *oldName,char *newName){rename(oldName,newName);}

int fileSize(FILEID fd){
int size;

	size = fileSeekEnd(fd);
	fileSeekFront(fd);
	return size;
}

int fileSeekEnd(FILEID fd){return lseek(fd,0L,2);}

int fileSeekFront(FILEID fd){return lseek(fd,0L,0);}

int fileSeekPos(FILEID fd,int pos){return lseek(fd,pos,0);}

//************************************************************************
//************************************************************************
#else	_USE_ANSI_FILECODE_
#include <stdio.h>		// for the 'rename' function

HANDLE openForRead(char *path){
HANDLE fh;
DWORD err;

	while (true) {

		fh = CreateFile(
				path,					// lpFileName
				GENERIC_READ,			// dwDesiredAccess
				FILE_SHARE_READ,		// dwShareMode, 
				NULL,					// lpSecurityAttributes, 
				OPEN_ALWAYS,			// dwCreationDistribution, 
				FILE_ATTRIBUTE_NORMAL,	// dwFlagsAndAttributes, 
				NULL					// hTemplateFile 
			);

		if (fh!=INVALID_HANDLE_VALUE) return fh;

		err = GetLastError();

		if (err==ERROR_SHARING_VIOLATION) continue;
		if (err==ERROR_LOCK_VIOLATION) continue;

		break;
	}

	return INVALID_HANDLE_VALUE;
}



HANDLE openForWrite(char *path){
HANDLE fh;
DWORD err;

	while (true) {

		fh = CreateFile(
				path,					// lpFileName
				GENERIC_WRITE,			// dwDesiredAccess
				0,						// dwShareMode, 
				NULL,					// lpSecurityAttributes, 
				OPEN_ALWAYS,			// dwCreationDistribution, 
				FILE_ATTRIBUTE_NORMAL,	// dwFlagsAndAttributes, 
				NULL					// hTemplateFile 
			);

		if (fh!=INVALID_HANDLE_VALUE) return fh;

		err = GetLastError();

		if (err==ERROR_SHARING_VIOLATION) continue;
		if (err==ERROR_LOCK_VIOLATION) continue;

		break;
	}

	return INVALID_HANDLE_VALUE;
}


HANDLE openForAppend(char *path){
HANDLE fh;
DWORD err;

	while (true) {
		fh = CreateFile(
				path,					// lpFileName
				GENERIC_WRITE,			// dwDesiredAccess
				FILE_SHARE_READ,		// dwShareMode, 
				NULL,					// lpSecurityAttributes, 
				OPEN_ALWAYS,			// dwCreationDistribution, 
				FILE_ATTRIBUTE_NORMAL,	// dwFlagsAndAttributes, 
				NULL					// hTemplateFile 
			);

		if (fh!=INVALID_HANDLE_VALUE) {
			SetFilePointer(fh,0,NULL,FILE_END);
			return fh;
		}

		err = GetLastError();

		if (err==ERROR_SHARING_VIOLATION) continue;
		if (err==ERROR_LOCK_VIOLATION) continue;

		break;
	}

	return INVALID_HANDLE_VALUE;
}


HANDLE openForReplace(char *path){
HANDLE fh;
DWORD err;

	while (true) {
		fh = CreateFile(
				path,					// lpFileName
				GENERIC_WRITE,			// dwDesiredAccess
				0,						// dwShareMode, 
				NULL,					// lpSecurityAttributes, 
				CREATE_ALWAYS,			// dwCreationDistribution, 
				FILE_ATTRIBUTE_NORMAL,	// dwFlagsAndAttributes, 
				NULL					// hTemplateFile 
			);

		if (fh!=INVALID_HANDLE_VALUE) return fh;

		err = GetLastError();

		if (err==ERROR_SHARING_VIOLATION) continue;
		if (err==ERROR_LOCK_VIOLATION) continue;

		break;
	}

	return INVALID_HANDLE_VALUE;
}


void fileDelete(char *path){
HANDLE fh;

	fh = CreateFile(
			path,						// lpFileName
			GENERIC_WRITE,				// dwDesiredAccess
			FILE_SHARE_READ,			// dwShareMode,
			NULL,						// lpSecurityAttributes,
			CREATE_ALWAYS,				// dwCreationDistribution,
			FILE_FLAG_DELETE_ON_CLOSE,	// dwFlagsAndAttributes,
			NULL						// hTemplateFile
		);

	if (fh!=INVALID_HANDLE_VALUE) CloseHandle(fh);
}

// KLUGE!!!!!
void fileRename(char *oldName,char *newName){rename(oldName,newName);}

void fileClose(FILEID fd){CloseHandle(fd);}

int fileRead(FILEID fd,void *buf,int size){
DWORD val;
	ReadFile(fd,buf,size,&val,NULL);
	return val;
}

int fileWrite(FILEID fd,void *buf,int size){
DWORD val;
	WriteFile(fd,buf,size,&val,NULL);
	return val;
}

int fileSize(FILEID fd){return GetFileSize(fd,NULL);}

int fileSeekFront(FILEID fd){return SetFilePointer(fd,0,NULL,FILE_BEGIN);}

int fileSeekEnd(FILEID fd){return SetFilePointer(fd,0,NULL,FILE_END);}

int fileSeekPos(FILEID fd,int pos){return SetFilePointer(fd,pos,NULL,FILE_BEGIN);}

//************************************************************************
#endif	_USE_ANSI_FILECODE_

//************************************************************************
//************************************************************************
// loads as '0' terminated string 

char *loadFile(char *path){
char *buf;
FILEID fd;
int size;

	fd = openForRead(path);
	if (badFileIndex(fd)) return NULL;

	size = fileSize(fd);
	buf = (char*)malloc(size+1);
	buf[size] = 0;

	fileRead(fd,buf,size);
	fileClose(fd);

	return buf;
}


char *loadHttpFile(char *path){
char *buf;
FILEID fd;
int size;

	fd = openForRead(path);
	if (badFileIndex(fd)) return NULL;

	size = fileSize(fd);
	buf = (char*)malloc(size+1);
	buf[size] = 0;

	fileRead(fd,buf,size);
	fileClose(fd);

//--- hero file alterations ---
	for (int i=0;buf[i]!=0;i++)
		if (buf[i]=='%') buf[i] = '+';

	return buf;
}



bool replaceFile(char *path,char *buf){
FILEID fd;
int size;

	fd = openForReplace(path);
	if (badFileIndex(fd)) return false;

	size = strlen(buf);
	fileWrite(fd,buf,size);
	fileClose(fd);
	
	return true;
}


bool appendFile(char *path,char *buf){
FILEID fd;
int size;

	fd = openForAppend(path);
	if (badFileIndex(fd)) return false;

	size = strlen(buf);

	fileWrite(fd,buf,size);
	fileClose(fd);

	return true;
}


bool insertFile(char *path,char *buf){
FILEID fd;
int size;
char *load;

	load = loadFile(path);

	fd = openForReplace(path);
	if (badFileIndex(fd)) return false;

	size = strlen(buf);
	fileWrite(fd,buf,size);

	if (load!=NULL) {
		size = strlen(load);
		fileWrite(fd,load,size);
	}

//--- cleanup ---
	fileClose(fd);
	free(load);
	return true;
}


bool storeFile(char *path,char *buf){
FILEID fh;
DWORD size;

	fh = openForReplace(path);
	if (badFileIndex(fh)) return false;

	size = strlen(buf);
	fileWrite(fh,buf,size);
	fileClose(fh);

	return true;
}

//************************************************************************
