import java.awt.*;
import java.applet.*;

class gsColor extends GameState {

//--- variables ---
	Button options;
	CheckboxGroup screenColor;
	Checkbox screenGreen,screenBlue,screenYellow,screenRed,screenAqua,screenPurple,screenOrange;
	CheckboxGroup boxColor;
	Checkbox boxGreen,boxBlue,boxYellow,boxRed,boxAqua,boxPurple,boxOrange;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);
	
	final String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	final int[] delta = {-100,-10,-1,1,10,100};

//--- primary functions ---
	public gsColor(){
		Graphics g;
	}

	public void init(){
		prepareTools();
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

		g.setColor(new Color(0,128,0));
		g.fillRect(0,0,500,400);

		fp = gsFleet;
		
		drawMiniMap(g);
		
		g.setColor(Color.white);
		g.drawString("Build Screen",150,30);
		g.drawString("Build Boxes",300,30);
		
	//--- draw buttons ---
			reshape(options,10,5,80,20);
		
			screenGreen.reshape(150,40,100,20);	
			screenBlue.reshape(150,60,100,20);
			screenYellow.reshape(150,80,100,20);
			screenRed.reshape(150,100,100,20);
			screenAqua.reshape(150,120,100,20);
			screenPurple.reshape(150,140,100,20);
			screenOrange.reshape(150,160,100,20);
		
			boxGreen.reshape(300,40,100,20);	
			boxBlue.reshape(300,60,100,20);
			boxYellow.reshape(300,80,100,20);
			boxRed.reshape(300,100,100,20);
			boxAqua.reshape(300,120,100,20);
			boxPurple.reshape(300,140,100,20);
			boxOrange.reshape(300,160,100,20);
			
	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(55,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,60,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}
	}

	public void action(Event e) {
		if (e.target==options) setState(new gsOptions());
		
		if (e.target==screenGreen) SCREEN_COLOR = new Color(0,128,0);
		if (e.target==screenBlue) SCREEN_COLOR = new Color(40,30,160);
		if (e.target==screenYellow) SCREEN_COLOR = Color.yellow;
		if (e.target==screenRed) SCREEN_COLOR = new Color(180,30,60);
		if (e.target==screenAqua) SCREEN_COLOR = new Color(30,160,160);
		if (e.target==screenPurple) SCREEN_COLOR = new Color(160,30,160);
		if (e.target==screenOrange) SCREEN_COLOR = Color.orange;
		
		if (e.target==boxGreen) BOX_COLOR = new Color(0,128,0);
		if (e.target==boxBlue) BOX_COLOR = new Color(40,30,160);
		if (e.target==boxYellow) BOX_COLOR = Color.yellow;
		if (e.target==boxRed) BOX_COLOR = new Color(180,30,60);
		if (e.target==boxAqua) BOX_COLOR = new Color(30,160,160);
		if (e.target==boxPurple) BOX_COLOR = new Color(160,30,160);
		if (e.target==boxOrange) BOX_COLOR = Color.orange;
	}
	
	final static int MAPW = 50;
	final static Rectangle map = new Rectangle(10,40,2*MAPW,2*MAPW);

	void drawMiniMap(Graphics g){
	int cx,cy,size,x,y,dx,dy;
	Worlds wp;
	Fleets fp;
	Color c;

		g.setColor(Color.black);
		g.fillRect(map.x,map.y,map.width,map.height);

		fp = gsFleet;
		if (fp==null) return;

		cx = fp.xloc();
		cy = fp.yloc();
		dx = map.x + MAPW;
		dy = map.y + MAPW;

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {

			switch (wp.type()) {
				case 16: g.setColor(wp.NEBULAE_COLOR); size = wp.NEBULAE_SIZE; break;
				case 17: g.setColor(wp.NEUTRON_COLOR); size = wp.NEUTRON_SIZE; break;
				case 18:
					x = StarDart.cycle;
					c = new Color(
						((x&32)==0?8*(x&31):252-8*(x&31)),
						((x&16)==0?16*(x&15):248-16*(x&15)),
						((x&64)==0?4*(x&63):253-4*(x&63))	
					); 
					size = wp.WORLD_SIZE; 
					break;
				default: g.setColor(wp.WORLD_COLOR); size = wp.WORLD_SIZE; break;
			}

			x = (wp.xloc()-cx) * MAPW / wp.scale;
			if (x+size<-MAPW || x-size>MAPW) continue;
			y = (wp.yloc()-cy) * MAPW / wp.scale;
			if (y+size<-MAPW || y-size>MAPW) continue;

			size = size * MAPW / wp.scale;
			g.fillOval(dx+x-size,dy+y-size,2*size+1,2*size+1);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {

			if (fp.ghost()) continue;

			x = (fp.xloc()-cx) * MAPW / wp.scale;
			if (x<-MAPW || x>MAPW) continue;
			y = (fp.yloc()-cy) * MAPW / wp.scale;
			if (y<-MAPW || y>MAPW) continue;

			wp = Worlds.get(fp.destID);
			if (wp!=null) {
				g.setColor(Color.blue);
				g.drawLine(dx+x,dy+y,
					dx+(wp.xloc()-cx) * MAPW / wp.scale,
					dy+(wp.yloc()-cy) * MAPW / wp.scale);
			}

			g.setColor(Color.red);
			g.fillRect(dx+x-1,dy+y-2,5,3);
		}

	//--- cut rects ---
		g.setColor(new Color(0,128,0));
		g.fillRect(0,map.y+map.height,500,400-map.y-map.height);
		g.fillRect(map.x+map.width,0,500-map.x-map.width,map.y+map.height);
		g.fillRect(map.x,0,map.width,map.y);
		g.fillRect(0,0,map.x,map.y+map.height);
	}

	public void move(int x,int y){
	int mx,my;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}
	
//--- tool functions ---
	void prepareTools(){
		root.add(options = new Button("Options"));

		screenColor = new CheckboxGroup();
		root.add(screenGreen = new Checkbox("Green",true,screenColor));		
		root.add(screenBlue = new Checkbox("Blue",false,screenColor));
		root.add(screenYellow = new Checkbox("Yellow",false,screenColor));
		root.add(screenRed = new Checkbox("Red",false,screenColor));
		root.add(screenAqua = new Checkbox("Aqua",false,screenColor));
		root.add(screenPurple = new Checkbox("Purple",false,screenColor));
		root.add(screenOrange = new Checkbox("Orange",false,screenColor));
		
		boxColor = new CheckboxGroup();
		root.add(boxGreen = new Checkbox("Green",false,boxColor));		
		root.add(boxBlue = new Checkbox("Blue",false,boxColor));
		root.add(boxYellow = new Checkbox("Yellow",true,boxColor));
		root.add(boxRed = new Checkbox("Red",false,boxColor));
		root.add(boxAqua = new Checkbox("Aqua",false,boxColor));
		root.add(boxPurple = new Checkbox("Purple",false,boxColor));
		root.add(boxOrange = new Checkbox("Orange",false,boxColor));
	}
}