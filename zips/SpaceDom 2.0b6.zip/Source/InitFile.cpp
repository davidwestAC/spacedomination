//**********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************
#include "fileIO.hpp"
#include "string.hpp"
#include <stdio.h>

//**********************************************************************

const char *INITFILE = "SDserver.ini";

char *headTest = "[StarDart]\n";

char dataPath[128],htmlPath[128];
int portNum,maxPlayers,fleetDecayRate,decayRate,victoryBase,movePixels,commandBuild,minWorlds;
int highWorlds,dropHours,firstEarthDeclareRatio,raceHomeDeclareRatio;
int firstPhenomenaDeclareRatio,racePhenomenaDeclareRatio;
int laterEarthDeclareRatio,laterPhenomenaDeclareRatio,maxSpeed;

//**********************************************************************

bool readInitFile(){
char line[1024],temp[256];
char *data;
int ix,i;

	dataPath[0] = 0;
	htmlPath[0] = 0;

	portNum = 1965;
	maxPlayers = 200;
	fleetDecayRate = 100;
	decayRate = 200;
	victoryBase = 50;
	movePixels = 150;
	commandBuild = 1000;
	minWorlds = 100;
	highWorlds = 10000;
	dropHours = 8;
	firstEarthDeclareRatio = 8;
	raceHomeDeclareRatio = 4;
	firstPhenomenaDeclareRatio = 6;
	racePhenomenaDeclareRatio = 3;
	laterEarthDeclareRatio = 12;
	laterPhenomenaDeclareRatio = 10;
	maxSpeed = 300;

//--- load & read file ---
	data = (char*)loadFile((char*)INITFILE);
	if (data==NULL) return false;

	i = search(data,headTest);
	if (i<0) return false;

	ix = i;
	while (true) {
		i = readToken(data+ix,line,'=');
		if (i<0) break;

		ix += i;

		if (equalsCI("DATAPATH",line)) {
			i = readToken(data+ix,dataPath,'\n');
		}
		else if (equalsCI("HTMLPATH",line)) {
			i = readToken(data+ix,htmlPath,'\n');
		}
		else if (equalsCI("PORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&portNum);
		}
		else if (equalsCI("MAXPLAYERS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxPlayers);
		}
		else if (equalsCI("FLEETATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&fleetDecayRate);
		}
		else if (equalsCI("WORLDATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&decayRate);
		}
		else if (equalsCI("VICTORYBASE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&victoryBase);
		}
		else if (equalsCI("MOVEMENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&movePixels);
		}
		else if (equalsCI("COMMAND",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBuild);
		}
		else if (equalsCI("MINWORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minWorlds);
		}
		else if (equalsCI("MAXWORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&highWorlds);
		}
		else if (equalsCI("DROPHOURS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dropHours);
		}
		else if (equalsCI("FIRSTEARTHDECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstEarthDeclareRatio);
		}
		else if (equalsCI("RACEHOMEDECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&raceHomeDeclareRatio);
		}
		else if (equalsCI("FIRSTPHENOMENADECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstPhenomenaDeclareRatio);
		}
		else if (equalsCI("RACEPHENOMENADECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&racePhenomenaDeclareRatio);
		}
		else if (equalsCI("LATEREARTHDECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterEarthDeclareRatio);
		}
		else if (equalsCI("LATERPHENOMENADECLARERATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterPhenomenaDeclareRatio);
		}
		else if (equalsCI("MAXSPEED",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxSpeed);
		}
		else {
			i = search(data+ix,"\n");
		}

		if (i<0) break;

		ix += i;
	}

//--- cleanup ---
	printf("Space Domination Version 2.0 Configuration Values:\n");
	printf("DATAPATH=%s\n",dataPath);
	printf("HTMLPATH=%s\n",htmlPath);
	printf("PORT=%d\n",portNum);
	printf("MAXPLAYERS=%d\n",maxPlayers);
	printf("FLEETATTRITION=%d\n",fleetDecayRate);
	printf("WORLDATTRITION=%d\n",decayRate);
	printf("VICTORYBASE=%d\n",victoryBase);
	printf("MOVEMENT=%d\n",movePixels);
	printf("COMMAND=%d\n",commandBuild);
	printf("MINWORLDS=%d\n\n",minWorlds);
	printf("MAXWORLDS=%d\n",highWorlds);
	printf("DROPHOURS=%d\n",dropHours);
	printf("FIRSTEARTHDECLARERATIO=%d\n",firstEarthDeclareRatio);
	printf("RACEHOMEDECLARERATIO=%d\n",raceHomeDeclareRatio);
	printf("FIRSTPHENOMENADECLARERATIO=%d\n",firstPhenomenaDeclareRatio);
	printf("RACEPHENOMENADECLARERATIO=%d\n",racePhenomenaDeclareRatio);
	printf("LATEREARTHDECLARERATIO=%d\n",laterEarthDeclareRatio);
	printf("LATERPHENOMENADECLARERATIO=%d\n",laterPhenomenaDeclareRatio);
	printf("MAXSPEED=%d\n",maxSpeed);

	free(data);
	return true;
}

//**********************************************************************
