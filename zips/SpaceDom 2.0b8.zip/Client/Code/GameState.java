import java.awt.*;
import java.applet.*;

class GameState implements MessageValues {

//--- global values ---
	static StarDart root;

	static String message = "";

	public static int setRace = 0;

	final static int MAX_CHAT = 5;
	static String[] chatMsg = new String[MAX_CHAT];
	static long[] chatTime = new long[MAX_CHAT];

	public static int gsEmpireID,gsFleetID;
	public static Empires gsEmpire=null;
	public static Fleets gsFleet=null;
	public static int fleetStatus=Fleets.DEAD;

	public final static Font hugeFNT = new Font("TimesRoman",Font.BOLD,116);
	public final static Font bigFNT = new Font("TimesRoman",Font.BOLD,50);
	public final static Font stoutFNT = new Font("TimesRoman",Font.BOLD,24);
	public final static Font textFNT = new Font("TimesRoman",Font.PLAIN,14);
	public final static FontMetrics hugeMET = new Button().getFontMetrics(hugeFNT);
	public final static FontMetrics bigMET = new Button().getFontMetrics(bigFNT);
	public final static FontMetrics stoutMET = new Button().getFontMetrics(stoutFNT);
	public final static FontMetrics textMET = new Button().getFontMetrics(textFNT);

	public static Color SCREEN_COLOR = new Color(0,128,0);
	public static Color BOX_COLOR = Color.yellow;

	static int[] top20List = {-1,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0};
	static int channel = 0;

//--- constructors ---
	public GameState(){
		root.setFont(textFNT);
		//fmet = root.getFontMetrics(root.getFont());
	}

	public void init(){}

	public static void setState(GameState gs){
		root.removeAll();	// kill tools
		StarDart.state = gs;
		gs.init();
		root.repaint();
		root.requestFocus();
	}

//--- primary functions ---
	public void paint(Graphics g){}

	public void action(Event e){}

	public void down(int x,int y){}
	public void raise(int x,int y){}
	public void move(int x,int y){}
	public void drag(int x,int y){}

	public boolean press(int key){
	int len;

		if (!(this instanceof gsPassword)) root.requestFocus();

		if (key==10) {	// send
			sendMessage();
			message = "";
		}
		else if (key==8) {	// backspace
			len = message.length();
			if (len>0) message = message.substring(0,len-1);
		}
		else {
			message += ""+(char)(key);
		}

		return true;
	}

	public boolean isMovingStatus(){return (fleetStatus<=Fleets.NEUTRON);}

//--- handle common inputs ---
	public boolean handleInput(Buffer buf){
		//System.out.println("Message="+buf.get(1));

		switch(buf.get(1)){
			case WORLD_SCAN: Worlds.add(buf); return true;
			case FLEET_SCAN: Fleets.add(buf); return true;
			case EMPIRE_SCAN: Empires.add(buf); return true;
			case COMBAT_SCAN: Fleets.combat(buf); return true;
			case BUILD_SCAN: Worlds.build(buf); return true;
			case TOP20_SCAN: readTop20List(buf); return true;

			case SECTOR_FLEETS: Fleets.scan(buf); return true;
			case SECTOR_WORLDS: Worlds.scan(buf); return true;

			case MESSAGE: chatAdd(buf); return true;
			case STATUS: 
				fleetStatus = buf.get(2); 
				sendPing();
				return true;

			case VICTORY:
				setState(new gsVictory(buf));
				return true;
		}
		
		return false;
	}

//--- tool utilities ---
	void reshape(Component cp,int x,int y,int w,int h){cp.reshape(x,y,w,h);}

	void readTop20List(Buffer buf){
	int len;

		len = buf.length();
		for (int i=0;i<20 && 2+i*4<len;i++) {
			top20List[i] = buf.getInt(2+i*4);
			sendEmpireQuery(top20List[i]);
		}
	}

//--- handle chat messages ---
	public int chatCount(){
	int ix,count;
	long time;

		time = System.currentTimeMillis();

		for (count=ix=0;ix<MAX_CHAT;ix++) {
			if (chatTime[ix]>time)	count++;
			else					chatMsg[ix] = null;
		}

		return count;
	}

	public String chatLine(int i){return chatMsg[i];}

	public void chatAdd(Buffer buf){
	String msg;
	int ix;

		msg = "";
		for(ix=2;ix<buf.length();ix++) msg += (char)buf.get(ix);

		for (ix=MAX_CHAT-1;ix>0;ix--) {
			chatMsg[ix] = chatMsg[ix-1];
			chatTime[ix] = chatTime[ix-1];
		}

		chatMsg[0] = msg;
		chatTime[0] = System.currentTimeMillis() + 1000 * 20;
	}

//--- common messages ---
	static void sendQuickMessage(int message){
	Buffer buf;

		buf = new Buffer(2);
		buf.set(0,2);
		buf.set(1,message);
		buf.send();
	}

	public static void sendSessionDone(){sendQuickMessage(SESSION_DONE);}

	public static void sendPing(){sendQuickMessage(SESSION_PING);}

	public static void sendTop20Query(){sendQuickMessage(TOP20_QUERY);}

	public static void sendRebirthRequest(){sendQuickMessage(REBIRTH_REQUEST);}

	public static void sendStatsQuery(){sendQuickMessage(STATS_QUERY);}

	public static void sendSettingsQuery(){sendQuickMessage(SETTINGS_QUERY);}

	public static void sendRestart(){sendQuickMessage(RESTART);}

	public static void signalLaunch(){sendFleetMove(-1);}

	public static void sendFleetMove(int dest){
	Buffer buf;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,SET_DESTINATION);
		buf.setShort(2,dest);
		buf.send();
	}

	public static void sendTransfer(Fleets fp,int index,boolean lift){
	Squadron sp=null;
	Buffer buf;
	int pos,ix;

		if (fp==null) return;

		for (pos=0;pos<6;pos++) {
			sp = fp.squads(pos);
			if (sp==null || sp.type==sp.SHIP_TYPES) continue;
			if (--index==0) break;
		}

		buf = new Buffer(8);
		buf.set(0,8);
		buf.set(1,FLEET_TRANSFER);
		buf.setShort(2,(sp.type()==sp.STARDART?1:sp.count()));
		buf.set(6,sp.type());
		buf.set(7,(lift?1:0));
		buf.send();
	}

	public static void sendChannel(){
	Buffer buf;

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,CHAT_CHANNEL);
		buf.setInt(2,channel);
		buf.send();
	}

	public static void sendMessage(){
	Buffer buf;
	int len;

		len = message.length();
		if (len==0) return;

		if (len>100) {
			message = message.substring(0,100);//all 253
			len = 100;
		}

		buf = new Buffer(len+2);
		buf.set(0,len+2);
		buf.set(1,CHAT_MESSAGE);
		for (int i=0;i<len;i++) buf.set(i+2,message.charAt(i));
		buf.send();
	}

	public static void sendRace(){
	Buffer buf;

		buf = new Buffer(8);
		buf.set(0,8);
		buf.set(1,RACE_CHANGE);
		buf.setInt(4,setRace);
		buf.send();
	}

	public static void sendEmpireQuery(int id){
	Buffer buf;

		if (id<0) return;
		
		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,EMPIRE_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendFleetQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,FLEET_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendWorldQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,WORLD_QUERY);
		buf.setShort(2,id);
		buf.send();
	}
}
