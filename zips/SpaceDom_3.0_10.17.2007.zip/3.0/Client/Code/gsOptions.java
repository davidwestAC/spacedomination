import java.awt.*;
import java.applet.*;
import java.awt.image.*;

class gsOptions extends GameState {

	Button quit,launch;
	Button top10,stats,settings;
	Button change[];
	Checkbox useSmooth;
	Checkbox autoBuild;
	Checkbox autoInd;
	boolean fromMovement;
	long lastTime;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final String[] ChanStr = {"-C","-D","-I","+C","+D","+I"};
	final int[] delta = {-100,-10,-1,100,10,1};
	
	Buffer statBuf = null;
	Buffer setBuf = null;
	public static Portrait fleetIcon[] = null;

	public gsOptions(boolean from) {
		Graphics g;
		fromMovement = from;
	}

	public void init() {
		sendTop20Query();
		sendStatsQuery();
		sendSettingsQuery();
		lastTime = System.currentTimeMillis();
		
		root.add(quit = new Button("Quit"));
		root.add(launch = new Button("Return"));
		root.add(useSmooth = new Checkbox("Smooth"));
		useSmooth.setBackground(SCREEN_COLOR);
		useSmooth.setForeground(Color.white);
		useSmooth.setState(GameState.smooth);
		root.add(autoBuild = new Checkbox("Auto Build"));
		autoBuild.setBackground(SCREEN_COLOR);
		autoBuild.setForeground(Color.white);
		autoBuild.setState(GameState.autoBuild);
		root.add(autoInd = new Checkbox("Auto Ind"));
		autoInd.setBackground(SCREEN_COLOR);
		autoInd.setForeground(Color.white);
		autoInd.setState(GameState.autoInd);
		change = new Button[6];
		for (int i=0;i<6;i++) root.add(change[i] = new Button(ChanStr[i]));
		fleetIcon = new Portrait[8];
		for (int i=0; i<8; i++) {
			fleetIcon[i] = SpaceDom.ships[i][0];
		}
		setBounds(launch,9,5,50,20);
		setBounds(quit,445,380,50,20);
		setBounds(useSmooth,370, 380, 70, 20);
		setBounds(autoInd,370, 365, 80, 20);
		setBounds(autoBuild,370, 350, 80, 20);
		for (int i=0;i<6;i++) setBounds(change[i],415+(i%3)*25,265+(i/3)*15,25,15);
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int val,count;

		long currentTime = System.currentTimeMillis();
		if (currentTime - lastTime > 10000) {
			sendTop20Query();
			sendStatsQuery();
			sendSettingsQuery();
			lastTime = currentTime;
		}

		g.setColor(SCREEN_COLOR);
		g.fillRect(0,0,500,400);

		fp = gsFleet;

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals
		
		drawEmpireStats(g,180,182);
		showTop10List(g,120,20);
		showGameStats(g,9,165,Color.white);
		drawChannelStats(g,415,245);
		
		drawChatMessages(g);
	}

	void drawChannelStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	
		g.setColor(Color.white);
		ep = gsEmpire;
		
		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
	}

	public void drawEmpireStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	int val1,val2,val3;
	float wb1,wb2;

		if (setBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}
		int offset = 2;
		int minWorlds =							setBuf.getInt(offset);
		int maxWorlds =							setBuf.getInt(offset+=4);
		int vicStart =							setBuf.getInt(offset+=4);
		int vicDrop =							setBuf.getInt(offset+=4);
		int gameHours =							setBuf.getInt(offset+=4);
		int timeShiftSessionHours =				setBuf.getInt(offset+=4);
		int timeShiftSkipDays =					setBuf.getInt(offset+=4);
		int command =							setBuf.getInt(offset+=4);
		int commandBonus =						setBuf.getInt(offset+=4);
		int merchantBonus =						setBuf.getInt(offset+=4);
		int merchantBonusType =					setBuf.getInt(offset+=4);
		int beaconBonus =						setBuf.getInt(offset+=4);
		int stardockWorldBonus =				setBuf.getInt(offset+=4);
		int stardockFleetBonus =				setBuf.getInt(offset+=4);
		int shieldBonus =						setBuf.getInt(offset+=4);
		int speed =								setBuf.getInt(offset+=4);
		int maxSpeed =							setBuf.getInt(offset+=4);
		int fleetDecay =						setBuf.getInt(offset+=4);
		int worldDecay =						setBuf.getInt(offset+=4);
		int facilityUpdate =					setBuf.getInt(offset+=4);
		int firstEarthDeclareRatio =			setBuf.getInt(offset+=4);
		int firstPhenomenaDeclareRatio =		setBuf.getInt(offset+=4);
		int laterEarthDeclareRatio =			setBuf.getInt(offset+=4);
		int laterPhenomenaDeclareRatio =		setBuf.getInt(offset+=4);
		int firstHomeDeclareRatio =				setBuf.getInt(offset+=4);
		int firstHomePhenomenaDeclareRatio =	setBuf.getInt(offset+=4);
		offset+=4;

		g.setColor(Color.white);
		ep = gsEmpire;

		g.drawString(ep.name(),h,v);		
		g.drawString("Race: "+ep.racename(),h,v+=15);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Phenomena: "+ep.phenom(),h,v+=15);
		g.drawString("Total Darts: "+ep.darts(),h,v+=15);
		g.drawString("Score Darts: "+ep.scoreDarts(),h,v+=15);
		g.drawString("Score: "+ep.score(),h,v+=15);

		h=290;
		v=190;
		g.drawString("Empire Facilities",h,v);
		g.drawString("Merchants: "+ep.Merchant(),h,v+=25);
		g.drawString("Cmd Build = "+ep.commandBuild(),h,v+=15);

		g.drawString("World Build = "+ep.worldBuild(),h,v+=15);
		
		g.drawString("Beacons: "+ep.Beacon(),h,v+=25);
		g.drawString("Cmd Speed = "+ep.commandSpeed(),h,v+=15);
		
		g.drawString("Stardocks: "+ep.Stardock(),h,v+=25);
		g.drawString("Cmd Decay = 1/"+ep.commandDecay(),h,v+=15);
		g.drawString("World Decay = 1/"+ep.worldDecay(),h,v+=15);
		g.drawString("Stellurae: "+ep.Stellurae(),h,v+=25);
	}

	void showTop10List(Graphics g,int h,int v){
	Empires emp;
	String name;
	int i;

		g.setColor(Color.white);
		g.drawString("Top 10 List",h+20,v);
		g.drawString("Score",h+120,v);
		g.drawString("Worlds",h+180,v);
		g.drawString("Darts",h+260,v);
		g.drawString("Race",h+330,v);
		v += 2;

		for (i=0;i<10;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			emp = Empires.get(top20List[i]);
			if (emp.online == 1) {
				g.drawString("*",h-10,v+=14);
				g.drawString(""+(i+1)+"> "+name,h,v);
			}else {
				g.drawString(""+(i+1)+"> "+name,h,v+=14);
			}
			g.drawString(""+emp.hiScore,h+120,v);
			g.drawString(""+emp.worlds + "/" + emp.hiWorlds,h+180,v);
			g.drawString(""+emp.darts + "/" + emp.hiDarts,h+260,v);
			int raceid = 0;
			raceid = emp.race();
			if (raceid < 0 || raceid > 7) {
				raceid=0;
			}
			fleetIcon[raceid].center(g,h+345,v-5);
		}
		if (i==0) g.drawString("List Empty",h,v+=14);
	}

	public void move(int x,int y) {
		int mx,my;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.contains(x,y);
	}

	public boolean handleInput(Buffer buf){
		Empires ep;
		Fleets fp=null;

		ep = gsEmpire;
		if (ep!=null && ep.channel!=channel) sendChannel();

		/*
		** Need to check for these before call to super.handleInput
		** so as to handle them here and not there.
		*/
		if (buf!=null) switch (buf.get(1)) {
			case STATS_RESULT:
				statBuf = buf;
				break;
				
			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}

		if (super.handleInput(buf)) return true;

		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		return false;
	}

	public void action(Event e) {
		int id;
		int i;

		super.action(e);

		if (e.target==launch) {
			if (fromMovement) {
				setState(new gsMovement());
			} else {
				setState(new gsIndustry());
			}
		}
		if (e.target==quit) {
			setState(new gsPassword());
			sendQuit();
		}
		if(e.target == useSmooth) {
			GameState.smooth = useSmooth.getState();
		}
		if(e.target == autoBuild) {
			GameState.autoBuild = autoBuild.getState();
		}
		if(e.target == autoInd) {
			GameState.autoInd = autoInd.getState();
		}
		for (i=0;i<6;i++) if (e.target==change[i]) {
			channel += delta[i];
			if (channel<0) channel = 0;
			if (channel>10000) channel = 10000;
			break;
		}
	}

	public boolean press(int key) {
		switch (key) {
			case 9:	// Tab
				if (fromMovement) {
					setState(new gsMovement());
				} else {
					setState(new gsIndustry());
				}
				return false;
		}
		return super.press(key);
	}
}