//*****************************************************************
//	copyright 1998, Fred's Friends, Inc.
//*****************************************************************
#include "CRecords.hpp"
#include "fileio.hpp"

//*****************************************************************

const int BlockCount = 100;

//*****************************************************************

CRecords::CRecords(char *path,int tag,int rec){
FILEID fh;
int size;

//--- fixed values ---
	file = NULL;
	currentRecord = NULL;
	if (tag>rec) tag = rec;
	tagSize = (tag<0?0:tag);
	recSize = (rec<0?0:rec);
	currentIndex = -1;
	count = 0;

//--- allocated values ---
	size = strlen(path);
	file = (char*)malloc(size+1);
	if (file==NULL) return;

	strcpy(file,path);

	fh = openForRead(file);
	if (!badFileIndex(fh)) {
		count = fileSize(fh) / recSize;
		fileClose(fh);
	}

	currentRecord = malloc(recSize);
	if (currentRecord==NULL) return;

	memset(currentRecord,0,recSize);
}


CRecords::~CRecords(){
	free(file);
	free(currentRecord);
}


void CRecords::clear(){
	fileDelete(file);
	currentIndex = -1;
	count =0;
}

//*****************************************************************

bool CRecords::findEmpty(){
static int blank = 0;

	return search(&blank);
}


bool CRecords::pickIndex(int index){
FILEID fh;
int size;

	currentIndex = -1;
	if (index<0 || index>=count) return false;

	fh = openForRead(file);
	if (badFileIndex(fh)) return false;

	size = fileSize(fh);
	count = size / recSize;

//--- load record ---
//	if (index<count) {
		fileSeekPos(fh,index*recSize);
		fileRead(fh,currentRecord,recSize);
		currentIndex = index;
//	}

//--- cleanup ---
	fileClose(fh);
	return true;
}

bool CRecords::first(void){return pickIndex(0);}

bool CRecords::next(void){
	if (currentIndex<0 ) return false;
	return pickIndex(currentIndex+1);
}

//*****************************************************************
//	loads Num records from the currentIndex, 
//	incrementing the currentIndex by num

int CRecords::LoadNumRecords(void *block,int num){
FILEID fh;
int size,read;

	if (currentIndex<0) return 0;

	fh = openForRead(file);
	if (badFileIndex(fh)) return 0;

	size = fileSize(fh);
	count = size / recSize;
	read = 0;

//--- load records ---
	fileSeekPos(fh,currentIndex*recSize);
	read = fileRead(fh,block,recSize * num);
	read = read / recSize;

//--- update current info ---
	currentIndex += read;
	if (currentIndex >= count) {
		currentIndex = -1;
	}
	else {
		fileRead(fh,currentRecord,recSize);
	}
	
//--- cleanup ---
	fileClose(fh);
	return read;
}

//*****************************************************************

bool CRecords::search(void *tag){
void *data,*recPtr;
int ix,block,size,blockSize,blockRecs;
FILEID fh;
bool found;

	if (tagSize==0) return false;		// no way to match a zero sized tag

//--- current = tag ? ---
	if (currentIndex>=0) {
		if (tagSize==4) {
			if ((*(int*)tag)==(*(int*)currentRecord)) return true;
		}
		else {
			if (equalsCI((char*)tag,(char*)currentRecord)) return true;
		}
	}

//--- prepare values ---
	count = 0;
	currentIndex = -1;

	blockSize = BlockCount * recSize;
	data = malloc(blockSize);
	if (data==NULL) return false;		// need loading space

	fh = openForRead(file);
	if (badFileIndex(fh)) {
		free(data);
		return false;					// can't open file
	}

	count = fileSize(fh) / recSize;

	found = false;
	block = 0;

//--- integer tag test ---
	if (tagSize==4) {
		do {
			size = fileRead(fh,data,blockSize);
			blockRecs = size / recSize;

			for (ix=0;ix<blockRecs;ix++) {
				recPtr = (char*)data + ix*recSize;
				if ((*(int*)recPtr)==(*(int*)tag)) continue;	// test 'tag'
				
				currentIndex = block * BlockCount + ix;
				memcpy(currentRecord,recPtr,recSize);
				found = true;
				break;
			}

			block++;

		} while (!found && size>=blockSize);
	}
//--- string tag test ---
	else {
		do {
			size = fileRead(fh,data,blockSize);
			blockRecs = size / recSize;

			for (ix=0;ix<blockRecs;ix++) {
				recPtr = (char*)data + ix*recSize;
				if (!equalsCI((char*)recPtr,(char*)tag)) continue;
				
				currentIndex = block * BlockCount + ix;
				memcpy(currentRecord,recPtr,recSize);
				found = true;
				break;
			}

			block++;

		} while (!found && size>=blockSize);
	}


//--- cleanup ---
	fileClose(fh);
	free(data);
	return found;			// record found or not
}


bool CRecords::testSearch(bool (*test)(void *record)){
char *data,*recPtr;
int ix,block,size,blockSize,blockRecs;
FILEID fh;
bool found;

	count = 0;
	currentIndex = -1;

	blockSize = BlockCount * recSize;
	data = (char*)LocalAlloc(GMEM_FIXED,blockSize);
	if (data==NULL) return false;		// need loading space

	fh = openForRead(file);
	if (badFileIndex(fh)) {
		LocalFree(data);
		return false;					// can't open file
	}

	count = fileSize(fh) / recSize;

//--- start loading records ---
	found = false;
	block = 0;

	do {
		size = fileRead(fh,data,blockSize);
		blockRecs = size / recSize;

		for (ix=0;ix<blockRecs;ix++) {
			recPtr = (char*)data + ix*recSize;
			if (!test(recPtr)) continue;	// test record attributes
			
			currentIndex = block * BlockCount + ix;
			memcpy(currentRecord,recPtr,recSize);
			found = true;
			break;
		}

		block++;

	} while (!found && size>=blockSize);


//--- cleanup ---
	fileClose(fh);
	LocalFree(data);
	return found;			// record found or not
}

//*****************************************************************

bool CRecords::change(int index,void *record){
	if (index!=currentIndex && !pickIndex(index)) return false;

	memcpy(currentRecord,record,recSize);
	if (change()) return true;

	currentIndex = -1;
	return false;
}


bool CRecords::change(void *record){

	if (!search(record)) return false;	// find record

	memcpy(currentRecord,record,recSize);
	if (change()) return true;

	currentIndex = -1;
	return false;
}


bool CRecords::change(void){
FILEID fh;

	fh = openForWrite(file);
	if (badFileIndex(fh)) return false;

	fileSeekPos(fh,currentIndex * recSize);
	fileWrite(fh,currentRecord,recSize);

	fileClose(fh);
	return true;
}


bool CRecords::create(void *record){
FILEID fh;
int size;

	if (search(record)) return false;

	if (findEmpty()) {
		fh = openForWrite(file);
		if (badFileIndex(fh)) return false;
		fileSeekPos(fh,currentIndex * recSize);
	}
	else {
		fh = openForAppend(file);
		if (badFileIndex(fh)) return false;
		fileSeekEnd(fh);
		size = fileSize(fh);
		currentIndex = size / recSize;
		count = currentIndex + 1;
	}

	fileWrite(fh,record,recSize);

	fileClose(fh);

//--- cleanup ---
	memcpy(currentRecord,record,recSize);
	return true;
}

//*****************************************************************

bool CRecords::kill(void *tag){

	if (!search(tag)) return false;	// find record

	if (kill()) return true;

	currentIndex = -1;
	return false;
}


bool CRecords::kill(void){
FILEID fh;

	fh = openForWrite(file);
	if (badFileIndex(fh)) return false;

	fileSeekPos(fh,currentIndex * recSize);

	memset(currentRecord,0,recSize);
	fileWrite(fh,currentRecord,recSize);

	fileClose(fh);
	return true;
}

//*****************************************************************
// copy file, removing all blank tags
//*****************************************************************

static char *StashFile = "Compact.dat";

void CRecords::compact(){
FILEID fromID,toID;
int ix,size;

	fileRename(file,StashFile);

	fromID = openForRead(StashFile);
	if (badFileIndex(fromID)) {
		fileRename(StashFile,file);
		return;
	}

	toID = openForReplace(file);
	if (badFileIndex(toID)) {
		fileClose(fromID);
		fileRename(StashFile,file);
		return;
	}

//--- start xfering files ---
	size = fileSize(fromID);
	count = size / recSize;

	for (ix=0;ix<count;ix++) {
		fileRead(fromID,currentRecord,recSize);
		if ((*(int*)currentRecord)==0) continue;
		fileWrite(toID,currentRecord,recSize);
	}

//--- cleanup ---
	fileClose(toID);
	fileClose(fromID);
	currentIndex = -1;

	fileDelete(StashFile);
}

//*****************************************************************
//*****************************************************************

CLists::CLists(char *path,int rec){

	list = NULL;
	file = NULL;
	recSize = rec;
	count = 0;

	file = (char*)malloc(strlen(path)+1);
	if (file==NULL) return;

	strcpy(file,path);
	load();
}


CLists::~CLists(){
	save();
	if (file!=NULL) free(file);
	if (list!=NULL) free(list);
}

//*****************************************************************

int CLists::increment(){
	count++;
	save();
	load();
	return count-1;
}


void CLists::expand(int num){
void *oldList;
int oldCount;

//	if (num<=count) return;
	if (num<count) return;

	oldList = list;
	oldCount = count;
	list = NULL;

	allocate(1 + num/BLOCK_RECS);
	count = num;

	if (oldList!=NULL) {
		memcpy(list,oldList,oldCount*recSize);
		free(oldList);
	}

	save();
}


void CLists::allocate(int needs){
	if (needs==blocks) return;
	if (list!=NULL) {
		free(list);
		list = NULL;
	}
	if (needs>0) list = malloc(recSize * needs * BLOCK_RECS);
	blocks = needs;
}


void CLists::clear(){
	fileDelete(file);
	allocate(0);
	count = 0;
}


void CLists::save(){
FILEID fh;

	if (file==NULL || list==NULL || count<1) return;

	fh = openForReplace(file);
	if (badFileIndex(fh)) return;

	fileWrite(fh,list,count*recSize);
	fileClose(fh);
}


void CLists::save(int index){
FILEID fh;

	if (list==NULL || file==NULL || index<0 || index>=count) return;

	fh = openForWrite(file);
	if (badFileIndex(fh)) return;

	fileSeekPos(fh,index * recSize);
	fileWrite(fh,(byte*)list+index*recSize,recSize);

	fileClose(fh);
}


void CLists::load(){
FILEID fh;
int size;

	if (file==NULL) return;

	fh = openForRead(file);
	if (badFileIndex(fh)) return;

	size = fileSize(fh);
	count = size / recSize;

	allocate(1 + count/BLOCK_RECS);
	if (list==NULL) return;

	fileRead(fh,list,size);
	fileClose(fh);
}

//*****************************************************************
