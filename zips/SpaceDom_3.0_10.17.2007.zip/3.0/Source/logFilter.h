#ifndef _LOGFILTER_H
#define _LOGFILTER_H

class LogFilter {
	private:
		int m_first_id;
		int m_last_id;
		LogFilter *m_pNext;

	public:
		LogFilter(int log_id);
		LogFilter(int first_id, int last_id);
		~LogFilter();
		void next(LogFilter *next);
		LogFilter* next();
		void getRange(int *first_id, int *last_id);
		bool matches(int log_id);
};

class LogFilterList {
	private:
		LogFilter *m_pRoot;
	public:
		LogFilterList();
		~LogFilterList();
		LogFilter* first() {return m_pRoot;}
		void add(int log_id);
		void add(int first_id, int last_id);
		bool contains(int log_id);
};
#endif // _LOGFILTER_H
