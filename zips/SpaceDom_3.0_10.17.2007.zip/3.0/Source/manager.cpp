//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"

//***************************************************************************
//***************************************************************************

bool commandManager(void);
void cmdPrompt(void);

//***************************************************************************

char commandLine[80];
int cmdIX=0;
bool managerShowChat = false;

//***************************************************************************
//***************************************************************************

bool prepareManager() {
	printf("\nSpace Domination Text Based Manager v3.0\n");
	cmdPrompt();

	cmdIX = 0;
	return true;
}

void cleanupManager(){}

//***************************************************************************

bool operateManager() {
char c;

	if (kbhit()==0) return true;

	c = getche();

	if (c==8 && cmdIX>0) {
		cmdIX--;
		commandLine[cmdIX] = 0;
	}

	if (c==13) {
		commandLine[cmdIX] = 0;
		if (commandManager()) return false;
	}

	if (c>=32) commandLine[cmdIX++] = c;

	return true;
}

//***************************************************************************

void printHelp() {
	printf("Space Domination Server Functions:\n");
	printf("[Help]         - shows this list\n");
	printf("[LogLevel <N>] - display or change current logging level\n");
	printf("[LogFilterAllow <N><N1,N2>] - display or add log id(or range) that is\n                              allowed to log, overrides logging level\n");
	printf("[LogFilterBlock <N><N1,N2>] - display or add log id(or range) that is\n                              not allowed to log, overrides logging level\n");
	printf("[Reset <N>]    - restarts the round with N worlds or random worlds\n");
	printf("[Say message]  - sends 'message' to all sessions\n");
	printf("[Chat]         - toggles display of player chat\n");
	printf("[Quit]         - exit the server\n");
}
bool commandManager() {
	char buf[BUFFERSIZE];
	int num, num2;
	int i;
	char command[1024];

	printf("\n");

	memset(command,0,sizeof(command));
	i = readToken(commandLine, command, ' ');

	if (matchCI(command,"Help")) printHelp();

	if (equalsCI(command,"Quit")) {
		sendGlobalMessage("<Server> ===Server Shutting Down===");
		return true;
	}
	if (equalsCI(command,"LogLevel")) {
		if (i<=0 || sscanf(commandLine+i,"%d",&num)<1) {
			printf("Current logging level is ");
			switch (gLog.getLogLevel()) {
				case Log::LOG_NONE:
					printf ("0 = OFF.\n");
					break;
				case Log::LOG_ERROR:
					printf ("1 = Errors only.\n");
					break;
				case Log::LOG_INFO:
					printf ("2 = Info, Errors.\n");
					break;
				case Log::LOG_VERBOSE:
					printf ("3 = Verbose, Info, Errors.\n");
					break;
				case Log::LOG_DEBUG:
					printf ("4 = Debug, Verbose, Info, Errors.\n");
					break;
				case Log::LOG_DEBUG_VERBOSE:
					printf ("5 = Verbose Debug, Debug, Verbose, Info, Errors -- duplicate messages not grouped.\n");
					break;
			}
		} else {
			printf("Setting log level to %d.\n",num);
			gLog.setLogLevel((Log::loggingLevel)num);
		}
	}
	if (equalsCI(command,"LogFilterAllow")) {
		if (i<=0 || sscanf(commandLine+i,"%d",&num)<1) {
			LogFilter *current = gLog.getAllowList()->first();
			if (current == NULL) {
				printf("There are no entries in the allow filter\n");
			} else {
				printf("Allow filter entries\n");
				printf("====================\n");
				while (current != NULL) {
					current->getRange(&num, &num2);
					if (num == num2) {
						printf("    %d\n",num);
					} else {
						printf("    %d,%d\n",num,num2);
					}
					current=current->next();
				}
			}
		} else {
			if (strchr(commandLine+i, ',') != NULL) {
				sscanf(commandLine+i, "%d,%d", &num, &num2);			   						  
			} else {
				sscanf(commandLine+i, "%d", &num);			   						  
				num2 = num;
			}  	   		  	
			gLog.addFilter(Log::LOG_ALLOW,num,num2);   
		}  	   
	}   										
	if (equalsCI(command,"LogFilterBlock")) {
		if (i<=0 || sscanf(commandLine+i,"%d",&num)<1) {
			LogFilter *current = gLog.getBlockList()->first();
			if (current == NULL) {
				printf("There are no entries in the block filter\n");
			} else {
				printf("Block filter entries\n");
				printf("====================\n");
				while (current != NULL) {
					current->getRange(&num, &num2);
					if (num == num2) {
						printf("    %d\n",num);
					} else {
						printf("    %d,%d\n",num,num2);
					}
					current=current->next();
				}
			}
		} else {
			if (strchr(commandLine+i, ',') != NULL) {
				sscanf(commandLine+i, "%d,%d", &num, &num2);			   						  
			} else {
				sscanf(commandLine+i, "%d", &num);			   						  
				num2 = num;
			}  	   		  	
			gLog.addFilter(Log::LOG_BLOCK,num,num2);   
		}  	   
	}   										
	if (matchCI(command,"Reset")) {
		sendGlobalMessage("********************************************");
		sendGlobalMessage("********************************************");
		sendGlobalMessage("============Universe Rebuilding=============");
		if (i<=0 || sscanf(commandLine+i,"%d",&num)<1) {
			num = Rand(highWorlds - minWorlds) + minWorlds;
		}
		resetGalaxy(num);
	}

	if (matchCI(command,"Say")) {
		sprintf(buf,"<Sysop> %s",commandLine+4);
		sendGlobalMessage(buf);
	}

	if (matchCI(command,"Chat")) {
		managerShowChat = !managerShowChat;
		if (managerShowChat)	printf("Chat Display *ON*\n");
		else					printf("Chat Display *OFF*\n");
	}

	cmdIX = 0;
	commandLine[cmdIX] = 0;

	cmdPrompt();
	return false;
}

//***************************************************************************

extern	int sessionCount;

void cmdPrompt(){
	printf("\n[%d]>",sessionCount);
	if (cmdIX>0) printf(commandLine);
}


void cmdMessage(char *msg){
	printf("\n");
	printf(msg);
	cmdPrompt();
}

//***************************************************************************
