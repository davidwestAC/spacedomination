//******************************************************************
//	abstracted file code so that I can change my mind about 
//	the coding style to use.
//******************************************************************
//#define	_USE_ANSI_FILECODE_
#ifndef _FFI_FILEIO_
#define _FFI_FILEIO_

//******************************************************************
#ifdef _USE_ANSI_FILECODE_ 

	typedef	int FILEID;
	inline	bool badFileIndex(FILEID fd){return (fd==-1);}

#else //_USE_ANSI_FILECODE_

	#include <windows.h>
	typedef HANDLE FILEID;
	inline bool badFileIndex(FILEID fd)
		{return (fd==INVALID_HANDLE_VALUE);}

#endif //_USE_ANSI_FILECODE_

//******************************************************************

extern	FILEID openForRead(char *path);
extern	FILEID openForWrite(char *path);
extern	FILEID openForAppend(char *path);
extern	FILEID openForReplace(char *path);
extern	void fileClose(FILEID fd);
extern	int fileRead(FILEID fd,void *buf,int size);
extern	int fileWrite(FILEID fd,void *buf,int size);

extern	void fileDelete(char *path);
extern	void fileRename(char *oldName,char *newName);

extern	int fileSize(FILEID fd);
extern	int fileSeekFront(FILEID fd);
extern	int fileSeekEnd(FILEID fd);
extern	int fileSeekPos(FILEID fd,int pos);

extern	char *loadFile(char *path);
extern	char *loadHttpFile(char *path);
extern	bool replaceFile(char *path,char *buf);
extern	bool appendFile(char *path,char *buf);
extern	bool insertFile(char *path,char *buf);
extern	bool storeFile(char *path,char *buf);

//******************************************************************
#endif //_FFI_FILEIO_

