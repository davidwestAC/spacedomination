import java.awt.*;
import java.net.*;
import java.applet.Applet;

public class Portrait {

	Image icon = null;
	String path = null;
	URL url = null;

	boolean visible=true;

	public static String artpath = null;
	public static boolean useURL;

//--- constructors ---
	//public Portrait(){}

	public Portrait(String pth){setpath(pth);}
	
//--- common interface ---
	public String toString(){return path;}

//--- display functions ---
	public void draw(Graphics g,int h,int v,StarDart d){
		if (!visible) return;
		if (icon==null) icon = d.loadImage(artpath+"/"+path);
		if (icon!=null) g.drawImage(icon,h,v,d);
	}

	public void center(Graphics g,int h,int v,StarDart d){
		if (!visible) return;
		if (icon==null) icon = d.loadImage(artpath+"/"+path);
		if (icon!=null) g.drawImage(icon,h-icon.getWidth(d)/2,v-icon.getHeight(d)/2,d);
	}

//--- interface functions ---
	public String path(){
		if (url==null) return path;
		return url.toString();
	}

	public void setpath(URL purl){
		icon = null;
		url = purl;
	}

	public void setpath(String pth){
		icon = null;
		path = pth;

		try {url=new URL(path);}
		catch (MalformedURLException e){}
		finally{if (url!=null) path = null;}
	}

	public void setpath(URL purl,String pth){
		icon = null;
		path = pth;
		url = null;
		try {url=new URL(purl,path);}
		catch (MalformedURLException e){}
		finally {if (url!=null) path = null;}
	}

	public void testpath(String pth){
		try {url=new URL(pth);}
		catch (MalformedURLException e){}
	}

//--- other stuff ---
	public void visible(boolean show){visible=show;}
	public boolean visible(){return visible;}
	public void show(){visible(true);}
	public void hide(){visible(false);}
}
