//**********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************
#include "fileIO.hpp"
#include "string.hpp"
#include <stdio.h>

//**********************************************************************

const char *INITFILE = "SDserver.ini";

char *headTest = "[SpaceDom]\n";

char dataPath[128],htmlPath[128];
int portNum,maxPlayers,fleetDecayRate,worldDecayRate,victoryBase,movePixels,commandBuild,commandBonus;
int merchantBonus,minWorlds,highWorlds,dropHours,firstEarthDeclarePercent,firstPhenomenaDeclarePercent;
int firstNonDeclarablePhenomenaPercent,laterEarthDeclarePercent,laterPhenomenaDeclarePercent,maxSpeed;
int dockFleetBonus,dockWorldBonus,beaconBonus;

//**********************************************************************

bool readInitFile(){
char line[1024],temp[256];
char *data;
int ix,i;

	dataPath[0] = 0;
	htmlPath[0] = 0;

	portNum = 1965;
	maxPlayers = 200;
	fleetDecayRate = 200;
	worldDecayRate = 200;
	victoryBase = 80;
	movePixels = 150;
	commandBuild = 1000;
	commandBonus = 10;
	merchantBonus = 2;
	minWorlds = 1000;
	highWorlds = 5000;
	dropHours = 12;
	firstEarthDeclarePercent = 20;
	firstPhenomenaDeclarePercent = 30;
	firstNonDeclarablePhenomenaPercent = 25;
	laterEarthDeclarePercent = 25;
	laterPhenomenaDeclarePercent = 45;
	maxSpeed = 500;
	dockFleetBonus = 4;
	dockWorldBonus = 4;
	beaconBonus = 3;

//--- load & read file ---
	data = (char*)loadFile((char*)INITFILE);
	if (data==NULL) return false;

	i = search(data,headTest);
	if (i<0) return false;

	ix = i;
	while (true) {
		i = readToken(data+ix,line,'=');
		if (i<0) break;

		ix += i;

		if (equalsCI("DATA_PATH",line)) {
			i = readToken(data+ix,dataPath,'\n');
		}
		else if (equalsCI("HTML_PATH",line)) {
			i = readToken(data+ix,htmlPath,'\n');
		}
		else if (equalsCI("PORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&portNum);
		}
		else if (equalsCI("MAX_PLAYERS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxPlayers);
		}
		else if (equalsCI("FLEET_ATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&fleetDecayRate);
		}
		else if (equalsCI("WORLD_ATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&worldDecayRate);
		}
		else if (equalsCI("VICTORY_BASE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&victoryBase);
		}
		else if (equalsCI("MOVEMENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&movePixels);
		}
		else if (equalsCI("COMMAND_BUILD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBuild);
		}
		else if (equalsCI("COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBonus);
		}
		else if (equalsCI("MERCHANT_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&merchantBonus);
		}
		else if (equalsCI("MIN_WORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minWorlds);
		}
		else if (equalsCI("MAX_WORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&highWorlds);
		}
		else if (equalsCI("DROP_HOURS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dropHours);
		}
		else if (equalsCI("FIRST_EARTH_DECLARE_PERCENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstEarthDeclarePercent);
		}
		else if (equalsCI("FIRST_PHENOMENA_DECLARE_PERCENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstPhenomenaDeclarePercent);
		}
		else if (equalsCI("FIRST_NON_DECLARABLE_PHENOMENA_PERCENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstNonDeclarablePhenomenaPercent);
		}
		else if (equalsCI("LATER_EARTH_DECLARE_PERCENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterEarthDeclarePercent);
		}
		else if (equalsCI("LATER_PHENOMENA_DECLARE_PERCENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterPhenomenaDeclarePercent);
		}
		else if (equalsCI("MAX_SPEED",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxSpeed);
		}
		else if (equalsCI("DOCK_FLEET_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dockFleetBonus);
		}
		else if (equalsCI("DOCK_WORLD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dockWorldBonus);
		}
		else if (equalsCI("BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&beaconBonus);
		}
		else {
			i = search(data+ix,"\n");
		}

		if (i<0) break;

		ix += i;
	}

//--- cleanup ---
	printf("Space Domination Version 2.66 Configuration Values:\n");
	printf("DATA_PATH=%s\n",dataPath);
	printf("HTML_PATH=%s\n",htmlPath);
	printf("PORT=%d\n",portNum);
	printf("MAX_PLAYERS=%d\n",maxPlayers);
	printf("FLEET_ATTRITION=%d\n",fleetDecayRate);
	printf("WORLD_ATTRITION=%d\n",worldDecayRate);
	printf("VICTORY_BASE=%d\n",victoryBase);
	printf("MOVEMENT=%d\n",movePixels);
	printf("COMMAND_BUILD=%d\n",commandBuild);
	printf("COMMAND_BONUS=%d\n",commandBonus);
	printf("MERCHANT_BONUS=%d\n",merchantBonus);
	printf("MIN_WORLDS=%d\n\n",minWorlds);
	printf("MAX_WORLDS=%d\n",highWorlds);
	printf("DROP_HOURS=%d\n",dropHours);
	printf("FIRST_EARTH_DECLARE_PERCENT=%d\n",firstEarthDeclarePercent);
	printf("FIRST_PHENOMENA_DECLARE_PERCENT=%d\n",firstPhenomenaDeclarePercent);
	printf("FIRST_NON_DECLARABLE_PHENOMENA_PERCENT=%d\n",firstNonDeclarablePhenomenaPercent);
	printf("LATER_EARTH_DECLARE_PERCENT=%d\n",laterEarthDeclarePercent);
	printf("LATER_PHENOMENA_DECLARE_PERCENT=%d\n",laterPhenomenaDeclarePercent);
	printf("MAX_SPEED=%d\n",maxSpeed);
	printf("DOCK_FLEET_BONUS=%d\n",dockFleetBonus);
	printf("DOCK_WORLD_BONUS=%d\n",dockWorldBonus);
	printf("BEACON_BONUS=%d\n",beaconBonus);

	free(data);
	return true;
}

//**********************************************************************
