import java.awt.*;
import java.applet.*;

class gsPlay extends GameState {

//--- variables ---
	Worlds selectWorld = null;
	Fleets selectFleet = null;

	int cx,cy;

	Button quit,change[];
	int channel;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	int[] delta = {-100,-10,-1,1,10,100};

//--- constructors ---
	public gsPlay(){}

	public void init(){
		root.add(quit = new Button("Quit"));

		change = new Button[6];
		for (int i=0;i<6;i++) root.add(change[i] = new Button(ChanStr[i]));
	}

//--- primary functions ---
	public void paint(Graphics g){
	Worlds wp;
	Fleets fp;
	Squadron sp;
	int v,count;

		g.setColor(Color.black);
		g.fillRect(0,0,500,400);

	//--- worlds & fleets ---
		cx = gsFleet.xloc();
		cy = gsFleet.yloc();

		for (wp=Worlds.start();wp!=null;wp=wp.next()) drawWorld(g,wp);
		for (fp=Fleets.start();fp!=null;fp=fp.next()) drawFleet(g,fp);

		markEarthDirection(g);

	//--- status region ---
		g.setColor(Color.blue);
		g.fillRect(0,0,100,400);

		drawEmpireStats(g);
		gsFleet.drawStats(g,5,115,86,120);
		drawTargetStats(g);
		drawWorldStats(g);

	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,110,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}

	//--- move tools ---
		reshape(quit,5,380,80,15);
		for (int i=0;i<6;i++) reshape(change[i],10+(i%3)*25+(i/3)*5,78+(i/3)*15,25,15);
	}


	void drawWorld(Graphics g,Worlds wp){
	int x,y,rad;
	int size;
	Color c;

		if (wp.empireID<0) return;

		switch (wp.type()) {
			case Worlds.NEBULAE: c = wp.NEBULAE_COLOR; size = wp.NEBULAE_SIZE; break;
			case Worlds.NEUTRON: c = wp.NEUTRON_COLOR; size = wp.NEUTRON_SIZE; break;
			case Worlds.GATEWAY:
				x = StarDart.cycle;
				c = new Color(
					((x&32)==0?8*(x&31):252-8*(x&31)),
					((x&16)==0?16*(x&15):248-16*(x&15)),
					((x&64)==0?4*(x&63):253-4*(x&63))
				);
				size = wp.WORLD_SIZE; 
				break;
			default: c = wp.WORLD_COLOR; size = wp.WORLD_SIZE; break;
		}

		x = 300 + (wp.xloc()-cx) * 200 / wp.scale;
		if (x+size<100 || x-size>500) return;
		y = 200 + (wp.yloc()-cy) * 200 / wp.scale;
		if (y+size<0 || y-size>400) return;

		g.setColor(c);
		rad = size * 200 / wp.scale;
		if (wp.type==wp.GATEWAY) {
			g.fillOval(x-rad-3,y-rad/2,2*rad+7,rad+1);
			g.fillOval(x-rad/2,y-rad-3,rad+1,2*rad+7);
		}
		else g.fillOval(x-rad,y-rad,2*rad+1,2*rad+1);

	//--- details ---
		if (wp.isPlanet()) {
			if (wp.empireID==gsEmpireID)	g.setColor(Color.yellow);
			else if (wp.empireID>0)		g.setColor(Color.cyan);
			else						g.setColor(Color.gray);
			drawFlag(g,x+6,y-12);
		}


		if (wp==selectWorld) {
			g.setColor(Color.cyan);
			g.drawOval(x-11,y-11,23,23);
		}

		g.setColor(Color.black);
		g.drawString(wp.name,x+13,y+7);
		g.setColor(Color.red);
		g.drawString(wp.name,x+12,y+6);
	}


	void drawFleet(Graphics g,Fleets fp){
	Worlds wp;
	Fleets ep;
	int x,y,wx,wy,rad;
	int size;

		if (fp.ghost()) return;

		x = 300 + (fp.xloc()-cx) * 200 / Worlds.scale;
		if (x<100 || x>500) return;
		y = 200 + (fp.yloc()-cy) * 200 / Worlds.scale;
		if (y<0 || y>400) return;

		wp = Worlds.get(fp.destID);
		if (wp!=null) {
			wx = 300 + (wp.xloc()-cx) * 200 / Worlds.scale;
			wy = 200 + (wp.yloc()-cy) * 200 / Worlds.scale;
			g.setColor(Color.blue);
			g.drawLine(x,y,wx,wy);
		}
		else {
			ep = Fleets.get(fp.destID);
			if (ep!=null) {
				wx = 300 + (ep.xloc()-cx) * 200 / Worlds.scale;
				wy = 200 + (ep.yloc()-cy) * 200 / Worlds.scale;
				g.setColor(Color.blue);
				g.drawLine(x,y,wx,wy);
			}
		}

		if (fp==selectFleet) {
			g.setColor(Color.blue);
			g.fillRect(x-7,y-5,15,11);
		}

		g.setColor(Color.red);
		g.fillRect(x-5,y-3,11,7);
	}


	void markEarthDirection(Graphics g){
	int range,dx,dy;
	String msg;

		range = Worlds.scale;
		if (cx>-range && cx<range && cy>-range && cy<range) return;

		dx = (cx<0?-cx:cx);
		dy = (cy<0?-cy:cy);

		range = (dx>dy?dx+dy/2:dy+dx/2);

		if (dx>dy) {
			dy = cy * 196 / (1+dx);
			dx = cx * 196 / (1+dx);
		}
		else {
			dx = cx * 196 / (1+dy);
			dy = cy * 196 / (1+dy);
		}

		dx = 300 - dx;
		dy = 200 - dy;
		
		g.setColor(Color.green);
		g.drawLine(dx-4,dy,dx,dy-4);
		g.drawLine(dx,dy-4,dx+4,dy);
		g.drawLine(dx+4,dy,dx,dy+4);
		g.drawLine(dx,dy+4,dx-4,dy);

		msg = ""+range;
		if (dx>300) g.drawString(msg,dx-textMET.stringWidth(msg)-5,dy+5);
		else		g.drawString(msg,dx+5,dy+5);
	}


	void drawEmpireStats(Graphics g){
	Empires ep;
	String msg;
	int v;

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),5,v=13);
		g.drawString("Worlds "+ep.worlds(),5,v+=15);
		g.drawString("Darts "+ep.darts(),5,v+=15);
		g.drawString("Score "+ep.score(),5,v+=15);

		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,5,v+=15);
	}


	void drawTargetStats(Graphics g){
	Empires emp;
	int v;

		g.setColor(Color.orange);
		g.fillRect(5,v=240,86,60);
		if (selectFleet==null) return;

		g.setColor(Color.black);
		g.drawString(selectFleet.empireName(),7,v+=15);
		g.drawString("-->"+selectFleet.destName(),7,v+=15);

		emp = Empires.get(selectFleet.empireID);
		if (emp==null) return;

		g.drawString("Score: "+emp.score(),7,v+=15);

	}

	void drawWorldStats(Graphics g){
	int v;

		g.setColor(Color.cyan);
		g.fillRect(5,v=305,86,70);

		if (selectWorld!=null) {
			g.setColor(Color.black);
			g.drawString(selectWorld.name(),7,v+=15);
//			g.drawString(selectWorld.special(),7,v+=15);
			g.drawString(selectWorld.special()+" m"+selectWorld.minerals(),7,v+=15);
			if (selectWorld.isPlanet()) {
				g.drawString(selectWorld.empireName(),7,v+=15);
				g.drawString("pop"+selectWorld.pop()+" ind"+selectWorld.ind(),7,v+=15);
			}
		}
	}

	void drawFlag(Graphics g,int x,int y){
	int[] xp = {0,12,0};
	int[] yp = {-5,0,5};

		for (int i=0;i<3;i++) {
			xp[i] += x;
			yp[i] += y;
		}
		g.fillPolygon(xp,yp,3);
	}

//--- events & actions ---
	public void action(Event e){
	int i;
		super.action(e);
		if (e.target==quit) setState(new gsPassword());
		for (i=0;i<6;i++) if (e.target==change[i]) {
			channel += delta[i];
			if (channel<0) channel = 0;
			if (channel>10000) channel = 10000;
			break;
		}
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;
	Empires ep;

		fp=null;

		value = super.handleInput(buf);

		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.INDUSTRY) setState(new gsIndustry());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		ep = gsEmpire;
		if (ep!=null && ep.channel!=channel) sendChannel();
		
		return value;
	}

	public void down(int x,int y){
	Buffer buf;
	int mx,my;
	Worlds wp;
	Fleets fp;

		if (x<0 || gsFleet==null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;
		wp = Worlds.find(mx,my);

		if (wp!=null) {
			sendFleetMove(wp.worldID());
			return;
		}

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;
		fp = Fleets.find(mx,my);

		if (fp!=null) sendFleetMove(fp.fleetID());
	}

	public void move(int x,int y){
	int mx,my;

		if (x<100) return;
		if (gsFleet==null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;

		selectWorld = Worlds.find(mx,my);
		selectFleet = Fleets.find(mx,my);
		if (selectFleet!=null && selectFleet.ghost()) selectFleet = null;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}
}