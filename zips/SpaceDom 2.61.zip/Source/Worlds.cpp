//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant
#include <math.h>

//**********************************************************************************
//**********************************************************************************

extern	void FirstVictoryRecord(void);

void CreateGalaxy(int wcount);
void MakeName(worldRec *worlds,int index);
int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start);
void killAllSessions(void);
void calcVictoryStats(void);
void CreateNeutralEmpire(int wcount);

//**********************************************************************************

const char *empireFile="Empires.dat";
const char *fleetFile="Fleets.dat";
const char *worldFile="Galaxy.dat";
const char *victoryFile="Victors.dat";

char empirePath[256],fleetPath[256],worldPath[256],victoryPath[256];

CLists *empireList=NULL,*worldList=NULL,*fleetList=NULL;
CRecords *victoryList=NULL;

int worldFleetPos[stCOUNT] = {
	posDefendMid,posDefendTop,posDefendTop,
	posInvadeMid,posInvadeTop,posInvadeBot,
};

int maxEmpireScore,victoryDate,victoryTime,victoryPercent,coreCount;

//**********************************************************************************
//**********************************************************************************

/*	resetGalaxy is the main function which calls all other functions needed to end a
	game in progress and get everything set for the next game. This is the function
	that should be called up whenever a game is to be restarted. */

bool resetGalaxy(int goal){
int count;

	RecordVictory();

	if (goal<minWorlds) goal = Rand(highWorlds - minWorlds) + minWorlds;

	if (empireList!=NULL) {
//		count = empireList->getCount();
//		count *= worldsPlayer;
		count = Rand(highWorlds - minWorlds) + minWorlds;
		if (count>goal) goal = count;
		empireList->clear();
	}
	if (fleetList!=NULL) fleetList->clear();
	if (worldList!=NULL) worldList->clear();

	printf("RESETTING = %d\n",goal);
	cleanupGalaxy();

	if (sroot!=NULL) {		// kill outstanding sessions
		delete sroot;
		sroot = new SessionList();
	}

	if (goal>highWorlds) goal = highWorlds;
	return prepareGalaxy(goal);
}

/*	The prepareGalaxy function takes the number of worlds that will be in the next
	game and then creates the data files for the next game depending on that. It then
	calls the function to create the Neutral Empire and calculates the maximum score. */

bool prepareGalaxy(int wcount){		// called during startup+reset
empireRec *emp;
int worlds,darts;

	emp = NULL;

	if (empireList==NULL) {
		sprintf(empirePath,"%s/%s",dataPath,empireFile);
		empireList = new CLists(empirePath,sizeof(empireRec));
		empireList->save();
	}

	if (fleetList==NULL) {
		sprintf(fleetPath,"%s/%s",dataPath,fleetFile);
		fleetList = new CLists(fleetPath,sizeof(fleetRec));
		fleetList->save();
	}

	if (worldList==NULL) {
		sprintf(worldPath,"%s/%s",dataPath,worldFile);
		worldList = new CLists(worldPath,sizeof(worldRec));
		worldList->save();
	}

	if (victoryList==NULL){
		sprintf(victoryPath,"%s/%s",dataPath,victoryFile);
		victoryList = new CRecords(victoryPath,0,sizeof(victoryRec));
		if (victoryList->getCount()<1) FirstVictoryRecord();
		calcVictoryStats();
	}

	CreateNeutralEmpire(wcount);

//--- rebuild world ---
	if (worldList->getCount()<1) CreateGalaxy(wcount);

	worlds = worldList->getCount();
	darts = CalcDarts(worlds);
	coreCount = CalcCores(worlds);

	worlds -= CalcNeutron(worlds) + CalcNebulae(worlds) + CalcGates(worlds) + coreCount + 1;
	worlds += EarthValue(worlds) + (8 * HomeValue(worlds)) + (coreCount * CoreValue(worlds));
	maxEmpireScore = (worlds + (darts * darts)) * 1000;

	return true;
}


void cleanupGalaxy(){
	if (empireList!=NULL) {delete empireList;empireList=NULL;}
	if (fleetList!=NULL) {delete fleetList;fleetList=NULL;}
	if (worldList!=NULL) {delete worldList;worldList=NULL;}
}

void calcVictoryStats(){
victoryRec *vrp;
int count;

	count = victoryList->getCount();
	if (victoryList->pickIndex(count-1)) {
		vrp = (victoryRec*)victoryList->getRecord();
		victoryDate = vrp->getDate();
		victoryTime = vrp->getTime();
	}
	else {
		victoryDate = dateIndex();
		victoryTime = secondsSinceMidnight();
	}
}

//**********************************************************************************

/*	The CreateGalaxy function is the function which actually creates all the worlds
	in a particular game and later converts some of them to phenomena and homeworlds. */

void CreateGalaxy(int wcount){
int ix,i,pos,num;
worldRec *worlds,*wp;
fleetRec *fleets,*fp;
int locRoot;

bool humanHomeWorld = false;
bool makluvianHomeWorld = false;
bool kaletianHomeWorld = false;
bool zorestianHomeWorld = false;
bool avarianHomeWorld = false;
bool najunianHomeWorld = false;
bool cestanianHomeWorld = false;
bool quarethianHomeWorld = false;

	printf("\nBuilding New Galaxy\n");
	srand(time(NULL));

	worldList->expand(wcount);
	worlds = (worldRec*)worldList->getList();
	memset(worlds, 0, worldList->getCount() * sizeof(worldRec));

	fleetList->expand(wcount);
	fleets = (fleetRec*)fleetList->getList();
	memset(fleets, 0, fleetList->getCount() * sizeof(fleetRec));

//--- Create Earth ---
	wp = &worlds[0];
	wp->worldID = 0;

	printf("Making=%d",0);
	wp->pop = 200;
	wp->ind = 1200;
	wp->type = wtHome;
	wp->sector = 8;
	wp->facility = ftStardock;

	strcpy(wp->name,"Old Earth");
	for (i=0;i<btIndustry;i++) {
		wp->cmd[i].repeat = true;
		wp->cmd[i].type = i;
		wp->cmd[i].goal = cost[stFrigate] / cost[i];
	}
	printf(" (%s)\n",wp->name);

	fp = &fleets[0];

	fp->ecm = 25000;

	for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
	for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,100*worldDecayRate/cost[i]);
	for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;

//--- Core Worlds ---
	locRoot = MINDIST;

	for (ix=1;ix<=coreCount;ix++) {
		printf("Making=%d",ix);

		wp = &worlds[ix];
		wp->worldID = ix;

	//--- world record ---
		wp->pop = 100;
		wp->ind = 600;
		wp->type = wtCore;
		wp->sector = 8;
		wp->facility = ftStellurae;

		MakeName(worlds,ix);
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
		printf(" (%s)\n",wp->name);

		for (i=0;i<btIndustry;i++) {
			wp->cmd[i].repeat = true;
			wp->cmd[i].type = i;
			wp->cmd[i].goal = cost[stFrigate] / cost[i];
		}

	//--- fleet record ---
		fp = &fleets[ix];

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;

		fp->ecm = 2500;

		for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
		for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,40*worldDecayRate/cost[i]);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
	}

//--- The Remaining Cluster ---
	for (;ix<wcount;ix++) {
printf("Making=%d",ix);

		wp = &worlds[ix];
		wp->worldID = ix;

	//--- world record ---
		wp->type = Rand32();
		if (wp->type<=wtCore || wp->type>=wtNewEarth) wp->type = wtNormal;

		wp->pop = 99 - 90*ix/wcount;
		wp->ind = Rand(201) * wp->pop / 100;	// up to x2
		wp->facility = ftCOUNT;

		MakeName(worlds,ix);
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
printf(" (%s)\n",wp->name);



		if (wp->xloc>0 && wp->yloc>0 && wp->xloc>wp->yloc) {
			wp->sector = 2;
		}
		else if (wp->xloc>0 && wp->yloc>0 && wp->xloc<wp->yloc) {
			wp->sector = 3;
		}
		else if (wp->xloc<0 && wp->yloc<0 && wp->xloc>wp->yloc) {
			wp->sector = 7;
		}
		else if (wp->xloc<0 && wp->yloc<0 && wp->xloc<wp->yloc) {
			wp->sector = 6;
		}
		else if (wp->xloc>0 && wp->yloc<0 && (wp->xloc * wp->xloc < wp->yloc * wp->yloc)) {
			wp->sector = 0;
		}
		else if (wp->xloc>0 && wp->yloc<0 && (wp->xloc * wp->xloc > wp->yloc * wp->yloc)) {
			wp->sector = 1;
		}
		else if (wp->xloc<0 && wp->yloc>0 && (wp->xloc * wp->xloc > wp->yloc * wp->yloc)) {
			wp->sector = 5;
		}
		else if (wp->xloc<0 && wp->yloc>0 && (wp->xloc * wp->xloc < wp->yloc * wp->yloc)) {
			wp->sector = 4;
		}
		else {
			wp->sector = 8;
		}

		wp->cmd[0].repeat = true;
		wp->cmd[0].type = btStation;
		wp->cmd[0].goal = 10;

	//--- fleet record ---
		Sleep(10);

		fp = &fleets[ix];

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;

		fp->ecm = Rand(101) - Rand(101);

		for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
		buildFleetShips(fp,stStation,(wp->pop+wp->ind)*worldDecayRate/cost[stStation]);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
	}

//--- add 8 nebulae + 6 gravity wells + 4 gateways ---
	num = CalcNebulae(wcount);
	coreCount = CalcCores(wcount);
	//num = wcount / 30;
printf("Nebulaes = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = coreCount + Rand(wcount-coreCount);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtNebulae;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

	num = CalcNeutron(wcount);
printf("Neutrons = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = coreCount + Rand(wcount-coreCount);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtNeutron;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

	num = CalcGates(wcount);
printf("Gateways = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = coreCount + Rand(wcount-coreCount);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtGateway;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

// --- Home Worlds ---
	for (ix=wcount/2;ix<wcount;ix++) {
		wp = &worlds[ix];
		if (wp->sector==0 && humanHomeWorld==false) {
			wp->type = wtNewEarth;
			strcpy(wp->name,"New Earth");
			printf("Converting New Earth\n",ix);
			humanHomeWorld = true;
		}
		if (wp->sector==1 && makluvianHomeWorld==false) {
			wp->type = wtMakluvia;
			strcpy(wp->name,"Makluvia");
			printf("Converting Makluvia\n",ix);
			makluvianHomeWorld = true;
		}
		if (wp->sector==2 && kaletianHomeWorld==false) {
			wp->type = wtKaletia;
			strcpy(wp->name,"Kaletia");
			printf("Converting Kaletia\n",ix);
			kaletianHomeWorld = true;
		}
		if (wp->sector==3 && zorestianHomeWorld==false) {
			wp->type = wtZorestia;
			strcpy(wp->name,"Zorestia");
			printf("Converting Zorestia\n",ix);
			zorestianHomeWorld = true;
		}
		if (wp->sector==4 && avarianHomeWorld==false) {
			wp->type = wtAvaria;
			strcpy(wp->name,"Avaria");
			printf("Converting Avaria\n",ix);
			avarianHomeWorld = true;
		}
		if (wp->sector==5 && najunianHomeWorld==false) {
			wp->type = wtNajunia;
			strcpy(wp->name,"Najunia");
			printf("Converting Najunia\n",ix);
			najunianHomeWorld = true;
		}
		if (wp->sector==6 && cestanianHomeWorld==false) {
			wp->type = wtCestania;
			strcpy(wp->name,"Cestania");
			printf("Converting Cestania\n",ix);
			cestanianHomeWorld = true;
		}
		if (wp->sector==7 && quarethianHomeWorld==false) {
			wp->type = wtQuarethia;
			strcpy(wp->name,"Quarethia");
			printf("Converting Quarethia\n",ix);
			quarethianHomeWorld = true;
		}

		if (wp->type>=wtNewEarth && wp->type<=wtQuarethia) {
			wp->pop = 150;
			wp->ind = 900;
			wp->facility = ftStardock;

			for (i=0;i<btIndustry;i++) {
				wp->cmd[i].repeat = true;
				wp->cmd[i].type = i;
				wp->cmd[i].goal = cost[stFrigate] / cost[i];
			}

			fp = &fleets[ix];

			fp->ecm = 10000;

			for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
			for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,70*worldDecayRate/cost[i]);
			for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
		}
	}

	num = CalcDarts(wcount);
	printf("StarDarts = %d\n",num);

	i = (num+9) / 10;
	addFleetShips(&fleets[0],stStarDart,i);		// 10% of Darts to earth

	for (;i<num;i++) {
		do ix = coreCount + Rand(wcount-coreCount);
		while (!isPlanet(worlds[ix].type));
		addFleetShips(&fleets[ix],stStarDart,1);
	}

//--- cleanup ---
	worldList->save();
	fleetList->save();

	if (empireList->getCount()<2) {
		CreateEmpire("Destroyer","facubvuten45");
		CreateEmpire("Reptile","r7pw39hvc6n");
	}
}

//**********************************************************************************

const char *vowels = "aaaiiueeeoy";
const char *cons = "bcdfghjklmnpqrstvwxz";
const int vlen = strlen(vowels);
const int clen = strlen(cons);
inline char RandVowel(){return vowels[Rand(vlen)];}
inline char RandCons(){return cons[Rand(clen)];}


void MakeName(worldRec *worlds,int index){
int ix,num,i;
char *name;

	name = worlds[index].name;

	while (true) {

	//--- build name ---
		ix = 0;
		num = 1+Rand(2)+Rand(3)/2+Rand(4)/3;

		if (Rand(3)==0) name[ix++] = RandVowel();
		for (i=0;i<num;i++) {
			name[ix++] = RandCons();
			name[ix++] = RandVowel();
		}
		if (Rand(2)==0) name[ix++] = RandCons();
		name[ix++] = 0;

		name[0] = name[0] - 'a' + 'A';	// capitolize

	//--- compare name ---
		for (i=0;i<index;i++) {
			if (equals(worlds[i].name,name)) break;
		}
		if (i==index) return;	// no matches
	}
}

/*	The FleetLocation function is responsible for recognizing where a fleet has moved
	and officially updating the new location of that fleet. */

void FleetLocation(int *xloc,int *yloc){
worldRec *worlds,*wp;
int sx,sy,min,val,i,count;
float dx,dy;

	worlds = (worldRec*)worldList->getList();
	count = worldList->getCount();

	while (true) {

		wp = &worlds[count*4/5 + Rand(count/5)];

		sx = wp->xloc + Rand(MINDIST) - MINDIST/2;
		sy = wp->yloc + Rand(MINDIST) - MINDIST/2;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST/2) continue;
		if (min>MINDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		return;
	}
}


int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start){
int cx,cy,sx,sy,range,min,i,val;
float dx,dy;

//-- calculate galactic center ---
	dx = dy = 0.0;
	for (i=0;i<count;i++) {
		dx += worlds[i].xloc;
		dy += worlds[i].yloc;
	}

	if (count>0) {
		cx = (int)(dx / count);
		cy = (int)(dy / count);
	}
	else cx = cy = 0;

//--- start testing random locations --- 
	range = start * 3 / 4;

	while (true) {

		sx = BRand(range) - range/2 - cx;
		sy = BRand(range) - range/2 - cy;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST) {
			range += MINDIST;
			continue;
		}
		if (min>MAXDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		break;
	}

	return range;
}

//**********************************************************************************

static int startCount[stCOUNT] = {40,200,10,0,0,0};
static int startType[stCOUNT] = {stCorsair,stPinnace,stFrigate,stCOUNT,stCOUNT,stCOUNT};

void CreateNeutralEmpire(int wcount){
fleetRec *fp;
empireRec *emp;
int i;

//--- create empire ---

	if (empireList->getCount()<1) empireList->increment();
	emp = (empireRec*)empireList->getRecord(0);

	if (emp!=NULL) {
		memset(emp,0,sizeof(empireRec));
		strcpy(emp->name,"Neutral");
		strcpy(emp->pass,"np");
		emp->race = -1;
		emp->ruler = -1;
		emp->worlds = wcount;
		emp->darts = wcount / 25;
		emp->fleetID = fleetList->increment();
		emp->Merchant = 0;
		emp->Beacon = 0;
		emp->Stardock = 0;
		emp->Stellurae = 0;
		emp->scoreDarts  = 0;
		}

	empireList->save(0);
}

bool CreateEmpire(char *name,char *pass){
fleetRec *fp;
empireRec *emp;
int empireID;

//--- create empire ---
	empireID = empireList->increment();

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return false;

	memset(emp,0,sizeof(empireRec));
	strcpy(emp->name,name);
	strcpy(emp->pass,pass);

	emp->race = 8;
	emp->ruler = -1;
	emp->worlds = 0;
	emp->darts = 0;
	emp->fleetID = fleetList->increment();
	emp->Merchant = 0;
	emp->Beacon = 0;
	emp->Stardock = 0;
	emp->scoreDarts  = 0;

	emp->changedRace = false;

	empireList->save(empireID);

//--- create fleet ---
	fleetList->increment();
	fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
	if (fp==NULL) return false;

	CreateFleet(fp,empireID);

	fleetList->save(emp->fleetID);
	
//--- cleanup ---
	return true;
}


void CreateFleet(fleetRec *fp,int empireID){
int i;

	memset(fp,0,sizeof(fleetRec));
	fp->empireID = empireID;

	FleetLocation(&fp->xloc,&fp->yloc);

	fp->destID = -1;
	for (i=0;i<stCOUNT;i++) {
		fp->squad[i].count = startCount[i];
		fp->squad[i].type = startType[i];
	}
	for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
}

//**********************************************************************************
