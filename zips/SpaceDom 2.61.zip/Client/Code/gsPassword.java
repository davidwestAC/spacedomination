import java.awt.*;
import java.applet.*;

class gsPassword extends GameState {
                                               
//--- constants ---
	final static String[][] response = {
		{"Waiting...",null},
		{"Empire Found",null},
		{"Empire Created",null},
		{"Session Denied,","Bad Password"},
		{"Empire Destroyed",null},
		{"Session Denied,","Empire In Play"},
		{"Session Denied,","Records Error"},
		{"Session Denied,","Server Full"},
	};

//--- variables ---
	TextField name,pass;
	Button send,enter,rebirth;
	Button top20,stats,settings;
	
	final static int SHOW_TOP20 = 0;
	final static int SHOW_STATS = 1;
	final static int SHOW_SETTINGS = 2;

	int status,displayType;
	Buffer statBuf = null;
	Buffer setBuf = null;

	Portrait title;

//--- primary functions ---
	public gsPassword(){

		status = JOIN_REQUEST;
		displayType = SHOW_TOP20;

		gsEmpireID = gsFleetID = -1;
		gsEmpire = null;
		gsFleet = null;

		Fleets.root = null;
		Empires.root = null;
		Worlds.root = null;

		title = new Portrait("SpaceDomination.jpg");
	}

	public void init(){
		prepareTools();
		sendTop20Query();
	}

//--- primary functions ---

	public void paint(Graphics g){
//	long time = System.currentTimeMillis();

		g.setFont(textFNT);

		if (SpaceDom.conn==null) {
			g.setColor(Color.black);
			g.fillRect(0,0,SpaceDom.DEFAULT_WIDTH,SpaceDom.DEFAULT_HEIGHT);
			g.setColor(Color.white);
			g.drawString("Server Not Responding...",10,20);
			moveTools(false);
			return;
		}

		moveTools(true);

	//--- regular ---
		g.setColor(Color.black);
		g.fillRect(0,0,SpaceDom.DEFAULT_WIDTH,SpaceDom.DEFAULT_HEIGHT);

		g.setColor(Color.white);
		g.drawString("Username:",10,15);
		g.drawString("Password:",10,55);
		g.drawString(response[status][0],5,150);
		if (response[status][1]!=null) {
			g.drawString(response[status][1],5,165);
		}
		else if (gsEmpireID>=0) empireInfo(g,5,165);

		switch (displayType) {
			case SHOW_TOP20: showTop20List(g,130,15); break;
			case SHOW_STATS: showGameStats(g,130,15); break;
			case SHOW_SETTINGS: showSettings(g,130,15); break;
		}

		title.center(g,250,450,root);
//	System.out.println("FrameTime="+(System.currentTimeMillis()-time));
	}


	void showTop20List(Graphics g,int h,int v){
	Empires emp;
	String name;
	int i;

		g.setColor(Color.white);
		g.drawString("Top 20 List",h+20,v);
		g.drawString("Score",h+130,v);
		g.drawString("Worlds",h+200,v);
		g.drawString("Darts",h+250,v);
		g.drawString("Race",h+290,v);
		v += 2;

		for (i=0;i<20;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			g.drawString(""+(i+1)+"> "+name,h,v+=14);
			emp = Empires.get(top20List[i]);
			g.drawString(""+emp.hiScore,h+130,v);
			g.drawString(""+emp.hiWorlds,h+200,v);
			g.drawString(""+emp.hiDarts,h+250,v);
			g.drawString(""+emp.racename(),h+290,v);
		}
		
		if (i==0) g.drawString("List Empty",h,v+=14);
	}
	
//-------------------------------------------------------------
	
	void empireInfo(Graphics g,int h,int v) {

		g.setColor(Color.white);

		g.drawString("Empire ID: "+gsEmpireID,h,v);

		if (gsEmpire==null || gsFleet==null) {
			g.drawString("Waiting for Data",h,v+=15);
			if (gsEmpire==null) {
				gsEmpire = Empires.get(gsEmpireID);
				g.drawString("Emp Get = "+gsEmpire,h,v+=15);
			}
			else {
				gsFleetID = gsEmpire.fleetID;
				gsFleet = Fleets.get(gsFleetID);
				g.drawString("Fleet Get = "+gsEmpire,h,v+=15);
			}
			return;
		}

		g.drawString("Name: "+gsEmpire.name,h,v+=15);
		g.drawString("Score: "+gsEmpire.score+" / "+gsEmpire.hiScore,h,v+=15);
		g.drawString("Worlds: "+gsEmpire.worlds+" / "+gsEmpire.hiWorlds,h,v+=15);
		g.drawString("Darts: "+gsEmpire.darts+" / "+gsEmpire.hiDarts,h,v+=15);
		g.drawString("Squads: "+gsFleet.countSquads(),h,v+=15);
		g.drawString("Guns: "+gsFleet.guns(),h,v+=15);
	}


	public void action(Event e) {
		if (e.target==send) sendPetition();
		if (e.target==enter) setState(new gsMovement());

		if (e.target==top20) {
			sendTop20Query();
			displayType = SHOW_TOP20;
		}
		if (e.target==stats) {
			sendStatsQuery();
			displayType = SHOW_STATS;
		}
		if (e.target==settings) {
			sendSettingsQuery();
			displayType = SHOW_SETTINGS;
		}

		if (e.target==rebirth) sendRebirthRequest();
	}


	public boolean handleInput(Buffer buf){

		if (super.handleInput(buf)) return true;

		if (buf!=null) switch (buf.get(1)) {
			case BAD_PASSWORD:
			case EMPIRE_INPLAY:
			case RECORDS_ERROR:
			case SERVER_FULL:
				gsEmpireID = gsFleetID = -1;
				gsEmpire = null;
				gsFleet = null;
				status = buf.get(1);
				return true;

			case SESSION_CREATED:
			case SESSION_GRANTED:
			case EMPIRE_DEAD:
				status = buf.get(1);
				gsEmpireID = buf.getShort(2);
				return true;

			case STATS_RESULT:
				statBuf = buf;
				break;

			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}

		return false;
	}

	public boolean press(int key){return false;}

//--- tool functions ---
	void prepareTools(){
		root.add(send = new Button("Send"));
		root.add(enter = new Button("Enter"));
		root.add(top20 = new Button("Top20"));
		root.add(stats = new Button("Stats"));
		root.add(settings = new Button("Settings"));
		root.add(rebirth = new Button("Rebirth"));
		root.add(name = new TextField(15));
		root.add(pass = new TextField(15));
		pass.setEchoCharacter('*');
	}

	void moveTools(boolean show){
		if (show) {
			reshape(name,10,20,100,20);
			reshape(pass,10,60,100,20);
			reshape(send,10,90,100,20);
			reshape(enter,10,115,100,20);
			reshape(rebirth,10,115,100,20);
			reshape(top20,10,325,55,20);
			reshape(stats,10,350,55,20);
			reshape(settings,10,375,55,20);

			send.enable(status!=SERVER_FULL);
			enter.show((status==SESSION_CREATED || status==SESSION_GRANTED) && 
							gsEmpire!=null && gsFleet!=null);
			rebirth.show(status==EMPIRE_DEAD);
		}
		else {
			send.hide();
			name.hide();
			pass.hide();
			enter.hide();
		}
	}

//--- communications ---
	void sendPetition(){
	Buffer buf;
	String msg;

		if (pass.getText().length()<4) return;

		buf = new Buffer(34);
		buf.set(0,34);
		buf.set(1,JOIN_REQUEST);

		msg = name.getText();
		if (msg.length()<4) return;
		if (msg.length()>15) msg = msg.substring(0,15);
		buf.setString(2,msg);

		msg = pass.getText();
		if (msg.length()<4) return;
		if (msg.length()>15) msg = msg.substring(0,15);
		buf.setString(18,msg);

		buf.send();
	}
}