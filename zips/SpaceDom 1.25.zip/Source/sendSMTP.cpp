//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"

//**********************************************************************************
//**********************************************************************************

const int MAILLINES	= 5;
//const int BUFFERSIZE = 256;

struct mailSession {
	SOCKET		sock;
	struct mailSession *next;

	bool		sending,killed;
	int			mailSize,mailSent,mailItem;
	char		buf[MAILLINES][BUFFERSIZE];

	char		inBuf[BUFFERSIZE];
	int			inSize;
};
typedef struct mailSession mailSession;

sockaddr ffiMailAddr = {
	AF_INET,
	0,25,									// port 25 = SMTP port
	(char)204,(char)245,(char)229,(char)17,
	0,0,0,0,0,0,0,0
};

mailSession root={INVALID_SOCKET,NULL};

//--- sendAddress, message ---
char *mailResponse[MAILLINES+1] = {"220","250","250","354","250","220"};
char *mailString[MAILLINES] = {
	"MAIL FROM:Fred@FFIends.com\n",
	"RCPT TO:%s\n",
	"DATA\n",

	"Date: %s\nFrom: Support@FFIends.com\n"
		"To: %s\nSubject: Star Dart Automated Message\n%s\n.\n",

	"QUIT\n"
};

//**********************************************************************************

void handleMailSession(mailSession *mp);
int handleMailOutput(mailSession *mp);
int handleMailInput(mailSession *mp);

void killMailSessions(void);
void killOneMailSession(mailSession *temp);

//**********************************************************************************
//**********************************************************************************

bool prepareSMTP(){
WSAData wsad;
int err;

	err = WSAStartup(MAKEWORD(2,0),&wsad);		// called by sockets as well, works fine
	if (err!=0) return false;

	if (wsad.wVersion != MAKEWORD(2,0)) return false;

	return true;
}


void cleanupSMTP(){
	killMailSessions();
}

//**********************************************************************************

void operateSMTP(){
mailSession *temp,*next;

	temp = root.next;

	while (temp!=NULL) {
		handleMailSession(temp);
		temp = temp->next;
	}

//--- cull finished sessions ---
	temp = &root;
	next = temp->next;

	while (next!=NULL) {

		if (!next->killed) temp = next;
		else {
			temp->next = next->next;
			killOneMailSession(next);
		}

		next = temp->next;
	}
}


void handleMailSession(mailSession *mp){

//--- send or connect? ---
	if (mp->sending)	handleMailOutput(mp);
	else				handleMailInput(mp);
}


int handleMailOutput(mailSession *mp){
int result,size,err;
char *src;

	if (mp->killed) return 0;

printf("Output=[%d]%s",mp->mailSize,mp->buf[mp->mailItem]);

	src = mp->buf[mp->mailItem] + mp->mailSent;
	size = mp->mailSize - mp->mailSent;
	result = send(mp->sock,src,size,0);

	if (result==SOCKET_ERROR) {
		err = WSAGetLastError();
		//if (err==WSAENOTCONN) return WSAENOTCONN;
		mp->killed = (err!=WSAEWOULDBLOCK);
		return err;
	}

	if (result<1) return 0;

//--- test for finished ---
printf("out done = %d\n",result);
	mp->mailSent += result;
	if (mp->mailSent >= mp->mailSize) {
		if (++(mp->mailItem)==MAILLINES) mp->killed = true;
		else {
			mp->mailSize = strlen(mp->buf[mp->mailItem]);
			mp->mailSent = 0;
			mp->sending = false;
		}
	}

	return 0;
}


int handleMailInput(mailSession *mp){
int result,size,err;
char *dest;

	if (mp->killed) return 0;

	dest = mp->inBuf + mp->inSize;
	size = BUFFERSIZE - mp->inSize;

	result = recv(mp->sock,dest,size,0);
	if (result>0) mp->inSize += result;

//--- errors/message done ---
	if (result==SOCKET_ERROR) {
		err = WSAGetLastError();
		if (err==WSAENOTCONN) return WSAENOTCONN;
		if (err!=WSAEWOULDBLOCK) {
			mp->killed = true;
			return err;
		}
	}

//--- check for message done ---
	dest = mp->inBuf + mp->inSize - 2;
	if (dest[0]!=13 || dest[1]!=10) return 0;

	mp->inBuf[mp->inSize] = 0;
printf("INBUF=%s\n",mp->inBuf);
	mp->inSize = 0;

	if (mp->mailItem==MAILLINES)	mp->killed = true;
	else							mp->sending = true;

//--- cleanup ---
	return 0;
}

//**********************************************************************************

int sendSMTP(char *addr,char *msg) {
mailSession *temp;
DWORD arg;
int err;

printf("SENDING=%s\n",addr);
	root.sock = socket(AF_INET,SOCK_STREAM,IPPROTO_TCP);
	if (root.sock==INVALID_SOCKET) return -1;

//--- make socket non-blocking ---
	arg = 1L;
	if (ioctlsocket(root.sock,FIONBIO,&arg)==SOCKET_ERROR) {
		printf("IOCTL ERROR=%d\n",WSAGetLastError());
		return -1;
	}

//--- attempt to connect ---
	if (connect(root.sock,&ffiMailAddr,sizeof(ffiMailAddr))==SOCKET_ERROR) {
		err = WSAGetLastError();
		if (err!=WSAEWOULDBLOCK) {
			printf("CONNECT_ERROR=%d\n",err);
			return -1;								// not added to queue
		}
	}

//--- create record ---
	setTodaysDate();
	
	sprintf(root.buf[0],"MAIL FROM:Support@FFIends.com\n");
	sprintf(root.buf[1],"RCPT TO:%s\n",addr);
	sprintf(root.buf[2],"DATA\n");
	sprintf(root.buf[3],
		"Date: %s\nFrom: Support@FFIends.com\n"
		"To: %s\nSubject: Star Dart Automated Message\n"
		"%s\n.\n",
			todayStr,addr,msg);
	sprintf(root.buf[4],"QUIT\n");
	root.mailItem = 0;

//--- other values ---
	root.mailSize = strlen(root.buf[0]);
	root.mailSent = 0;
	root.sending = false;
	root.killed = false;
	root.inSize = 0;

//--- add to list ---
	temp = (mailSession*)malloc(sizeof(mailSession));
	if (temp==NULL) {
		//free(root.buffer);
		return -1;
	}

	memcpy(temp,&root,sizeof(mailSession));
	root.next = temp;

printf("SENDING-OKAY\n");

	return temp->sock;
}


bool mailDone(int mailID){
mailSession *temp;

	temp = root.next;

	while (temp!=NULL) {
		if ((int)(temp->sock)==mailID) return false;
		temp = temp->next;
	}

	return true;
}

//**********************************************************************************

void killMailSessions(){
mailSession *temp,*next;

	temp = root.next;

	while (temp!=NULL) {
		next = temp->next;
		killOneMailSession(temp);
		temp = next;
	}

	root.next = NULL;
}


void killOneMailSession(mailSession *mp){
printf("Kill Mail Session=%d\n",mp->sock);
	closesocket(mp->sock);
	//free(mp->buffer);
	free(mp);
}

//**********************************************************************************
