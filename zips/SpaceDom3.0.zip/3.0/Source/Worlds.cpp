//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant
#include <math.h>

//**********************************************************************************
//**********************************************************************************

int gCORECOUNT;
extern	void FirstVictoryRecord(void);

void CreateGalaxy(int wcount);
void makeWorld(worldRec *worlds, int ix, int wcount);
void MakeName(worldRec *worlds,int index);
int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start);
void killAllSessions(void);
void calcVictoryStats(void);
void CreateNeutralEmpire(int wcount);

//**********************************************************************************

const char *empireFile="Empires.dat";
const char *fleetFile="Fleets.dat";
const char *worldFile="Galaxy.dat";
const char *victoryFile="Victors.dat";

char empirePath[256],fleetPath[256],worldPath[256],victoryPath[256];

CLists *empireList=NULL,*worldList=NULL,*fleetList=NULL;
CRecords *victoryList=NULL;

/*int worldFleetPos[stCOUNT] = {
	posDefendMid,posDefendTop,posDefendTop,
	posInvadeMid,posInvadeTop,posInvadeBot,
};*/

int maxEmpireScore,victoryDate,victoryTime,victoryPercent;
int earthExists,totalWorlds,totalDarts,totalCores,totalHomeWorlds;
long currentTime, elapsedTime, estTimeRemaining, sessionElapsedTime, startTime, resumeTime;

//**********************************************************************************
//**********************************************************************************

/*	resetGalaxy is the main function which calls all other functions needed to end a
	game in progress and get everything set for the next game. This is the function
	that should be called up whenever a game is to be restarted. */

bool resetGalaxy(int goal) {

	elapsedTime = 0;
	currentTime = 0;
	RecordVictory();

	/*
	** Re-read init file on reset to automate settings change
	*/
	if (!readInitFile()) {
		gLog.logMsg(Log::LOG_ERROR,5000,"Can't Read Init File");
	}

	if (goal<minWorlds || goal>highWorlds) {
		goal = Rand(highWorlds - minWorlds) + minWorlds;
	}

	if (empireList!=NULL) {
		empireList->clear();
	}
	if (goal>highWorlds) {
		goal = highWorlds;
	}
	if (fleetList!=NULL) {
		fleetList->clear();
	}
	if (worldList!=NULL) {
		worldList->clear();
	}

	gLog.logMsg(Log::LOG_INFO, 5005, "RESETTING with new world total of %d.", goal);
	cleanupGalaxy();

	if (sroot!=NULL) {		// kill outstanding sessions
		delete sroot;
		sroot = new SessionList();
	}

	return prepareGalaxy(goal);
}

/*	The prepareGalaxy function takes the number of worlds that will be in the next
	game and then creates the data files for the next game depending on that. It then
	calls the function to create the Neutral Empire and calculates the maximum score. */

bool prepareGalaxy(int wcount) {		// called during startup+reset
	empireRec *emp;
	worldRec *worlds, *wp;

	emp = NULL;

	if (empireList==NULL) {
		sprintf(empirePath,"%s/%s",dataPath,empireFile);
		empireList = new CLists(empirePath,sizeof(empireRec));
		empireList->save();
	}

	if (fleetList==NULL) {
		sprintf(fleetPath,"%s/%s",dataPath,fleetFile);
		fleetList = new CLists(fleetPath,sizeof(fleetRec));
		fleetList->save();
	}

	if (worldList==NULL) {
		sprintf(worldPath,"%s/%s",dataPath,worldFile);
		worldList = new CLists(worldPath,sizeof(worldRec));
		worldList->save();
	}

	if (victoryList==NULL){
		sprintf(victoryPath,"%s/%s",dataPath,victoryFile);
		victoryList = new CRecords(victoryPath,0,sizeof(victoryRec));
		if (victoryList->getCount()<1) FirstVictoryRecord();
		calcVictoryStats();
	}

	CreateNeutralEmpire(wcount);

//--- rebuild world ---
	if (worldList->getCount()<1) {
		CreateGalaxy(wcount);
		gCORECOUNT		= (int)((float)wcount * ((float)coreWorldPercent / 100.0));
		if (gCORECOUNT < minNumCoreWorld) gCORECOUNT = minNumCoreWorld;
		totalCores = gCORECOUNT;
		totalHomeWorlds = 8;
		if (oeStartsDead == 1) {
			worlds = (worldRec*)worldList->getList();
			wp = &worlds[0];
			wp->type = wtDead;
		}
		if (timeShiftSkipDays > 0) {
			startTime = time(NULL);
			struct tm *tm_resume;
			tm_resume = localtime(&startTime);
			tm_resume->tm_min = 0;
			tm_resume->tm_sec = 0;
			tm_resume->tm_hour += 1;  // game sessions will start on the hour mark
			resumeTime = mktime(tm_resume);
			startTime = resumeTime;
			sessionElapsedTime = 0;
			gamePaused = true;
			saveStartTime();
		}
	}

	totalWorlds = worldList->getCount();
	totalDarts = CalcDarts(totalWorlds);

	totalWorlds -= CalcNeutron(totalWorlds) + CalcNebulae(totalWorlds) + CalcGates(totalWorlds) + CalcWormholes(totalWorlds) + 1;

	worlds = (worldRec*)worldList->getList();
	/*
	** Check to see of Old Earth still exists
	*/
	wp = &worlds[0];
	if (wp->type == wtDead) {
		earthExists = 0;
	} else {
		earthExists = 1;
	}

	/*
	** Subtract out dead worlds and calculate
	** totals for remaining special worlds
	*/
	for (int ix=1;ix<wcount;ix++) {
		wp = &worlds[ix];
		switch (wp->type) {
			case wtCore:
				totalCores++;
				break;
			case wtNewEarth:
			case wtMakluvia:
			case wtKaletia:
			case wtZorestia:
			case wtAvaria:
			case wtNajunia:
			case wtCestania:
			case wtQuarethia:
			case wtHome:
				totalHomeWorlds++;
				break;
			case wtDead:
				totalWorlds--;
				break;
		}
	}
	maxEmpireScore = calculateMaxEmpireScore();

	loadElapsedTime();
	currentTime = secondsSinceMidnight();
	return true;
}

int calculateMaxEmpireScore()
{
	int maxScore;

	maxScore = totalWorlds;
	maxScore += (earthExists * EarthValue(totalWorlds)) + (totalHomeWorlds * HomeValue(totalWorlds)) + (totalCores * CoreValue(totalWorlds));
	maxScore += totalWorlds + (totalDarts * totalDarts);
	maxScore = maxScore * 1000;

	return maxScore;
}


void cleanupGalaxy(){
	if (empireList!=NULL) {delete empireList;empireList=NULL;}
	if (fleetList!=NULL) {delete fleetList;fleetList=NULL;}
	if (worldList!=NULL) {delete worldList;worldList=NULL;}
}

void calcVictoryStats(){
victoryRec *vrp;
int count;

	count = victoryList->getCount();
	if (victoryList->pickIndex(count-1)) {
		vrp = (victoryRec*)victoryList->getRecord();
		victoryDate = vrp->getDate();
		victoryTime = vrp->getTime();
	}
	else {
		victoryDate = dateIndex();
		victoryTime = secondsSinceMidnight();
	}
}

//**********************************************************************************

/*	The CreateGalaxy function is the function which actually creates all the worlds
	in a particular game and later converts some of them to phenomena and homeworlds. */

void CreateGalaxy(int wcount) {
	int ix,i,numDarts,numDartsAdded;
	worldRec *worlds,*wp;
	fleetRec *fleets,*fp;
	int locRoot;

	bool humanHomeWorld = false;
	bool makluvianHomeWorld = false;
	bool kaletianHomeWorld = false;
	bool zorestianHomeWorld = false;
	bool avarianHomeWorld = false;
	bool najunianHomeWorld = false;
	bool cestanianHomeWorld = false;
	bool quarethianHomeWorld = false;
	int poorCount;
	int richCount;
	int smallCount;
	int largeCount;
	int aquaticCount;
	int mountainCount;
	int desertCount;
	int tundraCount;
	int jungleCount;
	int metallicCount;
	int merchantCount;
	int beaconCount;
	int stardockCount;
	int nebulaeCount;
	int neutronCount;
	int gatewayCount;
	int wormholeCount;
	int count;
	int dartsToAdd;

	gLog.logMsg(Log::LOG_INFO, 5010, "*** Building New Galaxy ***");
	srand(time(NULL));

	elapsedTime = 0;
	saveElapsedTime();

	worldList->expand(wcount);
	worlds = (worldRec*)worldList->getList();
	memset(worlds, 0, worldList->getCount() * sizeof(worldRec));

	fleetList->expand(wcount);
	fleets = (fleetRec*)fleetList->getList();
	memset(fleets, 0, fleetList->getCount() * sizeof(fleetRec));

	gCORECOUNT		= (int)((float)wcount * ((float)coreWorldPercent / 100.0));
	poorCount		= (int)((float)wcount * ((float)poorWorldPercent / 100.0));
	richCount		= (int)((float)wcount * ((float)richWorldPercent / 100.0));
	smallCount		= (int)((float)wcount * ((float)smallWorldPercent / 100.0));
	largeCount		= (int)((float)wcount * ((float)largeWorldPercent / 100.0));
	aquaticCount	= (int)((float)wcount * ((float)aquaticWorldPercent / 100.0));
	mountainCount	= (int)((float)wcount * ((float)mountainWorldPercent / 100.0));
	desertCount		= (int)((float)wcount * ((float)desertWorldPercent / 100.0));
	tundraCount		= (int)((float)wcount * ((float)tundraWorldPercent / 100.0));
	jungleCount		= (int)((float)wcount * ((float)jungleWorldPercent / 100.0));
	metallicCount	= (int)((float)wcount * ((float)metallicWorldPercent / 100.0));
	merchantCount	= (int)((float)wcount * ((float)merchantWorldPercent / 100.0));
	beaconCount		= (int)((float)wcount * ((float)beaconWorldPercent / 100.0));
	stardockCount	= (int)((float)wcount * ((float)stardockWorldPercent / 100.0));
	nebulaeCount	= (int)((float)wcount * ((float)nebulaePercent / 100.0));
	neutronCount	= (int)((float)wcount * ((float)neutronPercent / 100.0));
	gatewayCount	= (int)((float)wcount * ((float)gatewayPercent / 100.0));
	wormholeCount	= (int)((float)wcount * ((float)wormholePercent / 100.0));
	
	if (gCORECOUNT < minNumCoreWorld) gCORECOUNT = minNumCoreWorld;
	if (poorCount < minNumPoorWorld) poorCount = minNumPoorWorld;
	if (richCount < minNumRichWorld) richCount = minNumRichWorld;
	if (smallCount < minNumSmallWorld) smallCount = minNumSmallWorld;
	if (largeCount < minNumLargeWorld) largeCount = minNumLargeWorld;
	if (aquaticCount < minNumAquaticWorld) aquaticCount = minNumAquaticWorld;
	if (mountainCount < minNumMountainWorld) mountainCount = minNumMountainWorld;
	if (desertCount < minNumDesertWorld) desertCount = minNumDesertWorld;
	if (tundraCount < minNumTundraWorld) tundraCount = minNumTundraWorld;
	if (jungleCount < minNumJungleWorld) jungleCount = minNumJungleWorld;
	if (metallicCount < minNumMetallicWorld) metallicCount = minNumMetallicWorld;
	if (merchantCount < minNumMerchantWorld) merchantCount = minNumMerchantWorld;
	if (beaconCount < minNumBeaconWorld) beaconCount = minNumBeaconWorld;
	if (stardockCount < minNumStardockWorld) stardockCount = minNumStardockWorld;
	if (nebulaeCount < minNumNebulae) nebulaeCount = minNumNebulae;
	if (neutronCount < minNumNeutron) neutronCount = minNumNeutron;
	if (gatewayCount < minNumGateway) gatewayCount = minNumGateway;
	if (wormholeCount < minNumWormhole) wormholeCount = minNumWormhole;

	count = gCORECOUNT
			+ poorCount
			+ richCount
			+ smallCount
			+ largeCount
			+ aquaticCount
			+ mountainCount
			+ desertCount
			+ tundraCount
			+ jungleCount
			+ metallicCount
			+ merchantCount
			+ beaconCount
			+ stardockCount
			+ nebulaeCount
			+ neutronCount
			+ gatewayCount
			+ wormholeCount;

	if (allowHomeWorlds == 1) {
		count += 8;
	}

	count += 1; // oe is always there

	if (count > wcount) {
		gLog.logMsg(Log::LOG_ERROR, 5020, "Too many special worlds, %d is greater than number of worlds in galaxy %d",count, wcount);
		exit(0);
	}

//--- Create Earth ---
	wp = &worlds[0];
	wp->worldID = 0;

	gLog.logMsg(Log::LOG_INFO, 5030, "Making world id %d (%s)",wp->worldID, "Old Earth");
	wp->pop = oePop;
	wp->ind = (int)(oePop * oeIndMod);
	wp->type = wtHome;
	if (facilityVariation == 0) {
		wp->maxMerchant = 1;
		wp->maxBeacon = 1;
		wp->maxStardock = 1;
		wp->Merchant = 0;
		wp->Beacon = 0;
		wp->Stardock = 0;
	} else {
		wp->Merchant = earthMerchant;
		wp->maxMerchant = earthMerchant;
		wp->Beacon = earthBeacon;
		wp->maxBeacon = earthBeacon;
		wp->Stardock = earthStardock;
		wp->maxStardock = earthStardock;
	}
	wp->sector = 8;

	wp->facility = ftStellurae;
	wp->facilityTime = 0;

	strcpy(wp->name,"Old Earth");
	for (i=0;i<btIndustry;i++) {
		wp->cmd[i].repeat = true;
		wp->cmd[i].type = i;
		wp->cmd[i].goal = cost[stFrigate] / cost[i];
	}

	fp = &fleets[0];

	fp->ecm = ecmOE;

	for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
	for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,100*worldDecayRate/cost[i]);
	for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;

//--- Core Worlds ---
//	locRoot = MINDIST;
	locRoot = 1000;

	numDarts = CalcDarts(wcount);
	numDartsAdded = 0;

	for (ix=1;ix<=gCORECOUNT;ix++) {

		wp = &worlds[ix];
		wp->worldID = ix;

	//--- world record ---
		wp->pop = corePop;
		wp->ind = (int)(corePop * coreIndMod);
		wp->type = wtCore;
		if (facilityVariation == 0) {
			wp->maxMerchant = 1;
			wp->maxBeacon = 1;
			wp->maxStardock = 1;
			wp->Merchant = 0;
			wp->Beacon = 0;
			wp->Stardock = 0;
		} else {
			wp->Merchant = coreMerchant;
			wp->maxMerchant = coreMerchant;
			wp->Beacon = coreBeacon;
			wp->maxBeacon = coreBeacon;
			wp->Stardock = coreStardock;
			wp->maxStardock = coreStardock;
		}
		wp->sector = 8;

		wp->facility = ftStellurae;
		wp->facilityTime = 0;

		MakeName(worlds,ix);
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
		gLog.logMsg(Log::LOG_INFO, 5050, "Making world id %d (%s)",ix ,wp->name);

		for (i=0;i<btIndustry;i++) {
			wp->cmd[i].repeat = true;
			wp->cmd[i].type = i;
			wp->cmd[i].goal = cost[stFrigate] / cost[i];
		}

	//--- fleet record ---
		fp = &fleets[ix];

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;

		fp->ecm = ecmCore;

		for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
		for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,40*worldDecayRate/cost[i]);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;

		dartsToAdd = (int)((float)numDarts * ((float)dartsPerCorePercent/100.0));
		if (dartsToAdd < minDartsPerCore) dartsToAdd = minDartsPerCore;

		addFleetShips(fp,stStarDart,dartsToAdd);
		numDartsAdded += dartsToAdd;
	}

//--- The Remaining Cluster ---
	i = ix;  // save current ix for use after types have been assigned
	while (poorCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtPoor;
		poorCount--;
	}
	while (richCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtRich;
		richCount--;
	}
	while (smallCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtSmall;
		smallCount--;
	}
	while (largeCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtLarge;
		largeCount--;
	}
	while (aquaticCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtAquatic;
		aquaticCount--;
	}
	while (mountainCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtMountain;
		mountainCount--;
	}
	while (desertCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtDesert;
		desertCount--;
	}
	while (tundraCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtTundra;
		tundraCount--;
	}
	while (jungleCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtJungle;
		jungleCount--;
	}
	while (metallicCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtMetallic;
		metallicCount--;
	}
	while (merchantCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtMerchant;
		merchantCount--;
	}
	while (beaconCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtSmall;
		beaconCount--;
	}
	while (stardockCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtStardock;
		stardockCount--;
	}
	while (nebulaeCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtNebulae;
		nebulaeCount--;
	}
	while (neutronCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtNeutron;
		neutronCount--;
	}
	while (gatewayCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtGateway;
		gatewayCount--;
	}
	while (wormholeCount > 0) {
		ix = Rand(wcount - 1) + 1;
		wp = &worlds[ix];
		if (wp->type != wtNormal) {
			continue;
		}
		wp->type = wtWormhole;
		wormholeCount--;
	}

	for (ix=i ;ix<wcount ;ix++) {
		makeWorld(worlds, ix, wcount);
		wp = &worlds[ix];
		fp = &fleets[ix];
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
		if (wp->xloc>0 && wp->yloc>0 && wp->xloc>wp->yloc) {
			wp->sector = 2;
		}
		else if (wp->xloc>0 && wp->yloc>0 && wp->xloc<wp->yloc) {
			wp->sector = 3;
		}
		else if (wp->xloc<0 && wp->yloc<0 && wp->xloc>wp->yloc) {
			wp->sector = 7;
		}
		else if (wp->xloc<0 && wp->yloc<0 && wp->xloc<wp->yloc) {
			wp->sector = 6;
		}
		else if (wp->xloc>0 && wp->yloc<0 && (wp->xloc * wp->xloc < wp->yloc * wp->yloc)) {
			wp->sector = 0;
		}
		else if (wp->xloc>0 && wp->yloc<0 && (wp->xloc * wp->xloc > wp->yloc * wp->yloc)) {
			wp->sector = 1;
		}
		else if (wp->xloc<0 && wp->yloc>0 && (wp->xloc * wp->xloc > wp->yloc * wp->yloc)) {
			wp->sector = 5;
		}
		else if (wp->xloc<0 && wp->yloc>0 && (wp->xloc * wp->xloc < wp->yloc * wp->yloc)) {
			wp->sector = 4;
		}
		else {
			wp->sector = 8;
		}

		//--- fleet record ---
		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;
		fp->ecm = Rand(ecmMax - ecmMin) + ecmMin + wp->pop*ecmPopBonus;
		for (i=0;i<posCOUNT;i++) {
			fp->squad[i].type = stCOUNT;
		}
		if (isPhenomena(wp->type)) {
  		    fp->status = fsDead;
		} else {
			if (stationsOnly) {
				wp->cmd[0].repeat = true;
				wp->cmd[0].type = btStation;
				wp->cmd[0].goal = 10;
				buildFleetShips(fp,stStation,(wp->pop+wp->ind)*worldDecayRate/cost[stStation]);
			} else {
				wp->cmd[0].repeat = true;
				wp->cmd[0].type = btPinnace;
				wp->cmd[0].goal = 20;
				buildFleetShips(fp,stPinnace,(wp->pop+wp->ind)*worldDecayRate/cost[stPinnace]);
				if ((wp->pop+wp->ind) > (cost[btStation]/10)) {
					wp->cmd[1].repeat = true;
					wp->cmd[1].type = btStation;
					wp->cmd[1].goal = 10;
					buildFleetShips(fp,stStation,(wp->pop+wp->ind)*worldDecayRate/cost[stStation]);
				}
				if ((wp->pop+wp->ind) > (cost[btCorsair]/10)) {
					wp->cmd[2].repeat = true;
					wp->cmd[2].type = btCorsair;
					wp->cmd[2].goal = 4;
					buildFleetShips(fp,stCorsair,(wp->pop+wp->ind)*worldDecayRate/cost[stCorsair]);
				}
				if ((wp->pop+wp->ind) > (cost[btRanger]/10)) {
					wp->cmd[3].repeat = true;
					wp->cmd[3].type = btRanger;
					wp->cmd[3].goal = 4;
					buildFleetShips(fp,stRanger,(wp->pop+wp->ind)*worldDecayRate/cost[stRanger]);
				}
				if ((wp->pop+wp->ind) > (cost[btFrigate]/10)) {
					wp->cmd[3].repeat = true;
					wp->cmd[3].type = btFrigate;
					wp->cmd[3].goal = 1;
					buildFleetShips(fp,stFrigate,(wp->pop+wp->ind)*worldDecayRate/cost[stFrigate]);
				}
			}
  		    fp->status = fsWaiting;
	    }

		for (i=0;i<sideCOUNT;i++) {
			fp->engageID[i] = -1;
		}

		Sleep(10);


	}

// --- Home Worlds ---
	if (allowHomeWorlds == 1) {
		for (ix=wcount/2;ix<wcount;ix++) {
			wp = &worlds[ix];
			if (wp->sector==0 && humanHomeWorld==false) {
				wp->type = wtNewEarth;
				strcpy(wp->name,"New Earth");
				gLog.logMsg(Log::LOG_INFO, 5070, "Converting New Earth.");
				humanHomeWorld = true;
			}
			if (wp->sector==1 && makluvianHomeWorld==false) {
				wp->type = wtMakluvia;
				strcpy(wp->name,"Makluvia");
				gLog.logMsg(Log::LOG_INFO, 5080, "Converting Makluvia.");
				makluvianHomeWorld = true;
			}
			if (wp->sector==2 && kaletianHomeWorld==false) {
				wp->type = wtKaletia;
				strcpy(wp->name,"Kaletia");
				gLog.logMsg(Log::LOG_INFO, 5090, "Converting Kaletia.");
				kaletianHomeWorld = true;
			}
			if (wp->sector==3 && zorestianHomeWorld==false) {
				wp->type = wtZorestia;
				strcpy(wp->name,"Zorestia");
				gLog.logMsg(Log::LOG_INFO, 5100, "Converting Zorestia.");
				zorestianHomeWorld = true;
			}
			if (wp->sector==4 && avarianHomeWorld==false) {
				wp->type = wtAvaria;
				strcpy(wp->name,"Avaria");
				gLog.logMsg(Log::LOG_INFO, 5110, "Converting Avaria.");
				avarianHomeWorld = true;
			}
			if (wp->sector==5 && najunianHomeWorld==false) {
				wp->type = wtNajunia;
				strcpy(wp->name,"Najunia");
				gLog.logMsg(Log::LOG_INFO, 5120, "Converting Najunia.");
				najunianHomeWorld = true;
			}
			if (wp->sector==6 && cestanianHomeWorld==false) {
				wp->type = wtCestania;
				strcpy(wp->name,"Cestania");
				gLog.logMsg(Log::LOG_INFO, 5130, "Converting Cestania.");
				cestanianHomeWorld = true;
			}
			if (wp->sector==7 && quarethianHomeWorld==false) {
				wp->type = wtQuarethia;
				strcpy(wp->name,"Quarethia");
				gLog.logMsg(Log::LOG_INFO, 5140, "Converting Quarethia.");
				quarethianHomeWorld = true;
			}

			if (wp->type>=wtNewEarth && wp->type<=wtQuarethia) {
				wp->pop = homePop;
				wp->ind = (int)(homePop * homeIndMod);
				if (facilityVariation == 0) {
					wp->maxMerchant = 1;
					wp->maxBeacon = 1;
					wp->maxStardock = 1;
					wp->Merchant = 0;
					wp->Beacon = 0;
					wp->Stardock = 0;
				} else {
					wp->Merchant = homeMerchant;
					wp->maxMerchant = homeMerchant;
					wp->Beacon = homeBeacon;
					wp->maxBeacon = homeBeacon;
					wp->Stardock = homeStardock;
					wp->maxStardock = homeStardock;
				}

				wp->facility = ftStellurae;
				wp->facilityTime = 0;

				for (i=0;i<btIndustry;i++) {
					wp->cmd[i].repeat = true;
					wp->cmd[i].type = i;
					wp->cmd[i].goal = cost[stFrigate] / cost[i];
				}

				fp = &fleets[ix];

				fp->ecm = ecmHome;

				for (i=0;i<posCOUNT;i++) {
					fp->squad[i].type = stCOUNT;
				}
				for (i=0;i<stStarDart;i++) {
					buildFleetShips(fp,i,70*worldDecayRate/cost[i]);
				}
				for (i=0;i<sideCOUNT;i++) {
					fp->engageID[i] = -1;
				}
				
				dartsToAdd = (int)((float)numDarts * ((float)dartsPerHomePercent/100.0));

				if (dartsToAdd < minDartsPerHome) {
					dartsToAdd = minDartsPerHome;
				}

				addFleetShips(fp,stStarDart,dartsToAdd);
				numDartsAdded += dartsToAdd;
			}
		}
	}

	gLog.logMsg(Log::LOG_INFO, 5150, "StarDarts = %d\n",numDarts);

	dartsToAdd = (int)((float)numDarts * ((float)dartsPerOEPercent/100.0));

	if (oeStartsDead == 1) {	// no darts for OE if it starts out dead
		dartsToAdd = 0;
	} else {
		if (dartsToAdd < minDartsPerOE) dartsToAdd = minDartsPerOE;

		addFleetShips(&fleets[0],stStarDart,dartsToAdd);		// dartsPerOEPercent% of Darts to earth with a minimum of minDartsPerOE
	}

	for (i = numDartsAdded;i<numDarts;i++) {
		do ix = 13 + Rand(wcount-13);
		while (!isPlanet(worlds[ix].type));
		addFleetShips(&fleets[ix],stStarDart,1);
	}

//--- cleanup ---
	worldList->save();
	fleetList->save();
}


void makeWorld(worldRec *worlds, int ix, int wcount) {
	worldRec *wp;
	wp = &worlds[ix];
	wp->worldID = ix;

	MakeName(worlds,ix);

	/*
	** If logging level is high enough to show LOG_INFO messages,
	** set logging level to LOG_DEBUG_VERBOSE for this log message
	** to prevent grouping since the world id and name are different
	** for every message
	*/
	Log::loggingLevel ll = gLog.getLogLevel();
	if (ll >= Log::LOG_INFO) {
	   ll = gLog.setLogLevel(Log::LOG_DEBUG_VERBOSE);
 	}
	gLog.logMsg(Log::LOG_INFO, 5160, "Making world id %d (%s)",ix ,wp->name);
	/*
	** Return logging level to what it was originally
	*/
	gLog.setLogLevel(ll);
	
	if (wp->type >= wtNebulae && wp->type <= wtWormhole) {
		fleetRec *fleets = (fleetRec*)fleetList->getList();
		for (int pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
		return;
	}
//	wp->pop = 99 - 90*ix/wcount;
    wp->pop = maxPop - (maxPop - minPop)*ix/wcount;
    switch(wp->type) {
	    case wtNormal:
		case wtMerchant:
		case wtBeacon:
		case wtStardock:
		case wtAquatic:
		case wtMountain:
		case wtDesert:
		case wtTundra:
		case wtJungle:
		case wtMetallic:
			 wp->maxInd = (int)(wp->pop*normalIndMod);
			 break;
	    case wtRich:
			 wp->maxInd = (int)(wp->pop*richIndMod);	// up to 1/2 of max industry	 
			 break;
	    case wtPoor:
			 wp->maxInd = (int)(wp->pop*poorIndMod);	// up to 1/2 of max industry	 
			 break;
	    case wtLarge:
			 wp->maxInd = (int)(wp->pop*largeIndMod);	// up to 1/2 of max industry	 
			 break;
	    case wtSmall:
			 wp->maxInd = (int)(wp->pop*smallIndMod);	// up to 1/2 of max industry	 
			 break;
	    case wtCore:
			 wp->maxInd = (int)(wp->pop*coreIndMod);	// up to 1/2 of max industry	 
			 break;
	    case wtHome:
		case wtNewEarth:
		case wtMakluvia:
		case wtKaletia:
		case wtZorestia:
		case wtAvaria:
		case wtNajunia:
		case wtCestania:
		case wtQuarethia:
			 wp->maxInd = (int)(wp->pop*homeIndMod);	// up to 1/2 of max industry	 
			 break;
	 }
	 wp->ind = Rand(wp->maxInd/2);	// up to 1/2 of max industry	 
//	wp->pop = 79 - 70*ix/wcount;
//	wp->ind = Rand(201) * wp->pop / 100;	// up to x2

	wp->facility = ftCOUNT;
	wp->facilityTime = 0;

	wp->Merchant = 0;
	wp->Beacon = 0;
	wp->Stardock = 0;

	/*
	** facilityVariation of zero means all worlds can build
	** at least one of each facility.
	** facilityVariation of one varies available facilities
	** based on population.
	** facility worlds behave the same for their facility
	** for either value of facilityVariation.
	*/
	if (facilityVariation == 0) {
		wp->maxMerchant = 1;
		wp->maxBeacon = 1;
		wp->maxStardock = 1;
	} else {
		wp->maxMerchant = (wp->pop / 30) + 1;
		wp->maxStardock = (wp->pop / 40) + 1;
		if (wp->pop>=60) {
			wp->maxBeacon = 1;
		}
	}
	if (wp->type==wtMerchant) {
		if (facilityVariation == 0) {
			wp->maxMerchant = 2;
			wp->Merchant = 1;
		} else {
			wp->maxMerchant = wp->pop / 5;
		}
	}

	if (wp->type==wtBeacon) {
		if (facilityVariation == 0) {
			wp->maxBeacon = 2;
			wp->Beacon = 1;
		} else {
			wp->maxBeacon = wp->pop / 8;
		}
	}

	if (wp->type==wtStardock) {
		if (facilityVariation == 0) {
			wp->maxStardock = 2;
			wp->Stardock = 1;
		} else {
			wp->maxStardock = wp->pop / 5;
		}
	}
}

//**********************************************************************************

const char *vowels = "aaaiiueeeoy";
const char *cons = "bcdfghjklmnpqrstvwxz";
const int vlen = strlen(vowels);
const int clen = strlen(cons);
inline char RandVowel(){return vowels[Rand(vlen)];}
inline char RandCons(){return cons[Rand(clen)];}


void MakeName(worldRec *worlds,int index){
int ix,num,i;
char *name;

	name = worlds[index].name;

	while (true) {

	//--- build name ---
		ix = 0;
		num = 1+Rand(2)+Rand(3)/2+Rand(4)/3;

		if (Rand(3)==0) name[ix++] = RandVowel();
		for (i=0;i<num;i++) {
			name[ix++] = RandCons();
			name[ix++] = RandVowel();
		}
		if (Rand(2)==0) name[ix++] = RandCons();
		name[ix++] = 0;

		name[0] = name[0] - 'a' + 'A';	// capitalize

	//--- compare name ---
		for (i=0;i<index;i++) {
			if (equals(worlds[i].name,name)) break;
		}
		if (i==index) return;	// no matches
	}
}

/*	The FleetLocation function is responsible for recognizing where a fleet has moved
	and officially updating the new location of that fleet. */

void FleetLocation(int *xloc,int *yloc){
worldRec *worlds,*wp;
int sx,sy,min,val,i,count;
float dx,dy;

	worlds = (worldRec*)worldList->getList();
	count = worldList->getCount();

	while (true) {

		wp = &worlds[count*4/5 + Rand(count/5)];

		sx = wp->xloc + Rand(MINDIST) - MINDIST/2;
		sy = wp->yloc + Rand(MINDIST) - MINDIST/2;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST/2) continue;
		if (min>MINDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		return;
	}
}


int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start){
int cx,cy,sx,sy,range,min,i,val;
float dx,dy;

//-- calculate galactic center ---
	dx = dy = 0.0;
	for (i=0;i<count;i++) {
		dx += worlds[i].xloc;
		dy += worlds[i].yloc;
	}

	if (count>0) {
		cx = (int)(dx / count);
		cy = (int)(dy / count);
	}
	else cx = cy = 0;

//--- start testing random locations --- 
	range = start * 3 / 4;

	while (true) {

		sx = BRand(range) - range/2 - cx;
		sy = BRand(range) - range/2 - cy;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST) {
			range += MINDIST;
			continue;
		}
		if (min>MAXDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		break;
	}

	return range;
}

//**********************************************************************************

static int startCount[stCOUNT] = {20,100,5,0,0,0};
static int startType[stCOUNT] = {stCorsair,stPinnace,stFrigate,stCOUNT,stCOUNT,stCOUNT};

void CreateNeutralEmpire(int wcount){
empireRec *emp;

//--- create empire ---

	if (empireList->getCount()<1) {
       empireList->increment();
    }
	emp = (empireRec*)empireList->getRecord(0);

	if (emp!=NULL) {
		memset(emp,0,sizeof(empireRec));
		strcpy(emp->name,"Neutral");
		strcpy(emp->pass,"np");
//		emp->race = 0;
		emp->ruler = -1;
		emp->worlds = wcount;
		emp->darts = CalcDarts(wcount);
		emp->fleetID = -1;	// Neutral does not need a fleet
//		emp->Merchant = 0;
//		emp->Beacon = 0;
//		emp->Stardock = 0;
//		emp->scoreDarts  = 0;
	}

	empireList->save(0);
}

bool CreateEmpire(char *name,char *pass){
fleetRec *fp;
empireRec *emp;
int empireID;

//--- create empire ---
	empireID = empireList->increment();

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return false;

	memset(emp,0,sizeof(empireRec));
	strcpy(emp->name,name);
	strcpy(emp->pass,pass);

	emp->race = 8;
	emp->ruler = -1;
	emp->worlds = 0;
	emp->darts = 0;
	emp->fleetID = fleetList->increment();
	emp->Merchant = 0;
	emp->Beacon = 0;
	emp->Stardock = 0;
	emp->scoreDarts  = 0;

	emp->changedRace = false;
	emp->declaredEarth = false;
	emp->declaredHome = false;
	
	emp->worldGuns = 0;

	empireList->save(empireID);

//--- create fleet ---
	fleetList->increment();
	fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
	if (fp==NULL) return false;

	CreateFleet(fp,empireID);

	fleetList->save(emp->fleetID);
	
//--- cleanup ---
	return true;
}


void CreateFleet(fleetRec *fp,int empireID){
	int i=0;
	memset(fp,0,sizeof(fleetRec));
	fp->empireID = empireID;

	FleetLocation(&fp->xloc,&fp->yloc);

	fp->destID = -1;
	for (int pos=0;pos<posCOUNT;pos++)
	{
		fp->squad[pos].type=stCOUNT;
	}
    int totalGuns=0, averageGuns = 0;
    empireRec *emp;
    for (int ix=0; ix < empireList->getCount(); ix++) {
		emp=(empireRec*)empireList->getRecord(ix);
        if (emp->worlds <= 0) {
	        continue;
	    }
	    totalGuns += emp->worldGuns;
 	}
 	averageGuns = (int)(totalGuns/totalWorlds);
    gLog.logMsg(Log::LOG_INFO,5170,"Game currently has an average of %d guns per world.",averageGuns);
	/*
	**  pos layout:
	**   ___     
	**  |   |___ 
	**  | 3 |   |
	**  |___| 0 |
	**  |   |___|
	**  | 4 |   |
	**  |___| 1 |
	**  |   |___|
	**  | 5 |   |
	**  |___| 2 |
	**      |___|
	*/
	/*
	** Increase starting guns based on current average guns per world
	*/
	while (fp->guns < averageGuns) {
		addFleetShips(fp, stPinnace, 0 /*pos*/, start_sloop);
		addFleetShips(fp, stRanger,  1 /*pos*/, start_ranger);
		addFleetShips(fp, stCorsair, 2 /*pos*/, start_corsair);
		addFleetShips(fp, stFrigate, 5 /*pos*/, start_frigate);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
	}
    gLog.logMsg(Log::LOG_INFO,5180,"New players will start with %d guns.",fp->guns);
}

//**********************************************************************************
