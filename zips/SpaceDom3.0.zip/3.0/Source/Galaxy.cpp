//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant

//**********************************************************************************

void pauseGame();
void captureWorld(int worldID,worldRec *wp,int newEmpire);
int calculateCost(int mineral, int baseCost);
bool calculateScore(long *estTimeRemaining);

void sessionScanFleets(Session *ssn);
void sessionScanWorlds(Session *ssn);

void fleetAdvance(int fleetID,fleetRec *fp);
void fleetHitsTarget(int fleetID,fleetRec *fp);
void fleetHitsZone(fleetRec *fp,worldRec *wp);

void fleetBattle(int fleetID,fleetRec *fp);
void fleetAutoAction(int fleetID,fleetRec *fp);
void fleetMoveSquad(fleetRec *fp,int squadID,int action);
void fleetFireSquad(fleetRec *fp,int squadID,int action,int enemy);

inline int InverseEngage(int i){return sideCOUNT-1-i;}

//**********************************************************************************

int lastCaptureUpdate = 0;
int lastWorldUpdate = 0;

int dartCheck(worldRec *wp) {
	fleetRec *fp;
	int count;

	fp = (fleetRec*)fleetList->getRecord(wp->worldID);
	count = 0;

	for (int currentSquad=0; currentSquad < stCOUNT; currentSquad++) {
		if (fp->squad[currentSquad].type == stStarDart) {
			count = fp->squad[currentSquad].count;
		}
	}
	return count;
}

void operateCapture() {
	int update,count,ix;
	fleetRec *fp,*fleets;
	worldRec *wp,*worlds;

	update = time(NULL);
	if (lastCaptureUpdate+1 > update) {
		return;
	}
	lastCaptureUpdate = update;
	count = worldList->getCount();
	worlds = (worldRec*)worldList->getList();
	fleets = (fleetRec*)fleetList->getList();

	for (ix=0; ix < count; ix++) {
		wp = &worlds[ix];
		if (!isPlanet(wp->type)) {
			continue;
		}

		fp = &fleets[ix];

		if (wp->empireID!=fp->empireID) {
			gLog.logMsg(Log::LOG_DEBUG, 3010, "Planet %s has been captured.",wp->name);
			captureWorld(ix,wp,fp->empireID);
		}
	}
}

void operateWorlds() {
	int update,count,ix,i,num,val,wcount;
	fleetRec *fp,*fleets;
	worldRec *wp,*worlds;
	empireRec *emp;
	squadRec *sp;
	buildCmd bd;
	bool autoReset;
	int reducedRate;
	int lastTime=0, deltaTime=0;

	update = time(NULL);
	if (lastWorldUpdate + gameTicks > update) {
		return;
	}
	lastWorldUpdate = update;

	count = worldList->getCount();
	worlds = (worldRec*)worldList->getList();
	fleets = (fleetRec*)fleetList->getList();

	gLog.logMsg(Log::LOG_DEBUG, 3020, "Operating build.");
	for (ix=0;ix<count;ix++) {
		wp = &worlds[ix];
		if (!isPlanet(wp->type)) continue;

		fp = &fleets[ix];

		if (wp->empireID!=fp->empireID) captureWorld(ix,wp,fp->empireID);

		if (fp->status==fsBattle) continue;		// no production

	//--- compress build commands ---
		for (val=num=0;num<MAXBUILD;num++) {
			if (wp->cmd[num].type>=btCOUNT || wp->cmd[num].goal==0) continue;
			if (val<num) {
				wp->cmd[val] = wp->cmd[num];
				wp->cmd[num].type = btCOUNT;
			}
			val++;
		}

	//--- produce build points ---
		if (val==0) {
			wp->storage = 0;
		} else {
			num = wp->pop + wp->ind;
			int bpBonusMerchant = 0;
			int bpBonusWorldType = 0;
			int bpBonusHomeWorld = 0;
			int bpBonusCommand = 0;
			emp = (empireRec*)empireList->getRecord(fp->empireID);

			if (emp!=NULL && fp->empireID!=0) {
				if (merchantBonusType == 1) {
					bpBonusMerchant += (int)((num * (emp->Merchant * merchantBonus) / 1000.0) * raceBuildModifier[emp->race]);
				} else {
					bpBonusMerchant += (int)((num + (emp->Merchant * merchantBonus)) * raceBuildModifier[emp->race]);
				}
			}

			if (wp->type>=wtNewEarth && wp->type<=wtQuarethia && fp->empireID==0) {
				bpBonusHomeWorld = num * (fp->empireID==0)?3:1;
			}

			switch (wp->type) {
				case wtHome:
					bpBonusWorldType = (int)(num * (fp->empireID==0)?4:(3.0/2.0));
					break;
				case wtCore:
					bpBonusWorldType = (int)(num * (fp->empireID==0)?2:(1.0/2.0));
					break;
				case wtPoor:
					bpBonusWorldType = -(num / 2);
					break;
				case wtRich:
					bpBonusWorldType = num / 2;
					break;
			}

			/*
			** Worlds in your race's sector get a build bonus too
			*/
			if (emp->race == wp->sector) {
				bpBonusWorldType += (int)(num * raceSectorBuildModifier);
			}

			/*
			** Fleet command bonus
			*/
			if (wp->empireID!=0) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				if (emp!=NULL) {
					fp = &fleets[emp->fleetID];
					if (fp->xloc==wp->xloc && fp->yloc==wp->yloc) {
						bpBonusCommand = (int)((commandBuild + emp->Merchant * commandBonus) * raceCommandModifier[emp->race]);
					}
					fp = &fleets[ix];
				}
			}

			wp->storage += num
						+ bpBonusMerchant
						+ bpBonusWorldType
						+ bpBonusCommand;
		}

		bool bDone = false;
		while (!bDone && (wp->storage>0)) {
			bd = wp->cmd[0];
			int newCost = cost[bd.type];
			int oldFacility = ftCOUNT;

			if (newCost == 0) {
				/*
				** Cost of 0 means that facility isn't allowed.
				** Client should NOT be able to send a build command
				** for it.
				*/
				bDone = true;
				continue;
			}

			switch (bd.type) {
				case btCOUNT:
					bDone = true;
					continue;
					break;
				case btPinnace:
					if (wp->type==wtAquatic) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btStation:
					if (wp->type==wtJungle) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btCorsair:
					if (wp->type==wtTundra) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btRanger:
					if (wp->type==wtMountain) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btFrigate:
					if (wp->type==wtDesert) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btIndustry:
					if (wp->type==wtMetallic) {
						newCost = (int)(newCost * specialWorldShipModifier);
					}
					break;
				case btMerchant:
					newCost = merchantCost;
					break;
				case btBeacon:
					newCost = beaconCost;
					break;
				case btStardock:
					newCost = stardockCost;
					break;
				case btSabotage:
					newCost = doomsdayCost;
					break;
				case btShield:
					newCost = shieldCost;
					break;
				case btStellurae:
					newCost = stelluraeCost;
					break;
			}

			num = wp->storage / newCost;

			if (facilityCostType == 1) {	// some facilities time base
				if (bd.type >= btMerchant && bd.type <= btStardock) {
					num = wp->facilityTime / newCost;
					if (num > 0) {
						wp->facilityTime = 0;
					}
				}
			}

			if (num==0) break;

			if (facilityCostType == 1) {	// some facilities time base
				if (bd.type<btMerchant || bd.type>btStardock) {
					if (num>bd.goal-bd.built) {
						num = bd.goal - bd.built;
					}
					bd.built += num;
				}
			} else	{	// no facilities time based
				if (num>bd.goal-bd.built) num = bd.goal - bd.built;
				bd.built += num;
			}
			if (bd.type==btIndustry) {	
				wp->ind += num;
				if (wp->ind >= wp->maxInd) {
					wp->cmd[0].type = btCOUNT;
 			    }
			} else if (bd.type==btMerchant) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				if (wp->Merchant < wp->maxMerchant) {
					wp->Merchant += 1;
					emp->Merchant = emp->Merchant + 1;
				}
				if (wp->Merchant >= wp->maxMerchant) {
					wp->cmd[0].type = btCOUNT;
				}
				if (allowMultipleFacilities == 0) {
					oldFacility = wp->facility;
					wp->facility = ftMerchant;
				}
			} else if (bd.type==btBeacon) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				fp = (fleetRec*)fleetList->getRecord(wp->empireID);
				if (wp->Beacon < wp->maxBeacon) {
					wp->Beacon += 1;
					emp->Beacon = emp->Beacon + 1;
					fp->Beacon = fp->Beacon + 1;
				}
				if (wp->Beacon >= wp->maxBeacon) {
					wp->cmd[0].type = btCOUNT;
				}
				if (allowMultipleFacilities == 0) {
					oldFacility = wp->facility;
					wp->facility = ftBeacon;
				}
			} else if (bd.type==btStardock) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				fp = (fleetRec*)fleetList->getRecord(wp->empireID);
				if (wp->Stardock < wp->maxStardock) {
					wp->Stardock += 1;
					emp->Stardock = emp->Stardock + 1;
					fp->Stardock = fp->Stardock + 1;
				}
				if (wp->Stardock >= wp->maxStardock) {
					wp->cmd[0].type = btCOUNT;
				}
				if (allowMultipleFacilities == 0) {
					oldFacility = wp->facility;
					wp->facility = ftStardock;
				}
			} else if (bd.type==btSabotage) {
				oldFacility = wp->facility;
				wp->facility = ftSabotage;
			} else if (bd.type==btStellurae) {
				oldFacility = wp->facility;
				wp->facility = ftStellurae;
			} else if (bd.type==btShield) {
				if (wp->facility == ftShield) {
					fp = (fleetRec*)fleetList->getRecord(wp->worldID);
					fp->ecm -= shieldBonus;
				}
				oldFacility = wp->facility;
				wp->facility = ftShield;
				fp = (fleetRec*)fleetList->getRecord(wp->worldID);
				fp->ecm += shieldBonus;
			} else if (bd.type>=btCOUNT) {
				/*
				** Bulding nothing?
				*/
			} else {
				buildFleetShips(fp,bd.type,num);
			}

			if (oldFacility != wp->facility) {
				switch (oldFacility) {
					case ftMerchant:
						if (allowMultipleFacilities == 0) {
							emp = (empireRec*)empireList->getRecord(wp->empireID);
							emp->Merchant -= wp->Merchant;
							wp->Merchant = 0;
						}
						break;
					case ftBeacon:
						if (allowMultipleFacilities == 0) {
							emp = (empireRec*)empireList->getRecord(wp->empireID);
							emp->Beacon -= wp->Beacon;
							wp->Beacon = 0;
						}
						break;
					case ftStardock:
						if (allowMultipleFacilities == 0) {
							emp = (empireRec*)empireList->getRecord(wp->empireID);
							emp->Stardock -= wp->Stardock;
							wp->Stardock = 0;
						}
						break;
					case ftSabotage:
						break;
					case ftStellurae:
						break;
					case ftShield:
						fp = (fleetRec*)fleetList->getRecord(wp->worldID);
						fp->ecm -= shieldBonus;
						break;
				}
			}

			wp->storage -= num * newCost;

			if (bd.built<bd.goal) {
				wp->cmd[0].built = bd.built;
				break;
			}
			else {
				for (i=0;i<MAXBUILD-1;i++) {
					wp->cmd[i] = wp->cmd[i+1];
					if (wp->cmd[i].goal==0 || wp->cmd[i].type==btCOUNT) break;
				}

				if (!bd.repeat)	{
					wp->cmd[i].type = btCOUNT;
					wp->cmd[i].goal = 0;
				}
				else {
					bd.built = 0;
					wp->cmd[i] = bd;
				}
			}
		}
		/*
		** Toss excess industry
		*/
		if (wp->ind>wp->maxInd) wp->ind = wp->maxInd;

		/*
		** decay storage
		*/
		wp->storage -= (int)((wp->storage + 9.0) / 10.0);
	}

    for (ix=0; ix < empireList->getCount(); ix++) {
		emp=(empireRec*)empireList->getRecord(ix);
 	    emp->worldGuns = 0;
 	}
 	
//--- decay fleets and repair ships ---
	count = fleetList->getCount();
	wcount = worldList->getCount();
	for (ix=0;ix<=wcount;ix++) {
		fp = &fleets[ix];
		wp = &worlds[ix];
		/*
		** Don't bother with phenomena
		*/
		if (!isPlanet(wp->type)) {
	        continue;
		}

		emp = (empireRec*)empireList->getRecord(fp->empireID);

		/*
		** Don't decay or repair during battle or if dead
		*/
		if (fp->status==fsBattle || fp->status==fsDead) {
	 	    emp->worldGuns += fp->guns;
			continue;
		}

		for (i=0;i<posCOUNT;i++) {
			sp = &fp->squad[i];
			if (sp->damage > 0) {
				if (fp->empireID > 0) {
					/*
					** Repair damaged ships
					** One point of damage repaired for every stardock in empire
					*/
					if (sp->damage <= emp->Stardock) {
						sp->damage = 0;
					} else {
						sp->damage -= (emp->Stardock+1);
					}
				} else {
					sp->damage--;
				}
			}
			if (sp->type==stCOUNT || sp->type==stStarDart) {
				/*
				** Don't decay empty slots or stardarts
				*/
				continue;
			}

			val = sp->count;

			if (worldDecayRate>0 && fp->empireID>0) {
				reducedRate = (int)(((emp->Stardock * stardockWorldBonus) + worldDecayRate) * raceDecayModifier[emp->race]);
				if (reducedRate > 0) {
					val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				}
				pullSquadShips(fp,sp,val);
			} else if (worldDecayRate>0) {
				val = val/worldDecayRate + (Rand(worldDecayRate)<(val%worldDecayRate)?1:0);
				pullSquadShips(fp,sp,val);			
			}
		}
 	    emp->worldGuns += fp->guns;
	}

	for (ix=wcount+1;ix<=count;ix++) {
		fp = &fleets[ix];
		/*
		** Don't decay or repair during battle or if dead
		*/
		if (fp->status==fsBattle || fp->status==fsDead) {
			continue;
		}

		emp = (empireRec*)empireList->getRecord(fp->empireID);

		for (i=0;i<posCOUNT;i++) {

			sp = &fp->squad[i];
			if (sp->damage > 0) {
				if (fp->empireID > 0) {
					/*
					** Repair damaged ships
					** One point of damage repaired for every stardock in empire
					*/
					if (sp->damage <= emp->Stardock) {
						sp->damage = 0;
					} else {
						sp->damage -= (emp->Stardock+1);
					}
				} else {
					sp->damage--;
				}
			}
			if (sp->type==stCOUNT || sp->type==stStarDart) {
				/*
				** Don't decay empty slots or stardarts
				*/
				continue;
			}

			val = sp->count;

			if (fleetDecayRate>0 && fp->empireID>0) {
				reducedRate = (int)(((((empireRec*)empireList->getRecord(fp->empireID))->Stardock * stardockFleetBonus) + fleetDecayRate) * raceDecayModifier[emp->race]);
				if (reducedRate > 0) {
					val = val/reducedRate + (Rand(reducedRate)<(val%reducedRate)?1:0);
				}
				pullSquadShips(fp,sp,val);
			} else if (fleetDecayRate>0) {
				val = val/worldDecayRate + (Rand(worldDecayRate)<(val%worldDecayRate)?1:0);
				pullSquadShips(fp,sp,val);			
			}
		}
	}

//--- cleanup ---
	empireList->save();
	worldList->save();

	count = Rand(highWorlds - minWorlds) + minWorlds;

	lastTime = currentTime;
	currentTime = secondsSinceMidnight();
	deltaTime = currentTime - lastTime;
	if (deltaTime < 0)
	{
		/*
		** We crossed over into a new day, need to add
		** one day's worth of seconds.
		*/
		deltaTime += 86400;
	}
	elapsedTime += deltaTime;


	estTimeRemaining = 0;
	if (gameHours != 0)
	{
		/*
		** Timed game, check to see if time is up
		*/
		if (elapsedTime >= (gameHours * 3600))
		{
			resetGalaxy(count);
			return;
		}
		/*
		** Even though we are not using time returned,
		** still need to calculate the scores
		*/
		calculateScore(&estTimeRemaining);
		estTimeRemaining = (gameHours * 3600) - elapsedTime;
	} else {
		/*
		** Not a timed game, has anyone won?
		*/
		estTimeRemaining = deltaTime;
		autoReset = calculateScore(&estTimeRemaining);
/*
printf("Time remaining %d days, %d hours, %d minutes, %d seconds.\n",
(estTimeRemaining / 86400),
((estTimeRemaining % 86400) / 3600),
(((estTimeRemaining % 86400)%3600) / 60),
(((estTimeRemaining % 86400)%3600)%60));
//*/
		if (autoReset)
		{
			resetGalaxy(count);
			return;
		}
		
	}
	/*
	** Check to see if this is a time shifted game
	** If it is, increase elapsed time of this session
	** and check to see if this session is over
	*/
	if (timeShiftSkipDays > 0) {
		sessionElapsedTime += deltaTime;
		if (sessionElapsedTime >= (timeShiftSessionHours * 3600)) {
			pauseGame();
		}
	}

	saveElapsedTime();
}

void pauseGame() {
	struct tm *tm_resume;
	tm_resume = localtime(&startTime);
	tm_resume->tm_min = 0;
	tm_resume->tm_sec = 0;
	while (mktime(tm_resume) < time(NULL)) {
		tm_resume->tm_mday += timeShiftSkipDays;
	}
	resumeTime = mktime(tm_resume);
	sessionElapsedTime = 0;
	gamePaused = true;
}


void captureWorld(int worldID,worldRec *wp,int newEmpire) {
	char buf[BUFFERSIZE];
	empireRec *emp;
	fleetRec *fp;
	squadRec *sp;
	worldRec *wp_tmp;
	Session *ssn;
	int oldEmpire; 
	int count,ix;
	unsigned long base_dmg, dmg;
	long kills, killed;
	int type;
	bool makeDead = false;

	oldEmpire = wp->empireID;
	wp->empireID = newEmpire;
	worldList->save();

	gLog.logMsg(Log::LOG_DEBUG, 3030, "Reducing facilities of player losing world.");
	emp = (empireRec*)empireList->getRecord(oldEmpire);
	fp = (fleetRec*)fleetList->getRecord(oldEmpire);
	if (emp!=NULL) {
		emp->worlds--;
		emp->Merchant   -= wp->Merchant;
		emp->Beacon     -= wp->Beacon;
		emp->Stardock   -= wp->Stardock;
		if (wp->facility == ftStellurae) {
			emp->Stellurae  -= 1;
		}
	}
	if (fp!=NULL) {
		fp->Beacon    -= wp->Beacon;
		fp->Stardock  -= wp->Stardock;
	}

	if (wp->facility==ftSabotage) {
		makeDead = (dd_destroy_world == 1);
		emp = (empireRec*)empireList->getRecord(newEmpire);
		fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
		switch (dd_dmg_type) {
			case 0:
				base_dmg = wp->pop * 5;
				if (wp->type==wtHome || wp->type==wtCore || wp->type==wtLarge || wp->type>=wtNewEarth && wp->type<=wtQuarethia) {
					base_dmg = wp->pop * 7;
				}
				if (wp->type==wtSmall) {
					base_dmg = wp->pop * 3;
				}
				base_dmg += wp->Beacon * dd_beacon_mod;
				base_dmg += wp->Stardock * dd_stardock_mod;
				base_dmg += wp->Merchant * dd_merchant_mod;
				base_dmg += wp->ind * dd_ind_mod;
				dmg = base_dmg * dd_dmg_mod;
				dmg -= fp->ecm;
				break;
			case 1:
				break;
			case 2:
				dmg = dd_dmg_mod;
				break;
			default:
				dmg = 0;
				// no damage at all
				break;
		}
		// remove all builds
		for (ix=0;ix<10;ix++) {
			wp->cmd[ix].type = btCOUNT;
		}
		wp->facility = ftCOUNT;
		wp->ind = 0;
		wp->Merchant = 0;
		wp->Beacon = 0;
		wp->Stardock = 0;
		/*
		** Special worlds will keep at least one facility of their type
		*/
		if (wp->type==wtMerchant) {
			wp->Merchant = 1;
		}
		if (wp->type==wtBeacon) {
			wp->Beacon = 1;
		}
		if (wp->type==wtStardock) {
			wp->Stardock = 1;
		}
		emp = (empireRec*)empireList->getRecord(newEmpire);
		fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
		if (dmg > 0) {
			for (int i=0; i<posCOUNT; i++) {
				sp = &fp->squad[i];
				type = sp->type;
				if (type != stCOUNT) {
					kills = 0;
					if (dd_dmg_type == 1) {
						dmg = (int)((float)sp->count * (float)guns[type] * ((float)dd_dmg_mod/100.0));
					}
					if (dmg > 0) {
						kills = dmg / (unsigned long)guns[type];
						sp->damage = (unsigned short)(dmg % (unsigned long)guns[type]);
					} else {
						kills = 0;
						sp->damage = 0;
					}
					killed = pullSquadShips(fp,sp,kills);			

					if (killed > 0 && type==stStarDart) {
						emp->darts -= killed;
						if (killed > 1) {
							sprintf(buf,"*** %s Empire loses %d Star Darts ***",emp->name, killed);
						} else {
							sprintf(buf,"*** %s Empire loses a Star Dart ***",emp->name);
						}
						sendGlobalMessage(buf);
						for (;killed>0;killed--) {
							randomizeStarDart(1);
						}
					}
				}
			}
		}
		setFleetDestination(fp,-1);
		if (dd_teleport == 1) {
			FleetLocation(&fp->xloc,&fp->yloc);
		}
		ssn = findEmpireSession(newEmpire);
		if (ssn!=NULL) {
			sprintf(buf,"=== Doomsday device blows up the world! ===");
			sendMessage(ssn,buf);
		}
	} else {
		wp->ind /= 2;
		wp->Merchant /= 2;
		wp->Beacon /= 2;
		wp->Stardock /= 2;
	}

	emp = (empireRec*)empireList->getRecord(newEmpire);
	fp = (fleetRec*)fleetList->getRecord(newEmpire);
	if (emp!=NULL && !makeDead) {
		emp->worlds++;
		emp->Merchant   += wp->Merchant;
		emp->Beacon     += wp->Beacon;
		emp->Stardock   += wp->Stardock;
		if (wp->facility == ftStellurae) {
			emp->Stellurae  += 1;
		}
	}
	if (fp!=NULL && !makeDead) {
		fp->Beacon    += wp->Beacon;
		fp->Stardock  += wp->Stardock;
	}

	ssn = findEmpireSession(oldEmpire);
	if (ssn!=NULL) {
		sprintf(buf,"=== %s in sector %d has been captured by %s!===",wp->name,wp->sector,emp->name);
		sendLastCaptured(ssn,wp->worldID);
		sendMessage(ssn,buf);
		sendWorldScan(ssn,worldID,wp);
	}

	if (worldID>0 && worldID <= gCORECOUNT) {
		if (emp!=NULL) {
			sprintf(buf,"=== %s captures a Core World! ===",emp->name);
			sendGlobalMessage(buf);
		}
	}

	ssn = findEmpireSession(newEmpire);
	if (ssn!=NULL) sendWorldScan(ssn,worldID,wp);

	count = worldList->getCount();
	worldRec *worlds = (worldRec*)worldList->getList();
	fleetRec *fleets = (fleetRec*)fleetList->getList();
	fleetRec *ep;
	if (worldID==0 || (emp->race + 17)==wp->type
		|| (wp->type >= 17 && wp->type < 17+rtCOUNT && hwDeclareForAll == 1))
	{
		int declareRatio = 0;
		int declareRatioPhenomena = 0;
		int minSect = 0;
		int maxSect = 0;
		if (worldID == 0) {
			//
			// Old Earth was taken, worlds in all sectors up for grabs
			//
			minSect = 0;
			maxSect = 7;
		} else {
			//
			// A home world was taken, only worlds in this sector up for grabs
			//
			minSect = wp->sector;
			maxSect = wp->sector;
		}
		if (oldEmpire==0) {
			//
			// First time world was taken as it is being taken from Neutral
			//
			if (worldID == 0) {
				//
				// Old Earth was taken
				//
				declareRatio = firstEarthDeclareRatio;
				declareRatioPhenomena = firstPhenomenaDeclareRatio;
				emp->declaredEarth = true;
			} else {
				//
				// A home world was taken
				//
				declareRatio = firstHomeDeclareRatio;
				declareRatioPhenomena = firstHomePhenomenaDeclareRatio;
				emp->declaredHome = true;
			}
		} else {
			//
			// World is being taken from another player
			//
			if (worldID == 0) {
				//
				// Old Earth was taken
				//
				declareRatio = laterEarthDeclareRatio;
				declareRatioPhenomena = laterPhenomenaDeclareRatio;
				emp->declaredEarth = true;
			} else {
				//
				// A home world was taken
				//
				declareRatio = laterHomeDeclareRatio;
				declareRatioPhenomena = laterHomePhenomenaDeclareRatio;
				emp->declaredHome = true;
			}
		}
		emp = (empireRec*)empireList->getRecord(newEmpire);
		sprintf(buf,"=== %s has captured %s! ===",emp->name,wp->name);
		sendGlobalMessage(buf);

		int decCount = 0;
		int decCountPhenom = 0;
		int dartCount = 0;

		for (int ix=gCORECOUNT+1;ix<worldList->getCount();ix++) {
			wp_tmp = &worlds[ix];
			if (wp_tmp->empireID != oldEmpire || wp_tmp->sector < minSect || wp_tmp->sector > maxSect) {
				//
				// Skip over worlds that didn't belong to the old owner
				// or are in the wrong sector
				//
				continue;
			}
			if (isNormalPlanet(wp_tmp->type)) {
				if (Rand(declareRatio)==0) {
					decCount++;
					dartCount = 0;

					ep = &fleets[ix];
					ep->empireID=newEmpire;												
					wp_tmp->empireID=newEmpire;
					dartCount = dartCheck(wp_tmp);

					emp = (empireRec*)empireList->getRecord(oldEmpire);
					fp = (fleetRec*)fleetList->getRecord(oldEmpire);
					if (emp!=NULL) {
						emp->worlds--;
						emp->Merchant -= wp_tmp->Merchant;
						emp->Beacon   -= wp_tmp->Beacon;
						emp->Stardock -= wp_tmp->Stardock;
						if (wp_tmp->facility == ftStellurae) {
							emp->Stellurae  -= 1;
						}
						emp->darts    -= dartCount;
					}
					if (fp!=NULL) {
						fp->Beacon     -= wp_tmp->Beacon;
						fp->Stardock   -= wp_tmp->Stardock;
					}

					emp = (empireRec*)empireList->getRecord(newEmpire);
					if (emp!=NULL) {
						emp->worlds++;
						emp->Merchant += wp_tmp->Merchant;
						emp->Beacon   += wp_tmp->Beacon;
						emp->Stardock += wp_tmp->Stardock;
						if (wp_tmp->facility == ftStellurae) {
							emp->Stellurae  += 1;
						}
						emp->darts    += dartCount;
					}
					fp = (fleetRec*)fleetList->getRecord(newEmpire);
					if (fp!=NULL) {
						fp->Beacon     += wp_tmp->Beacon;
						fp->Stardock   += wp_tmp->Stardock;
					}
				}
			} else if (isPhenomena(wp_tmp->type)) {
				if (Rand(declareRatioPhenomena)==0) {
					decCountPhenom++;

					ep = &fleets[ix];

					ep->empireID=newEmpire;
					wp_tmp->empireID=newEmpire;
					emp = (empireRec*)empireList->getRecord(oldEmpire);
					if (emp!=NULL) emp->worlds--;
					emp = (empireRec*)empireList->getRecord(newEmpire);
					if (emp!=NULL) emp->worlds++;
				}
			}
		}
		sprintf(buf,"=== %d worlds declare for %s! ===", decCount, emp->name);
		sendGlobalMessage(buf);
		sprintf(buf,"=== %d phenomena declare for %s! ===", decCountPhenom, emp->name);
		sendGlobalMessage(buf);
	} else if (wp->type >= wtNewEarth && wp->type <= wtQuarethia) {
		emp = (empireRec*)empireList->getRecord(newEmpire);
		sprintf(buf,"=== %s has captured %s! ===",emp->name,wp->name);
		sendGlobalMessage(buf);
	}

	if (makeDead) {
		/*
		** Adjust counts for special worlds
		*/
		switch (wp->type) {
			case wtCore:
				totalCores--;
				break;
			case wtNewEarth:
			case wtMakluvia:
			case wtKaletia:
			case wtZorestia:
			case wtAvaria:
			case wtNajunia:
			case wtCestania:
			case wtQuarethia:
			case wtHome:
				totalHomeWorlds--;
				break;
		}
		if (worldID == 0) {
			earthExists = 0;
		}
		totalWorlds--;

		/*
		** Make the world dead and neutral
		*/
		wp->type = wtDead;
		wp->empireID = 0;

		/*
		** re-calculate maximum possible score
		*/
		maxEmpireScore = calculateMaxEmpireScore();

		/*
		** Need to scan the area for fleets and send them the updated world type
		** if a doomsday device went off
		*/
		int count,ix;
		fleetRec *fleets,*fp;

		ix = worldList->getCount();		// skip planetary fleets
		count = fleetList->getCount();

		fleets = (fleetRec*)fleetList->getList();
		if (fleets==NULL) return;

		for (;ix<count;ix++) {
			fp = &fleets[ix];
			if (fp->status==fsDead) continue;
			ssn = findEmpireSession(fp->empireID);
			if (ssn!=NULL) sendWorldScan(ssn,worldID,wp);
		}
	} else {
		ssn = findEmpireSession(newEmpire);
		if (ssn!=NULL) sendWorldScan(ssn,worldID,wp);
		ssn = findEmpireSession(oldEmpire);
		if (ssn!=NULL) sendWorldScan(ssn,worldID,wp);
	}
	worldList->save();
}


int calculateCost(int mineral, int baseCost) {
	switch (mineral) {
		case 0:
			return 0;
			break;
		case 1:
			return (int)(baseCost * 3.0 / 2.0);
			break;
		case 2:
			return baseCost;
			break;
		case 3:
			return baseCost / 2;
			break;
	}
	return baseCost;
}

bool saveElapsedTime() {
	FILEID fh;
	char elapsedTimeFile[256];

	sprintf(elapsedTimeFile,"%s/%s",dataPath,"elapsedTime.dat");
	fh = openForAppend(elapsedTimeFile);
	if (badFileIndex(fh)) {
		gLog.logMsg(Log::LOG_ERROR, 3040, "Error saving elapsed time\n");
		return false;
	}
	fileSeekPos(fh,0);
	fileWrite(fh,(void *)&elapsedTime,sizeof(long));
	fileClose(fh);
	return true;
}

bool loadElapsedTime() {
	FILEID fh;
	int size=0;
	char elapsedTimeFile[256];

	sprintf(elapsedTimeFile,"%s/%s",dataPath,"elapsedTime.dat");
	fh = openForRead(elapsedTimeFile);
	if (badFileIndex(fh)) {
		gLog.logMsg(Log::LOG_ERROR, 3050, "Error loading elapsed time\n");
		return false;
	}
	size = fileRead(fh,(void *)&elapsedTime,sizeof(long));
	if (size != sizeof(int)) {
		gLog.logMsg(Log::LOG_ERROR, 3060, "Error loading elapsed time\n");
		return false;
	}
	fileClose(fh);
	if (timeShiftSkipDays > 0) {
		loadStartTime();
//todo: verify that this properly sets resumeTime, sessionElapsedTime and gamePaused
		struct tm *tm_resume;
		tm_resume = localtime(&startTime);
		tm_resume->tm_min = 0;
		tm_resume->tm_sec = 0;
		tm_resume->tm_hour += timeShiftSessionHours;  // Adding in session hours in case restart happened during active state
		while (mktime(tm_resume) < time(NULL)) {
			tm_resume->tm_mday += timeShiftSkipDays;
		}
		tm_resume->tm_hour -= timeShiftSessionHours;  // Need to reset this so session starts at its normal time
		resumeTime = mktime(tm_resume);
		/*
		** Check to see if game is in active state
		*/
		if (mktime(tm_resume) < time(NULL)) {
			sessionElapsedTime = time(NULL) - mktime(tm_resume);
			gamePaused = false;
		} else {
			sessionElapsedTime = 0;
			gamePaused = true;
		}
		long deltaTime = resumeTime - time(NULL);
		gLog.logMsg(Log::LOG_INFO, 3070, "Time remaining untill resume is %d days, %d hours, %d minutes, %d seconds."
			,(deltaTime / 86400)
			,((deltaTime % 86400) / 3600)
			,(((deltaTime % 86400) % 3600) / 60)
			,(((deltaTime % 86400) % 3600) % 60));
	}
	return true;
}

bool saveStartTime() {
	FILEID fh;
	char startTimeFile[256];

	sprintf(startTimeFile,"%s/%s",dataPath,"startTime.dat");
	fh = openForAppend(startTimeFile);
	if (badFileIndex(fh)) {
		gLog.logMsg(Log::LOG_ERROR, 3110, "Error saving start time.");
		return false;
	}
	fileSeekPos(fh,0);
	fileWrite(fh,(void *)&startTime,sizeof(long));
	fileClose(fh);
	return true;
}

bool loadStartTime() {
	FILEID fh;
	int size=0;
	char startTimeFile[256];

	sprintf(startTimeFile,"%s/%s",dataPath,"startTime.dat");
	fh = openForRead(startTimeFile);
	if (badFileIndex(fh)) {
		gLog.logMsg(Log::LOG_ERROR, 3120, "Error loading start time.");
		return false;
	}
	size = fileRead(fh,(void *)&startTime,sizeof(long));
	if (size != sizeof(int)) {
		gLog.logMsg(Log::LOG_ERROR, 3130, "Error loading start time.");
		return false;
	}
	fileClose(fh);
	return true;
}

bool calculateScore(long *estTimeRemaining){
	int top20Score[20];
	int wcount,count,ix,i,num,resetScore;
	empireRec *emp;
	fleetRec *fp;
	worldRec *wp;
	bool autoReset;
	long deltaTime,timeSinceDrop, tmpTimeRemaining,estTimeRemainingMax;
	int score, scoreDelta, scoreVic;

	memset(top20List,0xff,sizeof(top20List));
	memset(top20Score,0,sizeof(top20Score));

	wcount = worldList->getCount();
	count = empireList->getCount();

	victoryPercent = victoryBase - ((int)elapsedTime / (int)(dropHours * 3600));
//	if (victoryPercent<1) victoryPercent = 1;
	if (victoryPercent<0) victoryPercent = 0;

	autoReset = false;
	maxEmpireScore = calculateMaxEmpireScore();
	resetScore = (int)(maxEmpireScore * (victoryPercent / 100.0));
	scoreVic = resetScore;
	
//--- decay score, collect non-score hi values ---
	for (ix=1;ix<count;ix++) {
		emp = (empireRec*)empireList->getRecord(ix);
		fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
		if (emp==NULL || fp==NULL) continue;
		emp->score -= emp->score / 1000;
		if (fp->status==fsDead && emp->score>0) emp->score--;
		if (emp->darts > emp->hiDarts) emp->hiDarts = emp->darts;
		if (emp->worlds > emp->hiWorlds) emp->hiWorlds = emp->worlds;
	}

//--- control earth ---
	wp = (worldRec*)worldList->getRecord(0);
	if (wp!=NULL) {
		emp = (empireRec*)empireList->getRecord(wp->empireID);
		if (emp!=NULL) {
			emp->score += EarthValue(wcount) - 1; 
		}
	}	

//--- control home worlds ---
	for (ix=13;ix<=wcount;ix++) {
		wp = (worldRec*)worldList->getRecord(ix);
		if (wp!=NULL && (wp->type>=wtNewEarth && wp->type<=wtQuarethia)) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->score += HomeValue(wcount) - 1;
			}
		}
	}

//--- control core worlds ---
	for (ix=1;ix<=12;ix++) {
		wp = (worldRec*)worldList->getRecord(ix);
		if (wp!=NULL) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->score += CoreValue(wcount) - 1;	
			}
		}
	}

	/*
	** Add to scores and
	** find the score that is on course to win
	*/
	deltaTime = *estTimeRemaining;
	estTimeRemainingMax = victoryBase * 3600 * dropHours - elapsedTime;
	*estTimeRemaining = estTimeRemainingMax;
	tmpTimeRemaining = estTimeRemainingMax;
	for (ix=1;ix<count;ix++) {
		emp = (empireRec*)empireList->getRecord(ix);
		if (emp==NULL) continue;

		emp->score += emp->worlds;
		emp->score += emp->darts * emp->darts;
		if (emp->score > emp->hiScore) {
			/*
			** Check to see if this is the person who is going to win
			*/
			scoreDelta = emp->score - emp->hiScore;
			score = emp->score;
			tmpTimeRemaining = (long)(((double)(scoreVic - score) / (double)scoreDelta) * deltaTime);
			if (tmpTimeRemaining < *estTimeRemaining && tmpTimeRemaining > 0) {
				*estTimeRemaining = tmpTimeRemaining;
				/*
				** Need to factor drop hours into this as game could end at
				** next drop, which could be very soon
				*/
				timeSinceDrop = ((long)elapsedTime % (long)(dropHours * 3600));
				if (((long)(timeSinceDrop + *estTimeRemaining) / (long)(dropHours * 3600)) > 0) {
					if (((long)(elapsedTime + *estTimeRemaining) / (long)(dropHours * 3600)) < victoryBase) {
						victoryPercent = victoryBase - ((long)(elapsedTime + *estTimeRemaining)/ (long)(dropHours * 3600));
						scoreVic = (long)(maxEmpireScore * (victoryPercent / 100.0));
						tmpTimeRemaining = (long)(((double)(scoreVic - score) / (double)scoreDelta) * deltaTime);
					}
					if (tmpTimeRemaining < *estTimeRemaining && tmpTimeRemaining > 0) {
						*estTimeRemaining = tmpTimeRemaining;
					}
				}
			}
			emp->hiScore = emp->score;
		}
		if (emp->hiScore<1) continue;

	//--- check for auto-reset ---
		if (emp->hiScore >= resetScore) autoReset = true; 

	//--- sort list ---
		for (num=19;num>=0;num--) if (top20Score[num] > emp->hiScore) break;

		if (num<19) {
			for (i=19;i>=num+2;i--) {
				top20List[i] = top20List[i-1];
				top20Score[i] = top20Score[i-1];
			}
			top20List[num+1] = ix;
			top20Score[num+1] = emp->hiScore;
		}
	}

	return autoReset;
}

//**********************************************************************************
/*
** Default build positions for ships
*/
int buildPos[stCOUNT]={
	posDefendTop,posDefendBot,posInvadeTop,
	posDefendMid,posInvadeMid,posInvadeBot
};

int buildFleetShips(fleetRec *fp,int type,int num){
	int pos;
	int lastPos = posCOUNT;
	int totalAdded = 0;
	int numSlots = 0;
	int newNum = 0;
	int remainder = 0;
	int slot[posCOUNT][2];

	if (num <= 0) {
		return 0;
	}

	/*
	** Count slots with the desired ship type
	*/
	for (pos=0;pos<posCOUNT;pos++) {
		if (fp->squad[pos].type==type) {
			lastPos = pos;
			slot[numSlots][0] = pos;
			slot[numSlots][1] = fp->squad[pos].count;
			numSlots++;
		}
	}
	pos = lastPos;

	/*
	** Need to divide the build as evenly as possible between the slots
	** In the case where num < number of slots and for the remainder,
	** need to fill in the slots starting with the slot with least ships
	*/
	if (numSlots > 1) {
		newNum = num/numSlots;
		remainder = num%numSlots;
		if (newNum > 0) {
			for (int i=0; i<numSlots; i++) {
				totalAdded += addSquadShips(fp,&fp->squad[slot[i][0]],newNum);
			}
		}
		/*
		** Remainder will always be less than 6
		** Max number of slots is six.
		** Max comparisons to find the slot with the fewest ships is 5x6 = 30;
		** This shouldn't be a huge performance bottleneck, but multiply
		** 30 times the max worlds in an arena and it could become significant.
		*/
		while (remainder > 0) {
			/*
			** Find the slot with the fewest ships
			*/
			int min = 0x7fffffff;	// max int
			int minPos = 0;
			for (int i=0; i<numSlots; i++) {
				if (slot[i][1] < min) {
					min = slot[i][1];
					minPos = i;
				}
			}
			/*
			** Add one to slot with least guns
			*/
			totalAdded += addSquadShips(fp,&fp->squad[slot[minPos][0]],1);
			remainder--;
		}
		return totalAdded;
	}

	/*
	** Don't have this ship type yet, See if default build position
	** for this type is empty.
	*/
	if (pos==posCOUNT) {
		if (fp->squad[buildPos[type]].type==stCOUNT) {
			pos = buildPos[type];
		}
	}

	/*
	** Don't have this ship type yet and default build position
	** for this type is not empty, look for an empty slot.
	*/
	if (pos==posCOUNT) {
		for (pos=0;pos<posCOUNT;pos++) {
			if (fp->squad[pos].type==stCOUNT) {
				break;
			}
		}
	}

	/*
	** No place to put ships built with this type
	*/
	if (pos==posCOUNT) {
		return 0;
	}

	fp->squad[pos].type = type;
	return addSquadShips(fp,&fp->squad[pos],num);
}


int addFleetShips(fleetRec *fp,int type,int num){
	int pos;

	if (num <= 0) {
		return 0;
	}

	/*
	** Look for slot with the desired ship type
	*/
	for (pos=0;pos<posCOUNT;pos++) {
		if (fp->squad[pos].type==type) {
			break;
		}
	}

	/*
	** Don't have this ship type yet, look for an empty slot
	*/
	if (pos==posCOUNT) {
		for (pos=0;pos<posCOUNT;pos++) {
			if (fp->squad[pos].type==stCOUNT) {
				break;
			}
		}
	}

	/*
	** Don't have this ship type and not empty slots, can't take any
	*/
	if (pos==posCOUNT) {
		return 0;
	}

	fp->squad[pos].type = type;

	return addSquadShips(fp,&fp->squad[pos],num);
}

int addFleetShips(fleetRec *fp,int type,int pos,int num){
	if (num <= 0) {
		return 0;
	}
	fp->squad[pos].type = type;
	return addSquadShips(fp,&fp->squad[pos],num);
}


int addSquadShips(fleetRec *fp,squadRec *sp,int num){
	int fill;

	if (num <= 0) {
		return 0;
	}
	fill = max[sp->type] - sp->count;
	if (num>fill) num = fill;

	sp->count += num;
	fp->ecm += num * ecm[sp->type];
	fp->guns += num * guns[sp->type];

	return num;
}


int pullFleetShips(fleetRec *fp,int pos,int num) {		// for transfer
	return pullSquadShips(fp,&fp->squad[pos],num);
}


int pullSquadShips(fleetRec *fp,squadRec *sp,int num) {
	int type;

	if (num <= 0) {
		return 0;
	}

	type = sp->type;
		
	if (num < sp->count) {
		sp->count -= num;
	} else {
		num = sp->count;
		sp->count = 0;
		sp->damage = 0;
		sp->type = stCOUNT;	// DEAD!
	}

	/*
	** This needs to happen after above if statement to prevent guns
	** going negative from trying to pull more ships than are in the sqad.
	** Same goes for ecm, don't want it going negative.
	*/
	fp->guns -= num * guns[type];
	fp->ecm -= num * ecm[type];

	return num;
}

//**********************************************************************************

int lastFleetUpdate=0;

void operateFleets() {
	int update,count,ix,i;
	fleetRec *fp,*fleets;

	update = time(NULL);
	if (lastFleetUpdate + 1 > update) return;
	lastFleetUpdate = update;

	count = fleetList->getCount();
	fleets = (fleetRec*)fleetList->getList();

//--- scan list ---
	for (ix=0;ix<count;ix++) {
		fp = &fleets[ix];

		switch (fp->status) {
			case fsMoving: case fsNebulae: case fsNeutron:
				fleetAdvance(ix,fp); 
				break;
			case fsBattle:	
				fleetBattle(ix,fp); 
				break;
//			case fsWaiting:    // todo: fix as this is BAD all world fleets are fsWaiting
//				for (i=0;i<posCOUNT;i++) if (fp->squad[i].type!=stCOUNT) break;
//				if (i==posCOUNT) fp->status = fsDead;
//				break;
		}
	}

	fleetList->save();
}

//**********************************************************************************
//**********************************************************************************
//**********************************************************************************

int lastSessionFleet=0;
int lastSessionScan=0;

void operateSessions() {
	SessionList *slp;
	int update;

	update = time(NULL);

//--- send fleet info ---
	if (lastSessionFleet+1 > update) return;
	lastSessionFleet = update;

	slp = sroot->next();
	while (slp!=NULL) {
		sessionScanFleets(slp->ssn());
		slp = slp->next();
	}

//--- send fleet info ---
	if (lastSessionScan+1 > update) return;
	lastSessionScan = update;

	slp = sroot->next();
	while (slp!=NULL) {
		sessionScanWorlds(slp->ssn());
		slp = slp->next();
	}
}

//**********************************************************************************
//**********************************************************************************

void fleetBattle(int fleetID,fleetRec *fp){
	bool autoplay,guard,dead,retreat;
	squadRec *sp;
	fleetRec *ep;
	int ix,i;

	autoplay = guard = (fleetID<worldList->getCount());
	if (!autoplay && findEmpireSession(fp->empireID)==NULL) autoplay = true;
	
	if (autoplay) fleetAutoAction(fleetID,fp);

//--- check engagement ---
	for (i=0;i<sideCOUNT;i++) if (fp->engageID[i]>=0) break;
	if (i==sideCOUNT) {
		fp->status = fsMoving;
		return;
	}

//--- check status ---
	dead = retreat = true;
	for (ix=0;ix<posCOUNT && (dead || retreat);ix++) {
		sp = &fp->squad[ix];
		if (sp->type==stCOUNT) continue;
		dead = false;
		if (!isRetreatAction(sp->action) || sp->timer!=0) retreat = false;
	}

//--- fleet dead ---
	if (dead) {

		fp->status = fsDead;

		if (guard) {
			ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideDefend]);
			if (ep!=NULL) fp->empireID = ep->empireID;
		}
		else {
			setFleetDestination(fp,-1);
		}
		return;
	}

//--- runaway ---
	if (retreat) {
		setFleetDestination(fp,-1);
		return;
	}

//--- enemies subdued ---
	if (fp->engageID[sideDefend]<0 && fp->engageID[sideInvade]==fp->destID) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideInvade]);
		if (ep==NULL) return;

		if (ep->status==fsDead) {
			ep->status = fsWaiting; // MUST change status of enemy fleet to fsWaiting
			fp->status = fsIndustry;
			return;
		}
	}

//--- squadrons battle ---
	for (ix=0;ix<posCOUNT;ix++) {
		sp = &fp->squad[ix];
		if (sp->type==stCOUNT || isDefendAction(sp->action)) continue;

		/*
		** Check to make sure squad still has a valid target
		** switch to actDefend if it does not.
		*/
		if (sp->action >= actTarget0 &&  sp->action <= actTarget5) {
			fleetRec *efp = (fleetRec*)fleetList->getRecord(fp->engageID[sp->enemy]);
			int pos = sp->action - actTarget0;
			if (pos >= 0) {
				squadRec *sp2 = &efp->squad[pos];
				if (sp2->count <= 0) {
					setSquadAction(fp,ix,actDefend);
				}
			}
		}

		if (sp->timer>0) {
			sp->timer--;
			continue;
		}

	//--- retreating ---
		if (isRetreatAction(sp->action)) continue;

	//--- timer=zero, take action ---
		if (isMoveAction(sp->action)) {
			fleetMoveSquad(fp,ix,sp->action);
			continue;
		}

	//--- fire action ---
		fleetFireSquad(fp,ix,sp->action,sp->enemy);
		if (autoplay || !setSquadAction(fp,ix,sp->action,sp->enemy)) {
			setSquadAction(fp,ix,actDefend);
		}
	}
}


int searchPosition[sideCOUNT][posCOUNT]={{0,1,2,3,4,5},{0,0,0,0,0,0},{3,4,5,0,1,2},};

void fleetAutoAction(int fleetID,fleetRec *fp) {
	squadRec *sp;
	int pos,ix,type,val,side,e_pos;
	fleetRec *ip,*dp,*tp;

	dp = (fleetRec*)fleetList->getRecord(fp->engageID[sideDefend]); //dp = defending fleet
	ip = (fleetRec*)fleetList->getRecord(fp->engageID[sideInvade]); //ip = attacking fleet
	if (dp==NULL && ip==NULL) {
		fp->status = fsWaiting; //waiting for at least one fleet to show up 
		return;
	}

//--- squad actions ---
	for (pos=0;pos<posCOUNT;pos++) { //loop checks all possible squad positions
		sp = &fp->squad[pos]; //squadron record pulls position of squad from fleet record
		if (sp->type==stCOUNT) continue;  // if no squad
		if (isMoveAction(sp->action) || isRetreatAction(sp->action)) continue;
		if (isFireAction(sp->action)) {
			/*
			** Verify that the target is still valid before skipping
			*/
			if (sp->enemy==sideDefend 
				&& dp != NULL
				&& dp->squad[sp->action-actTarget0].type != stCOUNT)
			{
				continue; 
			} else if (ip != NULL && ip->squad[sp->action-actTarget0].type != stCOUNT) {
				continue;
			}
		}
		side = (isDefendPosition(pos)?sideDefend:sideInvade);

	//--- move into empty slot ---
		if (side==sideDefend && (dp==NULL || isFriendlyFleet(dp,fp))) {
			val = MoveGrid[ReadHeading(actMoveRight)][pos]; //value is new position to go to
			if (val!=posCOUNT && fp->squad[val].type==stCOUNT) { //if squad is empty
				if (sp->type !=stFrigate && sp->type!=stStarDart) { //frigates and darts don't need to move to fire
					setSquadAction(fp,pos,actMoveRight); //moves the squad right
					continue;
				}
			}
		}

		if (side==sideInvade && (ip==NULL || isFriendlyFleet(ip,fp))) {
			val = MoveGrid[ReadHeading(actMoveLeft)][pos]; //value is new position to go to
			if (val!=posCOUNT && fp->squad[val].type==stCOUNT) { //if squad is empty
				if (sp->type !=stFrigate && sp->type!=stStarDart) { //frigates and darts don't need to move to fire
					setSquadAction(fp,pos,actMoveLeft); //moves the squad left
					continue;
				}
			}
		}

	//--- search fleet ---
		val = 0;
		type = stCOUNT;
		tp = (side==sideDefend?dp:ip); //tp becomes equal to the fleet on the right
		if (tp==NULL) {
			if (sp->type!=stFrigate && sp->type!=stStarDart) continue;

			side = (side==sideDefend?sideInvade:sideDefend);	// switch
			tp = (side==sideDefend?dp:ip);
			if (tp==NULL) continue;
		}

		for (ix=0;ix<posCOUNT;ix++) { //checks all squad positions
		int test,num;

			if (ix==posCOUNT/2 && type!=stCOUNT) break;	// stop at first detected squad

			test = tp->squad[ searchPosition[side][ix] ].type; //checks to see if a squad is there
			if (test>=stCOUNT) continue; //goes on to attack first detected squad

			num = attack[sp->type][test]; //finds attack power of squad against squad
			if (num>val || (num==val && Rand2())) {
				type = test;
				val = num;
				e_pos = searchPosition[side][ix];  // targeting position now, not type
			}
		}

	//--- set action ---
		if (type==stCOUNT)	setSquadAction(fp,pos,actDefend);
		else				setSquadAction(fp,pos,MakeFireAction(e_pos),side);
	}
}


void fleetMoveSquad(fleetRec *fp,int squadID,int move){
	squadRec swap;
	fleetRec *ep;
	int dest,ix;

	dest = MoveGrid[ReadHeading(move)][squadID];
	if (dest==posCOUNT) return;

	/*
	** check engaged fleets to see if this squad is being targetted.
	*/
	if (fp->engageID[sideDefend] >= 0) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideDefend]);
		if (ep!=NULL) {
			/*
			** Check all squad positions to see if they are targetting either
			** of the moving squads
			*/
			for (ix=0;ix<posCOUNT;ix++) {
				/*
				** Make sure the squad is engaged with the fleet that has the moving squad
				*/
				if (ep->squad[ix].enemy == sideInvade) {
					if (MakeFireAction(squadID) == ep->squad[ix].action) {
						ep->squad[ix].action = MakeFireAction(dest);
					} else if (MakeFireAction(dest) == ep->squad[ix].action) {
						ep->squad[ix].action = MakeFireAction(squadID);
					}
				}
			}
		}
	}
	if (fp->engageID[sideInvade] >= 0) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[sideInvade]);
		if (ep != NULL) {
			/*
			** Check all squad positions to see if they are targetting either
			** of the moving squads
			*/
			for (ix=0;ix<posCOUNT;ix++) {
				/*
				** Make sure the squad is engaged with the fleet that has the moving squad
				*/
				if (ep->squad[ix].enemy == sideDefend) {
					if (MakeFireAction(squadID) == ep->squad[ix].action) {
						ep->squad[ix].action = MakeFireAction(dest);
					} else if (MakeFireAction(dest) == ep->squad[ix].action) {
						ep->squad[ix].action = MakeFireAction(squadID);
					}
				}
			}
		}
	}

	swap = fp->squad[squadID];
	fp->squad[squadID] = fp->squad[dest];
	fp->squad[dest] = swap;

	setSquadAction(fp,dest,actDefend);
	setSquadAction(fp,squadID,actDefend);
}


void fleetFireSquad(fleetRec *fp,int squadID,int action,int enemy) {
	int type,ftype,pos,dmg,kills, darts;
	double percent;
	char buf[BUFFERSIZE];
	empireRec *emp;
	fleetRec *efp;
	squadRec *sp;
	int count = 0;

	efp = (fleetRec*)fleetList->getRecord(fp->engageID[enemy]);
	if (efp==NULL) return;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

    pos = action - actTarget0;
	if (pos < 0) return;

	sp = &efp->squad[pos];
	type = sp->type;
	ftype = fp->squad[squadID].type;

	percent = guns[ftype] * fp->squad[squadID].count;
	percent = percent * attack[ftype][type];

	if (emp->race==rtNajunian) {
		percent *= 6.0 / 5.0;
	}

	if (ftype==stStarDart) percent += sp->count * guns[type];	// +1% damage per stardart
	percent += fp->ecm - efp->ecm;
//	if (percent<=0) return;

//--- calc damage, kill ships ---
	if (isDefendAction(sp->action)) percent /= 2;

	//dmg = (int)(sp->damage + percent / 100.0 + (Rand(100)<((int)percent%100)?1:0));
	dmg = (int)(sp->damage + percent/100.0);
	if (dmg<=0) return;

	kills = dmg / guns[type];
	count = sp->count;
	sp->damage = dmg % guns[type];
	kills = pullSquadShips(efp,sp,kills);			

	if (kills>0 && type==stStarDart) {
		darts = kills;
		emp = (empireRec*)empireList->getRecord(efp->empireID);
		if (emp!=NULL) {
			emp->darts -= kills;
			if (kills > 1) {
				sprintf(buf,"*** %s Empire loses %d Star Darts ***",emp->name, kills);
			} else {
				sprintf(buf,"*** %s Empire loses a Star Dart ***",emp->name);
			}
			sendGlobalMessage(buf);
		}
		randomizeStarDart(darts);
	}
}

//**********************************************************************************

void fleetAdvance(int fleetID,fleetRec *fp) {
	int dx,dy,tx,ty,total,delta;
	fleetRec *tp;
	empireRec *emp;

	if (fleetID<worldList->getCount()) return;		// planetary fleet
	if (fp->destID<0) return;

	tp = (fleetRec*)fleetList->getRecord(fp->destID);
	if (tp==NULL) return;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

	dx = tp->xloc - fp->xloc;
	tx = (dx<0?-dx:dx);
	dy = tp->yloc - fp->yloc;
	ty = (dy<0?-dy:dy);

	if (tx>ty)	{
		total = tx + ty/2;
	} else {
		total = ty + tx/2;
	}

	delta = (int)(((((empireRec*)empireList->getRecord(fp->empireID))->Beacon * beaconBonus) + movePixels) * raceBeaconModifier[emp->race]);
	if (delta > maxSpeed * raceBeaconModifier[emp->race]) {
		delta = (int)(maxSpeed * raceBeaconModifier[emp->race]);
	}

	if (emp->race!=rtKaletian && fp->status==fsNebulae) {
		delta /= 2;
	}
	if (fp->status==fsNeutron) {
		delta *= 2;
	}

	if (delta >= total) {				// arrives
		fp->xloc = tp->xloc;
		fp->yloc = tp->yloc;
		fleetHitsTarget(fleetID,fp);
		return;
	}
	
	if (total!=0) {
		fp->xloc += dx * delta / total;
		fp->yloc += dy * delta / total;
	}
}


void fleetHitsTarget(int fleetID,fleetRec *fp){
	int targetID,i;
	fleetRec *ep;
	worldRec *wp;
	empireRec *emp;
	char buf[BUFFERSIZE];

//--- handle special zones ---
	wp = (worldRec*)worldList->getRecord(fp->destID);
	if (wp!=NULL && !isPlanet(wp->type)) {
		fleetHitsZone(fp,wp);
		return;
	}

//--- find tail fleet ---
	targetID = fp->destID;
	ep = (fleetRec*)fleetList->getRecord(targetID);		// planet fleet;

	while (ep->engageID[sideDefend]>=0) {
		targetID = ep->engageID[sideDefend];
		ep = (fleetRec*)fleetList->getRecord(targetID);
	}

//--- guard fleet ---
	if (targetID==fp->destID) {
		if (isFriendlyFleet(ep,fp)) {
			fp->status = fsIndustry;	
			ep->engageID[sideDefend] = fleetID;
			fp->engageID[sideInvade] = targetID;
			return;
		} else {
		//--- ghost fleet cannot attack worlds
			if (fp->guns <= 0) {
				targetID = -1;
				fp->status=fsMoving;
				setFleetDestination(fp,-1);
				return;
			}
			if (wp!=NULL && wp->empireID>0) {
				emp = (empireRec*)empireList->getRecord(wp->empireID);
				if (emp!=NULL) {
					sprintf(buf,"<<< %s in sector %d is under attack >>>",wp->name,wp->sector);
					sendEmpireMessage(wp->empireID,buf);
					Session *sp;
					sp = findEmpireSession(wp->empireID);
					if (sp!=NULL) {
						sendWorldScan(sp,wp->worldID,wp);
						sendLastAttacked(sp,wp->worldID);
					}
				} else if (wp!=NULL && targetID==0) {
					sendGlobalMessage("<<< Old Earth is under attack >>>");
				}
			}
		}
	}

//--- ghost fleet cannot attack other fleets
	if (fp->guns <= 0) {
		targetID = -1;
		fp->status=fsMoving;
		setFleetDestination(fp,-1);
		return;
	}

//--- engage target fleet ---
	if (fp->destID>=worldList->getCount()) fp->destID = -1;

	ep->engageID[sideDefend] = fleetID;
	fp->engageID[sideInvade] = targetID;

	ep->status = fsBattle;
	fp->status = fsBattle;

	for (i=0;i<posCOUNT;i++) {
		setSquadAction(fp,i,actDefend);
		setSquadAction(ep,i,actDefend);
	}
}


void fleetHitsZone(fleetRec *fp,worldRec *wp_dest) {
	empireRec *emp;
	fleetRec *ep;
	worldRec *wp=NULL;
	int worldID,oldID,count,i,dest,num,added,type;
	char buf[BUFFERSIZE];
	Session *ssn;

	type = wp_dest->type;
	if (type == wtDead) {
		return;
	}

	dest = fp->destID;
	fp->destID = -1;

//--- find stardarts ---
	ep = (fleetRec*)fleetList->getRecord(dest);
	if (ep!=NULL && ep->squad[0].count>0) {
		num = ep->squad[0].count;

		added = addFleetShips(fp,stStarDart,num);

		emp = (empireRec*)empireList->getRecord(fp->empireID);
		if (emp!=NULL) emp->darts += added;

		sprintf(buf,"+++ %s Empire finds a Star Dart +++",emp->name);
		for (i=0;i<added;i++) sendGlobalMessage(buf);
		ep->squad[0].count = num - added;
	}

//--- gateway ---
	if (type==wtGateway) {

		count = worldList->getCount();

		for (i=1;i<count;i++) {
			worldID = (dest + i) % count;
			wp = (worldRec*)worldList->getRecord(worldID);
			if (wp!=NULL && wp->type==wtGateway) break;
		}
		if (wp==NULL || wp->type!=wtGateway) return;

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		ssn = findEmpireSession(fp->empireID);
		if (ssn==NULL) return;

		sessionScanFleets(ssn);
		sessionScanWorlds(ssn);
	}

//--- wormhole ---
	if (type==wtWormhole) {

		count = worldList->getCount();
		oldID = wp_dest->worldID;

		for (i=1;i>0;i++) {
			worldID = Rand(count);
			// don't want to stay at same wormhole
			if (worldID == oldID) continue;
			wp = (worldRec*)worldList->getRecord(worldID);
			if (wp!=NULL && wp->type==wtWormhole) break;
		}

		if (wp==NULL || wp->type!=wtWormhole) return;

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		ssn = findEmpireSession(fp->empireID);
		if (ssn==NULL) return;

		sessionScanFleets(ssn);
		sessionScanWorlds(ssn);
	}
}

//**********************************************************************************
//**********************************************************************************

void sessionScanFleets(Session *ssn){
	int count,ix,radius,x,y,engageID,len,empireID,fleetID;
	fleetRec *fleets,*fp,*ep;
	char buf[BUFFERSIZE];
	CRect scan;

	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	fleets = (fleetRec*)fleetList->getList();
	if (fleets==NULL) return;


	fp = &fleets[fleetID];		// session fleet
	sendStatus(ssn,fp->status);

//--- engage scan ---
	if (fp->status==fsBattle) {
		sendCombatScan(ssn,fleetID,fp);	// scan self
		for (ix=0;ix<sideCOUNT;ix++) {
			engageID = fp->engageID[ix];
			if (engageID<0) continue;

			ep = &fleets[engageID];
			sendCombatScan(ssn,engageID,ep);
		}
		return;
	}

//--- region scan ---
	x = fp->xloc;
	y = fp->yloc;

	//-- add NEUTRON_SIZE so that fleet race type is known
	//-- before fleet becomes visible to player
	radius = SCAN_SIZE+NEUTRON_SIZE;
	scan.setRect(x-radius,y-radius,2*radius,2*radius);

	ix = worldList->getCount();		// skip planetary fleets
	count = fleetList->getCount();

//--- create message ---
	for (len=2;ix<count && len<BUFFERSIZE-5*sizeof(int);ix++) {
		ep = &fleets[ix];
		if (ep->status==fsDead || !scan.inside(ep->xloc,ep->yloc)) continue;

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&ep->xloc,4*sizeof(int));
		len += 4*sizeof(int);
	}
	
	buf[0] = len;
	buf[1] = mfSectorFleets;
	ssn->send(buf);
}

//***************************************************************************

void sessionScanWorlds(Session *ssn){	// every 5 seconds
	CRect scan,nebulae,neutron;
	int count,ix,radius,dx,dy,len,empireID,fleetID;
	int oldStatus, maxLen;
	int neutronSqrd, nebulaeSqrd;
	char buf[BUFFERSIZE];
	fleetRec *fp,*ep;
	worldRec *worlds,*wp;
	empireRec *emp;

	gLog.logMsg(Log::LOG_DEBUG, 3140, "Scanning worlds...");

	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	worlds = (worldRec*)worldList->getList();
	if (worlds==NULL) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL || fp->status==fsBattle) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return;

//--- super scan self ---
	sendCombatScan(ssn,fleetID,fp);
	sendEmpireScan(ssn,empireID,emp);

	if (fp->status==fsIndustry) {
		ep = (fleetRec*)fleetList->getRecord(fp->destID);
		if (ep!=NULL) sendCombatScan(ssn,fp->destID,ep);
		wp = &worlds[fp->destID];
		if (wp!=NULL) sendBuildScan(ssn,fp->destID,wp);
		return;
	}

//--- build scan regions ---
	dx = fp->xloc;
	dy = fp->yloc;

	radius = SCAN_SIZE;
	scan.setRect(dx-radius,dy-radius,2*radius,2*radius);

	radius = SCAN_SIZE+NEUTRON_SIZE;
	neutron.setRect(dx-radius,dy-radius,2*radius,2*radius);

	radius = SCAN_SIZE+NEBULAE_SIZE;
	nebulae.setRect(dx-radius,dy-radius,2*radius,2*radius);

	oldStatus = fp->status;
//--- build message ---
	if (isMoveState(fp->status)) fp->status = fsMoving;
	
	neutronSqrd = NEUTRON_SIZE*NEUTRON_SIZE;
	nebulaeSqrd = NEBULAE_SIZE*NEBULAE_SIZE;
	maxLen = BUFFERSIZE-3*sizeof(int);

	count = worldList->getCount();
	for (ix=0,len=2;ix<count && len<maxLen;ix++) {

		wp = &worlds[ix];

		switch (wp->type) {
			case wtNeutron:
				if (!neutron.inside(wp->xloc,wp->yloc)) continue;
				if (fp->status==fsNeutron || fp->status==fsNebulae || fp->status==fsMoving) {
					dx = wp->xloc - fp->xloc;
					dy = wp->yloc - fp->yloc;
					if (dx*dx + dy*dy < neutronSqrd) {
						fp->status = fsNeutron;
					} else {
						fp->status = fsMoving;
					}
				}
				break;
			case wtNebulae:
				if (!nebulae.inside(wp->xloc,wp->yloc)) continue;
				if (fp->status==fsNeutron || fp->status==fsNebulae || fp->status==fsMoving) {
					dx = wp->xloc - fp->xloc;
					dy = wp->yloc - fp->yloc;
					if (dx*dx + dy*dy < nebulaeSqrd) {
						fp->status = fsNebulae;
					} else {
						fp->status = fsMoving;
					}
				}
				break;
			default:
				if (!scan.inside(wp->xloc,wp->yloc)) continue;
				break;
		}

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&wp->empireID,2*sizeof(int));
		len += 2*sizeof(int);
	}

	buf[0] = len;
	buf[1] = mfSectorWorlds;
	ssn->send(buf);

	if (fp->status != oldStatus) {
		// notify the client of the change in speed
//		sendFleetScan(ssn, fleetID, fp);
	}
}


void sessionHomeWorlds(Session *ssn) {	// once on startup
	int count,ix,len,empireID,fleetID;
	char buf[BUFFERSIZE];
	worldRec *worlds,*wp;

	gLog.logMsg(Log::LOG_DEBUG, 3150, "Display worlds to player just logging in.");
	if (!sessionGetInfo(ssn,&empireID,&fleetID)) return;

	worlds = (worldRec*)worldList->getList();
	if (worlds==NULL) return;

//--- build message ---
	count = worldList->getCount();

	for (ix=0,len=2;ix<count && len<BUFFERSIZE-3*sizeof(int);ix++) {

		wp = &worlds[ix];
		if (wp->empireID!=empireID || !isPlanet(wp->type)) continue;

		memcpy(buf+len,&ix,sizeof(int));
		len += sizeof(int);
		memcpy(buf+len,&wp->empireID,2*sizeof(int));
		len += 2*sizeof(int);
	}

	buf[0] = len;
	buf[1] = mfSectorWorlds;
	ssn->send(buf);
}

//***************************************************************************
//***************************************************************************

void setFleetDestination(fleetRec *fp,int id) {		// players fleets only
	fleetRec *ep;
	squadRec *sp;
	empireRec *emp;
	int i;

	gLog.logMsg(Log::LOG_DEBUG, 3160, "Setting fleet destination.");
//--- legal target? ---
	if (id>=0) {
		ep = (fleetRec*)fleetList->getRecord(id);
		if (ep==NULL) return;

		i = ep->xloc - fp->xloc;
		if (i<0) i = -i;
		if (i>SCAN_SIZE) return;

		i = ep->yloc - fp->yloc;
		if (i<0) i = -i;
		if (i>SCAN_SIZE) return;
	}

//--- break engagements ---
	for (i=0;i<sideCOUNT;i++) {
		ep = (fleetRec*)fleetList->getRecord(fp->engageID[i]);
		if (ep!=NULL) {
		   ep->engageID[InverseEngage(i)] = -1;
		}
		fp->engageID[i] = -1;
	}

//--- reset squad actions ---
	for (i=0;i<posCOUNT;i++) {
		sp = &fp->squad[i];
		sp->action = actDefend;
		sp->timer = 0;
	}

//--- set status ---
	if (fp->status==fsDead) {
		emp = (empireRec*)empireList->getRecord(fp->empireID);
		if (emp!=NULL && emp->worlds>0) fp->status = fsMoving;
	}
	else if (!isMoveState(fp->status)) fp->status = fsMoving;

	fp->destID = id;
}


bool setSquadAction(fleetRec *fp,int squadID,int action){
	return setSquadAction(fp,squadID,action,sideCOUNT);
}


bool setSquadAction(fleetRec *fp,int squadID,int action,int which){
	/*
	** fp is fleet record for squad attempting the action
	** squadID is squad performing the action
	** targetPos is position within the fleet (0-5)
	** which is target fleet position (0-2)
	**
	**  targetPos layout:                  which layout:
	**   ___        ___        ___          ___        ___        ___     
	**  |   |___   |   |___   |   |___     |   |___   |   |___   |   |___ 
	**  | 3 |   |  | 3 |   |  | 3 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 0 |  |___| 0 |  |___| 0 |    |___| 0 |  |___| 1 |  |___| 2 |
	**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
	**  | 4 |   |  | 4 |   |  | 4 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 1 |  |___| 1 |  |___| 1 |    |___| 0 |  |___| 1 |  |___| 2 |
	**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
	**  | 5 |   |  | 5 |   |  | 5 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 2 |  |___| 2 |  |___| 2 |    |___| 0 |  |___| 1 |  |___| 2 |
	**      |___|      |___|      |___|        |___|      |___|      |___|
	*/
	int heading,type,targetPos;
	fleetRec *ep;
	squadRec *sp;
	empireRec *emp;

	sp= &fp->squad[squadID];

	if (illegalAction(action)) return false;

	if (isRetreatAction(action)) {
		gLog.logMsg(Log::LOG_DEBUG, 3170, "Fleet retreating from battle.");
//		if (sp->type==stStation) return false;
		if (sp->action==action) return true;
	}

//--- move action / swap squads ---
	if (isMoveAction(action)) {
		gLog.logMsg(Log::LOG_DEBUG, 3180, "Squad moving in battle.");
		heading = ReadHeading(action);
		if (action < actMoveUp    ||
			action > actMoveRight ||
			MoveGrid[heading][squadID]==posCOUNT) return false;
	}

//--- firing, position prevents penetration ---
	type = sp->type;
	if (isFireAction(action) && type!=stStarDart && type!=stFrigate && type!=stStation) {

		ep = (fleetRec*)fleetList->getRecord(fp->engageID[which]);
		if (ep==NULL || isFriendlyFleet(ep,fp)) return false;

		targetPos = action-actTarget0;
		if (ep->squad[targetPos].type >= stCOUNT) return false;

		switch (which) {

			case sideInvade: // sideInvade
				/*
				** Only the front row gets to fire unless the front row is empty
				*/
				if (squadID>=3 && (fp->squad[0].type!=stCOUNT ||
					fp->squad[1].type!=stCOUNT || fp->squad[2].type!=stCOUNT)) return false;
				/*
				** Can only target the enemy's front row unless their front row is empty
				*/
				if (targetPos<3 && (ep->squad[3].type!=stCOUNT ||
					ep->squad[4].type!=stCOUNT || ep->squad[5].type!=stCOUNT)) return false;
				break;

			case sideDefend: // sideDefend
				/*
				** Only the front row gets to fire unless the front row is empty
				*/
				if (squadID<3 && (fp->squad[3].type!=stCOUNT ||
					fp->squad[4].type!=stCOUNT || fp->squad[5].type!=stCOUNT)) return false;
				/*
				** Can only target the enemy's front row unless their front row is empty
				*/
				if (targetPos>=3 && (ep->squad[0].type!=stCOUNT ||
					ep->squad[1].type!=stCOUNT || ep->squad[2].type!=stCOUNT)) return false;
				break;
		}
	}
	/*
	** Frigates and stations can fire from back row to enemy's front row
	*/
	if (isFireAction(action) && (type==stFrigate || type==stStation)) {

		ep = (fleetRec*)fleetList->getRecord(fp->engageID[which]);
		if (ep==NULL || isFriendlyFleet(ep,fp)) return false;

		targetPos = action-actTarget0;
		if (ep->squad[targetPos].type >= stCOUNT) return false;

		switch (which) {

			case sideInvade: // sideInvade
				/*
				** Can only target the enemy's front row unless their front row is empty
				*/
				if (targetPos<3 && (ep->squad[3].type!=stCOUNT ||
					ep->squad[4].type!=stCOUNT || ep->squad[5].type!=stCOUNT)) return false;
				break;

			case sideDefend: // sideDefend
				/*
				** Can only target the enemy's front row unless their front row is empty
				*/
				if (targetPos>=3 && (ep->squad[0].type!=stCOUNT ||
					ep->squad[1].type!=stCOUNT || ep->squad[2].type!=stCOUNT)) return false;
				break;
		}
	}

//--- action approved ---
	sp->action = action;
	sp->enemy = which;

	emp = (empireRec*)empireList->getRecord(fp->empireID);

	switch (action) {
		case actDefend:
			gLog.logMsg(Log::LOG_DEBUG, 3190, "Squad defending, timer set to 0.");
			sp->timer = 0; 
			break;
		case actRetreat:
			gLog.logMsg(Log::LOG_DEBUG, 3195, "Squad retreating, set retreat timer.");
			if (emp->race==rtQuarethian) {
				sp->timer = FastRetreatTimer[sp->type];
				break;
			}
			else if (emp->race!=rtQuarethian) {
				sp->timer = RetreatTimer[sp->type];
				break;
			}
		case actMoveUp:
		case actMoveDown:
		case actMoveLeft:
		case actMoveRight:
			gLog.logMsg(Log::LOG_DEBUG, 3200, "Squad moving, set move timer.");
			if (emp->race==rtQuarethian) {
				sp->timer = FastMoveTimer[sp->type]; 
				break;
			}
			else if (emp->race!=rtQuarethian) {
				sp->timer = MoveTimer[sp->type];
				break;
			}
		default: // actTarget0 through actTarget5
			gLog.logMsg(Log::LOG_DEBUG, 3210, "Squad firing, set fire timer.");
			if (emp->race==rtQuarethian) {
				sp->timer = FastFireTimer[sp->type];
				break;
			}
			else if (emp->race!=rtQuarethian) {
				sp->timer = FireTimer[sp->type];
				break;
			}
	}

	return true;
}


void randomizeStarDart(int num) {
	char buf[BUFFERSIZE];
	int ix,count;
	worldRec *wp;
	fleetRec *fp;
	empireRec *emp;
	int slot=0;
	bool done;

	count = worldList->getCount();

	for (;num>0;num--) {
		done = false;

		while (!done) {

			ix = Rand(count);

			wp = (worldRec*)worldList->getRecord(ix);
			if ((wp==NULL) || ((isPlanet(wp->type) && wp->facility!=ftStellurae))) {
				continue;
			}

			fp = (fleetRec*)fleetList->getRecord(ix);
			if (fp==NULL) continue;
			for (slot=0; slot < posCOUNT; slot++) {
				if (fp->squad[slot].type == stStarDart || fp->squad[slot].type == stCOUNT) {
					done = true;
					break;
				}
			}

		}

		gLog.logMsg(Log::LOG_DEBUG, 3220, "Found a world to place dart.");
		
		fp->squad[slot].type = stStarDart;
		fp->squad[slot].count++;

		if (wp->empireID != 0) {
			emp = (empireRec*)empireList->getRecord(wp->empireID);
			if (emp!=NULL) {
				emp->darts++;
				if (isPlanet(wp->type)) {
					sprintf(buf,"+++ %s stells a Star Dart! +++",emp->name);
				} else {
					emp->scoreDarts++;
					sprintf(buf,"+++ %s scores a Star Dart! +++",emp->name);
				}
				sendGlobalMessage(buf);
				gLog.logMsg(Log::LOG_DEBUG, 3230, buf);
			}
			if (emp!=NULL && !isPlanet(wp->type) && emp->race==rtCestanian) {
				if (Rand(10)==0) {
					emp->darts++;
					emp->scoreDarts++;
					sprintf(buf,"+++ %s scores a Star Dart! +++",emp->name);
					sendGlobalMessage(buf);
					gLog.logMsg(Log::LOG_DEBUG, 3240, buf);
				}
			}
		}
	}
}

//***************************************************************************

