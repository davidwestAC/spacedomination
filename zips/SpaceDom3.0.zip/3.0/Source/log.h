#ifndef _LOG_H
#define _LOG_H

class Log {
	public:
		enum loggingLevel {LOG_NONE=0,LOG_ERROR=1,LOG_INFO=2,LOG_VERBOSE=3,LOG_DEBUG=4,LOG_DEBUG_VERBOSE=5};

	private:
		char *m_lpLogFileName;
		loggingLevel m_logLevel;
		int m_last_log_id;
		int m_last_log_count;

	public:
		Log(loggingLevel ll=LOG_ERROR, const char *lpFileName=NULL);
		~Log();
		void logMsg(loggingLevel ll, const int log_id, const char* lpFormatString, ...);
		void setLogFile(const char *lpFileName);
		loggingLevel setLogLevel(loggingLevel ll);
		loggingLevel getLogLevel() {return m_logLevel;}
};

#endif // _LOG_H
