#include <io.h>
#include <time.h>
#include <stdio.h>
#include "string.hpp"
#include <stdlib.h>
//#include <varargs.h>
#include <stdarg.h>
#include "log.h"


Log::Log(loggingLevel ll, const char *lpFileName)
	:m_lpLogFileName(NULL) {
	m_logLevel = ll;
	m_last_log_count = 0;
	setLogFile(lpFileName);
}


Log::~Log() {
	if (m_lpLogFileName) {
		delete[] m_lpLogFileName;
		m_lpLogFileName = NULL;
	}
}


void Log::logMsg(loggingLevel ll, const int log_id, const char* lpFormatString, ...) {
	if (ll <= m_logLevel) {
		/*
		** If last log message has the same id as this one, don't output it again
		** unless verbose debug level logging is enabled.  Instead, eep track of
		** how many come in until it changes, then output the count.
		*/
		if (m_last_log_id == log_id && m_logLevel != LOG_DEBUG_VERBOSE) {
			m_last_log_count++;
			return;
		} else {
			m_last_log_id = log_id;
			if (m_lpLogFileName) {
				FILE *fsLogFile;
				fsLogFile = fopen(m_lpLogFileName, "a");
				if (m_last_log_count > 1) {
					fprintf (fsLogFile, " <-- occurred %d times\n", m_last_log_count);
				} else {
					fprintf (fsLogFile, "\n");
				}
				fclose(fsLogFile);
			} else {
				if (m_last_log_count > 1) {
					fprintf (stdout, " <-- occurred %d times\n", m_last_log_count);
				} else {
					fprintf (stdout, "\n");
				}
			}
			m_last_log_count = 1;
		}

		/*
		** Create a time stamp for the log message
		*/
		time_t t;
		tm*    d;
		char timeStamp[25];
		time(&t);
		d = localtime(&t);
		strftime(timeStamp, 25, "%x %I:%M:%S%p: ", d);

		va_list args;
		va_start (args, lpFormatString);

		if (m_lpLogFileName) {
			FILE *fsLogFile;
			fsLogFile = fopen(m_lpLogFileName, "a");

			fprintf (fsLogFile, timeStamp);

			switch (ll) {
				case LOG_ERROR:
					fprintf (fsLogFile, "ERROR(%d): ", log_id);
					break;
				case LOG_INFO:
					fprintf (fsLogFile, "INFO(%d): ", log_id);
					break;
				case LOG_VERBOSE:
					fprintf (fsLogFile, "VERBOSE(%d): ", log_id);
					break;
				case LOG_DEBUG:
					fprintf (fsLogFile, "DEBUG(%d):  ", log_id);
					break;
				case LOG_DEBUG_VERBOSE:
					fprintf (fsLogFile, "DEBUG_VERBOSE(%d): ", log_id);
					break;
			}

			vfprintf (fsLogFile, lpFormatString, args);
//			fprintf (fsLogFile, "\n");
			fclose(fsLogFile);
		} else {
			fprintf (stdout, timeStamp);
			switch (ll) {
				case LOG_ERROR:
					fprintf (stdout, "ERROR(%d): ", log_id);
					break;
				case LOG_INFO:
					fprintf (stdout, "INFO(%d): ", log_id);
					break;
				case LOG_VERBOSE:
					fprintf (stdout, "VERBOSE(%d): ", log_id);
					break;
				case LOG_DEBUG:
					fprintf (stdout, "DEBUG(%d): ", log_id);
					break;
				case LOG_DEBUG_VERBOSE:
					fprintf (stdout, "DEBUG_VERBOSE(%d): ", log_id);
					break;
			}
			vfprintf (stdout, lpFormatString, args);
//			fprintf (stdout, "\n");
			fflush(stdout);
		}
		va_end(args);
	}
}


void Log::setLogFile(const char *lpFileName) {
	if (lpFileName) {
		m_lpLogFileName = new char[strlen(lpFileName) + 1];
		if (m_lpLogFileName) {
			strcpy(m_lpLogFileName, lpFileName);
		}
	} else {
        m_lpLogFileName = NULL;
    }
}

Log::loggingLevel Log::setLogLevel(loggingLevel ll) {
	loggingLevel llReturnVal = m_logLevel;

	m_logLevel = ll;

	return llReturnVal;
}
