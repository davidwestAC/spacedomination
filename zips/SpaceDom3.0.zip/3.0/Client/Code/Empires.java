import java.awt.*;

class Empires implements MessageValues {

	final static String UNKNOWN = "<unknown>";
	final static String EMPIRE = "";

	static Empires root = null;

	public final static String[] racename = {
		"Human","Makluvian","Kaletian",
		"Zorestian","Avarian","Najunian",
		"Cestanian","Quarethian",
		"Nothing",
	};

//--- variables ---
	String name;
	int empireID,worlds,phenom,hiWorlds,darts,hiDarts,score,hiScore,fleetID,channel,race=0,ruler;
	int Merchant,Beacon,Stardock,Stellurae,scoreDarts;
	int online=0;
	Empires next;

//--- constructors ---
	public Empires(){next = null;}

	public String toString(){return "("+empireID+")"+name;}

	public String name(){return name+EMPIRE;}
	public String racename(){return racename[race];}

	public int worlds(){return worlds;}
	public int phenom(){return phenom;}
	public int darts(){return darts;}
	public int score(){return score;}
	public int fleetID(){return fleetID;}
	public int channel(){return channel;}
	public int race(){return race;}
	public int ruler(){return ruler;}
	public int Merchant(){return Merchant;}
	public int Beacon(){return Beacon;}
	public int Stardock(){return Stardock;}
	public int scoreDarts(){return scoreDarts;}

	public static Empires start(){return root;}
	public Empires next(){return next;}

//--- functions ---
	public static void add(Buffer buf){
	Empires temp,ep;
	int id, offset;

		offset = 2;
		id = buf.getInt(offset);
		ep = get(id);

		temp = (ep!=null?ep:new Empires());

		temp.empireID = id;
		temp.fleetID = buf.getInt(offset+=4);
		temp.channel = buf.getInt(offset+=4);
		temp.ruler = buf.getInt(offset+=4);
		temp.race = buf.getInt(offset+=4);
		temp.worlds = buf.getInt(offset+=4);
		temp.phenom = buf.getInt(offset+=4);
		temp.darts = buf.getInt(offset+=4);
		temp.score = buf.getInt(offset+=4);
		temp.hiWorlds = buf.getInt(offset+=4);
		temp.hiDarts = buf.getInt(offset+=4);
		temp.hiScore = buf.getInt(offset+=4);
		temp.Merchant = buf.getInt(offset+=4);
		temp.Beacon = buf.getInt(offset+=4);
		temp.Stardock = buf.getInt(offset+=4);
		temp.Stellurae = buf.getInt(offset+=4);
		temp.scoreDarts = buf.getInt(offset+=4);
		temp.online = buf.getInt(offset+=4);
		temp.name = buf.getString(offset+=4);

		if (ep==null) insert(temp);
	}

	public static Empires get(int empireID){
	Empires temp;

		temp = root;
		while (temp!=null) {
			if (temp.empireID==empireID) return temp;
			temp = temp.next;
		}
		return null;
	}

	public static String findEmpireName(int empireID){
	String temp;

		temp = Empires.findName(empireID);

		if (UNKNOWN.equals(temp)) {
			GameState.sendEmpireQuery(empireID);
			return UNKNOWN;
		}

		return temp+EMPIRE;
	}

	public static String findName(int empireID){
	Empires temp;
	Buffer buf;

		temp = get(empireID);
		if (temp!=null) return temp.name;

		temp = new Empires();

		temp.empireID = empireID;
		temp.name = UNKNOWN;
		temp.worlds = 0;
		temp.phenom = 0;
		temp.score = 0;
		temp.channel = 0;
		temp.fleetID = 0;
		temp.race = 8;
		temp.ruler = -1;
		temp.Merchant = 0;
		temp.Beacon = 0;
		temp.Stardock = 0;

		insert(temp);

		return temp.name;
	}

//--- private functions ---
	static void insert(Empires temp){
		temp.next = root;
		root = temp;
	}
};