import java.awt.*;
import java.applet.*;

class gsIndustry extends GameState {

//--- variables ---
	Button launch,options,repeat,send,maxInd,collect;
	Button[] build;
	Scrollbar goal;
	CheckboxGroup transferShips;
	Checkbox transferAll, transferHalf, transferOne;
	Builds gbuild = null;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final static Rectangle[] crect = {
		new Rectangle(5,249,55,70),new Rectangle(65,249,55,70),new Rectangle(125,249,55,70),
			new Rectangle(185,249,55,70),new Rectangle(245,249,55,70),
		new Rectangle(5,325,55,70),new Rectangle(65,325,55,70),new Rectangle(125,325,55,70),
			new Rectangle(185,325,55,70),new Rectangle(245,325,55,70),	
			
	//--- orbit rects ---
		new Rectangle(300,35,60,30),new Rectangle(300,65,60,30),new Rectangle(300,95,60,30),
			new Rectangle(240,20,60,30),new Rectangle(240,50,60,30),new Rectangle(240,80,60,30),

	//--- ground rects ---
		new Rectangle(430,35,60,30),new Rectangle(430,65,60,30),new Rectangle(430,95,60,30),
			new Rectangle(370,20,60,30),new Rectangle(370,50,60,30),new Rectangle(370,80,60,30),
	};
	
	Rectangle orbit = new Rectangle(240,5,120,140);
	Rectangle ground = new Rectangle(370,5,120,140);

	int select=-1,over=-1,selectSquad=-1,target=-1;
	int fromPos=-1,toPos=-1;
	int fromFleet=0,fromCount=0;
	Worlds wp=null;
	boolean initialized = false;

//--- constructors ---
	public gsIndustry() {}

	public void init() {
	int i;
	
		initialized=false;
		transferShips = new CheckboxGroup();
		root.add(transferAll = new Checkbox("All",(transferType==0),transferShips));
		root.add(transferHalf = new Checkbox("1/2",(transferType==1),transferShips));
		root.add(transferOne = new Checkbox("One",(transferType==2),transferShips));
		transferAll.setForeground(Color.white);
		transferAll.setBackground(SCREEN_COLOR);
		transferHalf.setForeground(Color.white);
		transferHalf.setBackground(SCREEN_COLOR);
		transferOne.setForeground(Color.white);
		transferOne.setBackground(SCREEN_COLOR);

		root.add(launch = new Button("Launch"));
		root.add(options = new Button("Options"));
		root.add(repeat = new Button("Repeat"));
		root.add(send = new Button("Send"));
		send.setVisible(false);
		root.add(maxInd = new Button("Max Ind"));
		root.add(collect = new Button("Collect"));

		build = new Button[Builds.BUILD_TYPES];
		for (i=0;i<Builds.BUILD_TYPES;i++) {
			/*
			** cost of 0 indicates that item not allowed in this arena
			*/
			if (Builds.cost[i] != 0) {
				root.add(build[i] = new Button(Builds.name[i]));
			}
		}
		root.add(build[Builds.BUILD_TYPES-1] = new Button(Builds.name[Builds.BUILD_TYPES-1]));

		root.add(goal = new Scrollbar(Scrollbar.HORIZONTAL,0,10,0,250));
		gbuild = new Builds();
		initialized=true;

	}

	public void paint(Graphics g) {
		Rectangle r;
		Fleets fp,ep;
		Squadron sp;
		Builds bp;
		int i,val,count;
		int h,v;

		if (!initialized) {
			return;
		}
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,0,500,400);

		setBounds(transferAll,335,140,40,20);
		setBounds(transferHalf,377,140,40,20);
		setBounds(transferOne,419,140,50,20);

		setBounds(launch,9,5,50,20);
		setBounds(options,62,5,50,20);

		setBounds(goal,5,224,247,19);
		setBounds(repeat,255,224,46,20);
		setBounds(build[Builds.BUILD_PINNACE],10,200,55,20);
		setBounds(build[Builds.BUILD_CORSAIR],181,200,55,20);
		setBounds(build[Builds.BUILD_FRIGATE],238,200,55,20);
		setBounds(build[Builds.BUILD_STATION],124,200,55,20);
		setBounds(build[Builds.BUILD_RANGER],67,200,55,20);
		setBounds(build[Builds.BUILD_INDUSTRY],67,152,58,20);
		setBounds(maxInd,127,152,58,20);		// Max Ind
		setBounds(collect,187,152,50,20);		// Collect
		setBounds(build[Builds.BUILD_NOTHING],10,152,55,20);

		/*
		** Order of the following if statements will determine
		** button order on screen from left to right
		*/
		int x = 8;
		int width = 0;
		int spacing = 2;
		if (Builds.cost[Builds.BUILD_MERCHANT] != 0) {
			x += spacing+width;
			width = 65;
			setBounds(build[Builds.BUILD_MERCHANT],x,176,width,20);		// Merchant
		}
		if (Builds.cost[Builds.BUILD_BEACON] != 0) {
			x += spacing+width;
			width = 50;
			setBounds(build[Builds.BUILD_BEACON],x,176,width,20);	// Beacon
		}
		if (Builds.cost[Builds.BUILD_STARDOCK] != 0) {
			x += spacing+width;
			width = 58;
			setBounds(build[Builds.BUILD_STARDOCK],x,176,width,20);	// Stardock
		}
		if (Builds.cost[Builds.BUILD_DOOMSDAY] != 0) {
			x += spacing+width;
			width = 64;
			setBounds(build[Builds.BUILD_DOOMSDAY],x,176,width,20);	// Doomsday
		}
		if (Builds.cost[Builds.BUILD_SHIELD] != 0) {
			x += spacing+width;
			width = 55;
			setBounds(build[Builds.BUILD_SHIELD],x,176,width,20);	// Shield
		}
		if (Builds.cost[Builds.BUILD_STELLURAE] != 0) {
			x += spacing+width;
			width = 58;
			setBounds(build[Builds.BUILD_STELLURAE],x,176,width,20);	// Stellurae
		}

		fp = gsFleet;
		ep = Fleets.get(fp.destID);
		wp = Worlds.get(fp.destID);

		if (wp==null) {
			g.setColor(Color.black);
			g.drawString("Waiting for Info",10,10);
			g.drawString("fleet = "+fp.fleetID,10,30);
			g.drawString("world = "+fp.destID,10,50);
			return;
		}


		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals

		g.setColor(Color.white);
		g.drawString(fp.empireName(),120,20);
		g.drawString("World: "+wp.name(),120,35);
		g.drawString("Type: "+wp.special(),120,50);
		g.drawString("Sector: "+wp.sector(),120,65);
		g.drawString("Population: "+wp.pop(),120,80);
		val = (wp.maxInd()-wp.ind());
		g.drawString("Industry: "+wp.ind()+(val>0?" ("+val+")":" (Max)"),120,95);
		g.drawString("Storage: "+wp.storage(),120,110);
		g.drawString("Facility: "+wp.facilityname(),120,125);
	
		h = 320;
		v = 220;
/*		g.drawString("Minerals:",h+40,v);
		g.drawString("Pladesium: "+wp.pladesium(),h,v+=15);
		g.drawString("Stenterium: "+wp.stenterium(),h,v+=15);
		g.drawString("Calastium: "+wp.calastium(),h,v+=15);
		g.drawString("Revidium: "+wp.revidium(),h,v+=15);
		g.drawString("Frelenium: "+wp.frelenium(),h,v+=15);

		v+=7;
		g.drawString("Global Facilities:",h+25,v+=15);
		if (Builds.cost[6] != 0) {
			g.drawString("Merchants: "+wp.Merchant()+" Max: "+wp.maxMerchant(),h,v+=15);
		}
		if (Builds.cost[7] != 0) {
			g.drawString("Beacons: "+wp.Beacon()+" Max: "+wp.maxBeacon(),h,v+=15);
		}
		if (Builds.cost[8] != 0) {
			g.drawString("Stardocks: "+wp.Stardock()+" Max: "+wp.maxStardock(),h,v+=15);
		}
		if (Builds.cost[9] != 0) {
			g.drawString("Blasters: "+wp.Blaster()+" Max: "+wp.maxBlaster(),h,v+=15);
		}
		if (facilityCostType == 1) {
			g.drawString("Timer: "+wp.facilityTime(),h,v+=15);
		}
*/

		if (fp!=null) {
			int ox, oy;
			ox = orbit.x;
			oy = orbit.y;
			g.setColor(Color.white);
			g.drawString("Orbit",ox+5,oy+12);
			for (int pos = 0; pos < Fleets.POS_COUNT; pos++) {
				r = crect[pos+10];
				g.setColor(BOX_COLOR_FLEET);
				g.fillRect(r.x,r.y,r.width,r.height);
				fp.drawStats(g,r.x,r.y,pos);
				g.setColor(SCREEN_COLOR);
				g.drawRect(r.x,r.y,r.width,r.height);

			}
			g.setColor(Color.white);
			g.drawString("Guns="+fp.guns(),ox+5,oy+orbit.height-5);
		}
		if (ep!=null) {
			int ox, oy;
			ox = ground.x;
			oy = ground.y;
			g.setColor(Color.white);
			g.drawString("Guard",ox+5,oy+12);
			for (int pos = 0; pos < Fleets.POS_COUNT; pos++) {
				r = crect[pos+16];
				g.setColor(BOX_COLOR_FLEET);
				g.fillRect(r.x,r.y,r.width,r.height);
				ep.drawStats(g,r.x,r.y,pos);
				g.setColor(SCREEN_COLOR);
				g.drawRect(r.x,r.y,r.width,r.height);
			}
			g.setColor(Color.white);
			g.drawString("Guns="+ep.guns(),ox+5,oy+orbit.height-5);
		}

		g.setColor(Color.white);
		g.drawString("Ship Transfer: ",245,155);

	//--- builds ---
		g.setColor(BOX_COLOR);
		for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			g.fillRect(r.x,r.y,r.width,r.height);
		}

		if (select<0 || select>=10) send.setVisible(false);
		else {
			r = crect[select];
			g.setColor(Color.red);
			g.drawRect(r.x-1,r.y-1,r.width+2,r.height+2);

			gbuild.setGoal(goal.getValue());

			r = crect[select];
			setBounds(send,r.x+20,r.y+53,35,17);
			send.setVisible(true);
		}

		g.setColor(Color.black);
		if (wp!=null) for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			bp = (i==select?gbuild:wp.builds(i));
			if (bp==null) continue;
			if ((bp.type()==bp.BUILD_NOTHING || bp.goal()==0) && i!=select) continue;
			
			if (bp.type()<=bp.BUILD_INDUSTRY) {
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				g.drawString(""+bp.cost(),r.x+2,r.y+60);
			}

			if (bp.type()>=bp.BUILD_MERCHANT && bp.type()<=bp.BUILD_STARDOCK) {
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				if (facilityCostType == 0) {
					g.drawString(""+bp.cost(),r.x+2,r.y+60);
				}
			}
			
			if (bp.type()>=bp.BUILD_DOOMSDAY && bp.type()<=bp.BUILD_SHIELD) {
				bp.goal = 1;
				bp.repeat = false;
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.cost(),r.x+2,r.y+30);
			}
		}
		
		g.setColor(Color.white);
		if (over>=0) {
			r = crect[over];
			g.setColor(Color.blue);
			g.drawRect(r.x,r.y,r.width,r.height);
		}
		drawSelect(g);
		drawChatMessages(g);
	}

	void drawSelect(Graphics g){
	Rectangle rs,rt;
	int cx,cy;

		if (selectSquad<0) return;

		rs = crect[selectSquad+10];
		g.setColor(Color.blue);

		if (selectSquad==target) {
			g.drawRect(rs.x,rs.y,rs.width,rs.height);
			return;
		}

		rt = crect[target+10];
		cx = rt.x + rt.width / 2;
		cy = rt.y + rt.height / 2;
		
		g.drawLine(rs.x,rs.y,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y,cx,cy);
		g.drawLine(rs.x,rs.y+rs.height,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y+rs.height,cx,cy);
	}

//--- primary functions ---
	public void down(int x,int y,Event e){
	Squadron sp=null;
	Fleets fp=null;
	int i;

		for (i=0;i<10;i++) {
			if (!crect[i].contains(x,y)) continue;
			if (i!=select) {
				select = i;
				gbuild.copy(wp.builds(i));
				goal.setValue(gbuild.goal);
			}else {
				select = -1;
			}
			break;
		}

		if (orbit.contains(x,y)) {
			fromFleet = 0;
			fp=gsFleet;
			sp = fp.squads(over-10);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				target = selectSquad = over-10;
				fromPos = over-10;
			}
		}

		if (ground.contains(x,y)) {
			fromFleet = 1;
			fp = gsFleet.getInvade();
			sp = fp.squads(over-16);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				target = selectSquad = over-10;
				fromPos = over-16;
			}
		}
	}

	public void move(int x,int y) {
		Fleets fp;
		int i,num;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.contains(x,y);

		over = -1;
		for (i=0;i<10;i++) {
			if (crect[i].contains(x,y)) {
				over = i;
				return;
			}
		}

		if (orbit.contains(x,y)) {
			for (i=10;i<16;i++) {
				if (crect[i].contains(x,y)) {
					over=i;
					return;
				}
			}
		}

		if (ground.contains(x,y)) {
			for (i=16;i<22;i++) {
				if (crect[i].contains(x,y)) {
					over=i;
					return;
				}
			}
		}
	}
	
	public void raise(int x,int y) {
		int toFleet=0;
		Squadron sp=null;
		Fleets fp=null;

		if (target != -1 && selectSquad != -1 && selectSquad != target) {
			if (orbit.contains(x,y)) {
				toFleet = 0;
				toPos = target;
			}
			if (ground.contains(x,y)) {
				toFleet = 1;
				toPos = target-6;
			}
			if (fromFleet == 0) {
				fp=gsFleet;
			} else {
				fp = gsFleet.getInvade();
			}
			sp = fp.squads(fromPos);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				switch(transferType) {
					case 1:
						fromCount = sp.count()/2;
						break;
					case 2:
						fromCount = 1;
						break;
					default:
						fromCount = sp.count();
				}
			}
			sendTransfer(fromFleet,toFleet,fromPos,toPos,fromCount);
		}
		selectSquad = target = -1;
	}

	public void drag(int x,int y) {
		for (int i=0;i<12;i++) {
			if (!crect[i+10].contains(x,y)) {
				continue;
			}
			target = i;
			break;
		}
	}

	public void action(Event e) {
		int id;

		super.action(e);

		if (e.target==launch) signalLaunch();
		if (e.target==options) setState(new gsOptions(false));

		if (e.target==repeat) gbuild.flipRepeat();
		for (id=0;id<Builds.BUILD_TYPES;id++) {
			if (e.target==build[id]) {
				gbuild.setType(id);
				Worlds wp = Worlds.get(gsFleet.destID);
				switch(id) {
					case 0: // Sloop
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 1: // Corsair
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 2: // Frigate
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 3: // Station
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 4: // Ranger
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 6: // Merchant
						goal.setValue(wp.maxMerchant()-wp.Merchant());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
					case 7: // Beacon
						goal.setValue(wp.maxBeacon()-wp.Beacon());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
					case 8: // Stardock
						goal.setValue(wp.maxStardock()-wp.Stardock());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
				}
			}
		}
		if (e.target==send) sendBuildMessage();
		if (e.target==transferAll) transferType=0;
		if (e.target==transferHalf) transferType=1;
		if (e.target==transferOne) transferType=2;
		if (e.target==maxInd) {
			Worlds wp = Worlds.get(gsFleet.destID);
			if(gsFleet != null && wp != null) {
				if (wp.ind() != wp.maxInd()) {
					int val = wp.maxInd() - wp.ind();
					buildIndustry(val);
				}
			}
		}
		if (e.target==collect) collectShips();
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;

		fp=null;

		value = super.handleInput(buf);

		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());

		return value;
	}

//--- change build values ---
	void sendBuildMessage() {
		Buffer buf;

		if (select<0 || select>=10 || gbuild==null) return;

		if (gbuild.type() >= 0 && gbuild.type() <= 4) {
			Worlds wp = Worlds.get(gsFleet.destID);
			switch(gbuild.type()) {
				case 0: // Sloop
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 1: // Corsair
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 2: // Frigate
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 3: // Station
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 4: // Ranger
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
			}
		}

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,BUILD_COMMAND);
		buf.set(2,select);
		buf.set(3,(gbuild.repeat()?1:0));
		buf.set(4,gbuild.type());
		buf.set(5,gbuild.goal());
		buf.send();

		select = -1;
		send.setVisible(false);
	}

	public boolean press(int key) {
		switch (key) {
			case 9:	// Tab 10 enter
				setState(new gsOptions(false));
				return false;
		}
		return super.press(key);
	}

	void buildIndustry(int val) {
		int slot = 9;
		Buffer buf;

		if (val <= 0) {
			return;
		}

		while (val > 240 && slot >= 0) {
			buf = new Buffer(6);
			buf.set(0,6);
			buf.set(1, BUILD_COMMAND);
			buf.set(2, slot);
			buf.set(3, 0);
			buf.set(4, Builds.BUILD_INDUSTRY);
			buf.set(5, 240);
			buf.send();
			val -= 240;
			slot--;
		}
		if (val > 0 && slot >= 0) {
			buf = new Buffer(6);
			buf.set(0,6);
			buf.set(1, BUILD_COMMAND);
			buf.set(2, slot);
			buf.set(3, 0);
			buf.set(4, Builds.BUILD_INDUSTRY);
			buf.set(5, val);
			buf.send();
		}
	}

	void collectShips() {
		Fleets fpFrom=null;
		Fleets fpToo=null;
		Squadron spFrom=null;
		Squadron spToo=null;

		int count = 0;

		fpFrom = gsFleet.getInvade();
		fpToo = gsFleet;

		for (int toPos=0; toPos<6; toPos++) {
			spToo = fpToo.squads(toPos);
			for (int fromPos=0; fromPos<6; fromPos++) {
				spFrom = fpFrom.squads(fromPos);
				if (spToo.type == spFrom.type && spToo.type != spToo.SHIP_TYPES) {
					switch(transferType) {
						case 1:
							count = spFrom.count()/2;
							break;
						case 2:
							count = 1;
							break;
						default:
							count = spFrom.count();
					}
					sendTransfer(1,0,fromPos,toPos,count);
				}
			}
		}
	}
}
