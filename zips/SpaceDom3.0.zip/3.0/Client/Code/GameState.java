import java.awt.*;
import java.applet.*;
import java.util.Vector;
import java.util.Hashtable;
import java.text.SimpleDateFormat;

class GameState implements MessageValues {

//--- global values ---
	static SpaceDom root;

	static String message = "";

	public static int setRace = 0;
	public static int transferType = 0;

	final static int MAX_CHAT = 5;
	static String[] chatMsg = new String[MAX_CHAT];
	static long[] chatTime = new long[MAX_CHAT];
	boolean showChat = true;
	public static boolean smooth = true;
	public static Hashtable redWorlds = new Hashtable();
	public static Hashtable greenWorlds = new Hashtable();

	public static int gsEmpireID,gsFleetID;
	public static Empires gsEmpire=null;
	public static Fleets gsFleet=null;
	public static int fleetStatus=Fleets.DEAD;

	public static Vector activeMarkers = new Vector();
	public static ScreenMarker nearestWorld=null;
	public static ScreenMarker nearestGate=null;
	public static ScreenMarker lastAttacked=null;
	public static ScreenMarker lastCaptured=null;

	public final static Font hugeFNT = new Font("TimesRoman",Font.BOLD,116);
	public final static Font bigFNT = new Font("TimesRoman",Font.BOLD,50);
	public final static Font stoutFNT = new Font("TimesRoman",Font.BOLD,24);
	public final static Font textFNT = new Font("TimesRoman",Font.PLAIN,14);
	public final static FontMetrics hugeMET = new Button().getFontMetrics(hugeFNT);
	public final static FontMetrics bigMET = new Button().getFontMetrics(bigFNT);
	public final static FontMetrics stoutMET = new Button().getFontMetrics(stoutFNT);
	public final static FontMetrics textMET = new Button().getFontMetrics(textFNT);

	public static Color SCREEN_COLOR = new Color(100,131,158);
	public static Color BOX_COLOR = new Color(149,174,193);
	public static Color BOX_COLOR_FLEET = new Color(126,176,207);

	static int[] top20List = {-1,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0,	0,0,0,0,0};
	static int channel = 0;
	public static int[] lastBuilt = {20,4,1,10,4};
	public static boolean[] lastRepeat = {true,true,true,true,true};

	public static int allFacilitiesActLocal;
	public static int facilityCostType;

	public static int daysTillResume;
	public static int hoursTillResume;
	public static int minutesTillResume;
	public static int secondsTillResume;
	public static boolean suspended=false;

	Buffer statBuf = null;
	Buffer setBuf = null;

//--- constructors ---
	public GameState(){
		root.setFont(textFNT);
		//fmet = root.getFontMetrics(root.getFont());
	}

	public void init() {}

	public static void setState(GameState gs){
		root.removeAll();	// kill tools
		SpaceDom.state = gs;
		gs.init();
		root.repaint();
		root.requestFocus();
	}

//--- primary functions ---
	public void paint(Graphics g) {}

	public void action(Event e) {}

	public void down(int x,int y,Event e) {}
	public void raise(int x,int y) {}
	public void move(int x,int y) {}
	public void drag(int x,int y) {}

	public boolean press(int key) {
	int len;

		if (!(this instanceof gsPassword)) root.requestFocus();

		if (key==10) {	// send
			sendMessage();
			message = "";
		} else if (key==8) {	// backspace
			len = message.length();
			if (len>0) message = message.substring(0,len-1);
		} else {
			message += ""+(char)(key);
		}
		return true;
	}

	static void addActiveMarker(ScreenMarker marker) {
		GameState.activeMarkers.addElement(marker);
	}

	static void removeActiveMarker(ScreenMarker marker) {
		GameState.activeMarkers.removeElement(marker);
	}

	public boolean isMovingStatus(){return (fleetStatus<=Fleets.NEUTRON);}

//--- handle common inputs ---
	public boolean handleInput(Buffer buf) {
		int worldID,offset;
		Worlds wp;

		switch(buf.get(1)) {
			case WORLD_SCAN:
				Worlds.add(buf);
				return true;
			case FLEET_SCAN:
				Fleets.add(buf);
				return true;
			case EMPIRE_SCAN:
				Empires.add(buf);
				return true;
			case COMBAT_SCAN:
				Fleets.combat(buf);
				return true;
			case BUILD_SCAN:
				Worlds.build(buf);
				return true;
			case TOP20_SCAN:
				readTop20List(buf);
				return true;
			case SECTOR_FLEETS:
				Fleets.scan(buf);
				return true;
			case SECTOR_WORLDS:
				Worlds.scan(buf);
				return true;
			case MESSAGE:
				chatAdd(buf);
				return true;
			case LASTATTACKED:
				worldID = buf.getInt(2);
				if (lastAttacked != null) {
					removeActiveMarker(lastAttacked);
				}
				lastAttacked = new ScreenMarker(worldID,Color.blue);
				addActiveMarker(lastAttacked);
				return true;
			case LASTCAPTURED:
				worldID = buf.getInt(2);
				if (lastAttacked != null) {
					removeActiveMarker(lastCaptured);
				}
				if (lastAttacked.id == worldID) {
					removeActiveMarker(lastAttacked);
					lastAttacked = null;
				}
				lastCaptured = new ScreenMarker(worldID,Color.red);
				addActiveMarker(lastCaptured);
				return true;
			case STATUS: 
//todo detect movement status change and flag for Fleets.java
//to use when calculating speed until next fleet scan
				fleetStatus = buf.get(2);
				sendPing();
				return true;
			case VICTORY:
				setState(new gsVictory(buf));
				return true;
			case STATS_RESULT:
				statBuf = buf;
				return true;
			case SETTINGS_RESULT:
				setBuf = buf;
				return true;
			case FACILITY_INFO:
				offset = 2;
				allFacilitiesActLocal = buf.getInt(offset);
				facilityCostType = buf.getInt(offset+=4);
				Builds.cost = new int[15];
				Builds.cost[0] = 50;	// sloop
				Builds.cost[1] = 250;	// corsair
				Builds.cost[2] = 1000;	// frigate
				Builds.cost[3] = 100;	// station
				Builds.cost[4] = 250;	// ranger
				Builds.cost[5] = 100;	// industry
				Builds.cost[6] = buf.getInt(offset+=4);		// merchant
				Builds.cost[7] = buf.getInt(offset+=4);		// beacon
				Builds.cost[8] = buf.getInt(offset+=4);		// stardock
				Builds.cost[10] = buf.getInt(offset+=4);	// doomsday
				Builds.cost[12] = buf.getInt(offset+=4);	// stelllurae
				Builds.cost[13] = buf.getInt(offset+=4);	// shield
				Builds.cost[14] = 0;
				return true;
			case SESSION_SUSPENDED:
				offset = 2;
				daysTillResume = buf.getInt(offset);
				hoursTillResume = buf.getInt(offset+=4);
				minutesTillResume = buf.getInt(offset+=4);
				secondsTillResume = buf.getInt(offset+=4);
				if (!suspended) {
					suspended = true;
					setState(new gsPassword(true));
				}
				return true;
			case SESSION_RESUME:
				suspended = false;
				setState(new gsPassword());
				return true;
		}
		return false;
	}

//--- tool utilities ---
	void setBounds(Component cp,int x,int y,int w,int h){cp.setBounds(x,y,w,h);}

	void readTop20List(Buffer buf){
	int len;

		len = buf.length();
		for (int i=0;i<20 && 2+i*4<len;i++) {
			top20List[i] = buf.getInt(2+i*4);
			sendEmpireQuery(top20List[i]);
		}
	}

//--- handle chat messages ---
	public int chatCount(){
	int ix,count;
	long time;

		time = System.currentTimeMillis();

		for (count=ix=0;ix<MAX_CHAT;ix++) {
			if (chatTime[ix]>time)	count++;
			else					chatMsg[ix] = null;
		}

		return count;
	}

	public String chatLine(int i){return chatMsg[i];}

	public void chatAdd(Buffer buf){
	String msg;
	int ix;

		msg = "";
		for(ix=2;ix<buf.length();ix++) msg += (char)buf.get(ix);

		for (ix=MAX_CHAT-1;ix>0;ix--) {
			chatMsg[ix] = chatMsg[ix-1];
			chatTime[ix] = chatTime[ix-1];
		}

		chatMsg[0] = msg;
		chatTime[0] = System.currentTimeMillis() + 1000 * 20;
	}

	void drawChatMessages(Graphics g){
	int count;	
	
		SpaceDom.Images[SpaceDom.Chatbar].center(g,250,450);
	
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.setColor(Color.green);
			g.drawString(gsEmpire.name+": "+message,10,492);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(Color.white);
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),10,417+count*15);
		}
	}

	public void showGameStats(Graphics g,int h,int v, Color color){
	Empires emp;
	String name;
	Date date;
	int i;

		g.setColor(color);
		g.drawString("Game Stats",h,v);

		if (statBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		int offset = 2;
		int totalPlanets =						statBuf.getInt(offset);
		int totalEmpires =						statBuf.getInt(offset+=4);
		int totalDarts =						statBuf.getInt(offset+=4);
		int playersOnline =						statBuf.getInt(offset+=4);
		long currentTime =						statBuf.getInt(offset+=4);
		int maxScore =							statBuf.getInt(offset+=4);
		int victoryPercent =					statBuf.getInt(offset+=4);
		int currentHighScore =					statBuf.getInt(offset+=4);
		int currentHighScorePercent =			statBuf.getInt(offset+=4);
		int daysRemaining =						statBuf.getInt(offset+=4);
		int hoursRemaining =					statBuf.getInt(offset+=4);
		int minutesRemaining =					statBuf.getInt(offset+=4);
		int secondsRemaining =					statBuf.getInt(offset+=4);
		int timedGameLength =					statBuf.getInt(offset+=4);
		int lastVicDate =						statBuf.getInt(offset+=4);
		int lastVicTime =						statBuf.getInt(offset+=4);
		int lastVicLength =						statBuf.getInt(offset+=4);
		offset+=4;
		String lastVictor =						statBuf.getString(offset);

		g.drawString("Total Planets = "+totalPlanets,h,v+=22);
		g.drawString("Total Empires = "+totalEmpires,h,v+=15);
		g.drawString("Total StarDarts = "+totalDarts,h,v+=15);
		g.drawString("Players Online = "+playersOnline,h,v+=15);

		g.drawString("Maximum Score = "+maxScore,h,v+=30);
		g.drawString("Winning Score = "+victoryPercent+"% = "+(maxScore / 100) * victoryPercent,h,v+=15);
		g.drawString("Current High Score = "+currentHighScore+" = "+currentHighScorePercent+"%",h,v+=15);

		// time() on server returns seconds, java.util.Date takes milliseconds, multiply by 1000
		g.drawString("Current Time is "+(new SimpleDateFormat("EEE, MMM d, h:mm a, z")).format(new java.util.Date(currentTime*1000)),h,v+=15);

		StringBuffer timeLeft = new StringBuffer();
		if (daysRemaining > 0) {
			timeLeft.append(daysRemaining+" Days ");
		}
		if (hoursRemaining > 0) {
			timeLeft.append(hoursRemaining+" Hours ");
		}
		if (minutesRemaining > 0) {
			timeLeft.append(minutesRemaining+" Minutes ");
		}
		timeLeft.append(secondsRemaining+" Seconds.");
		if (timedGameLength == 0) {
			g.drawString("Estimated Time Remaining is ",h,v+=30);
			g.drawString(timeLeft.toString(),h,v+=15);
		} else {
			g.drawString("Time Remaining is "+timeLeft.toString(),h,v+=15);
		}

		if (lastVicLength==0) return;		// no immortal victor as yet
		g.drawString("Last Immortal Victor <"+lastVictor+" Empire>",h,v+=30);
		date = new Date(lastVicDate,lastVicTime);
		Date date2 = new Date(0,lastVicLength);
		g.drawString(date.toString()+" it took "+date2.lengthStr(),h,v+=15);
	}

	public void showSettings(Graphics g,int h,int v,Color color){
	int i;

		g.setColor(color);
		g.drawString("Server Settings",h+60,v);

		if (setBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		int offset = 2;
		int minWorlds =							setBuf.getInt(offset);
		int maxWorlds =							setBuf.getInt(offset+=4);
		int vicStart =							setBuf.getInt(offset+=4);
		int vicDrop =							setBuf.getInt(offset+=4);
		int gameHours =							setBuf.getInt(offset+=4);
		int timeShiftSessionHours =				setBuf.getInt(offset+=4);
		int timeShiftSkipDays =					setBuf.getInt(offset+=4);
		int command =							setBuf.getInt(offset+=4);
		int commandBonus =						setBuf.getInt(offset+=4);
		int merchantBonus =						setBuf.getInt(offset+=4);
		int merchantBonusType =					setBuf.getInt(offset+=4);
		int beaconBonus =						setBuf.getInt(offset+=4);
		int stardockWorldBonus =				setBuf.getInt(offset+=4);
		int stardockFleetBonus =				setBuf.getInt(offset+=4);
		int shieldBonus =						setBuf.getInt(offset+=4);
		int speed =								setBuf.getInt(offset+=4);
		int maxSpeed =							setBuf.getInt(offset+=4);
		int fleetDecay =						setBuf.getInt(offset+=4);
		int worldDecay =						setBuf.getInt(offset+=4);
		int facilityUpdate =					setBuf.getInt(offset+=4);
		int firstEarthDeclareRatio =			setBuf.getInt(offset+=4);
		int firstPhenomenaDeclareRatio =		setBuf.getInt(offset+=4);
		int laterEarthDeclareRatio =			setBuf.getInt(offset+=4);
		int laterPhenomenaDeclareRatio =		setBuf.getInt(offset+=4);
		int firstHomeDeclareRatio =				setBuf.getInt(offset+=4);
		int firstHomePhenomenaDeclareRatio =	setBuf.getInt(offset+=4);
		offset+=4;

		g.drawString("Possible Worlds - Minimum: "+minWorlds+" and Maximum: "+maxWorlds,h,v+=22);
		if (gameHours != 0){
			g.drawString("Game resets every "+gameHours+" Hours",h,v+=15);
		} else {
			g.drawString("Victory Starts at "+vicStart+"% and Drops 1% Every "+vicDrop+" Hours",h,v+=15);
		}
		if (timeShiftSkipDays > 0) {
			g.drawString("Session lasts "+timeShiftSessionHours+" hours with a "+timeShiftSkipDays+" day pause between sessions",h,v+=15);
		}
		
		g.drawString("Build Points",h,v+=30);
		g.drawString("Starting Command: "+command+" build points.",h,v+=15);
		g.drawString("Command Bonus: "+commandBonus+" build points per Merchant.",h,v+=15);
		if (merchantBonusType == 1) {
			g.drawString("World Bonus: "+(float)merchantBonus / 10F+"% increase to build points per Merchant.",h,v+=15);
		} else {
			g.drawString("World Bonus: "+merchantBonus+" build points per Merchant.",h,v+=15);
		}
		
		g.drawString("Speed",h,v+=30);
		g.drawString("Starting Speed: "+speed,h,v+=15);
		g.drawString("Beacon Bonus: "+beaconBonus+" movement point"+(beaconBonus==1?"":"s")+" per Beacon.",h,v+=15);
		g.drawString("Maximum Speed: "+maxSpeed,h,v+=15);
		
		g.drawString("Decay",h,v+=30);
		g.drawString("Fleet: 1/"+fleetDecay+" Ships Every 10 Seconds",h,v+=15);
		g.drawString("World: 1/"+worldDecay+" Ships Every 10 Seconds",h,v+=15);
		g.drawString("Fleet decay reduced by "+stardockFleetBonus+" for every StarDock",h,v+=15);
		g.drawString("World decay reduced by "+stardockFleetBonus+" for every StarDock",h,v+=15);
		
		g.drawString("Updates",h,v+=30);
		g.drawString("Global Facility Every "+facilityUpdate+" Seconds",h,v+=15);
		
		g.drawString("Declarations",h,v+=30);
		g.drawString("Old Earth First - Worlds: 1/"+firstEarthDeclareRatio+" Phenomena: 1/"+firstPhenomenaDeclareRatio,h,v+=15);
		g.drawString("Old Earth Later - Worlds: 1/"+laterEarthDeclareRatio+" Phenomena: 1/"+laterPhenomenaDeclareRatio,h,v+=15);
		g.drawString("Race Home World - Worlds: 1/"+firstHomeDeclareRatio+" Phenomena: 1/"+firstHomePhenomenaDeclareRatio,h,v+=15);
	}

	final static int MAPW = 50;
	final static Rectangle map = new Rectangle(10,30,2*MAPW,2*MAPW);

	void drawMiniMap(Graphics g){
	int cx,cy,size,x,y,dx,dy;
	Worlds wp;
	Fleets fp;
	Color c;

		g.setColor(Color.black);
		g.fillRect(map.x,map.y,map.width,map.height);

		fp = gsFleet;
		if (fp==null) return;

		cx = fp.xloc();
		cy = fp.yloc();
		dx = map.x + MAPW;
		dy = map.y + MAPW;

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {

			switch (wp.type()) {
				case Worlds.NEBULAE: g.setColor(wp.NEBULAE_COLOR); size = wp.NEBULAE_SIZE; break;
				case Worlds.NEUTRON: g.setColor(wp.NEUTRON_COLOR); size = wp.NEUTRON_SIZE; break;
				case Worlds.GATEWAY:
					x = SpaceDom.cycle;
					c = new Color(
						((x&32)==0?8*(x&31):252-8*(x&31)),
						((x&16)==0?16*(x&15):248-16*(x&15)),
						((x&64)==0?4*(x&63):253-4*(x&63))	
					); 
					size = wp.WORLD_SIZE; 
					break;
				default: g.setColor(Color.white); size = wp.WORLD_SIZE; break;
			}

			x = (wp.xloc()-cx) * MAPW / wp.scale;
			if (x+size<-MAPW || x-size>MAPW) continue;
			y = (wp.yloc()-cy) * MAPW / wp.scale;
			if (y+size<-MAPW || y-size>MAPW) continue;

			size = size * MAPW / wp.scale;
			g.fillOval(dx+x-size,dy+y-size,2*size+1,2*size+1);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {

			if (fp.ghost()) continue;

			x = (fp.xloc()-cx) * MAPW / wp.scale;
			if (x<-MAPW || x>MAPW) continue;
			y = (fp.yloc()-cy) * MAPW / wp.scale;
			if (y<-MAPW || y>MAPW) continue;

			wp = Worlds.get(fp.destID);
			if (wp!=null) {
				g.setColor(Color.blue);
				g.drawLine(dx+x,dy+y,
					dx+(wp.xloc()-cx) * MAPW / wp.scale,
					dy+(wp.yloc()-cy) * MAPW / wp.scale);
			}

			g.setColor(Color.red);
			g.fillRect(dx+x-1,dy+y-2,5,3);
		}

	//--- cut rects ---
		g.setColor(SCREEN_COLOR);
		g.fillRect(0,map.y+map.height,500,400-map.y-map.height);
		g.fillRect(map.x+map.width,0,500-map.x-map.width,map.y+map.height);
		g.fillRect(map.x,0,map.width,map.y);
		g.fillRect(0,0,map.x,map.y+map.height);
	}

//--- common messages ---
	static void sendQuickMessage(int message){
	Buffer buf;

		buf = new Buffer(2);
		buf.set(0,2);
		buf.set(1,message);
		buf.send();
	}

	public static void sendSessionDone(){sendQuickMessage(SESSION_DONE);}

	public static void sendPing(){sendQuickMessage(SESSION_PING);}

	public static void sendTop20Query(){sendQuickMessage(TOP20_QUERY);}

	public static void sendRebirthRequest(){sendQuickMessage(REBIRTH_REQUEST);}

	public static void sendStatsQuery(){sendQuickMessage(STATS_QUERY);}

	public static void sendSettingsQuery(){sendQuickMessage(SETTINGS_QUERY);}

	public static void sendQuit(){sendQuickMessage(QUIT);}

	public static void signalLaunch(){sendFleetMove(-1);}

	public static void sendFleetMove(int dest){
	Buffer buf;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,SET_DESTINATION);
		buf.setShort(2,dest);
		buf.send();
	}

	public static void sendTransfer(int fromFleet, int toFleet, int indexFrom, int indexTo, int count){
	Buffer buf;

		buf = new Buffer(10);
		buf.set(0,10);
		buf.set(1,FLEET_TRANSFER);
		buf.setShort(2,count);
		buf.set(6,fromFleet);
		buf.set(7,indexFrom);
		buf.set(8,toFleet);
		buf.set(9,indexTo);
		buf.send();
	}

	public static void sendChannel(){
	Buffer buf;

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,CHAT_CHANNEL);
		buf.setInt(2,channel);
		buf.send();
	}

	public static void sendMessage(){
	Buffer buf;
	int len;

		len = message.length();
		if (len==0) return;

		if (len>100) {
			message = message.substring(0,100);//all 253
			len = 100;
		}

		buf = new Buffer(len+2);
		buf.set(0,len+2);
		buf.set(1,CHAT_MESSAGE);
		for (int i=0;i<len;i++) buf.set(i+2,message.charAt(i));
		buf.send();
	}

	public static void sendRace(){
	Buffer buf;

		buf = new Buffer(8);
		buf.set(0,8);
		buf.set(1,RACE_CHANGE);
		buf.setInt(4,setRace);
		buf.send();
	}

	public static void sendEmpireQuery(int id){
	Buffer buf;

		if (id<0) return;
		
		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,EMPIRE_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendFleetQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,FLEET_QUERY);
		buf.setShort(2,id);
		buf.send();
	}

	public static void sendWorldQuery(int id){
	Buffer buf;
		
		if (id<0) return;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,WORLD_QUERY);
		buf.setShort(2,id);
		buf.send();
	}
}
