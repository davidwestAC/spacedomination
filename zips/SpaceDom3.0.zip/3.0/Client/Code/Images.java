interface Images {
	public static final int numImages = 23;
	public static final String imageName[] = {
		"Battlebar.jpg",
		"BattleScreen.jpg",
		"Chatbar.jpg",
		"Sidebar.jpg",
		"StarsNear.gif",
		"Ships.gif",
		"Planets.png",
		"Wormhole.gif",
		"Neutron.png",
		"Nebulae.png",
		"WormHole.png",
		"Gateway.png",
		"OldEarth.png",
		"NewEarth.png",
		"Makluvia.png",
		"Kaletia.png",
		"Zorestia.png",
		"Avaria.png",
		"Najunia.png",
		"Cestania.png",
		"Quarethia.png",
		"StarDart.png",
		"Background.jpg"};

	public static final int Battlebar         = 0; 
	public static final int BattleScreen      = 1; 
	public static final int Chatbar           = 2; 
	public static final int Sidebar           = 3; 
	public static final int StarsNear         = 4; 
	public static final int Ships             = 5; 
	public static final int Planets           = 6; 
	public static final int Wormhole          = 7; 
	public static final int Neutron           = 8; 
	public static final int Nebulae           = 9; 
	public static final int WormHole          = 10;
	public static final int Gateway           = 11;
	public static final int OldEarth          = 12;
	public static final int NewEarth          = 13;
	public static final int Makluvia          = 14;
	public static final int Kaletia           = 15;
 	public static final int Zorestia          = 16;
	public static final int Avaria            = 17;
	public static final int Najunia           = 18;
 	public static final int Cestania          = 19;
	public static final int Quarethia         = 20;
	public static final int StarDart          = 21;
	public static final int Background        = 22;
};