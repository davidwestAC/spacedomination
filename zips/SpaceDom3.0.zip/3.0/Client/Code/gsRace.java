import java.awt.*;
import java.applet.*;
import java.lang.Thread;

class gsRace extends GameState {

//--- variables ---
	Button enter;
	CheckboxGroup selectRace;
	Checkbox race0,race1,race2,race3,race4,race5,race6,race7;

//--- shot colors for the various races ---
	static int[] red1   = {171, 153,  69, 255, 200,  53,  20, 190};
	static int[] green1 = { 27,  51,  86, 150, 150, 153, 150, 130};
	static int[] blue1  = { 27, 153, 166, 220,  30,  53, 150,  20};
	static int[] red2   = {255, 255,   0, 100, 255,   0,   0, 255};
	static int[] green2 = {  0,   0,   0,  20, 255, 255, 255, 180};
	static int[] blue2  = {  0, 255, 255, 150,   0,   0, 255,  25};

//--- primary functions ---
	public gsRace(){
		Graphics g;
	}

	public void init(){
		prepareTools();
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

		g.setColor(new Color(0,0,128));
		g.fillRect(0,0,500,500);

		fp = gsFleet;
		
	//--- draw buttons ---
			setBounds(enter,200,230,100,20);
			race0.setBounds(200,60,100,20);
			race1.setBounds(200,80,100,20);
			race2.setBounds(200,100,100,20);
			race3.setBounds(200,120,100,20);
			race4.setBounds(200,140,100,20);
			race5.setBounds(200,160,100,20);
			race6.setBounds(200,180,100,20);
			race7.setBounds(200,200,100,20);

		g.setColor(Color.white);
		g.drawString("After pressing enter, please wait up to ten seconds to enter the game",50,50);
		
		g.setFont(stoutFNT);
		centerStout(g,"Select a Race",250,30);
	}

	void centerStout(Graphics g,String msg,int h,int v){
		g.drawString(msg,h-stoutMET.stringWidth(msg)/2,v);
	}

	public void action(Event e) {
		if (e.target==enter) {
			sendRace();
			try {
				Thread.sleep(6000);
			}
			catch (InterruptedException ie) {
			}
			setState(new gsMovement());
		}
		if (e.target==race0) setRace = 0;
		if (e.target==race1) setRace = 1;
		if (e.target==race2) setRace = 2;
		if (e.target==race3) setRace = 3;
		if (e.target==race4) setRace = 4;
		if (e.target==race5) setRace = 5;
		if (e.target==race6) setRace = 6;
		if (e.target==race7) setRace = 7;
	}
	
//--- tool functions ---
	void prepareTools(){
		root.add(enter = new Button("Enter"));

		selectRace = new CheckboxGroup();		
		root.add(race0 = new Checkbox("Humans",true,selectRace));
		root.add(race1 = new Checkbox("Makluvians",false,selectRace));
		root.add(race2 = new Checkbox("Kaletians",false,selectRace));
		root.add(race3 = new Checkbox("Zorestians",false,selectRace));
		root.add(race4 = new Checkbox("Avarians",false,selectRace));
		root.add(race5 = new Checkbox("Najunians",false,selectRace));
		root.add(race6 = new Checkbox("Cestanians",false,selectRace));
		root.add(race7 = new Checkbox("Quarethians",false,selectRace));
		Color background = new Color(0,0,128);
		race0.setForeground(Color.white);
		race0.setBackground(background);
		race1.setForeground(Color.white);
		race1.setBackground(background);
		race2.setForeground(Color.white);
		race2.setBackground(background);
		race3.setForeground(Color.white);
		race3.setBackground(background);
		race4.setForeground(Color.white);
		race4.setBackground(background);
		race5.setForeground(Color.white);
		race5.setBackground(background);
		race6.setForeground(Color.white);
		race6.setBackground(background);
		race7.setForeground(Color.white);
		race7.setBackground(background);
	}
}