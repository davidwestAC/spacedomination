import java.awt.*;
import java.applet.*;
import java.util.Vector;
import java.util.Hashtable;

class gsPassword extends GameState {
                                               
//--- constants ---
	final static String[][] response = {
		{"Waiting...",null},
		{"Empire Found",null},
		{"Empire Created",null},
		{"Session Denied,","Bad Password"},
		{"Empire Destroyed",null},
		{"Session Denied,","Empire In Play"},
		{"Session Denied,","Records Error, Name too short?"},
		{"Session Denied,","Server Full"},
	};

//--- variables ---
	TextField name,pass;
	Button send,enter,rebirth;
	Button top20,stats,settings;
	Checkbox useSmooth;
	boolean suspended;
	
	final static int SHOW_TOP20 = 0;
	final static int SHOW_STATS = 1;
	final static int SHOW_SETTINGS = 2;

	int status,displayType;
	Buffer statBuf = null;
	Buffer setBuf = null;

	Portrait back;
	public static Portrait fleetIcon[] = null;

//--- primary functions ---
	public gsPassword(){

		status = JOIN_REQUEST;
		displayType = SHOW_TOP20;
		suspended = false;

		gsEmpireID = gsFleetID = -1;
		gsEmpire = null;
		gsFleet = null;

		Fleets.root = null;
		Empires.root = null;
		Worlds.root = null;
		redWorlds = new Hashtable();
		greenWorlds = new Hashtable();
		nearestWorld=null;
		nearestGate=null;
		lastAttacked=null;
		lastCaptured=null;
		activeMarkers=new Vector();

		back = SpaceDom.Images[SpaceDom.Background];
		fleetIcon = new Portrait[8];
		for (int i=0; i<8; i++) {
			fleetIcon[i] = SpaceDom.ships[i][0];
		}
	}

	public gsPassword(boolean suspended){
		this();
		this.suspended = suspended;
	}

	public void init(){
		prepareTools();
		sendTop20Query();
	}

//--- primary functions ---

	public void paint(Graphics g){
//	long time = System.currentTimeMillis();

		g.setFont(textFNT);

		if (SpaceDom.conn==null) {
			g.setColor(Color.black);
			g.fillRect(0,0,SpaceDom.DEFAULT_WIDTH,SpaceDom.DEFAULT_HEIGHT);
			g.setColor(Color.white);
			g.drawString("Server Not Responding...",10,20);
			moveTools(false);
			return;
		}

		moveTools(true);

		//--- regular ---
		back.draw(g,0,0);

		if (suspended) {
			g.setColor(Color.black);
			g.drawString("Game resumes in ",11,16);
			g.drawString(daysTillResume+" days ",11,41);
			g.drawString(hoursTillResume+" hours ",11,56);
			g.drawString(minutesTillResume+" minutes ",11,81);
			g.drawString(secondsTillResume+" seconds",11,106);
			g.setColor(Color.white);
			g.drawString("Game resumes in ",10,15);
			g.drawString(daysTillResume+" days ",11,40);
			g.drawString(hoursTillResume+" hours ",11,55);
			g.drawString(minutesTillResume+" minutes ",11,80);
			g.drawString(secondsTillResume+" seconds",11,105);
			moveTools(false);
		} else {
			g.setColor(Color.black);
			g.drawString("Username:",11,16);
			g.drawString("Password:",11,56);
			g.drawString(response[status][0],6,151);
			g.setColor(Color.white);
			g.drawString("Username:",10,15);
			g.drawString("Password:",10,55);
			g.drawString(response[status][0],5,150);
			if (response[status][1] != null) {
				g.setColor(Color.black);
				g.drawString(response[status][1],6,166);
				g.setColor(Color.white);
				g.drawString(response[status][1],5,165);
			}
			else if (gsEmpireID >= 0) empireInfo(g,5,165);
		}

		switch (displayType) {
			case SHOW_TOP20:
				showTop20List(g,131,16,Color.black);
				showTop20List(g,130,15,Color.white);
				break;
			case SHOW_STATS:
				showGameStats(g,131,16,Color.black);
				showGameStats(g,130,15,Color.white);
				break;
			case SHOW_SETTINGS:
				showSettings(g,131,16,Color.black);
				showSettings(g,130,15,Color.white);
				break;
		}

//		title.center(g,250,450,root);
//	System.out.println("FrameTime="+(System.currentTimeMillis()-time));
	}


	void showTop20List(Graphics g,int h,int v, Color color) {
		Empires emp;
		String name;
		int i;

		g.setColor(color);
		g.drawString("Top 20 List",h+20,v);
		g.drawString("Score",h+120,v);
		g.drawString("Worlds",h+180,v);
		g.drawString("Darts",h+260,v);
		g.drawString("Race",h+330,v);
		v += 2;

		for (i=0;i<20;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			emp = Empires.get(top20List[i]);
			if (emp.online == 1) {
				g.drawString("*",h-10,v+=14);
				g.drawString(""+(i+1)+"> "+name,h,v);
			} else {
				g.drawString(""+(i+1)+"> "+name,h,v+=14);
			}
			g.drawString(""+emp.hiScore,h+120,v);
			g.drawString(""+emp.worlds + "/" + emp.hiWorlds,h+180,v);
			g.drawString(""+emp.darts + "/" + emp.hiDarts,h+260,v);
			int raceid = 0;
			raceid = emp.race();
			if (raceid < 0 || raceid > 7) {
				raceid=0;
			}
			fleetIcon[raceid].center(g,h+345,v-5);
		}
		if (i==0) g.drawString("List Empty",h,v+=14);
	}
	
//-------------------------------------------------------------
	
	void empireInfo(Graphics g,int h,int v) {
		int hb, vb;

		g.setColor(Color.black);
		g.drawString("Empire ID: "+gsEmpireID,h+1,v+1);

		g.setColor(Color.white);
		g.drawString("Empire ID: "+gsEmpireID,h,v);

		if (gsEmpire==null || gsFleet==null) {
			g.setColor(Color.black);
			g.drawString("Waiting for Data",h+1,v+16);
			g.setColor(Color.white);
			g.drawString("Waiting for Data",h,v+=15);
			if (gsEmpire==null) {
				gsEmpire = Empires.get(gsEmpireID);
				g.setColor(Color.black);
				g.drawString("Emp Get = "+gsEmpire,h+1,v+16);
				g.setColor(Color.white);
				g.drawString("Emp Get = "+gsEmpire,h,v+=15);
			} else {
				gsFleetID = gsEmpire.fleetID;
				gsFleet = Fleets.get(gsFleetID);
				g.setColor(Color.black);
				g.drawString("Fleet Get = "+gsEmpire,h+1,v+16);
				g.setColor(Color.white);
				g.drawString("Fleet Get = "+gsEmpire,h,v+=15);
			}
			return;
		}

		vb = v+1;
		hb = h+1;
		g.setColor(Color.black);
		g.drawString("Name: "+gsEmpire.name,hb,vb+=15);
		g.drawString("Score: "+gsEmpire.score+" / "+gsEmpire.hiScore,hb,vb+=15);
		g.drawString("Worlds: "+gsEmpire.worlds+" / "+gsEmpire.hiWorlds,hb,vb+=15);
		g.drawString("Darts: "+gsEmpire.darts+" / "+gsEmpire.hiDarts,hb,vb+=15);
		g.drawString("Squads: "+gsFleet.countSquads(),hb,vb+=15);
		g.drawString("Guns: "+gsFleet.guns(),hb,vb+=15);
		g.setColor(Color.white);
		g.drawString("Name: "+gsEmpire.name,h,v+=15);
		g.drawString("Score: "+gsEmpire.score+" / "+gsEmpire.hiScore,h,v+=15);
		g.drawString("Worlds: "+gsEmpire.worlds+" / "+gsEmpire.hiWorlds,h,v+=15);
		g.drawString("Darts: "+gsEmpire.darts+" / "+gsEmpire.hiDarts,h,v+=15);
		g.drawString("Squads: "+gsFleet.countSquads(),h,v+=15);
		g.drawString("Guns: "+gsFleet.guns(),h,v+=15);
	}


	public void action(Event e) {
		if (e.target==send) sendPetition();
		if (e.target==enter) {
			setState(new gsMovement());
			if (GameState.activeMarkers.isEmpty()) {
				addActiveMarker(new ScreenMarker(0,Color.green));
			}
		}

		if (e.target==top20) {
			sendTop20Query();
			displayType = SHOW_TOP20;
		}
		if (e.target==stats) {
			sendStatsQuery();
			displayType = SHOW_STATS;
		}
		if (e.target==settings) {
			sendSettingsQuery();
			displayType = SHOW_SETTINGS;
		}

		if (e.target==rebirth) sendRebirthRequest();

		if(e.target == useSmooth) {
			GameState.smooth = useSmooth.getState();
		}
	}


	public boolean handleInput(Buffer buf) {

		if (super.handleInput(buf)) return true;

		if (buf!=null) switch (buf.get(1)) {
			case BAD_PASSWORD:
			case EMPIRE_INPLAY:
			case RECORDS_ERROR:
			case SERVER_FULL:
				gsEmpireID = gsFleetID = -1;
				gsEmpire = null;
				gsFleet = null;
				status = buf.get(1);
				return true;
			case SESSION_CREATED:
			case SESSION_GRANTED:
			case EMPIRE_DEAD:
				status = buf.get(1);
				gsEmpireID = buf.getShort(2);
				return true;
			case STATS_RESULT:
				statBuf = buf;
				break;
			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}
		return false;
	}

	public boolean press(int key) {
		switch(key) {
			case 10:	// Enter
				if (name.hasFocus()) {
					pass.requestFocus();
					break;
				}
				if (pass.hasFocus() && !enter.isVisible()) {
					sendPetition();
				}
				if (pass.hasFocus() && enter.isVisible()) {
					setState(new gsMovement());
					if (GameState.activeMarkers.isEmpty()) {
						addActiveMarker(new ScreenMarker(0,Color.green));
					}
				}
				break;
		}
		return false;
	}

//--- tool functions ---
	void prepareTools() {
		root.add(send = new Button("Send"));
		root.add(enter = new Button("Enter"));
		root.add(top20 = new Button("Top20"));
		root.add(stats = new Button("Stats"));
		root.add(settings = new Button("Settings"));
		root.add(rebirth = new Button("Rebirth"));
		root.add(name = new TextField(15));
		root.add(pass = new TextField(15));
		pass.setEchoChar('*');
		root.add(useSmooth = new Checkbox("Smooth"));
		useSmooth.setBackground(Color.black);
		useSmooth.setForeground(Color.white);
		useSmooth.setState(GameState.smooth);
	}

	void moveTools(boolean show) {
		if (show) {
			setBounds(name,10,20,100,20);
			setBounds(pass,10,60,100,20);
			setBounds(send,10,90,100,20);
			setBounds(enter,10,115,100,20);
			setBounds(rebirth,10,115,100,20);
			setBounds(top20,10,325,55,20);
			setBounds(stats,10,350,55,20);
			setBounds(settings,10,375,55,20);
			setBounds(useSmooth,10, 400, 70, 20);

			send.setEnabled(status!=SERVER_FULL);
			enter.setVisible((status==SESSION_CREATED || status==SESSION_GRANTED) && 
							gsEmpire!=null && gsFleet!=null);
			rebirth.setVisible(status==EMPIRE_DEAD);
		} else {
			send.setVisible(false);
			name.setVisible(false);
			pass.setVisible(false);
			enter.setVisible(false);
		}
	}

//--- communications ---
	void sendPetition() {
		Buffer buf;
		String msg;

		if (pass.getText().length() < 4) {
			status = BAD_PASSWORD;
			return;
		}
		if (name.getText().length() < 4) {
			status = RECORDS_ERROR;
			return;
		}

		buf = new Buffer(34);
		buf.set(0,34);
		buf.set(1,JOIN_REQUEST);

		msg = name.getText();
		if (msg.length() > 15) msg = msg.substring(0,15);
		buf.setString(2,msg);

		msg = pass.getText();
		if (msg.length() > 15) msg = msg.substring(0,15);
		buf.setString(18,msg);

		buf.send();
	}
}