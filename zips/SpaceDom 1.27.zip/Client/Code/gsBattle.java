import java.awt.*;
import java.applet.*;

class gsBattle extends GameState {

	static Rectangle[] region = {
		new Rectangle(80,160,80,80),new Rectangle(80,240,80,80),new Rectangle(80,320,80,80),
		new Rectangle(0,130,80,80),new Rectangle(0,210,80,80),new Rectangle(0,290,80,80),

		new Rectangle(250,160,80,80),new Rectangle(250,240,80,80),new Rectangle(250,320,80,80),
		new Rectangle(170,130,80,80),new Rectangle(170,210,80,80),new Rectangle(170,290,80,80),

		new Rectangle(420,160,80,80),new Rectangle(420,240,80,80),new Rectangle(420,320,80,80),
		new Rectangle(340,130,80,80),new Rectangle(340,210,80,80),new Rectangle(340,290,80,80),
	};

	int select=-1,target=-1;

	Button retreat;

	Portrait[][] ships = null;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

//--- constructors ---
	public gsBattle(){
		ships = new Portrait[6][6];
		ships[0][0] = new Portrait("SloopHuman.gif");
		ships[0][1] = new Portrait("CorsairHuman.gif");
		ships[0][2] = new Portrait("FrigateHuman.gif");
		ships[0][3] = new Portrait("StationHuman.gif");
		ships[0][4] = new Portrait("RangerHuman.gif");
		ships[0][5] = new Portrait("StarDart.gif");		
		ships[1][0] = new Portrait("SloopMakluvian.gif");
		ships[1][1] = new Portrait("CorsairMakluvian.gif");
		ships[1][2] = new Portrait("FrigateMakluvian.gif");
		ships[1][3] = new Portrait("StationMakluvian.gif");
		ships[1][4] = new Portrait("RangerMakluvian.gif");
		ships[1][5] = new Portrait("StarDart.gif");	
		ships[2][0] = new Portrait("SloopKaletian.gif");
		ships[2][1] = new Portrait("CorsairKaletian.gif");
		ships[2][2] = new Portrait("FrigateKaletian.gif");
		ships[2][3] = new Portrait("StationKaletian.gif");
		ships[2][4] = new Portrait("RangerKaletian.gif");
		ships[2][5] = new Portrait("StarDart.gif");	
		ships[3][0] = new Portrait("SloopZorestian.gif");
		ships[3][1] = new Portrait("CorsairZorestian.gif");
		ships[3][2] = new Portrait("FrigateZorestian.gif");
		ships[3][3] = new Portrait("StationZorestian.gif");
		ships[3][4] = new Portrait("RangerZorestian.gif");
		ships[3][5] = new Portrait("StarDart.gif");	
		ships[4][0] = new Portrait("SloopAvarian.gif");
		ships[4][1] = new Portrait("CorsairAvarian.gif");
		ships[4][2] = new Portrait("FrigateAvarian.gif");
		ships[4][3] = new Portrait("StationAvarian.gif");
		ships[4][4] = new Portrait("RangerAvarian.gif");
		ships[4][5] = new Portrait("StarDart.gif");
		ships[5][0] = new Portrait("SloopNajunian.gif");
		ships[5][1] = new Portrait("CorsairNajunian.gif");
		ships[5][2] = new Portrait("FrigateNajunian.gif");
		ships[5][3] = new Portrait("StationNajunian.gif");
		ships[5][4] = new Portrait("RangerNajunian.gif");
		ships[5][5] = new Portrait("StarDart.gif");
	}

	public void init(){
		root.add(retreat = new Button("Retreat"));
	}

	public void paint(Graphics g){
	Fleets fp;
	int count;

		g.setColor(Color.black);
		g.fillRect(0,100,500,300);
		g.setColor(Color.blue);
		g.fillRect(0,0,500,100);

		fp = gsFleet;
		drawFleet(g,0,fp.getDefend());
		drawFleet(g,1,fp);
		drawFleet(g,2,fp.getInvade());

		drawSelect(g);

	//--- tools ---
		reshape(retreat,210,80,80,15);

	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(55,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,60,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}
	}

	void drawFleet(Graphics g,int which,Fleets fp){
	Squadron sp;
	int pos,val;
	String msg;

		if (fp==null) return;

		pos = 50 + which * 150;
		g.setColor(Color.white);
		g.drawString(fp.empireName(),pos,30);
		g.drawString("Guns="+fp.guns(),pos,45);

		val = fp.ecm();
		msg = "ECM=" + (val/100) + ".";
		if (val<0) val = -val;
		msg += ((val%100)/10);
		msg += (val%10);
		g.drawString(msg,pos,60);
	
		for (pos=0;pos<Fleets.POS_COUNT;pos++) drawSquad(g,fp,which,pos);
	}


	void drawSquad(Graphics g,Fleets fp,int which,int pos) {
	boolean invade;
	Rectangle r;
	Squadron sp;
	Fleets ep;
	Empires emp;
	int enemy;

		r = region[which*6+pos];
		g.setColor(Color.white);
		g.drawRect(r.x,r.y,r.width,r.height);

		emp = gsEmpire;

		sp = fp.squads(pos);
		if (sp==null || sp.type()==sp.SHIP_TYPES) return;

		if (ships!=null && ships[sp.type()]!=null) {
			ships[emp.race()][sp.type()].center(g,r.x+r.width/2,r.y+r.height/2,root);
		}

	//--- fleet icon, count, damage,timer;
		g.drawString(sp.name(),r.x+10,r.y+20);
		g.drawString(""+sp.count(),r.x+10,r.y+35);
		g.setColor(Color.red);
		g.fillRect(r.x,r.y+r.height-8,sp.damage()*r.width/sp.hits(),4);
		g.setColor(Color.yellow);
		g.fillRect(r.x,r.y+r.height-4,sp.timer()*r.width/20,4);
		
	//--- move actions ---
		if (sp.isDefend()) return;

		if (sp.isRetreat()) {
			drawRetreatArrow(g,r);
			return;
		}

		if (sp.isMoving()){
			drawMoveArrow(g,r,sp.Heading());
			return;
		}

	//--- fire action ---
		invade = sp.TargetInvade();
		ep = (invade?fp.getInvade():fp.getDefend());
		if (ep==null) return;

		sp = ep.findSquad(sp.TargetType());
		if (sp==null) return;

		enemy = (which+(invade?1:-1))*6 + sp.position();
		drawFireArrow(g,which*6+pos,enemy);
	}


	void drawMoveArrow(Graphics g,Rectangle r,int heading){
	int cx,cy;

		switch (heading) {
			case 0:
				g.setColor(Color.yellow);
				cx = r.x + r.width/2;
				cy = r.y;
				g.drawLine(cx,cy-8,cx+8,cy);
				g.drawLine(cx+8,cy,cx-8,cy);
				g.drawLine(cx-8,cy,cx,cy-8);
				break;
			case 1:
				g.setColor(Color.yellow);
				cx = r.x + r.width/2;
				cy = r.y+r.height;
				g.drawLine(cx,cy+8,cx+8,cy);
				g.drawLine(cx+8,cy,cx-8,cy);
				g.drawLine(cx-8,cy,cx,cy+8);
				break;
			case 2:
				g.setColor(Color.yellow);
				cx = r.x;
				cy = r.y+r.height/2;
				g.drawLine(cx-8,cy,cx,cy-8);
				g.drawLine(cx,cy-8,cx,cy+8);
				g.drawLine(cx,cy+8,cx-8,cy);
				break;
			case 3:
				g.setColor(Color.yellow);
				cx = r.x+r.width;
				cy = r.y+r.height/2;
				g.drawLine(cx+8,cy,cx,cy-8);
				g.drawLine(cx,cy-8,cx,cy+8);
				g.drawLine(cx,cy+8,cx+8,cy);
				break;
		}
	}


	void drawRetreatArrow(Graphics g,Rectangle r){
	int x,y;

		x = r.x;
		y = r.y + r.height/2;

		g.setColor(Color.red);
		g.drawLine(x,y-4,x,y+4);
		g.drawLine(x,y+4,x-8,y+4);
		g.drawLine(x-8,y+4,x-8,y+8);
		g.drawLine(x-8,y+8,x-16,y);
		g.drawLine(x-16,y,x-8,y-8);
		g.drawLine(x-8,y-8,x-8,y-4);
		g.drawLine(x-8,y-4,x,y-4);
	}

	void drawFireArrow(Graphics g,int from,int to){
	int sx,sy,dx,dy;
		
		sx = region[from].x+region[from].width/2;
		sy = region[from].y+region[from].height/2;
		dx = region[to].x+region[to].width/2 + (region[to].x>region[from].x?-20:20);
		dy = region[to].y+region[to].height/2 - 10 + (from%3)*10;

		g.setColor(Color.gray);
		g.drawLine(sx,sy-10,dx,dy);
		g.drawLine(sx,sy+10,dx,dy);
	}


	void drawSelect(Graphics g){
	Rectangle rs,rt;
	int cx,cy;

		if (select<0) return;

		rs = region[select];
		g.setColor(Color.red);

		if (select==target) {
			g.drawRect(rs.x,rs.y,rs.width,rs.height);
			return;
		}

		rt = region[target];
		cx = rt.x + rt.width / 2;
		cy = rt.y + rt.height / 2;
		
		g.drawLine(rs.x,rs.y,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y,cx,cy);
		g.drawLine(rs.x,rs.y+rs.height,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y+rs.height,cx,cy);
	}


//--- primary functions ---
	public void action(Event e){
		super.action(e);
		if (e.target==retreat) signalLaunch();
	}

	public void down(int x,int y){
	Fleets fp;
	int i;

		select = target = -1;

		for (i=0;i<12;i++)  if (region[i].inside(x,y)) {
			if (i<6) {
				fp = gsFleet.getInvade();
				if (fp==null || fp.empireID!=gsEmpireID) break;
			}
			select = target = i;
			break;
		}
	}

	public void raise(int x,int y){

		if (target/6==1)	MoveSquad();
		else				TargetSquad();

		target = select= -1;
	}

	public void move(int x,int y){

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}

	public void drag(int x,int y){
	int i;

		for (i=0;i<18;i++)  {
			if (!region[i].inside(x,y)) continue;
			target = i;
			break;
		}
	}

	public boolean handleInput(Buffer buf){
	boolean value;
	Fleets fp;
	Worlds wp;

		fp=null;

		value = super.handleInput(buf);

		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.INDUSTRY) setState(new gsIndustry());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());
		
		return value;
	}

//--- communications ---
	void MoveSquad(){
	int action;
	Buffer buf;

		if (target==select)			action = Squadron.DEFEND;
		else if (target==select-1)	action = Squadron.MOVEUP;
		else if (target==select+1)	action = Squadron.MOVEDOWN;
		else if (target>select)		action = Squadron.MOVELEFT;
		else						action = Squadron.MOVERIGHT;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,SQUAD_ACTION);
		buf.set(2,select-6);
		buf.set(3,action);
		buf.send();
	}


	void TargetSquad(){
	boolean invade;
	Squadron sp;
	Fleets fp;
	Buffer buf;
	int action;

		invade = (target/6==2);	

		fp = gsFleet;
		fp = (invade?fp.getInvade():fp.getDefend());
		if (fp==null) return;

		sp = fp.squads(target%6);
		if (sp==null) return;

		action = Squadron.MakeFireAction(sp.type());

		buf = new Buffer(5);
		buf.set(0,5);
		buf.set(1,SQUAD_ACTION);
		buf.set(2,select-6);
		buf.set(3,action);
		buf.set(4,(invade?1:0));
		buf.send();
	}
}
