//*****************************************************************
//
//		Common Programming Utilities
//			Copyright 1997 Fred's Friends, Inc.
//
//*****************************************************************
#ifndef _FFI_UTILITIES_
#define	_FFI_UTILITIES_

//*****************************************************************

// dates.cpp
extern	void setTodaysDate(void);
extern	int dateToDays(char *date);
extern	void daysToDate(int days,char *date);
extern	int todayToDays(void);
extern	char todayStr[32];

extern	int secondsSinceMidnight(void);

//*****************************************************************
#endif	_FFI_UTILITIES_