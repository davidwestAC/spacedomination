//******************************************************************************
//  Copyright 1998, Fred's Friends, Inc.
//******************************************************************************
import java.awt.*;
import java.net.*;
import java.io.*;
import java.util.*;

public class SpaceDomFrame extends Frame {

	static SpaceDom root;

    public static String server=null;
    public static String artpath=null;
    public static int port=0;

	public SpaceDomFrame(String title,SpaceDom sd,String config){
		super(title);
		root = sd;

		System.out.println("Space Domination Downloadable Version 2.1");
        System.out.println("Loading Config File=["+config+"]");

        try {
            Properties prop = new Properties();
            prop.load(new FileInputStream(config));
            server = prop.getProperty("spacedom.server.address");
            artpath = prop.getProperty("spacedom.artpath");
            port = Integer.parseInt(prop.getProperty("spacedom.server.port"));
        }
        catch (IOException ex){System.err.println("LOAD ERROR: "+ex);}
        catch (NumberFormatException ex){System.err.println("LOAD ERROR: "+ex);}

	}

	public static void main(String args[]) {
	SpaceDomFrame win;
	SpaceDom app;
	Insets edge;

        if (args.length<1 || args[0]==null) {
            System.out.println("Need Name of Properties File as Parameter");
            return;
        }

		app = new SpaceDom();
		app.isApplet = false;

		win = new SpaceDomFrame("Space Domination",app,args[0]);
		win.show();

		edge = win.insets();
		win.resize( edge.left+edge.right+SpaceDom.DEFAULT_WIDTH,
                    edge.top+edge.bottom+SpaceDom.DEFAULT_HEIGHT);
		win.setResizable(false);
		win.add("Center",app);

		app.init();
		app.start();
	}

	public boolean handleEvent(Event e){

		switch (e.id) {

			case Event.WINDOW_MOVED:
				repaint();
				break;

			case Event.WINDOW_DESTROY:
				root.closeConnection();
				dispose();
				System.exit(0);
				return true;
		}

		return super.handleEvent(e);
	}
}

