//************************************************************************
//
//************************************************************************
#ifndef _FFI_MSGQUEUE_
#define	_FFI_MSGQUEUE_
#include "FFItypes.hpp"

#include <stdio.h>

//************************************************************************

class MsgNode {

	private:
		int		length;
		void	*source;
		void	*msg;
		MsgNode *np,*lp;

	public:
		MsgNode(){
			source = NULL;
			length = 0;
			msg = NULL;
			np = lp = NULL;
		}
		MsgNode(void *from,char *message){
			source = from;
			msg = np = lp = NULL;
			setMessage(message);
		}
		~MsgNode(){
			free(msg);
			pop();
		}

		inline void *getMessage(){return msg;}
		inline void *getSource(){return source;}
		inline int getLength(){return length;}
		inline void setNext(MsgNode *next){np=next;}
		inline void setLast(MsgNode *last){lp=last;}
		inline MsgNode *next(){return np;}
		inline MsgNode *last(){return lp;}

		void push(MsgNode *node){
			node->np = np;
			np->lp = node;
			node->lp = this;
			np = node;
		}

	private:
		void setMessage(void *message){
			if (msg!=NULL) free(msg);
			length = ((byte*)message)[0];
			msg = malloc(length);
			if (msg==NULL) return;
			memcpy(msg,message,length);
		}
		void pop(){
			if (np!=NULL) np->lp = lp;
			if (lp!=NULL) lp->np = np;
		}

};

//************************************************************************

class MsgQueue {
	private:
		MsgNode	root;
		int		count;

	public:
		MsgQueue(){
			root.setNext(&root);
			root.setLast(&root);
			count = 0;
		}
		~MsgQueue(){
			while (root.next()!=&root) delete root.next();
		}

		inline bool isEmpty(){return (count==0);}

		void push(void *from,char *message){
			root.push(new MsgNode(from,message));
			count++;
		}
		void *getSource(){
			if (isEmpty()) return NULL;
			return root.last()->getSource();
		}
		int getLength(){
			if (isEmpty()) return -1;
			return root.last()->getLength();
		}
		void *getMessage(){
			if (isEmpty()) return NULL;
			return root.last()->getMessage();
		}
		void pop(){
			if (isEmpty()) return;
			delete root.last();
			count--;
		}
		void clear(){
			while (!isEmpty()) pop();
		}

};

//************************************************************************
#endif _FFI_MSGQUEUE_