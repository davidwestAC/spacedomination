//******************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//******************************************************************************
#ifndef _FFI_SESSIONS_
#define	_FFI_SESSIONS_

#include <winsock.h>
#include <time.h>

//******************************************************************************

class Session;
class SessionList;

extern	SessionList *sroot;
extern	int sessionCount,sessionIndex;

//******************************************************************************

class Session {
	private:
		sockaddr	address;
		int			addrsize,ktime,identity;		// address size, timeout seconds
		MsgQueue	*outq;
		bool		killed;
		void*		uinfo;				// user specific information
		SessionList *box;				// container

	public:
		Session(sockaddr *addr,int size);
		~Session();

		inline	void *info(){return uinfo;}
		inline	void kill(){killed=true;}
		inline	void timer(){ktime=time(NULL);}
		inline	bool cull(int kt){return (killed || kt>ktime);}

		void info(void *ip,int size);
		bool match(sockaddr *addr,int size){
			if (size!=addrsize) return false;
			return (memcmp(&address,addr,8)==0);	// only first 8 bytes are reliable
		}
		void output(void);
		void send(char *msg);

	friend SessionList;
};


class SessionList {
	private:
		Session		*sptr;
		SessionList	*nextp,*lastp;

	public:
		SessionList(){				// head is  (sp==NULL)
			sptr = NULL;
			nextp = lastp = this;
		}
		~SessionList(){
			if (sptr==NULL) {			// head kills entire list
				while (nextp!=this) delete nextp;
			}
			else {
				remove();
				delete sptr;
			}
		}
		inline Session *ssn(){return sptr;}

		void append(Session *sp){
		SessionList *slp;

			slp = new SessionList();
			slp->sptr = sp;
			sp->box = slp;

			lastp->nextp = slp;
			slp->lastp = lastp;
			lastp = slp;
			slp->nextp = this;
		}
		void remove(){
			if (nextp!=this) {
				lastp->nextp = nextp;
				nextp->lastp = lastp;
			}
		}
		SessionList *next(){if (nextp->sptr==NULL) return NULL; return nextp;}

		Session *find(sockaddr *addr,int size){
		SessionList *slp;
		Session *sp;

			slp = nextp;
			while (true) {
				sp = slp->sptr;
				if (sp==NULL) return NULL;
				if (sp->match(addr,size)) return sp;
				slp = slp->nextp;
			}
		}
};

//******************************************************************************
#endif _FFI_SESSIONS_