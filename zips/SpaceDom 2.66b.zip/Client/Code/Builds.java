import java.awt.*;

class Builds {

	public final static int BUILD_PINNACE = 0;
	public final static int BUILD_CORSAIR = 1;
	public final static int BUILD_FRIGATE = 2;
	public final static int BUILD_STATION = 3;
	public final static int BUILD_RANGER = 4;
	public final static int BUILD_INDUSTRY = 5;
	public final static int BUILD_MERCHANT = 6;
	public final static int BUILD_BEACON = 7;
	public final static int BUILD_STARDOCK = 8;
	public final static int BUILD_STELLURAE = 9;
	public final static int BUILD_NOTHING = 10;
	public final static int BUILD_TYPES = 11;

	public final static int MAX_COMMANDS = 10;

	public final static String[] name = {
		"Sloop","Corsair","Frigate",
		"Station","Ranger","Industry",
		"Merchant","Beacon","Stardock",
		"Stellurae",
		"Nothing",
	};

	public final static int[] cost = {50,250,1000,100,250,100,3000,5000,12000,20000};

//--- variables ---
	boolean repeat;
	int type,goal,built;

//--- constructor ---
	public Builds(){
		type = BUILD_NOTHING;
		repeat = false;
		goal = 0;
		built = 0;
	}

	public Builds(Builds bp){
		repeat = bp.repeat;
		type = bp.type;
		goal = bp.goal;
		built = bp.built;
	}

//--- access functions ---
	public boolean repeat(){return repeat;}
	public int type(){return type;}
	public int goal(){return goal;}
	public int built(){return built;}
	public int cost(){return cost[type];}
	public String name(){return name[type];}

	public void setGoal(int val){goal=val;}
	public void flipRepeat(){repeat=!repeat;}
	public void setType(int val){type=val;}

//--- functions ---
	public void copy(Builds bp){
		if (bp==null) return;
		repeat = bp.repeat;
		type = bp.type;
		goal = bp.goal;
		built = bp.built;
	}

	public void set(int pos,Buffer buf){
	int offset;

		offset = 14 + pos * 4;
		repeat = (buf.unsigned(offset+0)!=0);
		type = buf.unsigned(offset+1);
		goal = buf.unsigned(offset+2);
		built = buf.unsigned(offset+3);
	}

};