//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"
#include "Sessions.hpp"
//#include "Worlds.hpp"

//***************************************************************************
//***************************************************************************

int sessionCount=0,sessionIndex=0;
SessionList *sroot=NULL;			// acts as list head

//***************************************************************************

const int TIMEOUT_SECONDS = 60;

SOCKET appSock;

//const int PORT = 1965;

sockaddr ffiAddr = {
	AF_INET,
	//(char)(PORT/256),(char)(PORT&255),
	0,0,
	0,0,0,0,							// automatically becomes local address
	0,0,0,0,0,0,0,0
};

//***************************************************************************

bool createSocket(void);
bool killSocket(void);

bool createSession(SOCKET sock,sockaddr *addr);
Session *FindSession(sockaddr *addr,int size);

void checkSocketInput(void);

void sendClosedMessage(sockaddr *addr,int size,int reason);

//***************************************************************************
//***************************************************************************

bool prepareSockets(void){
WSAData wsad;
int err;

	ffiAddr.sa_data[0] = (char)(portNum/256);
	ffiAddr.sa_data[1] = (char)(portNum&255);

	err = WSAStartup(MAKEWORD(2,0),&wsad);
	if (err!=0) return false;

	if (wsad.wVersion != MAKEWORD(2,0)) return false;

	if (!createSocket()) return false;

	sroot = new SessionList();
	sessionCount = sessionIndex = 0;

	return true;
}


void cleanupSockets(void){
	killSocket();
	if (sroot!=NULL) {delete sroot;sroot=NULL;}
	WSACleanup();
}


void operateSockets(void){
SessionList *slp;
Session *sp;
int killTime;

	checkSocketInput();

//--- operate session list ----
	slp = sroot->next();
	if (slp==NULL) return;

	while (slp!=NULL) {
		sp = slp->ssn();
		if (sp!=NULL) sp->output();
		slp = slp->next();
	}

//--- remove dead & timed out sessions
	killTime = time(NULL) - TIMEOUT_SECONDS;

	slp = sroot;
	while (slp->next()!=NULL) {
		if (slp->next()->ssn()->cull(killTime)) {
			delete slp->next();
			continue;
		}
		slp = slp->next();
	}
}

//***************************************************************************

bool createSocket(){
DWORD arg;

	//memset(&sroot,0,sizeof(sroot));
	//sroot.outQue = new MsgQueue();

	appSock = socket(AF_INET,SOCK_DGRAM,IPPROTO_IP);
	if (appSock==INVALID_SOCKET) return false;

	arg = 1L;

	if (ioctlsocket(appSock,FIONBIO,&arg)==SOCKET_ERROR) {
		printf("IOCTL ERROR=%d\n",WSAGetLastError());
		return false;
	}

/*
	if (ioctlsocket(appSock,FIONBIO,&arg)==SOCKET_ERROR) {
		printf("IOCTL ERROR=%d\n",WSAGetLastError());
		return false;
	}
*/
	if (bind(appSock,&ffiAddr,sizeof(ffiAddr))==SOCKET_ERROR) {
		printf("BIND ERROR=%d\n",WSAGetLastError());
		return false;
	}

	return true;
}


bool killSocket(){
	closesocket(appSock);
	return false;
}

//***************************************************************************

void checkSocketInput(){
char inBuf[BUFFERSIZE];
int result;
Session *ssn;
SOCKADDR addr;

int size;

	while (true) {

		size = sizeof(addr);

		result = recvfrom(appSock,inBuf,BUFFERSIZE,0,(LPSOCKADDR)&addr,&size);
		if (result==SOCKET_ERROR) break;
	   
		ssn = FindSession(&addr,size);
		if (ssn!=NULL) {
			gameQueue->push(ssn,inBuf);
			ssn->timer();
		}
	}
}


Session *FindSession(sockaddr *addr,int size){
Session *sp;

	sp = sroot->find(addr,size);
	if (sp!=NULL) return sp;

//--- server full ---
	if (sessionCount>=maxPlayers) {
		sendClosedMessage(addr,size,mfServerFull);
		return NULL;
	}

//--- not found, create ---	
	sp = new Session(addr,size);
	sroot->append(sp);

	sendStatus(sp,fsDead);	// password screen

	return sp;
}

//***************************************************************************
//		Session Class Code
//***************************************************************************

Session::Session(sockaddr *addr,int size){
	memcpy(&address,addr,size);
	addrsize = size;
	ktime = time(NULL);
	identity = sessionIndex++;
	outq = new MsgQueue();
	killed = false;
	uinfo = NULL;
	box = NULL;

//--- app specific code ---
	{time_t ltime;

		time(&ltime);				// note: ctime ends with '\n'
		printf("\n   ADD SESSION=[%d] %s",identity,ctime(&ltime));
		cmdPrompt();
		sessionCount++;
	}
}

Session::~Session(){
	if (uinfo!=NULL) free(uinfo);
	delete outq;

//--- app specific code ---
	{time_t ltime;

		time(&ltime);				// note: ctime ends with '\n'
		printf("\n   KILL SESSION=[%d] %s",identity,ctime(&ltime));
		cmdPrompt();
		sessionCount--;
	}
}


void Session::info(void *ip,int size){
	if (uinfo!=NULL) free(uinfo);
	if (size==0)	uinfo = NULL;
	else			uinfo = malloc(size);
	if (uinfo!=NULL) memcpy(uinfo,ip,size);
}


void Session::output(){
int result,size;
char *src;

	while (!outq->isEmpty()) {

		src = (char*)outq->getMessage();
		size = outq->getLength();

		result = sendto(appSock,src,size,0,&address,addrsize);

		if (result==SOCKET_ERROR) {
			printf("Send Error=%d\n",WSAGetLastError());
			return;
		}

		outq->pop();
	}

}


void Session::send(char *msg){
	if (msg==NULL || msg[0]==0 || killed) return;
	outq->push(NULL,msg);
}

//***************************************************************************

void sendClosedMessage(sockaddr *addr,int size,int reason){
char buf[2];

	buf[0] = 2;
	buf[1] = (byte)reason;
	sendto(appSock,buf,2,0,addr,size);
}


//***************************************************************************

Session *findEmpireSession(int empireID){
SessionList *slp;
Session *sp;
int *data;

	slp = sroot->next();

	while (true) {
		if (slp==NULL) return NULL;
		sp = slp->ssn();
		if (sp!=NULL) {
			data = (int*)sp->info();
			if (data!=NULL && (*data)==empireID) return sp;
		}
		slp = slp->next();
	}
}


void sessionSetInfo(Session *sp,int empireID,int fleetID){
int data[2];

	if (sp==NULL) return;
	data[0] = empireID;
	data[1] = fleetID;
	sp->info(data,8);
}


bool sessionGetInfo(Session *sp,int *empireID,int *fleetID){

	if (sp==NULL || sp->info()==NULL) return false;
	*empireID = ((int*)sp->info())[0];
	*fleetID = ((int*)sp->info())[1];
	return true;
}


//***************************************************************************
