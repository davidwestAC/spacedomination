//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"

//***************************************************************************
// NOTE: clock() processer ticks since startup - expressed in milliseconds 
//***************************************************************************

void initialize(void);
void cleanup(void);

//***************************************************************************

void main(int argc,char *argv){

	initialize();

	while (true) {

		if (!operateManager()) break;

		operateSockets();
		operateWorlds();
		operateFleets();
		operateSessions();
		operateGameQueue();
		operateCapture();
		operateHappiness();

		Sleep(100);
	}

	cleanup();
}


void ErrorResult(char *msg){
	printf("\nERROR: %s\n",msg);
	exit(-1);
}

//***************************************************************************

void initialize(){
	if (!readInitFile()) ErrorResult("Can't Read Init File");
	if (!prepareGalaxy(minWorlds)) ErrorResult("Failure in Prepare Worlds");
	if (!prepareManager()) ErrorResult("Failure in Prepare Manager");
	if (!prepareGameQueue()) ErrorResult("Failure in Prepare MessageQueue");
	if (!prepareSockets()) ErrorResult("Failure in Prepare Sockets");
}


void cleanup(){
	cleanupSockets();
	cleanupGameQueue();
	cleanupManager();
	cleanupGalaxy();
}

//***************************************************************************



