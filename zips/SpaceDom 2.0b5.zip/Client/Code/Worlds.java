import java.awt.*;

class Worlds {

	static Worlds root = null;

	public final static int NORMAL = 0;

	public final static int HOME = 1;
	public final static int CORE = 2;
	public final static int POOR = 3;
	public final static int RICH = 4;
	public final static int SMALL = 5;
	public final static int LARGE = 6;
	public final static int AQUATIC = 7;
	public final static int MOUNTAIN = 8;
	public final static int DESERT = 9;
	public final static int TUNDRA = 10;
	public final static int JUNGLE = 11;
	public final static int METALLIC = 12;
	public final static int MERCHANT = 13;
	public final static int BEACON = 14;
	public final static int STARDOCK = 15;
	public final static int NEWEARTH = 16;
	public final static int MAKLUVIA = 17;
	public final static int KALETIA = 18;
	public final static int ZORESTIA = 19;
	public final static int AVARIA = 20;
	public final static int NAJUNIA = 21;
	public final static int CESTANIA = 22;
	public final static int QUARETHIA = 23;
	
	public final static int NEBULAE = 24;
	public final static int NEUTRON = 25;
	public final static int GATEWAY = 26;

	public final static int NEBULAE_SIZE = 2000;
	public final static int NEUTRON_SIZE = 1500;
	public final static int WORLD_SIZE = 100;
	public final static Color NEBULAE_COLOR = new Color(64,64,64);
	public final static Color NEUTRON_COLOR = new Color(128,128,64);
	public final static Color WORLD_COLOR = Color.white;
	public final static Color NORMAL_COLOR = Color.white;
	public final static Color HOME_COLOR = Color.blue;
	public final static Color CORE_COLOR = Color.orange;
	public final static Color POOR_COLOR = Color.magenta;
	public final static Color RICH_COLOR = Color.green;
	public final static Color SMALL_COLOR = Color.yellow;
	public final static Color LARGE_COLOR = Color.red;
	public final static Color AQUATIC_COLOR = new Color(40,40,220);
	public final static Color MOUNTAIN_COLOR = new Color(120,70,70);
	public final static Color DESERT_COLOR = new Color(160,140,0);
	public final static Color TUNDRA_COLOR = new Color(50,240,255);
	public final static Color JUNGLE_COLOR = new Color(30,120,40);
	public final static Color METALLIC_COLOR = Color.gray;
	public final static Color MERCHANT_COLOR = new Color(160,0,160);
	public final static Color BEACON_COLOR = new Color(110,30,70);
	public final static Color STARDOCK_COLOR = new Color(160,160,0);

	public static int scale = 2250;

	final static String[] special = {
		"Average",
		"Home World","Core World",
		"Poor","Rich",
		"Small","Large",
		"Aquatic","Mountain",
		"Desert","Tundra",
		"Jungle","Metallic",
		"Merchant","Beacon","Stardock",
		"Home World","Home World","Home World",
		"Home World","Home World","Home World",
		"Home World","Home World",
		"Nebulae","Neutron Star","Gateway",
	};
	
	final static int[] maxInd = {4,6,6,4,4,2,6,4,4,4,4,4,4,4,4,4,6,6,6,6,6,6,6,6,0,0,0};

	public final static String[] happinessname = {
		"Angry","Annoyed","Content",
		"Happy","Ecstatic",
		"Nothing",
	};

	Portrait[] planets = null;
	
	public static boolean graphical = true;

//--- variables ---
	int worldID,x,y,type,empireID,pop,ind,storage;
	int Merchant,maxMerchant,Beacon,maxBeacon,Stardock,maxStardock,Blaster,maxBlaster,sector;
	int pladesium,stenterium,calastium,revidium,frelenium,happiness;
	Builds[] builds;
	String name;
	Worlds next;

//--- constructors ---
	public Worlds(){
		builds = null;
		storage = 0;
		next = null;		
		
		planets = new Portrait[26];
		planets[0] = new Portrait("AverageWorld.jpg");
		planets[1] = new Portrait("OldEarth.jpg");
		planets[2] = new Portrait("CoreWorld.jpg");
		planets[3] = new Portrait("PoorWorld.jpg");
		planets[4] = new Portrait("RichWorld.jpg");
		planets[5] = new Portrait("SmallWorld.jpg");
		planets[6] = new Portrait("LargeWorld.jpg");
		planets[7] = new Portrait("AquaticWorld.jpg");
		planets[8] = new Portrait("MountainWorld.jpg");
		planets[9] = new Portrait("DesertWorld.jpg");
		planets[10] = new Portrait("TundraWorld.jpg");
		planets[11] = new Portrait("JungleWorld.jpg");
		planets[12] = new Portrait("MetallicWorld.jpg");
		planets[13] = new Portrait("MerchantWorld.jpg");
		planets[14] = new Portrait("BeaconWorld.jpg");
		planets[15] = new Portrait("StardockWorld.jpg");
		planets[16] = new Portrait("NewEarth.jpg");
		planets[17] = new Portrait("Makluvia.jpg");
		planets[18] = new Portrait("Kaletia.jpg");
		planets[19] = new Portrait("Zorestia.jpg");
		planets[20] = new Portrait("Avaria.jpg");
		planets[21] = new Portrait("Najunia.jpg");
		planets[22] = new Portrait("Cestania.jpg");
		planets[23] = new Portrait("Quarethia.jpg");
		planets[24] = new Portrait("NebulaeCenter.jpg");
		planets[25] = new Portrait("NeutronCenter.jpg");
	}

	public void init(){
	}

	public boolean isPlanet(){return type<NEBULAE;}
	public boolean isZone(){return (type==NEBULAE || type==NEUTRON);}

	public int worldID(){return worldID;}
	public int xloc(){return x;}
	public int yloc(){return y;}
	public int type(){return type;}
	public int pop(){return pop;}
	public int ind(){return ind;}
	public int maxInd(){return pop*maxInd[type];}
	public String name(){return name;}
	public String special(){return special[type];}
	public int storage(){return storage;}
	public int Merchant(){return Merchant;}
	public int maxMerchant(){return maxMerchant;}
	public int Beacon(){return Beacon;}
	public int maxBeacon(){return maxBeacon;}
	public int Stardock(){return Stardock;}
	public int maxStardock(){return maxStardock;}
	public int Blaster(){return Blaster;}
	public int maxBlaster(){return maxBlaster;}
	public int sector(){return sector;}
	
	public int pladesium(){return pladesium;}
	public int stenterium(){return stenterium;}
	public int calastium(){return calastium;}
	public int revidium(){return revidium;}
	public int frelenium(){return frelenium;}

	public int happiness(){return happiness;}
	public String happinessname(){return happinessname[happiness];}

	public static Worlds start(){return root;} 
	public Worlds next(){return next;}

	public int empireID(){return empireID;}
	public String empireName(){return Empires.findEmpireName(empireID);}


//--- statistics ---
	public void drawField(Graphics g,int cx,int cy){
		if (empireID<0) return;
		switch (type) {
			case NEBULAE: drawNebulaeField(g,cx,cy); break;
			case NEUTRON: drawNeutronField(g,cx,cy); break;
		}
	}


	public void draw(Graphics g,int cx,int cy){
		if (empireID<0) return;
		if (graphical == false){
		switch (type) {
			case NEBULAE: drawNebulae(g,cx,cy); break;
			case NEUTRON: drawNeutron(g,cx,cy); break;
			case GATEWAY: drawGateway(g,cx,cy); break;
			default: drawPlanet(g,cx,cy); break;
			}
		}
		else if (graphical == true){
		switch (type) {
			case NEBULAE: drawNebulae(g,cx,cy); break;
			case NEUTRON: drawNeutron(g,cx,cy); break;
			case GATEWAY: drawGateway(g,cx,cy); break;
			default: drawGraphicalPlanet(g,cx,cy); break;
			}
		}
	}

	
	void drawNebulae(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 300 + (x-cx) * 200 / scale;
		if (dx+NEBULAE_SIZE<100 || dx-NEBULAE_SIZE>500) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+NEBULAE_SIZE<0 || dy-NEBULAE_SIZE>400) return;

		drawStatistics(g,dx,dy);
	}


	void drawNeutron(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 300 + (x-cx) * 200 / scale;
		if (dx+NEUTRON_SIZE<100 || dx-NEUTRON_SIZE>500) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+NEUTRON_SIZE<0 || dy-NEUTRON_SIZE>400) return;

		drawStatistics(g,dx,dy);
	}

	
	void drawNebulaeField(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 200 + (x-cx) * 200 / scale;
		if (dx+NEBULAE_SIZE<0 || dx-NEBULAE_SIZE>400) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+NEBULAE_SIZE<0 || dy-NEBULAE_SIZE>400) return;

		g.setColor(NEBULAE_COLOR);
		rad = NEBULAE_SIZE * 200 / scale;
		
		if (graphical == true) {
			g.drawOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
			planets[24].center(g,dx,dy,GameState.root);
		}
		if (graphical == false) g.fillOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
	}


	void drawNeutronField(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 200 + (x-cx) * 200 / scale;
		if (dx+NEUTRON_SIZE<0 || dx-NEUTRON_SIZE>400) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+NEUTRON_SIZE<0 || dy-NEUTRON_SIZE>400) return;

		g.setColor(NEUTRON_COLOR);
		rad = NEUTRON_SIZE * 200 / scale;
		
		if (graphical == true) {
			g.drawOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
			planets[25].center(g,dx,dy,GameState.root);
		}
		if (graphical == false) g.fillOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
	}


	void drawGateway(Graphics g,int cx,int cy){
	int rad,dx,dy,cycle;
	Color c;


		dx = 300 + (x-cx) * 200 / scale;
		if (dx+WORLD_SIZE<100 || dx-WORLD_SIZE>500) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+WORLD_SIZE<0 || dy-WORLD_SIZE>400) return;

		cycle = StarDart.cycle;
		g.setColor(new Color(
				((cycle&32)==0?8*(cycle&31):252-8*(cycle&31)),
				((cycle&16)==0?16*(cycle&15):248-16*(cycle&15)),
				((cycle&64)==0?4*(cycle&63):253-4*(cycle&63))
			));
		rad = WORLD_SIZE * 200 / scale;
		g.fillOval(dx-rad-3,dy-rad/2,2*rad+7,rad+1);
		g.fillOval(dx-rad/2,dy-rad-3,rad+1,2*rad+7);

		drawStatistics(g,dx,dy);
	}

	void drawPlanet(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 300 + (x-cx) * 200 / scale;
		if (dx+WORLD_SIZE<100 || dx-WORLD_SIZE>500) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+WORLD_SIZE<0 || dy-WORLD_SIZE>400) return;

		if (type == NORMAL) g.setColor(NORMAL_COLOR);
		if (type == POOR) g.setColor(POOR_COLOR);
		if (type == SMALL) g.setColor(SMALL_COLOR);
		if (type == RICH) g.setColor(RICH_COLOR);
		if (type == LARGE) g.setColor(LARGE_COLOR);
		if (type == AQUATIC) g.setColor(AQUATIC_COLOR);
		if (type == MOUNTAIN) g.setColor(MOUNTAIN_COLOR);
		if (type == DESERT) g.setColor(DESERT_COLOR);
		if (type == TUNDRA) g.setColor(TUNDRA_COLOR);
		if (type == JUNGLE) g.setColor(JUNGLE_COLOR);
		if (type == METALLIC) g.setColor(METALLIC_COLOR);
		if (type == MERCHANT) g.setColor(MERCHANT_COLOR);
		if (type == BEACON) g.setColor(BEACON_COLOR);
		if (type == STARDOCK) g.setColor(STARDOCK_COLOR);
		if (type == CORE) g.setColor(CORE_COLOR);
		if (type == HOME || type >= NEWEARTH && type <= QUARETHIA) g.setColor(HOME_COLOR);
		
		rad = WORLD_SIZE * 200 / scale;
		g.fillOval(dx-rad,dy-rad,2*rad+1,2*rad+1);

		if (empireID==GameState.gsEmpireID) {
			g.setColor(Color.yellow);
			drawFlag(g,dx+6,dy-12);
		}
		else if (empireID>0){
			g.setColor(Color.cyan);
			drawFlag(g,dx+6,dy-12);
		}

		drawStatistics(g,dx,dy);
	}

	void drawGraphicalPlanet(Graphics g,int cx,int cy){
	int rad,dx,dy;

		dx = 300 + (x-cx) * 200 / scale;
		if (dx+WORLD_SIZE<100 || dx-WORLD_SIZE>500) return;
		dy = 200 + (y-cy) * 200 / scale;
		if (dy+WORLD_SIZE<0 || dy-WORLD_SIZE>400) return;
		
		planets[type].center(g,dx,dy,GameState.root);

		if (empireID==GameState.gsEmpireID) {
			g.setColor(Color.yellow);
			drawFlag(g,dx+6,dy-12);
		}
		else if (empireID>0){
			g.setColor(Color.cyan);
			drawFlag(g,dx+6,dy-12);
		}

		drawStatistics(g,dx,dy);
	}

	void drawFlag(Graphics g,int x,int y){
	int[] xp = {0,12,0};
	int[] yp = {-5,0,5};

		for (int i=0;i<3;i++) {
			xp[i] += x;
			yp[i] += y;
		}
		if (graphical==true) g.drawPolygon(xp,yp,3);
		if (graphical==false) g.fillPolygon(xp,yp,3);
	}


	void drawStatistics(Graphics g,int dx,int dy){
		if (this==gsMovement.selectWorld) {
			g.setColor(Color.cyan);
			g.drawOval(dx-11,dy-11,23,23);
		}
        if (name!=null) {
		    g.setColor(Color.black);
		    g.drawString(name,dx+13,dy+7);
		    g.setColor(Color.red);
		    g.drawString(name,dx+12,dy+6);
        }
	}

//--- functions ---
	public static void add(Buffer buf){
	Worlds temp,wp;
	boolean found;
	int id;

		id = buf.getInt(2);
		wp = get(id);

		found = (wp!=null);
		temp = (found?wp:new Worlds());

//		temp.worldID = id;

		temp.x = buf.getInt(6);
		temp.y = buf.getInt(10);
		temp.type = buf.getInt(14);
		temp.pop = buf.getInt(18);
		temp.maxMerchant= buf.getInt(22);
		temp.maxBeacon = buf.getInt(26);
		temp.maxStardock = buf.getInt(30);
		temp.maxBlaster = buf.getInt(34);
		temp.sector = buf.getInt(38);
		temp.worldID = buf.getInt(42);
		
		temp.pladesium = buf.getInt(46);
		temp.stenterium = buf.getInt(50);
		temp.calastium = buf.getInt(54);
		temp.revidium = buf.getInt(58);
		temp.frelenium = buf.getInt(62);
		temp.happiness = buf.getInt(66);

		temp.name = buf.getString(70);

		if (found) remove(temp);
		insert(temp);

		/*if (temp.x<-scale) scale = -temp.x;
		if (temp.x>scale) scale = temp.x;
		if (temp.y<-scale) scale = -temp.y;
		if (temp.y>scale) scale = temp.y;*/
	}

	public static void scan(Buffer buf){
	Worlds temp,wp;
	int id,length,ix;

	//--- check against list ---
		length = buf.length()-12;
		temp = root;

		while (temp!=null) {

			for (ix=2;ix<=length;ix+=12) {
				id = buf.getInt(ix);
				if (id==temp.worldID) break;
			}

			if (ix<=length){
				temp.empireID = buf.getInt(ix+4);
				temp.ind = buf.getInt(ix+8);
				buf.setInt(ix,-1);
			}

			temp = temp.next;
		}

	//--- add new ones to list ---
		for (ix=2;ix<=length;ix+=12) {
			id = buf.getInt(ix);
			if (id<0) continue;

			wp = new Worlds();
			wp.worldID = id;
			wp.empireID = buf.getInt(ix+4);
			wp.ind = buf.getInt(ix+8);
			wp.x = wp.y = wp.type = wp.pop = wp.storage = 0;
			insert(wp);
		}

	//--- query names for the unknowns ---
		wp = root;
		while (wp!=null) {
			if (wp.pop==0) GameState.sendWorldQuery(wp.worldID);
			wp = wp.next;
		}
	}

	public static Worlds get(int testID){
	Worlds wp;

		wp = root;
		while (wp!=null) {
			if (wp.worldID==testID) break;
			wp = wp.next;
		}
		return wp;
	}

	public static Worlds find(int mx,int my){
	Rectangle scan;
	Worlds wp;

		scan = new Rectangle(mx-10*scale/200,my-10*scale/200,20*scale/200,20*scale/200);
		wp = root;

		while (wp!=null) {
			if (scan.inside(wp.x,wp.y)) break;
			wp = wp.next;
		}
		return wp;
	}

//--- build functions ---
	public static void build(Buffer buf){
	Worlds wp;
	int i;

		wp = get(buf.getInt(2));
		if (wp==null) {
			GameState.sendWorldQuery(buf.getInt(2));
			return;
		}

		wp.ind = buf.getInt(6);
		wp.storage = buf.getInt(10);

		if (wp.builds==null) {
			wp.builds = new Builds[Builds.MAX_COMMANDS];
			for (i=0;i<Builds.MAX_COMMANDS;i++) wp.builds[i] = new Builds();
		}

		for (i=0;i<Builds.MAX_COMMANDS;i++) wp.builds[i].set(i,buf);
		
		wp.Merchant = buf.getInt(54);
		wp.Beacon = buf.getInt(58);
		wp.Stardock = buf.getInt(62);
		wp.Blaster = buf.getInt(66);
	}

	public Builds builds(int i){
		if (builds==null) return null;
		return builds[i];
	}

//--- private functions ---
// NOTE: keep worlds ordered so that Nebulae are first, Neutrons second, then regular worlds.
	static void insert(Worlds wp){
	Worlds temp;

	//--- put at top of list ---
		wp.next = root;
		root = wp;
		if (!root.sort()) return;

		temp = root;
		root = temp.next;
		temp.next = root.next;
		root.next = temp;
		
	//--- list sort ---
		temp = root;

		while (wp.sort()) {
			temp.next = wp.next;
			wp.next = temp.next.next;
			temp.next.next = wp;
			temp = temp.next;
		}
	}

	static void remove(Worlds wp){
	Worlds temp;

		if (root==wp) {
			root = wp.next;
			return;
		}

		temp = root;
		while (temp.next!=null) {
			if (temp.next==wp) {
				temp.next = wp.next;
				return;
			}
			temp = temp.next;
		}
	}

	boolean sort(){
		if (next==null) return false;
		if (type==NEBULAE) return false;
		if (type==NEUTRON && next.type()!=NEBULAE) return false;
		return (!next.isPlanet());
	}
};