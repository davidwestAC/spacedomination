import java.awt.*;

class Fleets {

	public final static int WAITING = 0;
	public final static int MOVING = 1;
	public final static int NEBULAE = 2;
	public final static int NEUTRON = 3;
	public final static int BATTLE = 4;
	public final static int INDUSTRY = 5;
	public final static int DEAD = 6;

	public final static int POS_COUNT = 6;

	static Fleets root;

//--- variables ---
	int	fleetID,x,y,empireID,destID,ecm;
	int invadeID,defendID;
	int Beacon,moveSpeed,Stardock;
	boolean updated;
	Squadron[] squads;
	Fleets next;

//--- constructors ---
	public Fleets() {
		squads = null;
		next = null;
	}

	public String toString(){return empireName();}

	public int fleetID(){return fleetID;}
	public int xloc(){return x;}
	public int yloc(){return y;}
	public int empireID(){return empireID;}
	public int destID(){return destID;}
	public int ecm(){return ecm;}
	public int Beacon(){return Beacon;}
	public int moveSpeed(){return moveSpeed;}
	public int Stardock(){return Stardock;}

	public static Fleets start(){return root;}
	public Fleets next(){return next;}

	public void setDest(int worldID){destID=worldID;}
	public String name(){return Empires.findName(empireID);}
	public String empireName(){
	Worlds wp;
		if (destID==fleetID) {
			wp = Worlds.get(fleetID);
			if (wp!=null) return wp.name+" Guard";
		}
		return Empires.findEmpireName(empireID);
	}

	public boolean engaged(){return (invadeID>=0 || defendID>=0);}
	public Fleets getInvade(){return root.get(invadeID);}
	public Fleets getDefend(){return root.get(defendID);}

	public boolean ghost(){return !updated;}

//--- draw functions ---
	void drawStats(Graphics g,int x,int y,int w,int h){
	Squadron sp;
	int i,v;

		v = y + 5;

//		g.setColor(Color.green);
//		g.fillRect(x,v=y,w,h);
		g.setColor(Color.white);
		g.drawString(empireName(),x+5,v+=12);
		if (squads!=null) for (i=0;i<POS_COUNT;i++) {
			sp = squads[i];
			if (sp.type()==sp.SHIP_TYPES) continue;
			g.drawString(sp.name()+" "+sp.count(),x+5,v+=15);//x+15
		}
		g.drawString("Guns="+guns(),x+5,v+=15);
	}

//--- functions ---
	public static void add(Buffer buf){
	Fleets temp,fp;
	int id;

		id = buf.getInt(2);
		fp = root.get(id);

		temp = (fp!=null?fp:new Fleets());

		temp.fleetID = id;
		temp.x = buf.getInt(6);
		temp.y = buf.getInt(10);
		temp.destID = buf.getInt(14);
		temp.empireID = buf.getInt(18);
		temp.Beacon = buf.getInt(22);
		temp.moveSpeed = buf.getInt(26);
		temp.Stardock = buf.getInt(30);
		temp.updated = true;

		if (fp==null) root.insert(temp);
	}

	public static void scan(Buffer buf){
	Fleets temp,fp;
	int id,ix,length;

	//--- update current list ---
		temp = root;
		length = buf.length()-10;

		while (temp!=null) {

			for (ix=2;ix<=length;ix+=20) {
				id = buf.getInt(ix);
				if (temp.fleetID==id) break;
			}

			if (ix<=length) {
				temp.x = buf.getInt(ix+4);
				temp.y = buf.getInt(ix+8);
				temp.destID = buf.getInt(ix+12);
				temp.empireID = buf.getInt(ix+16);
				buf.setInt(ix,-1);
				temp.updated = true;
			}
			else temp.updated = false;

			temp = temp.next;
		}

	//--- add new ones to list ---
		for (ix=2;ix<=length;ix+=20) {
			id = buf.getInt(ix);
			if (id<0) continue;

			fp = new Fleets();
			fp.fleetID = id;
			fp.x = buf.getInt(ix+4);
			fp.y = buf.getInt(ix+8);
			fp.destID = buf.getInt(ix+12);
			fp.empireID = -1;
			fp.ecm = fp.invadeID = fp.defendID = 0;
			fp.squads = null;
			fp.updated = true;

			insert(fp);
		}
	}

	public String destName(){
	Worlds wp;
	Fleets fp;

		wp = Worlds.get(destID);
		if (wp!=null) return wp.name();
		fp = Fleets.get(destID);
		if (fp!=null) return fp.name();
		return null;
	}


	public static Fleets get(int testID){
	Fleets temp;

		temp = root;
		while (temp!=null) {
			if (temp.fleetID==testID) return temp;
			temp = temp.next;
		}
		return null;
	}


	public static Fleets find(int mx,int my){
	Rectangle scan;
	Fleets fp;

		scan = new Rectangle(
			mx-10*Worlds.scale/200,my-10*Worlds.scale/200,
			20*Worlds.scale/200,20*Worlds.scale/200);
		fp = root;

		while (fp!=null) {
			if (scan.inside(fp.x,fp.y)) break;
			fp = fp.next;
		}
		return fp;
	}

//--- squad functions ---
	public static void combat(Buffer buf){
	Fleets fp;
	int i;

		fp = get(buf.getInt(2));
		if (fp==null) {
			GameState.sendFleetQuery(buf.getInt(2));
			return;
		}

		fp.ecm = buf.getInt(6);
		fp.defendID = buf.getInt(10);
		fp.invadeID = buf.getInt(14);

		if (fp.squads==null) {
			fp.squads = new Squadron[POS_COUNT];
			for (i=0;i<POS_COUNT;i++) fp.squads[i] = new Squadron(i);
		}

		for (i=0;i<POS_COUNT;i++) fp.squads[i].set(i,buf);
	}

	public int guns(){
	int guns,i;

		if (squads==null) return 0;
		for (guns=i=0;i<POS_COUNT;i++) {
			if (squads[i]==null) continue;
			guns += squads[i].guns();
		}
		return guns;
	}

	public Squadron squads(int index){
		if (squads==null) return null;
		return squads[index];
	}

	public Squadron findSquad(int type){
	int i;

		if (squads==null) return null;
		for (i=0;i<POS_COUNT;i++) if (squads[i].type()==type) return squads[i];
		return null;
	}

	public int countSquads(){
	int num,i;

		if (squads==null) return 0;
		for (num=i=0;i<POS_COUNT;i++) {
			if (squads[i]!=null && squads[i].type!=Squadron.SHIP_TYPES) num++;
		}
		return num;
	}

//--- private functions ---
	static void insert(Fleets temp){
		temp.next = root;
		root = temp;
	}
};