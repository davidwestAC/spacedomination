//********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//********************************************************************
#include "string.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//********************************************************************
// most string functions ignore '\r' completely
//********************************************************************

inline char upper(char c) {
	if (c>='a' && c<='z') return c-'a'+'A';
	return c;
}


char *clone(char *s){
char *tmp;

	if (s==NULL) return NULL;
	tmp = (char*)malloc(strlen(s)+1);
	if (tmp==NULL) return NULL;
	strcpy(tmp,s);
	return tmp;
}



void clone(char **buf,char *s){
	if (*buf!=NULL) free(*buf);

	if (s==NULL) buf = NULL;
	else {
		*buf = (char*)malloc(strlen(s)+1);
		if (*buf!=NULL) strcpy(*buf,s);
	}
}

//********************************************************************
//NOTE: strings must be identical including the terminator
bool equals(char *s1,char *s2){
int ix;

	if (s1==NULL && s2==NULL) return true;
	if (s1==NULL || s2==NULL) return false;

	for (ix=0;s1[ix]!=0 && s2[ix]!=0;ix++)
		if (s1[ix]!=s2[ix]) return false;

	return (s1[ix]==s2[ix]);
}

//NOTE: strings must be identical including the terminator
bool equalsCI(char *s1,char *s2){
int ix;

	if (s1==NULL && s2==NULL) return true;
	if (s1==NULL || s2==NULL) return false;

	for (ix=0;s1[ix]!=0 && s2[ix]!=0;ix++)
		if (upper(s1[ix])!=upper(s2[ix])) return false;

	return (s1[ix]==s2[ix]);
}

//NOTE: strings must be identical before the first terminator
bool match(char *s1,char *s2){
int ix;

	for (ix=0;s1[ix]!=0 && s2[ix]!=0;ix++)
		if (s1[ix]!=s2[ix]) return false;

	return (s2[ix]==0);
}


bool matchCI(char *s1,char *s2){
int ix;

	for (ix=0;s1[ix]!=0 && s2[ix]!=0;ix++)
		if (upper(s1[ix])!=upper(s2[ix])) return false;

	return (s2[ix]==0);
}

//********************************************************************

int search(char *area,char *find){
int ix,fx;

	if (area==NULL || area[0]==0) return -1;
	if (find==NULL || find[0]==0) return 0;

	for (fx=ix=0;area[ix]!=0;ix++) {
		if (area[ix]=='\r') continue;
		if (area[ix]!=find[fx]) {
			if (fx>0) ix=ix+1-fx;	// back to start...
			fx = 0;
		}
		else if (find[++fx]==0) break;
	}

	if (area[ix]==0) {
		if (find[fx]==0) return ix;
		return -1;
	}

	return ix+1;
}


int searchCI(char *area,char *find){
int ix,fx;

	if (area==NULL || area[0]==0) return -1;
	if (find==NULL || find[0]==0) return 0;

	for (fx=ix=0;area[ix]!=0;ix++) {
		if (area[ix]=='\r') continue;
		if (upper(area[ix])!=upper(find[fx])) {
			if (fx>0) ix=ix+1-fx;	// back to start...
			fx = 0;
		}
		else if (find[++fx]==0) break;
	}

	if (area[ix]==0) {
		if (find[fx]==0) return ix;
		return -1;
	}

	return ix+1;
}

//********************************************************************

int readToken(char *area,char *work,char stop){
int ix,dx;
char c;

	for (dx=ix=0;true;ix++) {
		c = area[ix];
		if (c==stop) break;
		if (c==0 || c=='\n') {
			if (stop=='\n') break;
			return -1;
		}
		if (c=='\r') continue;
		work[dx++] = c;
	}

	work[dx] = 0;
	return ix+1;		// skip the stop character
}


int dcToken(char *area,char *work){
int ix;
char c;

	for (ix=0;true;ix++) {
		c = area[ix];
		if (c=='|' || c=='}') break;
		if (c==0 || c=='\n') return -1;
		if (c=='\r') continue;
		work[ix] = c;
	}

	work[ix] = 0;
	return ix+1;		// skip the stop character
}


int readNumber(char *area,int *val){
int ix,num;
char c;

	*val = 0;

	for (ix=0;true;ix++) {
		c = area[ix];
		if (c==0 || c=='\n') return -1;
		if (c>='0' && c<='9') break;
	}

	for (num=0;true;ix++){
		c = area[ix];
		if (c<'0' || c>'9') break;
		num = num * 10 + (c-'0');
	}

	*val = num;
	return ix;
}

//********************************************************************

#define	thousand	1000L
#define	million		(1000L*thousand)
#define	billion		(1000L*million)

void bigNumber(char *str,int num){
float div;

	if (num>billion) {
		div = (float)num/billion;
		if (div<10) sprintf(str,"%.1fb",div);
		else		sprintf(str,"%.0fb",div);
	}
	else if (num>million) {
		div = (float)num/million;
		if (div<10) sprintf(str,"%.1fm",div);
		else		sprintf(str,"%.0fm",div);
	}
	else if (num>thousand) {
		div = (float)num/thousand;
		if (div<10) sprintf(str,"%.1fk",div);
		else		sprintf(str,"%.0fk",div);
	}
	else {
		sprintf(str,"%d",num);
	}
}

//*****************************************************************
