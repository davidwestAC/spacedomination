//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#ifndef _SD_WORLDS_
#define	_SD_WORLDS_

#include "FFItypes.hpp"
#include "CRecords.hpp"

//**********************************************************************************

const int MAXBUILD = 10;		// number of build commands

const int MAXNAMESIZE = 16;
const int MAXMAILSIZE = 32;

const int MAXDIST = 2000;
const int MINDIST = 1000;

const int SCAN_SIZE = 2250;
const int NEBULAE_SIZE = 2000;
const int NEUTRON_SIZE = 1500;

//const int ATTRITION = 200;
//const int VICTORY_PERCENT = 50;		// 50% is good
//const int pixelsPerSecond = 150;	// movement factor
//const int COMMAND_BONUS = 1000;		// + 1000 build points when fleet at world
//const int RESET_WORLDS_PER_EMPIRE = 10;

//**********************************************************************************

enum ShipTypes {
	stPinnace,stCorsair,stFrigate,
	stStation,stRanger,stStarDart,
	stCOUNT
};

enum BuildTypes {
	btPinnace,btCorsair,btFrigate,
	btStation,btRanger,btIndustry,
	btMerchant,btBeacon,btStardock,
	btCOUNT
};

enum RaceTypes {
	rtHuman,rtMakluvian,rtKaletian,
	rtZorestian,rtAvarian,rtNajunian,
	rtCestanian,rtQuarethian,
	rtCOUNT
};

const int guns[stCOUNT] = {2,10,40,4,10,5000};					// remember dmg = ushort
const int max[stCOUNT] = {62500,12500,3125,31250,12500,1000};
const int cost[btCOUNT] = {100,500,2000,200,500,100,3000,5000,8000};
const int ecm[stCOUNT] = {0,0,0,2,6,1000};

const int FireTimer[stCOUNT] = {6,8,12,8,8,18};
const int FastFireTimer[stCOUNT] = {5,7,11,7,7,16};

const int MoveTimer[stCOUNT] = {4,6,8,8,6,12};
const int FastMoveTimer[stCOUNT] = {3,5,6,6,3,8};

const int RetreatTimer[stCOUNT] = {4,5,6,6,5,8};
const int FastRetreatTimer[stCOUNT] = {2,3,4,4,3,5};

const int attack[stCOUNT][stCOUNT] = {		 // 1 minute * power / timer = constant
	{6,3,9,6,4,6},			// pinnace	60 * 6 / 4 = 90 
	{13,9,5,9,9,9},			// corsair	60 * 9 / 6 = 90
	{6,18,12,12,18,12},		// frigate	60 * 12 / 8 = 90
	{10,10,10,10,10,5},		// station	60 * 10 / 6 = 100
	{12,8,8,8,8,8},			// ranger	60 * 8 / 6 = 80
	{30,30,30,45,30,30},	// stardart	60 * 30 / 12 = 150
};

//**********************************************************************************

enum WorldType {
	wtNormal,

	wtHome,			// homeworld rich+large+2*strong
	wtCore,			// homeworld rich+strong
	wtPoor,			// population generates less bp
	wtRich,			// population generates more bp
	wtSmall,		// supports less industry
	wtLarge,		// supports more industry
	wtAquatic,		// build sloops faster
	wtMountain,		// build rangers faster
	wtDesert,		// build frigates faster
	wtTundra,		// build corsairs faster
	wtJungle,		// build stations faster
	wtMetallic,		// build industry faster

	wtMerchant,		// build build bonus faster and higher max build bonus
	wtBeacon,		// build speed bonus faster and higher max speed bonus
	wtStardock,		// build decay bonus faster and higher max decay bonus

	wtNewEarth,
	wtMakluvia,
	wtKaletia,
	wtZorestia,
	wtAvaria,
	wtNajunia,
	wtCestania,
	wtQuarethia,

	wtNebulae,		// radius 60, slow movement
	wtNeutron,		// radius 45, fast movement
	wtGateway,		// xfer from spot to spot
	wtCOUNT
};
inline bool isPlanet(int type){return (type<wtNebulae);}
inline bool isNormalPlanet(int type){return (type<wtNewEarth && type>wtCore);}
inline bool isPhenomena(int type){return (type>=wtNebulae);}

enum EngageSide {sideDefend,sideInvade,sideCOUNT};

enum SquadPosition {
	posInvadeTop,posInvadeMid,posInvadeBot,
	posDefendTop,posDefendMid,posDefendBot,
	posCOUNT
};
inline bool isDefendPosition(int pos){return pos>=posDefendTop;}
inline bool isInvadePosition(int pos){return pos<posDefendTop;}

enum SquadActions {
	actDefend,actRetreat,
	actMoveUp,actMoveDown,actMoveLeft,actMoveRight,
	actFirePinnace,actFireCorsair,actFireFrigate,
	actFireStation,actFireRanger,actFireStarDart,
	actCOUNT
};

inline int ReadHeading(int act){return (act-actMoveUp);}
inline int ReadType(int act){return (act-actFirePinnace);}
inline int MakeFireAction(int type){return (actFirePinnace+type);}

inline bool illegalAction(int action){return (action>=actCOUNT);}
inline bool isDefendAction(int action){return (action==actDefend);}
inline bool isRetreatAction(int action){return (action==actRetreat);}
inline bool isMoveAction(int action){return (action>=actMoveUp && action<actFirePinnace);}
inline bool isFireAction(int action){return (action>=actFirePinnace && action<=actCOUNT);}


enum FleetStatus {
	fsWaiting,
	fsMoving,fsNebulae,fsNeutron,
	fsBattle,fsIndustry,
	fsDead,
	fsCOUNT
};

inline bool isMoveState(int state){return (state>fsWaiting && state<fsBattle);}

//**********************************************************************************

// empireRec Size = 2 * MAXNAMESIZE + MAXMAILSIZE + 5*4 = 84
class empireRec {
public:
	char	name[MAXNAMESIZE];
	int		fleetID,channel,ruler,race;
	int		worlds,darts,score,hiWorlds,hiDarts,hiScore;
	char	pass[MAXNAMESIZE];
	char	email[MAXMAILSIZE];
	int		Merchant;
	int		Beacon;
	int		Stardock;
	bool	changedRace;
};

// battleGrp Size = 7 -> 8
class squadRec {
public:
	ushort 	count;
	byte	type,action,timer,enemy;
	ushort  damage;
};

// fleetRec Size = 5 * 4 + epCOUNT * 4 + stCOUNT * bgSize = 76
class fleetRec {
public:
	int			xloc,yloc,destID,empireID,status;
	int			engageID[sideCOUNT];		// engaged fleet ID's
	int			ecm,guns;
	squadRec	squad[posCOUNT];
	int			Beacon;
	int			moveSpeed;
	int			Stardock;
};

// buildCmd Size = 4
class buildCmd {
public:
	bool	repeat;					// re-posts command to end of queue when finished
	byte	type,goal,built;
};

// worldRec Size = 9 * 4 + MAXNAMESIZE + MAXBUILD * bcSize = 88
// worldScan Size = 3 * 4 + MAXNAMESIZE = 28
// first section of fleets correspond to worlds 1:1
class worldRec {
public:
	int			xloc,yloc,type,pop;
	char		name[MAXNAMESIZE];					// world name
	int			empireID,ind,storage;
	buildCmd	cmd[MAXBUILD];
	int			Merchant;
	int			maxMerchant;
	int			Beacon;
	int			maxBeacon;
	int			Stardock;
	int			maxStardock;
	int			sector;
	int			worldID;
	int			pladesium;
	int			stenterium;
	int			calastium;
	int			revidium;
	int			frelenium;
};

class victoryRec {
public:
	int		date,time;		// day + seconds when victory was recorded- see todayToDays
	int		score,worlds,darts,race;
	int		maxScore,maxWorlds,maxDarts,gameLength;
	char	name[MAXNAMESIZE];

	inline  int getDate(){return date;}
	inline  int getTime(){return time;}

};

//**********************************************************************************

typedef enum MessageToServer {
	msJoinRequest	= 0x00,
	msTop20Query	= 0x08,
	msAskForStats	= 0x0a,
	msRebirth		= 0x0d,
	msSessionDone	= 0x0e,
	msSessionPing	= 0x0f,

	msChatMessage	= 0x10,
	msChatChannel	= 0x11,

	msQueryEmpire	= 0x28,
	msQueryWorld	= 0x29,
	msQueryFleet	= 0x2a,

	msProbe			= 0x30,
	msScout			= 0x31,
	msFleetMove		= 0x40,

	msSquadAction	= 0x59,

	msBuildCommand	= 0x60,
	msFleetTransfer = 0x61,

	msRaceChange	= 0x70,

	msRestart		= 0x80,
};


typedef enum MessageToFront {
	mfSessionGranted	= 0x01,
	mfSessionCreated	= 0x02,
	mfBadPassword		= 0x03,
	mfEmpireDead		= 0x04,
	mfEmpireInPlay		= 0x05,
	mfRecordsError		= 0x06,
	mfServerFull		= 0x07,

	mfTop20List			= 0x09,
	mfGameStatistics	= 0x0b,
	mfVictory			= 0x0c,

	mfMessage		= 0x12,
	mfStatus		= 0x13,

	mfWorldScan		= 0x20,
	mfFleetScan		= 0x21,
	mfEmpireScan	= 0x22,
	mfCombatScan	= 0x23,
	mfBuildScan		= 0x24,

	mfSectorFleets	= 0x25,
	mfSectorWorlds	= 0x26,

	mfWorldProbe	= 0x32,
	mfArrival		= 0x41,

	mfEngageInvade	= 0x50,
	mfEngageDefend	= 0x51,
	mfGroupAttack	= 0x52,
	mfDisengage		= 0x53,
	mfDestroyed		= 0x54,
};

//***************************************************************************
//***************************************************************************

extern	CLists *empireList,*worldList,*fleetList;
extern	CRecords *victoryList;
extern	int top20List[20];

inline bool invadeGone(fleetRec *fp){
	return (fp->squad[0].count==0 && fp->squad[1].count==0 &&fp->squad[2].count==0);
}
inline bool defendGone(fleetRec *fp){
	return (fp->squad[4].count==0 && fp->squad[5].count==0 &&fp->squad[6].count==0);
}
inline bool fleetCollapsed(fleetRec *fp){
	return	invadeGone(fp) || defendGone(fp);
}

inline bool isFriendlyFleet(fleetRec *fp,fleetRec *ep){return (fp->empireID==ep->empireID);}


const int MoveGrid[4][posCOUNT]={
	{posCOUNT,posInvadeTop,posInvadeMid,posCOUNT,posDefendTop,posDefendMid},
	{posInvadeMid,posInvadeBot,posCOUNT,posDefendMid,posDefendBot,posCOUNT},
	{posDefendTop,posDefendMid,posDefendBot,posCOUNT,posCOUNT,posCOUNT},
	{posCOUNT,posCOUNT,posCOUNT,posInvadeTop,posInvadeMid,posInvadeBot},
};


inline	int CalcDarts(int wnum){return wnum/25;}
inline	int CalcGates(int wnum){return 2+wnum/75;}
inline	int CalcNebulae(int wnum){return wnum/30;}
inline	int CalcNeutron(int wnum){return wnum/45;}
inline	int EarthValue(int wnum){return wnum/4;}
inline  int HomeValue(int wnum){return wnum/20;}
inline	int CoreValue(int wnum){return wnum/100;}

const int CORECOUNT = 12;

//**********************************************************************************
#endif _SD_WORLDS_
