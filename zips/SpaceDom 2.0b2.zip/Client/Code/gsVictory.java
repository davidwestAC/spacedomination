import java.awt.*;
import java.applet.*;

class gsVictory extends GameState {

	Buffer vicBuf = null;

	Portrait title;
	final static String victory = "FINAL VICTORY!";

//--- primary functions ---
	public gsVictory(Buffer buf){
		vicBuf = buf;
		title = new Portrait("SpaceDomination.gif");
	}

//--- primary functions ---
	public void paint(Graphics g){
	Date date;
	int h,v;

		g.setColor(Color.black);
		g.fillRect(0,0,500,400);

		g.setColor(Color.yellow);
		g.setFont(bigFNT);
		g.drawString(victory,250-bigMET.stringWidth(victory)/2,150);

		if (vicBuf==null) return;

		g.setColor(Color.white);
		g.setFont(stoutFNT);

		centerStout(g,vicBuf.getString(28)+" Empire",h=250,v=200);
		date = new Date(vicBuf.getInt(4),vicBuf.getInt(8));
		centerStout(g,"at "+date.toString(),h,v+=30);
		date = new Date(0,vicBuf.getInt(12));
		centerStout(g,"after "+date.lengthStr(),h,v+=30);

		centerStout(g,"Final Score = "+vicBuf.getInt(16),h,v+=50);
		centerStout(g,"Final Worlds = "+vicBuf.getInt(20),h,v+=30);
		centerStout(g,"Final Darts = "+vicBuf.getInt(24),h,v+=30);

		g.setColor(Color.black);
		title.draw(g,10,10,root);
	}


	void centerStout(Graphics g,String msg,int h,int v){
		g.drawString(msg,h-stoutMET.stringWidth(msg)/2,v);
	}
}