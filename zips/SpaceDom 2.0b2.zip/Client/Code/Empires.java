import java.awt.*;

class Empires implements MessageValues {

	final static String UNKNOWN = "<unknown>";
	final static String EMPIRE = "";

	static Empires root = null;

	public final static String[] racename = {
		"Human","Makluvian","Kaletian",
		"Zorestian","Avarian","Najunian",
		"Cestanian","Quarethian",
		"Nothing",
	};

//--- variables ---
	String name;
	int empireID,worlds,hiWorlds,darts,hiDarts,score,hiScore,fleetID,channel,race,ruler;
	int Merchant,Beacon,Stardock,Blaster;
	Empires next;

//--- constructors ---
	public Empires(){next = null;}

	public String toString(){return "("+empireID+")"+name;}

	public String name(){return name+EMPIRE;}
	public String racename(){return racename[race];}

	public int worlds(){return worlds;}
	public int darts(){return darts;}
	public int score(){return score;}
	public int fleetID(){return fleetID;}
	public int channel(){return channel;}
	public int race(){return race;}
	public int ruler(){return ruler;}
	public int Merchant(){return Merchant;}
	public int Beacon(){return Beacon;}
	public int Stardock(){return Stardock;}
	public int Blaster(){return Blaster;}

	public static Empires start(){return root;}
	public Empires next(){return next;}

//--- functions ---
	public static void add(Buffer buf){
	Empires temp,ep;
	int id;

		id = buf.getInt(2);
		ep = get(id);

		temp = (ep!=null?ep:new Empires());

		temp.empireID = id;

		temp.fleetID = buf.getInt(6);
		temp.channel = buf.getInt(10);
		temp.ruler = buf.getInt(14);
		temp.race = buf.getInt(18);

		temp.worlds = buf.getInt(22);
		temp.darts = buf.getInt(26);
		temp.score = buf.getInt(30);

		temp.hiWorlds = buf.getInt(34);
		temp.hiDarts = buf.getInt(38);
		temp.hiScore = buf.getInt(42);

		temp.Merchant = buf.getInt(46);
		temp.Beacon = buf.getInt(50);
		temp.Stardock = buf.getInt(54);
		temp.Blaster = buf.getInt(58);

		temp.name = buf.getString(62);
		
		if (ep==null) insert(temp);
	}

	public static Empires get(int empireID){
	Empires temp;

		temp = root;
		while (temp!=null) {
			if (temp.empireID==empireID) return temp;
			temp = temp.next;
		}
		return null;
	}

	public static String findEmpireName(int empireID){
	String temp;

		temp = Empires.findName(empireID);

		if (UNKNOWN.equals(temp)) {
			GameState.sendEmpireQuery(empireID);
			return UNKNOWN;
		}

		return temp+EMPIRE;
	}

	public static String findName(int empireID){
	Empires temp;
	Buffer buf;

		temp = get(empireID);
		if (temp!=null) return temp.name;

		temp = new Empires();

		temp.empireID = empireID;
		temp.name = UNKNOWN;
		temp.worlds = 0;
		temp.score = 0;
		temp.channel = 0;
		temp.fleetID = 0;
		temp.race = 8;
		temp.ruler = -1;
		temp.Merchant = 0;
		temp.Beacon = 0;
		temp.Stardock = 0;
		temp.Blaster = 0;

		insert(temp);

		return temp.name;
	}

//--- private functions ---
	static void insert(Empires temp){
		temp.next = root;
		root = temp;
	}
};