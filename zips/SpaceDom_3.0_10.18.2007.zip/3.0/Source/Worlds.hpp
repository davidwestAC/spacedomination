//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#ifndef _SD_WORLDS_
#define	_SD_WORLDS_

#include "FFItypes.hpp"
#include "CRecords.hpp"

//**********************************************************************************

const int MAXBUILD = 10;		// number of build commands

//const int MAXNAMESIZE = 16;
const int MAXNAMESIZE = 26;
const int MAXMAILSIZE = 32;

//const int MAXDIST = 2000;
//const int MINDIST = 1000;
const int MAXDIST = 200;
const int MINDIST = 100;

//const int SCAN_SIZE = 2250;
//const int NEBULAE_SIZE = 2000;
//const int NEUTRON_SIZE = 1500;
//const int RED_GIANT_SIZE = 1800;
//const int BLUE_DWARF_SIZE = 1400;
const int SCAN_SIZE = 225;
const int NEBULAE_SIZE = 200;
const int NEUTRON_SIZE = 150;
const int RED_GIANT_SIZE = 180;
const int BLUE_DWARF_SIZE = 140;

//const int ATTRITION = 200;
//const int VICTORY_PERCENT = 50;		// 50% is good
//const int pixelsPerSecond = 150;	// movement factor
//const int COMMAND_BONUS = 1000;		// + 1000 build points when fleet at world
//const int RESET_WORLDS_PER_EMPIRE = 10;

//**********************************************************************************

enum ShipTypes {
	stPinnace,stCorsair,stFrigate,
	stStation,stRanger,stStarDart,
	stCOUNT
};

enum BuildTypes {
	btPinnace,btCorsair,btFrigate,
	btStation,btRanger,btIndustry,
	btMerchant,btBeacon,btStardock,
	btSabotage,btStellurae,btShield,
	btCOUNT
};

enum RaceTypes {
	rtHuman,rtMakluvian,rtKaletian,
	rtZorestian,rtAvarian,rtNajunian,
	rtCestanian,rtQuarethian,
	rtCOUNT
};

// Added ftMerchant,ftBeacon,ftStardock
enum FacilityTypes {
	ftMerchant,ftBeacon,ftStardock,
	ftSabotage,ftStellurae,ftShield,
	ftCOUNT
};


//                        stPinnace ,stCorsair ,stFrigate ,stStation ,stRanger  ,stStarDart,
//const int guns[stCOUNT] = {2         ,10        ,40        ,4         ,10        ,5000};					// remember dmg = ushort
//const int max[stCOUNT]  = {62500     ,12500     ,3125      ,31250     ,12500     ,1000};
//const int cost[btCOUNT] = {100       ,500       ,2000      ,200       ,500             ,100,1,1,1,1,3000,5000,8000,10000};
//const int ecm[stCOUNT]  = {0         ,0         ,0         ,2         ,6         ,1000};

//                        stPinnace ,stCorsair ,stFrigate ,stStation ,stRanger  ,stStarDart,
const int guns[stCOUNT] = {1         ,5         ,20        ,2         ,5         ,2500 };	// remember dmg = ushort
const int max[stCOUNT]  = {50000     ,10000     ,2500      ,25000     ,10000     ,500  };
const int cost[btCOUNT] = {50        ,250       ,1000      ,100       ,250             ,100,1,1,1,1,1,1};
const int ecm[stCOUNT]  = {0         ,0         ,0         ,2         ,5         ,500  };

//	                                   stPinnace ,stCorsair ,stFrigate ,stStation ,stRanger  ,stStarDart,
//const int FireTimer[stCOUNT]        = {6         ,8         ,12        ,10        ,9         ,18};
//const int FastFireTimer[stCOUNT]    = {5         ,7         ,11        ,9         ,8         ,16};
//const int MoveTimer[stCOUNT]        = {4         ,6         ,8         ,8         ,6         ,12};
//const int FastMoveTimer[stCOUNT]    = {3         ,5         ,6         ,6         ,5         ,9};
//const int RetreatTimer[stCOUNT]     = {7         ,9         ,13        ,11        ,10        ,15};
//const int FastRetreatTimer[stCOUNT] = {6         ,8         ,12        ,10        ,9         ,13};

//	                                   stPinnace ,stCorsair ,stFrigate ,stStation ,stRanger  ,stStarDart,
//const int FireTimer[stCOUNT]        = {4         ,6         ,10        ,8         ,7         ,16};
//const int FastFireTimer[stCOUNT]    = {3         ,5         ,9         ,7         ,6         ,15};
//const int MoveTimer[stCOUNT]        = {4         ,6         ,10        ,8         ,6         ,11};
//const int FastMoveTimer[stCOUNT]    = {3         ,5         ,9         ,7         ,5         ,10};
//const int RetreatTimer[stCOUNT]     = {5         ,7         ,11        ,9         ,8         ,16};
//const int FastRetreatTimer[stCOUNT] = {4         ,6         ,10        ,8         ,6         ,15};

const int FireTimer[stCOUNT]        = {4         ,5         ,8         ,7         ,6         ,12};
const int FastFireTimer[stCOUNT]    = {3         ,4         ,7         ,6         ,5         ,11};
const int MoveTimer[stCOUNT]        = {4         ,5         ,8         ,7         ,6         ,12};
const int FastMoveTimer[stCOUNT]    = {3         ,4         ,7         ,6         ,5         ,11};
const int RetreatTimer[stCOUNT]     = {5         ,6         ,9         ,8         ,7         ,13};
const int FastRetreatTimer[stCOUNT] = {4         ,5         ,8         ,7         ,6         ,12};

const int attack[stCOUNT][stCOUNT] = { // 1 minute * power / timer = constant
	{ 9, 5,14, 5, 9, 9},	// pinnace	60 * 6  / 4  = 90 
	{15,10, 5,10,10,10},	// corsair	60 * 9  / 6  = 90
	{10,20,15,20,20,15},	// frigate	60 * 12 / 8  = 90
	{10,10, 9,10,10, 5},	// station	60 * 10 / 6  = 100
	{14, 9, 5, 9, 9, 9},	// ranger	60 * 8  / 6  = 80
	{30,30,30,45,30,30},	// stardart	60 * 30 / 12 = 150
};

//**********************************************************************************

enum WorldType {
	wtNormal,

	wtHome,			// homeworld rich+large+2*strong
	wtCore,			// homeworld rich+strong
	wtPoor,			// population generates less bp
	wtRich,			// population generates more bp
	wtSmall,		// supports less industry
	wtLarge,		// supports more industry
	wtAquatic,		// build sloops faster
	wtMountain,		// build rangers faster
	wtDesert,		// build frigates faster
	wtTundra,		// build corsairs faster
	wtJungle,		// build stations faster
	wtMetallic,		// build industry faster

	wtMerchant,		// build build bonus faster and higher max build bonus
	wtBeacon,		// build speed bonus faster and higher max speed bonus
	wtStardock,		// build decay bonus faster and higher max decay bonus

	wtNewEarth,
	wtMakluvia,
	wtKaletia,
	wtZorestia,
	wtAvaria,
	wtNajunia,
	wtCestania,
	wtQuarethia,

	wtNebulae,		// radius 60, slow movement
	wtNeutron,		// radius 45, fast movement
	wtGateway,		// xfer from spot to spot sequentially
	wtWormhole,		// xfer from spot to spot randomly
	wtDead,			// dead world, permanently neutral, nothing happens when hit
	wtCOUNT
};
inline bool isPlanet(int type){return (type<wtNebulae);}
inline bool isNormalPlanet(int type){return (type==wtNormal || type>wtCore && type<wtNewEarth);}
inline bool isMainPlanet(int type){return (type==wtHome || type==wtCore || type>=wtNewEarth && type<=wtQuarethia);}
inline bool isPhenomena(int type){return (type>=wtNebulae && type<wtDead);}

//enum EngageSide {sideDefend,sideInvade,sideCOUNT};
enum EngageSide {sideDefend,sideSelf,sideInvade,sideCOUNT};

enum SquadPosition {
	posInvadeTop,posInvadeMid,posInvadeBot,
	posDefendTop,posDefendMid,posDefendBot,
	posCOUNT
};
inline bool isDefendPosition(int pos){return pos>=posDefendTop;}
inline bool isInvadePosition(int pos){return pos<posDefendTop;}

//enum SquadActions {
//	actDefend,actRetreat,
//	actMoveUp,actMoveDown,actMoveLeft,actMoveRight,
//	actFirePinnace,actFireCorsair,actFireFrigate,
//	actFireStation,actFireRanger,actFireStarDart,
//	actCOUNT
//};
enum SquadActions {
	actDefend,actRetreat,
	actMoveUp,actMoveDown,actMoveLeft,actMoveRight,
	actTarget0, actTarget1, actTarget2,
	actTarget3, actTarget4, actTarget5,
	actCOUNT
};

inline int ReadHeading(int act){return (act-actMoveUp);}
//inline int ReadType(int act){return (act-actFirePinnace);}
inline int MakeFireAction(int targetPos){return (actTarget0+targetPos);}

inline bool illegalAction(int act){return(act>=actCOUNT);}
inline bool isDefendAction(int act){return (act==actDefend);}
inline bool isRetreatAction(int act){return (act==actRetreat);}
inline bool isMoveAction(int act){return (act>=actMoveUp && act <= actMoveRight);}
inline bool isFireAction(int act){return (act>=actTarget0 && act <= actTarget5);}


enum FleetStatus {
	fsWaiting,
	fsMoving,
	fsNebulae,
	fsNeutron,
	fsBattle,
	fsIndustry,
	fsDead,
	fsCOUNT,
};

inline bool isMoveState(int state){return (state>fsWaiting && state<fsBattle);}

//**********************************************************************************

// empireRec Size = 2 * MAXNAMESIZE + MAXMAILSIZE + 5*4 = 84
class empireRec {
public:
	char	name[MAXNAMESIZE];
	int		fleetID,channel,ruler,race;
	int		worlds,phenom,darts,score,hiWorlds,hiDarts,hiScore;
	char	pass[MAXNAMESIZE];
	int		Merchant;
	int		Beacon;
	int		Stardock;
	int		Stellurae;
	int		scoreDarts;
	bool	changedRace;
	long	worldGuns;
	int		fleetGuns;
	int		numRebirths;
//todo add data structures for tracking who took worlds from who and who rebirthed who
//		will need to be fixed arrays
	int     rebirthed[500];       // empire ids rebirthed
	int     worldsTakenFrom[500]; // worlds taken from given empire id
};

// battleGrp Size = 7 -> 8
class squadRec {
public:
	byte			type,action,timer,enemy;
	ushort			damage;
	ushort			count;
};

// fleetRec Size = 5 * 4 + epCOUNT * 4 + stCOUNT * bgSize = 76
class fleetRec {
public:
	int			xloc,yloc,destID,empireID,status;
	int			engageID[sideCOUNT];		// engaged fleet ID's
	int			ecm,guns;
	int			Beacon;
	int			moveSpeed;
	int			Stardock;
	squadRec	squad[posCOUNT];
};

// buildCmd Size = 4
class buildCmd {
public:
	bool	repeat;					// re-posts command to end of queue when finished
	byte	type,goal,built;
};

// worldRec Size = 9 * 4 + MAXNAMESIZE + MAXBUILD * bcSize = 88
// worldScan Size = 3 * 4 + MAXNAMESIZE = 28
// first section of fleets correspond to worlds 1:1
class worldRec {
public:
	int			xloc,yloc,type,pop;
	int			empireID,ind,maxInd,storage;
	int			Merchant;
	int			maxMerchant;
	int			Beacon;
	int			maxBeacon;
	int			Stardock;
	int			maxStardock;
	int			sector;
	int			worldID;
	int			facility;
	int			facilityTime;
	buildCmd	cmd[MAXBUILD];
	char		name[MAXNAMESIZE];					// world name
};

class victoryRec {
public:
	int		date,time;		// day + seconds when victory was recorded- see todayToDays
	int		score,worlds,darts,race;
	int		maxScore,maxWorlds,maxDarts,gameLength;
	char	name[MAXNAMESIZE];

	inline victoryRec() {
		date=time=score=worlds=darts=race=maxScore=maxWorlds=maxDarts=gameLength=0;
		memset(&name,0,MAXNAMESIZE);
	}

	inline  int getDate(){return date;}
	inline  int getTime(){return time;}

};

//**********************************************************************************

typedef enum MessageToServer {
	msJoinRequest	= 0x00,

	msTop20Query	= 0x08,
	msAskForStats	= 0x0a,

	msRebirth		= 0x0d,
	msSessionDone	= 0x0e,
	msSessionPing	= 0x0f,
	msChatMessage	= 0x10,
	msChatChannel	= 0x11,

	msQueryEmpire	= 0x28,
	msQueryWorld	= 0x29,
	msQueryFleet	= 0x2a,

	msProbe			= 0x30,
	msScout			= 0x31,
	msFleetMove		= 0x40,

	msSquadAction	= 0x59,

	msBuildCommand	= 0x60,
	msFleetTransfer = 0x61,

	msRaceChange	= 0x70,
	msSettingsQuery = 0x71,

	msQuit			= 0x80,

};


typedef enum MessageToFront {
	mfSessionGranted	= 0x01,
	mfSessionCreated	= 0x02,
	mfBadPassword		= 0x03,
	mfEmpireDead		= 0x04,
	mfEmpireInPlay		= 0x05,
	mfRecordsError		= 0x06,
	mfServerFull		= 0x07,

	mfTop20List			= 0x09,

	mfGameStatistics	= 0x0b,
	mfVictory			= 0x0c,

	mfMessage		= 0x12,
	mfStatus		= 0x13,
	mfLastAttacked		= 0x14,
	mfLastCaptured		= 0x15,

	mfWorldScan		= 0x20,
	mfFleetScan		= 0x21,
	mfEmpireScan	= 0x22,
	mfCombatScan	= 0x23,
	mfBuildScan		= 0x24,

	mfSectorFleets	= 0x25,
	mfSectorWorlds	= 0x26,

	mfWorldProbe	= 0x32,
	mfArrival		= 0x41,

	mfEngageInvade	= 0x50,
	mfEngageDefend	= 0x51,
	mfGroupAttack	= 0x52,
	mfDisengage		= 0x53,
	mfDestroyed		= 0x54,

	mfFacilityStatistics	= 0x72,
	mfFacilityInfo			= 0x73,
	mfSessionSuspended		= 0x74,
	mfSessionResume			= 0x75,
};

//***************************************************************************
//***************************************************************************

extern	CLists *empireList,*worldList,*fleetList;
extern	CRecords *victoryList;
extern	int top20List[20];

inline bool invadeGone(fleetRec *fp){
	return (fp->squad[0].count==0 && fp->squad[1].count==0 &&fp->squad[2].count==0);
}
inline bool defendGone(fleetRec *fp){
	return (fp->squad[4].count==0 && fp->squad[5].count==0 &&fp->squad[6].count==0);
}
inline bool fleetCollapsed(fleetRec *fp){
	return	invadeGone(fp) || defendGone(fp);
}

inline bool isFriendlyFleet(fleetRec *fp,fleetRec *ep){return (fp->empireID==ep->empireID);}

/*
**actMoveUp,
**actMoveDown,
**actMoveLeft,
**actMoveRight
*/
const int MoveGrid[5][posCOUNT]={
	{posCOUNT    ,posInvadeTop,posInvadeMid,posCOUNT,    posDefendTop,posDefendMid},
	{posInvadeMid,posInvadeBot,posCOUNT    ,posDefendMid,posDefendBot,posCOUNT},
	{posDefendTop,posDefendMid,posDefendBot,posCOUNT,    posCOUNT,    posCOUNT},
	{posCOUNT    ,posCOUNT    ,posCOUNT,    posInvadeTop,posInvadeMid,posInvadeBot}
};


inline	int EarthValue   (int wnum)	{return wnum/4;}
inline  int HomeValue    (int wnum)	{return wnum/20;}
inline	int CoreValue    (int wnum)	{return wnum/100;}

extern int gCORECOUNT;

//**********************************************************************************
#endif //_SD_WORLDS_

