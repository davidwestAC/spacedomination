//**********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************
#include "fileIO.hpp"
#include "string.hpp"
#include <stdio.h>
#include "log.h"
#include "worlds.hpp"
//**********************************************************************
const char *INITFILE = "SDserver.ini";

char *headTest = "[SpaceDom]\n";

char dataPath[128],htmlPath[128];
int portNum,maxPlayers,fleetDecayRate,worldDecayRate,victoryBase,movePixels,commandBuild,commandBonus;
int worldBuildBonus, worldDecayBonus;
int minWorlds,highWorlds,dropHours,firstEarthDeclareRatio,firstHomeDeclareRatio;
int firstPhenomenaDeclareRatio,firstHomePhenomenaDeclareRatio,laterEarthDeclareRatio,laterHomeDeclareRatio;
int laterPhenomenaDeclareRatio,laterHomePhenomenaDeclareRatio,maxSpeed,timeoutSeconds;
int earthMerchant,earthBeacon,earthStardock;
int	coreMerchant,coreBeacon,coreStardock;
int homeMerchant,homeBeacon,homeStardock;
int dbPort;
char dbHost[64],dbUser[64],dbPasswd[64],dbName[64],dbTable[64],arenaName[64];
int arenaVersion,dd_dmg_mod,dd_beacon_mod,dd_stardock_mod,dd_merchant_mod,dd_ind_mod;
int dd_dmg_type, dd_destroy_world, dd_teleport, dd_damage_darts;
int start_frigate, start_sloop, start_ranger, start_corsair;
int merchantBonusType;
int merchantBonus, beaconBonus, stardockWorldBonus, stardockFleetBonus;
int doomsdayCost, stelluraeCost, shieldCost;
int merchantCost, beaconCost, stardockCost;
int shieldBonus;
int gameHours, gameTicks;
int minNumCoreWorld, minNumPoorWorld, minNumRichWorld, minNumSmallWorld, minNumLargeWorld;
int minNumAquaticWorld, minNumMountainWorld, minNumDesertWorld, minNumTundraWorld, minNumJungleWorld, minNumMetallicWorld;
int minNumMerchantWorld, minNumBeaconWorld, minNumStardockWorld;
int minNumNebulae, minNumNeutron, minNumGateway, minNumWormhole;
int coreWorldPercent, poorWorldPercent, richWorldPercent, smallWorldPercent, largeWorldPercent;
int aquaticWorldPercent, mountainWorldPercent, desertWorldPercent, tundraWorldPercent, jungleWorldPercent, metallicWorldPercent;
int merchantWorldPercent, beaconWorldPercent, stardockWorldPercent;
int nebulaePercent, neutronPercent, gatewayPercent, wormholePercent;
int allowHomeWorlds, dartPercent, minNumDarts;
int minDartsPerCore, minDartsPerHome, minDartsPerOE, dartsPerCorePercent, dartsPerHomePercent, dartsPerOEPercent;
int timeShiftSessionHours, timeShiftSkipDays;
int oeStartsDead, hwDeclareForAll;
int allowMultipleFacilities, facilityVariation, facilityCostType;
int ecmOE, ecmHome, ecmCore, ecmMin, ecmMax, ecmPopBonus;
int log_level, stationsOnly, maxPop, minPop, corePop, homePop, oePop;
char log_file[256];
int raceScoreDartChance[8];
double raceBuildModifier[8], raceDecayModifier[8], raceBeaconModifier[8], raceCommandModifier[8];
double raceSectorBuildModifier, specialWorldShipModifier;
double smallIndMod, poorIndMod, normalIndMod, richIndMod, largeIndMod, coreIndMod, homeIndMod, oeIndMod;
double starDartScoreModifier;

Log gLog(Log::LOG_DEBUG); // default to LOG_DEBUG level logging to stdout until overridden by init file

//**********************************************************************

bool readInitFile() {
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 2000, "Enter readInitFile()");
	char line[1024],temp[256];
	char *data;
	int ix,i;

	dataPath[0] = 0;
	htmlPath[0] = 0;

	timeShiftSessionHours = 1;
	timeShiftSkipDays = 0;
	portNum = 1965;
	maxPlayers = 200;
	fleetDecayRate = 100;
	worldDecayRate = 200;
	victoryBase = 50;
	movePixels = 15;
	commandBuild = 1000;
	commandBonus = 10;
	worldBuildBonus = 1;
	worldDecayBonus = 1;
	minWorlds = 100;
	highWorlds = 10000;
	dropHours = 8;
	gameHours = 0;
	gameTicks=10; 	// how many seconds between build cycles
	firstEarthDeclareRatio = 8;
	firstHomeDeclareRatio = 4;
	firstPhenomenaDeclareRatio = 6;
	firstHomePhenomenaDeclareRatio = 3;
	laterEarthDeclareRatio = 12;
	laterPhenomenaDeclareRatio = 10;
	laterHomeDeclareRatio = 2;
	laterHomePhenomenaDeclareRatio = 2;
	hwDeclareForAll = 0;	// 0 hw declares for that race only, 1 home worlds declare for every race
	maxSpeed = 300;
	timeoutSeconds = 60;
	earthMerchant = 200;
	earthBeacon = 50;
	earthStardock = 100;
	coreMerchant = 20;
	coreBeacon = 5;
	coreStardock = 10;
	homeMerchant = 50;
	homeBeacon = 10;
	homeStardock = 25;

	minNumCoreWorld = 12;
	minNumPoorWorld = 0;
	minNumRichWorld = 0;
	minNumSmallWorld = 0;
	minNumLargeWorld = 0;
	minNumAquaticWorld = 0;
	minNumMountainWorld = 0;
	minNumDesertWorld = 0;
	minNumTundraWorld = 0;
	minNumJungleWorld = 0;
	minNumMetallicWorld = 0;
	minNumMerchantWorld = 0;
	minNumBeaconWorld = 0;
	minNumStardockWorld = 0;
	minNumNebulae = 6;
	minNumNeutron = 3;
	minNumGateway = 8;
	minNumWormhole = 4;
	coreWorldPercent = 0;
	poorWorldPercent = 4;
	richWorldPercent = 2;
	smallWorldPercent = 4;
	largeWorldPercent = 2;
	aquaticWorldPercent = 2;
	mountainWorldPercent = 2;
	desertWorldPercent = 2;
	tundraWorldPercent = 2;
	jungleWorldPercent = 2;
	metallicWorldPercent = 2;
	merchantWorldPercent = 2;
	beaconWorldPercent = 2;
	stardockWorldPercent = 2;
	nebulaePercent = 3;
	neutronPercent = 2;
	gatewayPercent = 1;
	wormholePercent = 1;

	dartPercent = 5;
	minNumDarts = 25;
	starDartScoreModifier = 1;

	allowHomeWorlds = 1;	// 0 means no home worlds, 1 means normal home worlds
	
	stationsOnly = 0;	// 0 means starting neutrals will have ship types that their pop can support, 1 means only stations
	maxPop = 79; 		// maximum population a world smaller than a core can have
	minPop = 10;		// minimum population a world smaller than a core can have
	
	corePop = 100;		// the population of a core world
	homePop = 150;		// the population of a home world
	oePop = 200;		// the population of oe
	
	smallIndMod = 2.0;		// the max ind for a small world is pop * richIndMod
	poorIndMod = 3.0;			// the max ind for a poor world is pop * poorIndMod
	normalIndMod = 3.0;		// the max ind for an normal world is pop * normalIndMod. Facility worlds are normal.
	richIndMod = 3.0;			// the max ind for a rich world is pop * richIndMod
	largeIndMod = 6.0;		// the max ind for a large world is pop * largeIndMod
	coreIndMod = 6.0;			// the max ind for a core world is pop * coreIndMod
	homeIndMod = 6.0;			// the max ind for a home world is pop * homeIndMod
	oeIndMod = 8.0;			// the max ind for a oe world is pop * oeIndMod

	dd_beacon_mod = 10;
	dd_stardock_mod = 8;
	dd_merchant_mod = 4;
	dd_ind_mod = 2;
	dd_dmg_mod = 25;
	dd_dmg_type = 0;		// 0 = variable based on world stats, 1 = fixed percentage of fleet, 2 = fixed amount of damage, 3 = no damage
	dd_destroy_world = 1;	// 0 = no, 1 = yes
	dd_teleport = 0;		// send the attacking fleet to a random location
	dd_damage_darts = 1;    // 0 = nno, 1 = yes

	merchantBonusType = 1;	// 0 = fixed bonus, 1 = percentage bonus
	merchantBonus = 1;
	beaconBonus = 1;
	stardockWorldBonus = 2;
	stardockFleetBonus = 1;

	/*
	** This the chance any given race has of scoring
	** an extra dart.  If the value is 10, that race
	** will have a 1 in 10 chance of scroing an extra dart.
	** Zero means no chance.
	*/
	raceScoreDartChance[rtHuman]		= 0;
	raceScoreDartChance[rtMakluvian]	= 0;
	raceScoreDartChance[rtKaletian]		= 0;
	raceScoreDartChance[rtZorestian]	= 0;
	raceScoreDartChance[rtAvarian]		= 0;
	raceScoreDartChance[rtNajunian]		= 0;
	raceScoreDartChance[rtCestanian]	= 10;
	raceScoreDartChance[rtQuarethian]	= 0;

	/*
	** These modify how effective beacons are
	** greater than 1, positive impact
	** less than 1, negative impact
	** equal to 1, normal impact
	*/
	raceBeaconModifier[rtHuman]		= 1.0;
	raceBeaconModifier[rtMakluvian]	= 1.0;
	raceBeaconModifier[rtKaletian]	= 1.0;
	raceBeaconModifier[rtZorestian]	= 1.0;
	raceBeaconModifier[rtAvarian]	= 1.0;
	raceBeaconModifier[rtNajunian]	= 1.0;
	raceBeaconModifier[rtCestanian]	= 1.0;
	raceBeaconModifier[rtQuarethian]= 1.0;

	/*
	** These modify how effective stardocks are
	** greater than 1, positive impact
	** less than 1, negative impact
	** equal to 1, normal impact
	*/
	raceDecayModifier[rtHuman]		= 1.0;
	raceDecayModifier[rtMakluvian]	= 1.0;
	raceDecayModifier[rtKaletian]	= 1.0;
	raceDecayModifier[rtZorestian]	= 1.15;
	raceDecayModifier[rtAvarian]	= 1.0;
	raceDecayModifier[rtNajunian]	= 1.0;
	raceDecayModifier[rtCestanian]	= 1.0;
	raceDecayModifier[rtQuarethian]	= 1.0;

	/*
	** These modify how effective merchants are
	** Will obviously have a much greater impact when merchantBonusType is 1
	** greater than 1, positive impact
	** less than 1, negative impact
	** equal to 1, normal impact
	*/
	raceBuildModifier[rtHuman]		= 1.0;
	raceBuildModifier[rtMakluvian]	= 1.1;
	raceBuildModifier[rtKaletian]	= 1.0;
	raceBuildModifier[rtZorestian]	= 1.0;
	raceBuildModifier[rtAvarian]	= 1.0;
	raceBuildModifier[rtNajunian]	= 1.0;
	raceBuildModifier[rtCestanian]	= 1.0;
	raceBuildModifier[rtQuarethian]	= 1.0;

	/*
	** These modify how effective fleet command build is
	** greater than 1, positive impact
	** less than 1, negative impact
	** equal to 1, normal impact
	*/
	raceCommandModifier[rtHuman]		= 1.0;
	raceCommandModifier[rtMakluvian]	= 1.05;
	raceCommandModifier[rtKaletian]		= 1.0;
	raceCommandModifier[rtZorestian]	= 1.0;
	raceCommandModifier[rtAvarian]		= 1.0;
	raceCommandModifier[rtNajunian]		= 1.0;
	raceCommandModifier[rtCestanian]	= 1.0;
	raceCommandModifier[rtQuarethian]	= 1.0;

	/*
	** This gets added to build points for worlds controlled in same
	** sector as player's race.
	** pop+ind * raceSectorBuildModifier is what gets added
	** Range probably should be between 0 and 1, but you could
	** get stupid with it if you wanted too ;)
	*/
	raceSectorBuildModifier = 0.05;

	/*
	** This reduces cost of certain ships on the special worlds
	** Range definitely needs to be between 1/2 and 1.
	** newCost = newCost * specialWorldShipModifier;
	*/
	specialWorldShipModifier = 0.5;

	allowMultipleFacilities = 0;	// 0 = only one facility type per world
	facilityVariation = 1;			// 0 = one of each type can be built on all non-special worlds
									// 1 = population determines how many of each type can be built

	facilityCostType = 0;			// 0 = bp, 1 = time

	// set cost to 0 to disallow that facility
	merchantCost = 2000;
	beaconCost = 4000;
	stardockCost = 6000;
	doomsdayCost = 1000;
	stelluraeCost = 8000;
	shieldCost = 10000;

	// all ECM values get divided by 100 for actual ECM value
	ecmOE=20000;		//30000
	ecmHome=10000;		//20000
	ecmCore=5000;		//10000
	ecmMin=-200;		//-100
	ecmMax=200;
	ecmPopBonus=2;

	shieldBonus = 50000;  // this gets divided by 100 for actual ECM value
	minDartsPerCore = 1;
	minDartsPerHome = 4;
	minDartsPerOE = 8;
	dartsPerCorePercent = 1;
	dartsPerHomePercent = 5;
	dartsPerOEPercent = 10;

	oeStartsDead = 0;	// if this is 1, OE starts the game as a dead world, no declares, no points
//todo: allow players to see fleets under other fleets and attack them as well

//const int guns[stCOUNT] = {2,        10,       40,       4,        10,      5000};
//	                         stPinnace,stCorsair,stFrigate,stStation,stRanger,stStarDart,
	start_sloop=100;		// 200 guns
	start_ranger=0;
	start_corsair=20;		// 200 guns
	start_frigate=5;		// 200 guns
//todo: allow client to alter distribution of above guns

	dbPort=3306;
	dbHost[0]='\0';
	sprintf(dbHost, "__NONE__");
	dbUser[0]='\0';
	dbPasswd[0]='\0';
	dbName[0]='\0';
	dbTable[0]='\0';
	arenaName[0]='\0';
	arenaVersion=0;

//--- load & read file ---
	data = (char*)loadFile((char*)INITFILE);
	if (data==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 2002, "Error loading init file (%s).", INITFILE);
		gLog.logMsg(Log::LOG_DEBUG, 2003, "Leave readInitFile()");
		return false;
	}

	i = search(data,headTest);
	if (i<0) {
		gLog.logMsg(Log::LOG_ERROR, 2004, "Error \"%s\" not found in init file (%s).", headTest, INITFILE);
		gLog.logMsg(Log::LOG_DEBUG, 2005, "Leave readInitFile()");
		return false;
	}

	ix = i;
	while (true) {
		bool match = false;
		i = readToken(data+ix,line,'=');
		if (i<0) break;

		ix += i;

		if (equalsCI("LOG_LEVEL",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&log_level);
			gLog.setLogLevel((Log::loggingLevel)log_level);
			match = true;
		}
		if (equalsCI("LOG_FILTER_IN",line)) {
			i = readToken(data+ix,temp,'\n');
			int first_id, last_id;
			if (strchr(temp, ',') != NULL) {
				sscanf(temp,"%d,%d",&first_id, last_id);
			} else {   				 
				sscanf(temp,"%d",&first_id);
				last_id = first_id;
			}
			gLog.addFilter(Log::LOG_ALLOW,first_id, last_id);
			match = true;
		}
		if (equalsCI("LOG_FILTER_OUT",line)) {
			i = readToken(data+ix,temp,'\n');
			int first_id, last_id;
			if (strchr(temp, ',') != NULL) {
				sscanf(temp,"%d,%d",&first_id, last_id);
			} else {   				 
				sscanf(temp,"%d",&first_id);
				last_id = first_id;
			}
			gLog.addFilter(Log::LOG_BLOCK,first_id, last_id);
			match = true;
		}
		if (equalsCI("LOG_FILE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%s",&log_file);
			gLog.setLogFile(log_file);
			match = true;
		}
		if (equalsCI("GAME_TICKS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&gameTicks);
			match = true;
		}
		if (equalsCI("DATA_PATH",line)) {
			i = readToken(data+ix,dataPath,'\n');
			match = true;
		}
		if (equalsCI("HTML_PATH",line)) {
			i = readToken(data+ix,htmlPath,'\n');
			match = true;
		}
		if (equalsCI("PORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&portNum);
			match = true;
		}
		if (equalsCI("MAX_PLAYERS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxPlayers);
			match = true;
		}
		if (equalsCI("FLEET_ATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&fleetDecayRate);
			match = true;
		}
		if (equalsCI("WORLD_ATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&worldDecayRate);
			match = true;
		}
		if (equalsCI("VICTORY_BASE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&victoryBase);
			match = true;
		}
		if (equalsCI("MOVEMENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&movePixels);
			match = true;
		}
		if (equalsCI("COMMAND_BUILD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBuild);
			match = true;
		}
		if (equalsCI("COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBonus);
			match = true;
		}
		if (equalsCI("MERCHANT_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&merchantBonus);
			match = true;
		}
		if (equalsCI("MIN_WORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minWorlds);
			match = true;
		}
		if (equalsCI("MAX_WORLDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&highWorlds);
			match = true;
		}
		if (equalsCI("DROP_HOURS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dropHours);
			match = true;
		}
		if (equalsCI("GAME_HOURS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&gameHours);
			match = true;
		}
		if (equalsCI("FIRST_EARTH_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstEarthDeclareRatio);
			match = true;
		}
		if (equalsCI("FIRST_HOME_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstHomeDeclareRatio);
			match = true;
		}
		if (equalsCI("FIRST_PHENOMENA_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstPhenomenaDeclareRatio);
			match = true;
		}
		if (equalsCI("FIRST_HOME_PHENOMENA_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&firstHomePhenomenaDeclareRatio);
			match = true;
		}
		if (equalsCI("LATER_EARTH_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterEarthDeclareRatio);
			match = true;
		}
		if (equalsCI("LATER_HOME_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterHomeDeclareRatio);
			match = true;
		}
		if (equalsCI("LATER_PHENOMENA_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterPhenomenaDeclareRatio);
			match = true;
		}
		if (equalsCI("LATER_HOME_PHENOMENA_DECLARE_RATIO",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&laterHomePhenomenaDeclareRatio);
			match = true;
		}
		if (equalsCI("MAX_SPEED",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxSpeed);
			match = true;
		}
		if (equalsCI("TIMEOUT_SECONDS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&timeoutSeconds);
			match = true;
		}
		if (equalsCI("EARTH_MERCHANT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&earthMerchant);
			match = true;
		}
		if (equalsCI("EARTH_BEACON",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&earthBeacon);
			match = true;
		}
		if (equalsCI("EARTH_STARDOCK",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&earthStardock);
			match = true;
		}
		if (equalsCI("CORE_MERCHANT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&coreMerchant);
			match = true;
		}
		if (equalsCI("CORE_BEACON",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&coreBeacon);
			match = true;
		}
		if (equalsCI("CORE_STARDOCK",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&coreStardock);
			match = true;
		}
		if (equalsCI("HOME_MERCHANT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&homeMerchant);
			match = true;
		}
		if (equalsCI("HOME_BEACON",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&homeBeacon);
			match = true;
		}
		if (equalsCI("HOME_STARDOCK",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&homeStardock);
			match = true;
		}
		if (equalsCI("DB_PORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dbPort);
			match = true;
		}
		if (equalsCI("DB_HOST",line)) {
			i = readToken(data+ix,dbHost,'\n');
			match = true;
		}
		if (equalsCI("DB_USER",line)) {
			i = readToken(data+ix,dbUser,'\n');
			match = true;
		}
		if (equalsCI("DB_PASSWORD",line)) {
			i = readToken(data+ix,dbPasswd,'\n');
			match = true;
		}
		if (equalsCI("DB_NAME",line)) {
			i = readToken(data+ix,dbName,'\n');
			match = true;
		}
		if (equalsCI("DB_TABLE",line)) {
			i = readToken(data+ix,dbTable,'\n');
			match = true;
		}
		if (equalsCI("ARENA_NAME",line)) {
			i = readToken(data+ix,arenaName,'\n');
			match = true;
		}
		if (equalsCI("ARENA_VERSION",line)) {
			sscanf(temp,"%d",&arenaVersion);
			match = true;
		}
		if (equalsCI("DD_DMG_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_dmg_mod);
			match = true;
		}
		if (equalsCI("DD_BEACON_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_beacon_mod);
			match = true;
		}
		if (equalsCI("DD_STARDOCK_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_stardock_mod);
			match = true;
		}
		if (equalsCI("DD_MERCHANT_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_merchant_mod);
			match = true;
		}
		if (equalsCI("DD_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_ind_mod);
			match = true;
		}
		if (equalsCI("DD_DAMAGE_TYPE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_dmg_type);
			match = true;
		}
		if (equalsCI("DD_DESTROY_WORLD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_destroy_world);
			match = true;
		}
		if (equalsCI("DD_TELEPORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_teleport);
			match = true;
		}
		if (equalsCI("DD_DAMAGE_DARTS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dd_damage_darts);
			match = true;
		}
		if (equalsCI("START_FRIGATE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&start_frigate);
			match = true;
		}
		if (equalsCI("START_SLOOP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&start_sloop);
			match = true;
		}
		if (equalsCI("START_RANGER",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&start_ranger);
			match = true;
		}
		if (equalsCI("START_CORSAIR",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&start_corsair);
			match = true;
		}
		if (equalsCI("MERCHANT_BONUS_TYPE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&merchantBonusType);
			match = true;
		}
		if (equalsCI("BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&beaconBonus);
			match = true;
		}
		if (equalsCI("STARDOCK_FLEET_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stardockFleetBonus);
			match = true;
		}
		if (equalsCI("STARDOCK_WORLD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stardockWorldBonus);
			match = true;
		}
		if (equalsCI("MIN_NUM_COREWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumCoreWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_POORWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumPoorWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_RICHWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumRichWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_SMALLWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumSmallWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_LARGEWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumLargeWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_AQUATICWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumAquaticWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_MOUNTAINWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumMountainWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_DESERTWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumDesertWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_TUNDRAWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumTundraWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_JUNGLEWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumJungleWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_METALLICWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumMetallicWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_MERCHANTWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumMerchantWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_BEACONWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumBeaconWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_STARDOCKWORLD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumStardockWorld);
			match = true;
		}
		if (equalsCI("MIN_NUM_NEBULAE",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumNebulae);
			match = true;
		}
		if (equalsCI("MIN_NUM_NEUTRON",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumNeutron);
			match = true;
		}
		if (equalsCI("MIN_NUM_GATEWAY",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumGateway);
			match = true;
		}
		if (equalsCI("MIN_NUM_WORMHOLE",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumWormhole);
			match = true;
		}
		if (equalsCI("CORE_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&coreWorldPercent);
			match = true;
		}
		if (equalsCI("POOR_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&poorWorldPercent);
			match = true;
		}
		if (equalsCI("RICH_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&richWorldPercent);
			match = true;
		}
		if (equalsCI("SMALL_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&smallWorldPercent);
			match = true;
		}
		if (equalsCI("LARGE_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&largeWorldPercent);
			match = true;
		}
		if (equalsCI("AQUATIC_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&aquaticWorldPercent);
			match = true;
		}
		if (equalsCI("MOUNTAIN_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&mountainWorldPercent);
			match = true;
		}
		if (equalsCI("DESERT_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&desertWorldPercent);
			match = true;
		}
		if (equalsCI("TUNDRA_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&tundraWorldPercent);
			match = true;
		}
		if (equalsCI("JUNGLE_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&jungleWorldPercent);
			match = true;
		}
		if (equalsCI("METALLIC_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&metallicWorldPercent);
			match = true;
		}
		if (equalsCI("MERCHANT_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&merchantWorldPercent);
			match = true;
		}
		if (equalsCI("BEACON_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&beaconWorldPercent);
			match = true;
		}
		if (equalsCI("STARDOCK_WORLD_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stardockWorldPercent);
			match = true;
		}
		if (equalsCI("NEBULAE_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&nebulaePercent);
			match = true;
		}
		if (equalsCI("NEUTRON_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&neutronPercent);
			match = true;
		}
		if (equalsCI("GATEWAY_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&gatewayPercent);
			match = true;
		}
		if (equalsCI("WORMHOLE_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&wormholePercent);
			match = true;
		}
		if (equalsCI("ALLOW_HOME_WORLDS",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&allowHomeWorlds);
			match = true;
		}
		if (equalsCI("MIN_DARTS_PER_CORE",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minDartsPerCore);
			match = true;
		}
		if (equalsCI("MIN_DARTS_PER_HOME",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minDartsPerHome);
			match = true;
		}
		if (equalsCI("MIN_DARTS_PER_OE",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minDartsPerOE);
			match = true;
		}
		if (equalsCI("DARTS_PER_CORE_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dartsPerCorePercent);
			match = true;
		}
		if (equalsCI("DARTS_PER_HOME_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dartsPerHomePercent);
			match = true;
		}
		if (equalsCI("DARTS_PER_OE_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dartsPerOEPercent);
			match = true;
		}
		if (equalsCI("DART_PERCENT",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&dartPercent);
			match = true;
		}
		if (equalsCI("MIN_NUM_DARTS",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minNumDarts);
			match = true;
		}
		if (equalsCI("OE_STARTS_DEAD",line)) {
			i=readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&oeStartsDead);
			match = true;
		}
		if (equalsCI("ALLOW_MULTIPLE_FACILITIES",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&allowMultipleFacilities);
			match = true;
		}
		if (equalsCI("FACILITY_VARIATION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&facilityVariation);
			match = true;
		}
		if (equalsCI("FACILITY_COST_TYPE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&facilityCostType);
			match = true;
		}
		if (equalsCI("MERCHANT_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&merchantCost);
			match = true;
		}
		if (equalsCI("BEACON_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&beaconCost);
			match = true;
		}
		if (equalsCI("STARDOCK_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stardockCost);
			match = true;
		}
		if (equalsCI("DOOMSDAY_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&doomsdayCost);
			match = true;
		}
		if (equalsCI("STELLURAE_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stelluraeCost);
			match = true;
		}
		if (equalsCI("SHIELD_COST",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&shieldCost);
			match = true;
		}
		if (equalsCI("SHIELD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&shieldBonus);
			match = true;
		}
		if (equalsCI("HW_DECLARE_FOR_ALL",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&hwDeclareForAll);
			match = true;
		}
		if (equalsCI("TIME_SHIFT_SESSION_HOURS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&timeShiftSessionHours);
			match = true;
		}
		if (equalsCI("TIME_SHIFT_SKIP_DAYS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&timeShiftSkipDays);
			match = true;
		}
		if (equalsCI("ECM_OE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmOE);
			match = true;
		}
		if (equalsCI("ECM_HOME",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmHome);
			match = true;
		}
		if (equalsCI("ECM_CORE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmCore);
			match = true;
		}
		if (equalsCI("ECM_MIN",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmMin);
			match = true;
		}
		if (equalsCI("ECM_MAX",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmMax);
			match = true;
		}
		if (equalsCI("ECM_POP_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&ecmPopBonus);
			match = true;
		}
		if (equalsCI("HUMAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtHuman]);
			match = true;
		}
		if (equalsCI("MAKLUVIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtMakluvian]);
			match = true;
		}
		if (equalsCI("KALETIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtKaletian]);
			match = true;
		}
		if (equalsCI("ZORESTIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtZorestian]);
			match = true;
		}
		if (equalsCI("AVARIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtAvarian]);
			match = true;
		}
		if (equalsCI("NAJUNIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtNajunian]);
			match = true;
		}
		if (equalsCI("CESTANIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtCestanian]);
			match = true;
		}
		if (equalsCI("QUARETHIAN_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBuildModifier[rtQuarethian]);
			match = true;
		}
		if (equalsCI("HUMAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtHuman]);
			match = true;
		}
		if (equalsCI("MAKLUVIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtMakluvian]);
			match = true;
		}
		if (equalsCI("KALETIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtKaletian]);
			match = true;
		}
		if (equalsCI("ZORESTIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtZorestian]);
			match = true;
		}
		if (equalsCI("AVARIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtAvarian]);
			match = true;
		}
		if (equalsCI("NAJUNIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtNajunian]);
			match = true;
		}
		if (equalsCI("CESTANIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtCestanian]);
			match = true;
		}
		if (equalsCI("QUARETHIAN_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceDecayModifier[rtQuarethian]);
			match = true;
		}
		if (equalsCI("HUMAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtHuman]);
			match = true;
		}
		if (equalsCI("MAKLUVIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%f",&raceScoreDartChance[rtMakluvian]);
			match = true;
		}
		if (equalsCI("KALETIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtKaletian]);
			match = true;
		}
		if (equalsCI("ZORESTIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtZorestian]);
			match = true;
		}
		if (equalsCI("AVARIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtAvarian]);
			match = true;
		}
		if (equalsCI("NAJUNIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtNajunian]);
			match = true;
		}
		if (equalsCI("CESTANIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtCestanian]);
			match = true;
		}
		if (equalsCI("QUARETHIAN_SCORE_DART_CHANCE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceScoreDartChance[rtQuarethian]);
			match = true;
		}
		if (equalsCI("HUMAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtHuman]);
			match = true;
		}
		if (equalsCI("MAKLUVIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtMakluvian]);
			match = true;
		}
		if (equalsCI("KALETIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtKaletian]);
			match = true;
		}
		if (equalsCI("ZORESTIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtZorestian]);
			match = true;
		}
		if (equalsCI("AVARIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtAvarian]);
			match = true;
		}
		if (equalsCI("NAJUNIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtNajunian]);
			match = true;
		}
		if (equalsCI("CESTANIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtCestanian]);
			match = true;
		}
		if (equalsCI("QUARETHIAN_BEACON_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceBeaconModifier[rtQuarethian]);
			match = true;
		}
		if (equalsCI("HUMAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtHuman]);
			match = true;
		}
		if (equalsCI("MAKLUVIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtMakluvian]);
			match = true;
		}
		if (equalsCI("KALETIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtKaletian]);
			match = true;
		}
		if (equalsCI("ZORESTIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtZorestian]);
			match = true;
		}
		if (equalsCI("AVARIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtAvarian]);
			match = true;
		}
		if (equalsCI("NAJUNIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtNajunian]);
			match = true;
		}
		if (equalsCI("CESTANIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtCestanian]);
			match = true;
		}
		if (equalsCI("QUARETHIAN_COMMAND_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceCommandModifier[rtQuarethian]);
			match = true;
		}
		if (equalsCI("RACE_SECTOR_BUILD_MODIFIER",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&raceSectorBuildModifier);
			match = true;
		}
		if (equalsCI("SPECIAL_WORLD_SHIP_MODIFIER",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&specialWorldShipModifier);
			match = true;
		}
		if (equalsCI("STATIONS_ONLY",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&stationsOnly);
			match = true;
		}
		if (equalsCI("MAX_POP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxPop);
			match = true;
		}
		if (equalsCI("MIN_POP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&minPop);
			match = true;
		}
		if (equalsCI("CORE_POP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&corePop);
			match = true;
		}
		if (equalsCI("HOME_POP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&homePop);
			match = true;
		}
		if (equalsCI("OE_POP",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&oePop);
			match = true;
		}
		if (equalsCI("SMALL_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&smallIndMod);
			match = true;
		}
		if (equalsCI("POOR_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&poorIndMod);
			match = true;
		}
		if (equalsCI("NORMAL_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&normalIndMod);
			match = true;
		}
		if (equalsCI("RICH_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&richIndMod);
			match = true;
		}
		if (equalsCI("LARGE_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&largeIndMod);
			match = true;
		}
		if (equalsCI("CORE_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&coreIndMod);
			match = true;
		}
		if (equalsCI("HOME_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&homeIndMod);
			match = true;
		}
		if (equalsCI("OE_IND_MOD",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&oeIndMod);
			match = true;
		}
		if (equalsCI("STARDART_SCORE_MODIFIER",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%lf",&starDartScoreModifier);
			match = true;
		}
		if (equalsCI("WORLD_BUILD_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&worldBuildBonus);
			match = true;
		}
		if (equalsCI("WORLD_DECAY_BONUS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&worldDecayBonus);
			match = true;
		}
		if (!match) {
			i = search(data+ix,"\n");
		}

		if (i<0) break;

		ix += i;
	}

//--- cleanup ---
	gLog.logMsg(Log::LOG_INFO, 2010, "Space Domination Version 2.2 Configuration Values:");
	gLog.logMsg(Log::LOG_INFO, 2020, "DATA_PATH=%s",dataPath);
	gLog.logMsg(Log::LOG_INFO, 2030, "HTML_PATH=%s",htmlPath);
	gLog.logMsg(Log::LOG_INFO, 2040, "PORT=%d",portNum);
	gLog.logMsg(Log::LOG_INFO, 2050, "MAX_PLAYERS=%d",maxPlayers);
	gLog.logMsg(Log::LOG_INFO, 2060, "FLEET_ATTRITION=%d",fleetDecayRate);
	gLog.logMsg(Log::LOG_INFO, 2070, "WORLD_ATTRITION=%d",worldDecayRate);
	gLog.logMsg(Log::LOG_INFO, 2080, "VICTORY_BASE=%d",victoryBase);
	gLog.logMsg(Log::LOG_INFO, 2090, "MOVEMENT=%d",movePixels);
	gLog.logMsg(Log::LOG_INFO, 2100, "COMMAND_BUILD=%d",commandBuild);
	gLog.logMsg(Log::LOG_INFO, 2110, "COMMAND_BONUS=%d",commandBonus);
	gLog.logMsg(Log::LOG_INFO, 2120, "MERCHANT_BONUS=%d",merchantBonus);
	gLog.logMsg(Log::LOG_INFO, 2130, "MIN_WORLDS=%d",minWorlds);
	gLog.logMsg(Log::LOG_INFO, 2140, "MAX_WORLDS=%d",highWorlds);
	gLog.logMsg(Log::LOG_INFO, 2150, "DROP_HOURS=%d",dropHours);
	gLog.logMsg(Log::LOG_INFO, 2160, "FIRST_EARTH_DECLARE_RATIO=%d",firstEarthDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2170, "FIRST_HOME_DECLARE_RATIO=%d",firstHomeDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2180, "FIRST_PHENOMENA_DECLARE_RATIO=%d",firstPhenomenaDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2190, "FIRST_HOME_PHENOMENA_DECLARE_RATIO=%d",firstHomePhenomenaDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2200, "LATER_EARTH_DECLARE_RATIO=%d",laterEarthDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2210, "LATER_HOME_DECLARE_RATIO=%d",laterHomeDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2220, "LATER_PHENOMENA_DECLARE_RATIO=%d",laterPhenomenaDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2230, "LATER_HOME_PHENOMENA_DECLARE_RATIO=%d",laterHomePhenomenaDeclareRatio);
	gLog.logMsg(Log::LOG_INFO, 2240, "MAX_SPEED=%d",maxSpeed);
	gLog.logMsg(Log::LOG_INFO, 2270, "TIMEOUT_SECONDS=%d",timeoutSeconds);
	gLog.logMsg(Log::LOG_INFO, 2280, "EARTH_MERCHANTS=%d",earthMerchant);
	gLog.logMsg(Log::LOG_INFO, 2290, "EARTH_BEACONS=%d",earthBeacon);
	gLog.logMsg(Log::LOG_INFO, 2300, "EARTH_STARDOCKS=%d",earthStardock);
	gLog.logMsg(Log::LOG_INFO, 2320, "CORE_MERCHANTS=%d",coreMerchant);
	gLog.logMsg(Log::LOG_INFO, 2330, "CORE_BEACONS=%d",coreBeacon);
	gLog.logMsg(Log::LOG_INFO, 2340, "CORE_STARDOCKS=%d",coreStardock);
	gLog.logMsg(Log::LOG_INFO, 2360, "HOME_MERCHANTS=%d",homeMerchant);
	gLog.logMsg(Log::LOG_INFO, 2370, "HOME_BEACONS=%d",homeBeacon);
	gLog.logMsg(Log::LOG_INFO, 2380, "HOME_STARDOCKS=%d",homeStardock);
	gLog.logMsg(Log::LOG_INFO, 2400, "DB_PORT=%d",dbPort);
	gLog.logMsg(Log::LOG_INFO, 2410, "DB_HOST=%s",dbHost);
	gLog.logMsg(Log::LOG_INFO, 2420, "DB_USER=%s",dbUser);
	gLog.logMsg(Log::LOG_INFO, 2430, "DB_PASSWORD=%s",dbPasswd);
	gLog.logMsg(Log::LOG_INFO, 2440, "DB_NAME=%s",dbName);

	free(data);
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 2450, "Leave readInitFile()");
	return true;
}

//**********************************************************************
