//**********************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant
#include <math.h>

//**********************************************************************************
//**********************************************************************************

extern	void FirstVictoryRecord(void);

void CreateGalaxy(int wcount);
void MakeName(worldRec *worlds,int index);
int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start);
void killAllSessions(void);
void calcVictoryStats(void);

//**********************************************************************************

const char *empireFile="Empires.dat";
const char *fleetFile="Fleets.dat";
const char *worldFile="Galaxy.dat";
const char *victoryFile="Victors.dat";

char empirePath[256],fleetPath[256],worldPath[256],victoryPath[256];

CLists *empireList=NULL,*worldList=NULL,*fleetList=NULL;
CRecords *victoryList=NULL;

int worldFleetPos[stCOUNT] = {
	posDefendMid,posDefendTop,posDefendTop,
	posInvadeMid,posInvadeTop,posInvadeBot,
};

int maxEmpireScore,victoryDate,victoryTime,victoryPercent;

//**********************************************************************************
//**********************************************************************************

bool resetGalaxy(int goal){
int count;

	RecordVictory();

	if (goal<minWorlds) goal = minWorlds;

	if (empireList!=NULL) {
//		count = empireList->getCount();
//		count *= worldsPlayer;
		count = Rand(highWorlds - minWorlds) + minWorlds;
		if (count>goal) goal = count;
		empireList->clear();
	}
	if (fleetList!=NULL) fleetList->clear();
	if (worldList!=NULL) worldList->clear();

	printf("RESETTING = %d\n",goal);
	cleanupGalaxy();

	if (sroot!=NULL) {		// kill outstanding sessions
		delete sroot;
		sroot = new SessionList();
	}

	if (goal>highWorlds) goal = highWorlds;
	return prepareGalaxy(goal);
}


bool prepareGalaxy(int wcount){		// called during startup+reset
empireRec *emp;
int worlds,darts;

	emp = NULL;

	if (empireList==NULL) {
		sprintf(empirePath,"%s/%s",dataPath,empireFile);
		empireList = new CLists(empirePath,sizeof(empireRec));

		if (empireList->getCount()<1) empireList->increment();
		emp = (empireRec*)empireList->getRecord(0);

		if (emp!=NULL) {
			memset(emp,0,sizeof(empireRec));
			strcpy(emp->name,"Neutral");
			strcpy(emp->pass,"np");
			emp->worlds = wcount;
			emp->darts = wcount / 25;
		}

		empireList->save();
	}

	if (fleetList==NULL) {
		sprintf(fleetPath,"%s/%s",dataPath,fleetFile);
		fleetList = new CLists(fleetPath,sizeof(fleetRec));
		fleetList->save();
	}

	if (worldList==NULL) {
		sprintf(worldPath,"%s/%s",dataPath,worldFile);
		worldList = new CLists(worldPath,sizeof(worldRec));
		worldList->save();
	}

	if (victoryList==NULL){
		sprintf(victoryPath,"%s/%s",dataPath,victoryFile);
		victoryList = new CRecords(victoryPath,0,sizeof(victoryRec));
		if (victoryList->getCount()<1) FirstVictoryRecord();
		calcVictoryStats();
	}

//--- rebuild world ---
	if (worldList->getCount()<1) CreateGalaxy(wcount);

	worlds = worldList->getCount();
	darts = CalcDarts(worlds);

	worlds -= CalcNeutron(worlds) + CalcNebulae(worlds) + CalcGates(worlds) + CORECOUNT + 1;
	worlds += EarthValue(worlds) + CORECOUNT * CoreValue(worlds);
	maxEmpireScore = (worlds + (darts * darts)) * 1000;

	return true;
}


void cleanupGalaxy(){
	if (empireList!=NULL) {delete empireList;empireList=NULL;}
	if (fleetList!=NULL) {delete fleetList;fleetList=NULL;}
	if (worldList!=NULL) {delete worldList;worldList=NULL;}
}

void calcVictoryStats(){
victoryRec *vrp;
int count;

	count = victoryList->getCount();
	if (victoryList->pickIndex(count-1)) {
		vrp = (victoryRec*)victoryList->getRecord();
		victoryDate = vrp->getDate();
		victoryTime = vrp->getTime();
	}
	else {
		victoryDate = dateIndex();
		victoryTime = secondsSinceMidnight();
	}
}

//**********************************************************************************

void CreateGalaxy(int wcount){
int ix,i,pos,num;
worldRec *worlds,*wp;
fleetRec *fleets,*fp;
int locRoot;

	printf("\nBuilding New Galaxy\n");
	srand(time(NULL));

	worldList->expand(wcount);
	worlds = (worldRec*)worldList->getList();
	memset(worlds, 0, worldList->getCount() * sizeof(worldRec));

	fleetList->expand(wcount);
	fleets = (fleetRec*)fleetList->getList();
	memset(fleets, 0, fleetList->getCount() * sizeof(fleetRec));

//--- Create Earth ---
	wp = &worlds[0];

	printf("Making=%d",0);
	wp->pop = 200;
	wp->ind = 1200;
	wp->type = wtHome;
	wp->minerals = 3;
	wp->Merchant = wp->pop;
	wp->maxMerchant = wp->pop;
	wp->Beacon = wp->pop / 4;
	wp->maxBeacon = wp->pop / 4;
	wp->Stardock = wp->pop / 2;
	wp->maxStardock = wp->pop / 2;

	strcpy(wp->name,"Old Earth");
	for (i=0;i<btIndustry;i++) {
		wp->cmd[i].repeat = true;
		wp->cmd[i].type = i;
		wp->cmd[i].goal = cost[stFrigate] / cost[i];
	}
	printf(" (%s)\n",wp->name);

	fp = &fleets[0];

	fp->ecm = 25000;

	for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
	for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,100*decayRate/cost[i]);
	for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;

//--- Core Worlds ---
	locRoot = MINDIST;

	for (ix=1;ix<=CORECOUNT;ix++) {
		printf("Making=%d",ix);

		wp = &worlds[ix];

	//--- world record ---
		wp->pop = 100;
		wp->ind = 600;
		wp->type = wtCore;
		wp->minerals = 3;
		wp->Merchant = wp->pop / 10;
		wp->maxMerchant = wp->pop / 5;
		wp->Beacon = wp->pop / 20;
		wp->maxBeacon = wp->pop / 20;
		wp->Stardock = wp->pop / 10;
		wp->maxStardock = wp->pop / 10;

		MakeName(worlds,ix);
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
		printf(" (%s)\n",wp->name);

		for (i=0;i<btIndustry;i++) {
			wp->cmd[i].repeat = true;
			wp->cmd[i].type = i;
			wp->cmd[i].goal = cost[stFrigate] / cost[i];
		}

	//--- fleet record ---
		fp = &fleets[ix];

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;

		fp->ecm = 10000;

		for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
		for (i=0;i<stStarDart;i++) buildFleetShips(fp,i,40*decayRate/cost[i]);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
	}

//--- The Remaining Cluster ---
	for (;ix<wcount;ix++) {
printf("Making=%d",ix);

		wp = &worlds[ix];

	//--- world record ---
		wp->type = Rand32();
		if (wp->type<=wtCore || wp->type>=wtNebulae) wp->type = wtNormal;

		wp->pop = 99 - 90*ix/wcount;
		wp->ind = Rand(201) * wp->pop / 100;	// up to x2
		wp->minerals = Rand(4);

		wp->Merchant = 0;

		if (wp->type==wtMerchant) {
			wp->maxMerchant = wp->pop / 5;
		}
		else {
			wp->maxMerchant = wp->pop / 20;
		}

		wp->Beacon = 0;

		if (wp->type==wtBeacon) {
			wp->maxBeacon = wp->pop / 8;
		}
		else {
			wp->maxBeacon = (wp->pop / 10) - 7;
			if (wp->maxBeacon < 0) wp->maxBeacon = 0;
		}

		wp->Stardock = 0;

		if (wp->type==wtStardock) {
			wp->maxStardock = wp->pop / 5;
		}
		else {
			wp->maxStardock = (wp->pop / 10) - 4;
			if (wp->maxStardock < 0) wp->maxStardock = 0;
		}

		MakeName(worlds,ix);
		locRoot = MakeLocation(worlds,ix,&wp->xloc,&wp->yloc,locRoot);
printf(" (%s)\n",wp->name);

		if (wp->minerals == 0) {
			wp->cmd[0].repeat = true;
			wp->cmd[0].type = btStation;
			wp->cmd[0].goal = 10;
			wp->cmd[1].repeat = true;
			wp->cmd[1].type = btPinnace;
			wp->cmd[1].goal = 20;
		}
		else if (wp->minerals == 1) {
			wp->cmd[0].repeat = true;
			wp->cmd[0].type = btStation;
			wp->cmd[0].goal = 10;
			wp->cmd[1].repeat = true;
			wp->cmd[1].type = btPinnace;
			wp->cmd[1].goal = 20;
			if (wp->pop >= 50) {
				wp->cmd[2].repeat = true;
				wp->cmd[2].type = btCorsair;
				wp->cmd[2].goal = 4;
			}
		}
		else if (wp->minerals >= 2) {
			wp->cmd[0].repeat = true;
			wp->cmd[0].type = btStation;
			wp->cmd[0].goal = 10;
			wp->cmd[1].repeat = true;
			wp->cmd[1].type = btPinnace;
			wp->cmd[1].goal = 20;
			if (wp->pop >= 50) {
				wp->cmd[2].repeat = true;
				wp->cmd[2].type = btCorsair;
				wp->cmd[2].goal = 4;
				wp->cmd[3].repeat = true;
				wp->cmd[3].type = btRanger;
				wp->cmd[3].goal = 4;
			}
		}

	//--- fleet record ---

		Sleep(10);

		fp = &fleets[ix];

		fp->xloc = wp->xloc;
		fp->yloc = wp->yloc;
		fp->destID = ix;
		fp->ecm = Rand(101) - Rand(101);

		for (i=0;i<posCOUNT;i++) fp->squad[i].type = stCOUNT;
		buildFleetShips(fp,stStation,(wp->pop+wp->ind)*decayRate/cost[stStation]);
		for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
	}

//--- add 8 nebulae + 6 gravity wells + 4 gateways ---
	num = CalcNebulae(wcount);
	//num = wcount / 30;
printf("Nebulaes = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = 13 + Rand(wcount-13);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtNebulae;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

	num = CalcNeutron(wcount);
printf("Neutrons = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = 13 + Rand(wcount-13);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtNeutron;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

	num = CalcGates(wcount);
printf("Gateways = %d\n",num);
	for (i=0;i<num;i++) {
		do ix = 13 + Rand(wcount-13);
		while (!isPlanet(worlds[ix].type));
		worlds[ix].type = wtGateway;
		for (pos=0;pos<posCOUNT;pos++) {
			fleets[ix].squad[pos].type = stCOUNT;
			fleets[ix].squad[pos].count = 0;
		}
	}

	num = CalcDarts(wcount);
printf("StarDarts = %d\n",num);

	i = (num+9) / 10;
	addFleetShips(&fleets[0],stStarDart,i);		// 10% of Darts to earth

	for (;i<num;i++) {
		do ix = 13 + Rand(wcount-13);
		while (!isPlanet(worlds[ix].type));
		addFleetShips(&fleets[ix],stStarDart,1);
	}

//--- cleanup ---
	worldList->save();
	fleetList->save();
}

//**********************************************************************************

const char *vowels = "aaaiiueeeoy";
const char *cons = "bcdfghjklmnpqrstvwxz";
const int vlen = strlen(vowels);
const int clen = strlen(cons);
inline char RandVowel(){return vowels[Rand(vlen)];}
inline char RandCons(){return cons[Rand(clen)];}


void MakeName(worldRec *worlds,int index){
int ix,num,i;
char *name;

	name = worlds[index].name;

	while (true) {

	//--- build name ---
		ix = 0;
		num = 1+Rand(2)+Rand(3)/2+Rand(4)/3;

		if (Rand(3)==0) name[ix++] = RandVowel();
		for (i=0;i<num;i++) {
			name[ix++] = RandCons();
			name[ix++] = RandVowel();
		}
		if (Rand(2)==0) name[ix++] = RandCons();
		name[ix++] = 0;

		name[0] = name[0] - 'a' + 'A';	// capitolize

	//--- compare name ---
		for (i=0;i<index;i++) {
			if (equals(worlds[i].name,name)) break;
		}
		if (i==index) return;	// no matches
	}
}


void FleetLocation(int *xloc,int *yloc){
worldRec *worlds,*wp;
int sx,sy,min,val,i,count;
float dx,dy;

	worlds = (worldRec*)worldList->getList();
	count = worldList->getCount();

	while (true) {

		wp = &worlds[count*4/5 + Rand(count/5)];

		sx = wp->xloc + Rand(MINDIST) - MINDIST/2;
		sy = wp->yloc + Rand(MINDIST) - MINDIST/2;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST/2) continue;
		if (min>MINDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		return;
	}
}


int MakeLocation(worldRec *worlds,int count,int *xloc,int *yloc,int start){
int cx,cy,sx,sy,range,min,i,val;
float dx,dy;

//-- calculate galactic center ---
	dx = dy = 0.0;
	for (i=0;i<count;i++) {
		dx += worlds[i].xloc;
		dy += worlds[i].yloc;
	}

	if (count>0) {
		cx = (int)(dx / count);
		cy = (int)(dy / count);
	}
	else cx = cy = 0;

//--- start testing random locations --- 
	range = start * 3 / 4;

	while (true) {

		sx = BRand(range) - range/2 - cx;
		sy = BRand(range) - range/2 - cy;

		min = 0x7fffffff;

		for (i=0;i<count;i++) {
			dx = (float)(worlds[i].xloc - sx);
			dy = (float)(worlds[i].yloc - sy);
			val = (int)sqrt(dx * dx + dy * dy);
			if (val<min) min = val;
		}

		if (min<MINDIST) {
			range += MINDIST;
			continue;
		}
		if (min>MAXDIST) continue;
		
		*xloc = sx;
		*yloc = sy;
		break;
	}

	return range;
}

//**********************************************************************************

static int startCount[stCOUNT] = {200,40,10,0,0,0};
static int startType[stCOUNT] = {stPinnace,stCorsair,stFrigate,stCOUNT,stCOUNT,stCOUNT};


bool CreateEmpire(char *name,char *pass){
fleetRec *fp;
empireRec *emp;
int empireID;

//--- create empire ---
	empireID = empireList->increment();

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return false;

	memset(emp,0,sizeof(empireRec));
	strcpy(emp->name,name);
	strcpy(emp->pass,pass);
	emp->ruler = -1;
	emp->fleetID = fleetList->increment();
	emp->Merchant = 0;
	emp->Beacon = 0;

	empireList->save(empireID);

//--- create fleet ---
	fleetList->increment();
	fp = (fleetRec*)fleetList->getRecord(emp->fleetID);
	if (fp==NULL) return false;

	CreateFleet(fp,empireID);

	fleetList->save(emp->fleetID);
	
//--- cleanup ---
	return true;
}


void CreateFleet(fleetRec *fp,int empireID){
int i;

	memset(fp,0,sizeof(fleetRec));
	fp->empireID = empireID;

	FleetLocation(&fp->xloc,&fp->yloc);

	fp->destID = -1;
	for (i=0;i<stCOUNT;i++) {
		fp->squad[i].count = startCount[i];
		fp->squad[i].type = startType[i];
	}
	for (i=0;i<sideCOUNT;i++) fp->engageID[i] = -1;
}

//**********************************************************************************
