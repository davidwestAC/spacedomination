#ifndef _FFI_STRING_
#define _FFI_STRING_
#include <string.h>

//**********************************************************************

extern	char *clone(char *s);
extern	void clone(char **buf,char *s);
extern	bool equals(char *s1,char *s2);
extern	bool equalsCI(char *s1,char *s2);	// case insensitive
extern	bool match(char *s1,char *s2);
extern	bool matchCI(char *s1,char *s2);
extern	int search(char *area,char *find);
extern	int searchCI(char *area,char *find);
extern	int find(char *area,char *find);
extern	int readToken(char *area,char *dest,char stop);
extern	int dcToken(char *area,char *dest);
extern	int readNumber(char *area,int *val);
extern	void bigNumber(char *str,int num);

//**********************************************************************
#endif _FFI_STRING_