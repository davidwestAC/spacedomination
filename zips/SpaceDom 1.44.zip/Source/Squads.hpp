//***********************************************************************************
//
//***********************************************************************************
#include "FFItypes.hpp"

//***********************************************************************************

enum ShipTypes {
	stPinnace,stCorsair,stFrigate,
	stStation,stRanger,stStarDart,
	stCOUNT
};
const int guns[stCOUNT] = {1,5,20,6,4,100};
const int cost[stCOUNT] = {5,25,100,25,25,10};

const int FireTimer[stCOUNT] = {6,9,12,8,10,20};
const int MOVE_TIMER = 5;

const int RANGER_BONUS = 20;		// + 20% effect

const int attack[stCOUNT][stCOUNT] = {
	{2,1,3,2,2,3},		// pinnace	60 * 2 / 6 = 20
	{4,3,3,3,3,2},		// corsair	60 * 3 / 9 = 20
	{3,6,4,6,5,4},		// frigate	60 * 4 / 12 = 20
	{4,3,2,3,3,2},		// station	60 * 3 / 8 = 20
	{3,2,2,2,2,2},		// ranger	60 * 3 / 10 = 20
	{5,10,7,10,8,7},	// stardart	60 * 7 / 20 = 20
};

enum SquadActions {
	actDefend,
	actFireInvTop,actFireInvMid,actFireInvBot,
	actFireDefTop,actFireDefMid,actFireDefBot,
	actMoveUp,actMoveDown,actMoveLeft,actMoveRight,
	actCOUNT
};
inline bool isMoveAction(int action){return (action>=actMoveUp);}
inline bool isFireAction(int action){return (action>actDefend && action<actMoveUp);}

//***********************************************************************************

class Squads {
	private:
		int		_count;
		byte	_type,_damage,_action,_timer;

	public:
		inline int count(){return _count;}
		inline int type(){return _type;}
		inline int action(){return _action;}
		inline int timer(){return _timer;}

		inline void setCount(int val){count=val;}
		inline void setCount(int val){count=val;}
		inline void setCount(int val){count=val;}
		inline void setCount(int val){count=val;}

		void setAction(int action){
			_action = action;
			if (_action==actDefend)		sp->timer = 0;
			else if (_action<actMoveUp)	sp->timer = FireTimer[sp->type];
			else						sp->timer = MOVE_TIMER;
		}
};

//**********************************************************************************


//**********************************************************************************

