import java.awt.*;

class Date {

	final static int yearDays = 365;
	final static int leapDays = 4*yearDays + 1;


	final static int[] daysPerMonth = {
		31,28,31,30,31,30,
		31,31,30,31,30,31
	};
	final static int[] daysToMonth = {
		0,31,59,90,120,151,
		181,212,243,273,304,334,
	};

	int CDays,CSecs;

//--- constructor ---
	public Date(int d,int s){CDays=d;CSecs=s;}


//--- public functions ---
	public String toString(){
	int hours,minutes,seconds;
	int year,month,days,val;
	String msg;

	//--- calc years ---
		days = CDays;
		val = days / leapDays;
		days -= val * leapDays;
		year = val * 4;

		if (days>yearDays+1) {	// year 0 is a leap year, kinda
			days -= yearDays+1;
			year++;
		}

		while (days>yearDays) {
			days -= yearDays;
			year++;
		}

	//--- calc days ---
		for (month=0;month<12;month++) {
			val = daysPerMonth[month];
			if (val>days) break;
			days -= val;
		}
		month++;
		days++;

		msg = ""+month+"/"+days+"/"+(year%100)+"  ";

	//--- hours, minutes, seconds ---
		seconds = CSecs;
		minutes = seconds/60;
		hours = minutes / 60;
	
		seconds = seconds % 60;
		minutes = minutes % 60;
		hours = hours % 24;

		msg += (hours%12)+":"+(minutes/10)+(minutes%10)+" "+(hours>=12?"PM":"AM");

		return msg;
	}

	
	public String lengthStr(){
	int days,hours,minutes,seconds;
	String msg;

		seconds = CSecs;
		minutes = seconds/60;
		hours = minutes / 60;
		days = hours / 24;

		seconds = seconds % 60;
		minutes = minutes % 60;
		hours = hours % 24;

		msg = "";
		if (days>0) msg += days+" Days  ";
		if (hours>0) msg +=hours+" Hours  ";
		if (minutes>0) msg += minutes+" Minutes  ";
		if (seconds>0) msg += seconds+" Seconds";

		return msg;
	}
	
}