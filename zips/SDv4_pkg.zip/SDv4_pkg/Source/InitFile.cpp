//**********************************************************************
//	copyright 1998, Fred's Friends, Inc.
//**********************************************************************
#include "fileIO.hpp"
#include "string.hpp"
#include <stdio.h>

//**********************************************************************

const char *INITFILE = "SDserver.ini";

char *headTest = "[StarDart]\n";

char dataPath[128],htmlPath[128];
int portNum,maxPlayers,decayRate,victoryPercent,movePixels,commandBuild,worldSize;

//**********************************************************************

bool readInitFile(){
char line[1024],temp[256];
char *data;
int ix,i;

	dataPath[0] = 0;
	htmlPath[0] = 0;

	portNum=1965;
	decayRate = 200;
	victoryPercent = 50;
	commandBuild = 1000;
	movePixels = 150;
	worldSize = 1000;

//--- load & read file ---
	data = (char*)loadFile((char*)INITFILE);
	if (data==NULL) return false;

	i = search(data,headTest);
	if (i<0) return false;

	ix = i;
	while (true) {
		i = readToken(data+ix,line,'=');
		if (i<0) break;

		ix += i;

		if (equalsCI("DATAPATH",line)) {
			i = readToken(data+ix,dataPath,'\n');
		}
		else if (equalsCI("HTMLPATH",line)) {
			i = readToken(data+ix,htmlPath,'\n');
		}
		else if (equalsCI("PORT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&portNum);
		}
		else if (equalsCI("MAXPLAYERS",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&maxPlayers);
		}
		else if (equalsCI("ATTRITION",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&decayRate);
		}
		else if (equalsCI("VICTORY",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&victoryPercent);
		}
		else if (equalsCI("MOVEMENT",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&movePixels);
		}
		else if (equalsCI("COMMAND",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&commandBuild);
		}
		else if (equalsCI("UNIVERSE",line)) {
			i = readToken(data+ix,temp,'\n');
			sscanf(temp,"%d",&worldSize);
		}
		else {
			i = search(data+ix,"\n");
		}

		if (i<0) break;

		ix += i;
	}

//--- cleanup ---
	printf("StarDart v4 Configuration Values:\n");
	printf("DATAPATH=%s\n",dataPath);
	printf("HTMLPATH=%s\n",htmlPath);
	printf("PORT=%d\n",portNum);
	printf("MAXPLAYERS=%d\n",maxPlayers);
	printf("ATTRITION=%d\n",decayRate);
	printf("VICTORY=%d\n",victoryPercent);
	printf("MOVEMENT=%d\n",movePixels);
	printf("COMMAND=%d\n",commandBuild);
	printf("UNIVERSE=%d\n\n",worldSize);

	free(data);
	return true;
}

//**********************************************************************
