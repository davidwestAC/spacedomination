//****************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//****************************************************************************
#include "SDserver.hpp"

//****************************************************************************
//****************************************************************************

extern	void sendGlobalVictory(victoryRec *vrp);

void fixVictoryList(int date,int secs,empireRec *erp);
void fixVictoryHtml(int date,int secs,empireRec *erp);

//****************************************************************************

char *editPoint = "<!-- Top of List -->";

char *startVictoryHtml =
	"<html>\r\n"
	"<head><title>Star Dart Immortal Victors</title>\r\n"
	"</head>\r\n"
	"<body bgcolor=880088><center>\r\n"
	"<font size=8 color=yellow>Star Dart<br>\r\n"
	"Immortal Victors!</font><p>\r\n"
	"<font size=4 color=white>\r\n"
	"<!-- Top of List -->\r\n"
	"</center></body>\r\n"
	"</html>\r\n";

// todayStr, hour, 10min, 1min, AM/PM, name, 
// score, score%, worlds, worlds%, darts, darts% 
char *victoryStr = 
	"\r\n[%s %d:%d%d %s] <big>%s Empire</big> score <big>%d (%d%%)</big>"
	"\r\n\tworlds <big>%d (%d%%)</big> darts <big>%d (%d%%)</big><p>";

char *ampmStr[2] = {"AM","PM"};

//****************************************************************************
//****************************************************************************

void RecordVictory(){
empireRec *erp;
int date,secs;

	date = todayToDays();
	secs = secondsSinceMidnight();

	erp = (empireRec*)empireList->getRecord(top20List[0]);
	if (erp==NULL) return;

	fixVictoryList(date,secs,erp);
	fixVictoryHtml(date,secs,erp);
}


void FirstVictoryRecord(){
victoryRec vrec;

	memset(&vrec,0,sizeof(vrec));
	vrec.date = todayToDays();
	vrec.time = secondsSinceMidnight();
	victoryList->create(&vrec);
}

//****************************************************************************

void fixVictoryList(int date,int secs,empireRec *erp){
victoryRec vrec,*vrp;
int worlds,num;


	memset(&vrec,0,sizeof(vrec));
	strncpy(vrec.name,erp->name,MAXNAMESIZE);
	vrec.date = date;
	vrec.time = secs;

	vrec.worlds = erp->hiWorlds;
	vrec.darts = erp->hiDarts;
	vrec.score = erp->hiScore;
	vrec.race = 0;

	worlds = worldList->getCount();
	vrec.maxWorlds = worlds;
	vrec.maxDarts = CalcDarts(worlds);
	vrec.maxScore = maxEmpireScore;

	num = victoryList->getCount();
	if (victoryList->pickIndex(num-1)) {
		vrp = (victoryRec*)victoryList->getRecord();
		vrec.gameLength = (date - vrp->date) * 24 * 3600 + (secs - vrp->time);
	}

//--- cleanup ---
	victoryList->create(&vrec);
	sendGlobalVictory(&vrec);
}


void fixVictoryHtml(int date,int secs,empireRec *erp){
char *data,buf[256];
int split,length,maxWorlds,maxDarts,hours,minutes,ampm;
FILEID fd;

	data = loadFile(htmlPath);
	if (data==NULL || data[0]==0) clone(&data,startVictoryHtml);
	if (data==NULL) return;

	fd = openForReplace(htmlPath);
	if (badFileIndex(fd)) {
		free(data);
		return;
	}

//--- split file ---
	length = strlen(data);
	split = searchCI(data,editPoint);

	if (split>0) {
		fileWrite(fd,data,split);

		setTodaysDate();
		maxWorlds = worldList->getCount();
		maxDarts = CalcDarts(maxWorlds);

		minutes = (secs / 60) % 60;
		hours = secs / 3600;
		ampm = hours / 12;
		hours = hours % 12;

		sprintf(buf,victoryStr,
			todayStr,hours,minutes/10,minutes%10,ampmStr[ampm],
			erp->name,
			erp->hiScore,		erp->hiScore / (maxEmpireScore/100),
			erp->hiWorlds,		erp->hiWorlds * 100 / maxWorlds,
			erp->hiDarts,		erp->hiDarts * 100 / maxDarts);
		fileWrite(fd,buf,strlen(buf));
		
		fileWrite(fd,data+split,length-split);
	}

//--- cleanup ---
	fileClose(fd);
	free(data);
}

//****************************************************************************

