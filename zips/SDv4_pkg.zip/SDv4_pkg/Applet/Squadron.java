import java.awt.*;

class Squadron implements MessageValues {

	final static int STARDART = 5;
	final static int SHIP_TYPES = 6;
	final static String[] name = {
		"Sloop","Corsair","Frigate",
		"Station","Ranger","Star Dart",
		"<empty>"
	};
	final static int guns[] = {1,5,20,5,5,250,0};

	final static int INVADETOP = 0;
	final static int INVADEMID = 1;
	final static int INVADEBOT = 2;
	final static int DEFENDTOP = 3;
	final static int DEFENDMID = 4;
	final static int DEFENDBOT = 5;

//--- squadron combat actions ---
	public final static int DEFEND = 0;
	public final static int RETREAT = 1;

	public final static int MOVEUP = 2;
	public final static int MOVEDOWN = 3;
	public final static int MOVELEFT = 4;
	public final static int MOVERIGHT = 5;

	public final static int FIRE_SLOOP = 6;
	public final static int FIRE_CORSAIR = 7;
	public final static int FIRE_FRIGATE = 8;
	public final static int FIRE_STATION = 9;
	public final static int FIRE_RANGER = 10;
	public final static int FIRE_STARDART = 11;

//--- variables ---
	int position,count,type,damage,action,timer,enemy;

//--- constructors ---
	public Squadron(int pos){
		position = pos;
		type = SHIP_TYPES;
	}

	public int type(){return type;}
	public int count(){return count;}
	public int position(){return position;}
	public int damage(){return damage;}
	public int action(){return action;}
	public int timer(){return timer;}
	public String name(){return name[type];}

	public int guns(){return guns[type] * count - damage;}
	public int hits(){return guns[type];}

	public boolean isDefend(){return (action==DEFEND);}
	public boolean isRetreat(){return (action==RETREAT);}
	public boolean isMoving(){return (action>=MOVEUP && action<=MOVERIGHT);}
	public boolean isFiring(){return (action>=FIRE_SLOOP);}

//--- functions ---
	public void set(int pos,Buffer buf){
	int offset;

		offset = 18 + pos * 8;
		count = buf.getShort(offset+0);
		type = buf.unsigned(offset+2);
		damage = buf.unsigned(offset+3);
		action = buf.unsigned(offset+4);
		timer = buf.unsigned(offset+5);
		enemy = buf.unsigned(offset+6);
	}

//--- action functions ---
	public int Heading(){return (action-MOVEUP);}
	public int TargetType(){return (action-FIRE_SLOOP);}
	public boolean TargetInvade(){return (enemy==1);}

	public static int MakeFireAction(int type){return (FIRE_SLOOP+type);}
};