import java.awt.*;

class Buffer {

	byte[] buf;
	int size;

//--- constructors ---
	public Buffer(){
		buf = null;
		size = 0;
	}

	public Buffer(int sz){
		buf = new byte[sz];
		size = sz;
	}

	public Buffer(byte inbuf[],int sz){
		buf = inbuf;
		size = sz;
	}

//--- primary functions ---
	public void send(){StarDart.sessionOutput(this);}

	public int length(){return size;}
	public void length(int len){if (len>0 && len<size) size = len;}
	public byte get(int index){return buf[index];}
	public void set(int index,byte v){buf[index]=v;}
	public void set(int index,int v){buf[index]=(byte)v;}
	public byte[] buffer(){return buf;}

	public void trim(){
	byte[] temp;
	int len;

		len = unsigned(0);
		if (len==0 || len>=size) {
			size = 0;
			buf = null;
			return;
		}

		temp = buf;
		size -= len;
		buf = new byte[size];
		for (int ix=0;ix<size;ix++) buf[ix] = temp[len+ix];
	}

//--- functions ---
	public int unsigned(int index){
	byte b = buf[index];

		if (b>=0) return b;
		return 256 + b;
	}

	public void setInt(int index,int val){
		buf[index+0] = (byte)(val&0xff);
		buf[index+1] = (byte)((val>>8)&0xff);
		buf[index+2] = (byte)((val>>16)&0xff);
		buf[index+3] = (byte)((val>>24)&0xff);
	}

	public void setShort(int index,int val){
		buf[index+0] = (byte)(val&0xff);
		buf[index+1] = (byte)((val>>8)&0xff);
	}
	
	public int getInt(int index){
		return (buf[index+3]<<24) | (unsigned(index+2)<<16) | (unsigned(index+1)<<8) | unsigned(index+0);
	}
	
	public int getShort(int index){
		return (buf[index+1]<<8) | unsigned(index+0);
	}
	
	public int getUShort(int index){
		return (unsigned(index+1)<<8) | unsigned(index+0);
	}


	public void setString(int index,String msg){
	int i;
		for (i=0;i<msg.length();i++) buf[index+i] = (byte)msg.charAt(i);
		buf[index+i] = 0;

	}

	public String getString(int index){
	String msg = "";

		while (buf[index]!=0) msg += (char)(buf[index++]);
		return msg;
	}
};