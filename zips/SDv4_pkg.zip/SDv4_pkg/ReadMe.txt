//======================================================================
//	copyright 2001, Fred's Friends, Inc.
//	StarDart v4 installation package
//======================================================================
This Package Contains 10 files and 3 folders:

ReadMe.txt - This document which outlines the package contents.

=== Other Files ===
License.txt - The license for using this package.  It's contents 
were agreed to at the time you paid for this package.

Manual.txt - A document which describes how the package can be 
used and hopefully answers most technical questions.

SDserver.exe - A windows executable that acts as the game server.

SDserver.ini - A configuration file used by SDserver.exe.

RunServer.bat - A sample batch file that starts the game server.

RunClient.bat - A sample batch file which demonstrates how you  
can run the client AFTER installing a JRE.

RunClient.html - A sample browser document that demonstrates how 
you can place the Applet in a web-page with proper configuration.

SDclient.properties - This is the configuration file for the client 
application.

Victory.html - a sample html file that is edited by the game server 
to record winners.


=== Folders ===
Source - A folder which contains the *.cpp and *.hpp source files 
that will allow you to edit and compile the executable.

Applet - A folder which contains the *.java and *.class files for 
the client applet.

Images - A folder that contains the images used by the client applet.


//======================================================================
For further help please visit: 
http://www.ffiends.com

There is a specific help forum for stardart support is at: 
http://www.ffiends.com/Boards/StarDart_Developers.stm

//======================================================================
END OF FILE

