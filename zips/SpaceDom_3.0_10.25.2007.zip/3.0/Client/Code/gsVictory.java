import java.awt.*;
import java.applet.*;

class gsVictory extends GameState {

	Buffer vicBuf = null;

	Portrait back;
	final static String victory = "FINAL VICTORY!";
	long start;

//--- primary functions ---
	public gsVictory(Buffer buf){
		vicBuf = buf;
		back = SpaceDom.Images[SpaceDom.Background];
		start = System.currentTimeMillis();
	}

//--- primary functions ---
	public void paint(Graphics g){
	Date date;
	int h,v;

		long now = System.currentTimeMillis();
		long seconds = 15 - ((now - start) / 1000);
		if (seconds <= 0)
		{
			GameState.setState(new gsPassword());
		}
		back.draw(g,0,0);

		g.setFont(bigFNT);
		g.setColor(Color.black);
		g.drawString(victory,250-bigMET.stringWidth(victory)/2+1,150+1);
		g.setColor(Color.yellow);
		g.drawString(victory,250-bigMET.stringWidth(victory)/2,150);

		if (vicBuf==null) return;

		int offset = 2;
		int vicDate =						vicBuf.getInt(offset);
		int vicTime =						vicBuf.getInt(offset+=4);
		int vicLength =						vicBuf.getInt(offset+=4);
		int highScore =						vicBuf.getInt(offset+=4);
		int totalPlanets =					vicBuf.getInt(offset+=4);
		int totalDarts =					vicBuf.getInt(offset+=4);
		offset += 4;
		String victor =						vicBuf.getString(offset);

		g.setFont(stoutFNT);
		g.setColor(Color.black);
		centerStout(g,victor+" Empire",h=251,v=201);
		date = new Date(vicDate,vicTime);
		centerStout(g,"at "+date.toString(),h,v+=30);
		date = new Date(0,vicLength);
		centerStout(g,"after "+date.lengthStr(),h,v+=30);
		centerStout(g,"Final Score = "+highScore,h,v+=50);
		centerStout(g,"Final Worlds = "+totalPlanets,h,v+=30);
		centerStout(g,"Final Darts = "+totalDarts,h,v+=30);
		g.setFont(textFNT);
		centerStout(g,"Restarting in "+seconds+" seconds.",h,v+=70);

		g.setFont(stoutFNT);
		g.setColor(Color.white);
		centerStout(g,victor+" Empire",h=251,v=201);
		date = new Date(vicDate,vicTime);
		centerStout(g,"at "+date.toString(),h,v+=30);
		date = new Date(0,vicLength);
		centerStout(g,"after "+date.lengthStr(),h,v+=30);
		centerStout(g,"Final Score = "+highScore,h,v+=50);
		centerStout(g,"Final Worlds = "+totalPlanets,h,v+=30);
		centerStout(g,"Final Darts = "+totalDarts,h,v+=30);
		g.setFont(textFNT);
		centerStout(g,"Restarting in "+seconds+" seconds.",h,v+=70);
	}


	void centerStout(Graphics g,String msg,int h,int v){
		g.drawString(msg,h-stoutMET.stringWidth(msg)/2,v);
	}
}