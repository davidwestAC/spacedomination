import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Graphics;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.image.MemoryImageSource;
import java.awt.image.PixelGrabber;

public class Portrait {

	public Image image = null;
	String path = null;
	URL url = null;
	boolean animated=false;
	boolean playReverse=false;
	int frameWidth, frameHeight, frameRate, frameCount;
	private int x, y, width, height;

	boolean visible=true;

	public static String artpath = null;
	public static boolean useURL;

	/*
	** Create a new Portrait from specified path/url
	*/
	public Portrait(String pth) {
		setpath(pth);
		animated = false;
		playReverse = false;
		image = loadImage(artpath+"/"+path);
		try {
			MediaTracker mdtTracker = new MediaTracker(GameState.root);
			mdtTracker.addImage(image,0);
			mdtTracker.waitForAll();
		} catch(Exception e) {
			System.err.println("Error while waiting for image "+artpath+"/"+path+": "+e.toString());
		}
		x=0;
		y=0;
		width = image.getWidth(null);
		height = image.getHeight(null);
	}

	/*
	** Create a Portrait from within an existing Portrait
	** x,y is the upper left corner of the new Portrait
	** w and h are the width and the height of the new Portrait
	*/
	public Portrait(Portrait p, int x, int y, int w, int h) {
		animated = false;
		playReverse = false;
		image = p.image;
		this.x = x;
		this.y = y;
		width = w;
		height = h;
	}

	public Image loadImage(String path) {
		Image tmp = null;
		try {
			return Toolkit.getDefaultToolkit().getImage(new URL(path));
		} catch (MalformedURLException e) {
			tmp = Toolkit.getDefaultToolkit().getImage(path);
			return tmp;
		}
	}

	/*
	** Enable animation of this Portrait
	** width is the frame width
	** rate controls the speed of the animation
	**   higher values are slower, 1 is the fastest, 0 is not valid
	** reverse controls whether the animation plays from
	**   left to right or right to left.
	*/
	public void setAnimation(int width, int rate, boolean reverse) {
		animated = true;
		frameWidth = width;
		frameRate = rate;
		if (frameRate <= 0) {
			frameRate = 1;
		}
		playReverse = reverse;
		frameCount = image.getWidth(null)/width;
		frameHeight = image.getHeight(null);
	}
	
	public int width() {
		if (animated) {
			return frameWidth;
		}
		return width;
	}

	public int height() {
		if (animated) {
			return frameHeight;
		}
		return height;
	}

	public String toString() {
		return path;
	}

	public void draw(Graphics g,int h,int v) {
		if (!visible || image == null) {
			return;
		}
		if (animated) {
			int offset = (SpaceDom.cycle%(frameCount * frameRate))/frameRate;
			if (playReverse) {
				offset = frameCount - offset - 1;
			}
			g.drawImage(image,h,v,h+frameWidth,v+frameHeight,offset*frameWidth,0,(offset*frameWidth)+frameWidth,frameHeight,null);
		} else {
			g.drawImage(image,h,v,h+width,v+height,x,y,x+width,y+height,null);
		}
	}

	public void center(Graphics g,double h,double v) {
		if (!visible || image == null) {
			return;
		}
		if (animated) {
			int offset = (SpaceDom.cycle%(frameCount * frameRate))/frameRate;
			if (playReverse) {
				offset = frameCount - offset - 1;
			}
			g.drawImage(image,
				(int)(h-frameWidth/2.0),
				(int)(v-image.getHeight(null)/2.0),
				(int)(h+frameWidth/2.0),
				(int)(v+frameHeight/2.0),
				offset*frameWidth,
				0,
				(offset*frameWidth)+frameWidth,
				frameHeight,
				null);
		} else {
			int hCenter = (int)(h-(width/2.0));
			int vCenter = (int)(v-(height/2.0));
			g.drawImage(image,hCenter,vCenter,hCenter+width,vCenter+height,x,y,x+width,y+height,null);
		}
	}

	public void centerFlip(Graphics g,int h,int v){
		if (!visible || image == null) {
			return;
		}
		int x1 = (int)(h+width()/2.0);
		int y1 = (int)(v-height()/2.0);
		int x2 = (int)(h-width()/2.0);
		int y2 = (int)(v+height()/2.0);
		if (animated) {
			int offset = (SpaceDom.cycle%(frameCount * frameRate))/frameRate;
			if (playReverse) {
				offset = frameCount - offset - 1;
			}
			g.drawImage(image,x1,y1,x2,y2,offset*frameWidth,0,(offset*frameWidth)+width(),height(),null);
		} else {
			g.drawImage(image,x1,y1,x2,y2,x,y,x+width,y+height,null);
		}
	}

	public String path() {
		if (url==null) {
			return path;
		}
		return url.toString();
	}

	public void setpath(URL purl) {
		image = null;
		url = purl;
	}

	public void setpath(String pth) {
		image = null;
		path = pth;

		try {
			url=new URL(path);
		} catch (MalformedURLException e) {
		} finally {
			if (url!=null) {
				path = null;
			}
		}
	}

	public void setpath(URL purl,String pth) {
		image = null;
		path = pth;
		url = null;
		try {
			url=new URL(purl,path);
		} catch (MalformedURLException e) {
		} finally {
			if (url!=null) {
				path = null;
			}
		}
	}

	public void testpath(String pth) {
		try {
			url=new URL(pth);
		} catch (MalformedURLException e) {
		}
	}

	public void visible(boolean show) {
		visible=show;
	}
	public boolean visible() {
		return visible;
	}
	public void show() {
		visible(true);
	}
	public void hide() {
		visible(false);
	}
}
