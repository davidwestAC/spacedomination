//******************************************************************************
//
//******************************************************************************
import java.awt.*;
import java.net.*;
import java.io.*;

import java.applet.*;
import sun.applet.*;

public class SpaceDom extends Applet implements Runnable {

//--- constants ---
	public static final int DEFAULT_WIDTH = 500;
	public static final int DEFAULT_HEIGHT = 500;
	//public static final int PORT = 1965;

//--- variables ---
	public static Socket conn = null;
	public static InputStream inStream = null;
	public static OutputStream outStream = null;

	public static Image offscreen = null;
	public static Buffer inBuf = null;
	public static GameState state = null;

	public static int heroID=-1,cycle=0,port=0;
	public static Empires empire=null;
	public static Fleets fleet=null;

	Thread runner=null;
	String server;
	boolean isApplet=true;
	public static Toolkit kit;

//--- preparations ---
	public SpaceDom(){
        isApplet = true;
		inBuf = new Buffer(0);
	}

	public void init(){
		kit = getToolkit();

		if (isApplet) {
			//server = getParameter("SERVER");
			Portrait.artpath = getParameter("ARTPATH");
			server = getDocumentBase().getHost();
			try {port = new Integer(getParameter("PORT")).intValue();}
			catch (Exception e){port = 0;}
		}
		else {
			Portrait.artpath = SpaceDomFrame.artpath;
			server = SpaceDomFrame.server;
            port = SpaceDomFrame.port;
		}

		GameState.root = this;
		openConnection();

		GameState.setState(new gsPassword());
	}

	public void destroy(){closeConnection();}

	public void start(){
		if (runner==null) {
			runner = new Thread(this);
			runner.start();
		}
	}

	public void stop(){
		if (runner!=null) {
			runner.stop();
			runner = null;
		}
	}


	public Image loadImage(String path){
		if (!isApplet) return kit.getImage(path);
		try {return kit.getImage(new URL(path));}
		catch (MalformedURLException e){}
		return null;
	}

//--- operations ---
	public void update(Graphics g){
	Graphics og;

		if (offscreen==null) offscreen = createImage(DEFAULT_WIDTH,DEFAULT_HEIGHT);

		og = offscreen.getGraphics();
		state.paint(og);
		g.drawImage(offscreen,0,0,this);
	}


	public void run(){
		while (true) {

			cycle++;
			while (sessionInput()) state.handleInput(inBuf);
			repaint();

			try {Thread.sleep(100);}
			catch (InterruptedException e){}
		}
	}

	public boolean action(Event e,Object what) {
		state.action(e);
		return false;
	}


	public boolean handleEvent(Event e){

		if (state!=null) switch (e.id) {
			case Event.MOUSE_MOVE:	state.move(e.x,e.y); break;
			case Event.MOUSE_DRAG:	state.drag(e.x,e.y); break;
			case Event.MOUSE_DOWN:	state.down(e.x,e.y); break;
			case Event.MOUSE_UP:	state.raise(e.x,e.y); break;
			case Event.KEY_PRESS:	if (state.press(e.key)) return true; break;
		}

		return super.handleEvent(e);
	}

//--- handle streams ---
	public static boolean sessionInput(){
	int len;

		if (inStream==null) return false;

		try {
			len = inStream.available();
			if (len<1) return false;
			inBuf = new Buffer(len);
			len = inStream.read(inBuf.buffer());
			inBuf.length(len);
			return true;
		}
		catch (IOException e){return false;}
	}


	public static void sessionOutput(Buffer buf){
		if (outStream==null) return;
		try {outStream.write(buf.buffer());}
		catch (IOException e){}
	}


	void openConnection(){
		 try {
			System.out.println("Server="+server);
			System.out.println("Port="+port);
			conn = new Socket(server,port,false);		// DataGram connection
			inStream = conn.getInputStream();
			outStream = conn.getOutputStream();
			System.out.println("Connection Established");
		}
		catch (UnknownHostException e){
			conn = null;
			System.out.println("Unknown Host Exception");
		}
		catch (IOException e){
			conn = null;
			System.out.println("I/O Exception");
		}
	}

	void closeConnection(){
		if (conn==null) return;

		GameState.sendSessionDone();

		try {conn.close();}
		catch (IOException e){}
	}
}

