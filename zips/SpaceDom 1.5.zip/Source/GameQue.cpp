//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant

//***************************************************************************
//***************************************************************************

void takeJoinRequest(void);
void takeTop20Query(void);
void takeAskForStats(void);
void takeRebirth(void);
void takeSessionDone(void);

void takeChatMessage(void);
void takeChatChannel(void);

void takeRaceChange(void);

void takeQueryEmpire(void);
void takeQueryWorld(void);
void takeQueryFleet(void);

void takeProbe(void);
void takeScout(void);
void takeFleetMove(void);

void takeSquadAction(void);

void takeBuildCommand(void);
void takeFleetTransfer(void);

void sendSessionDenied(Session *sp,int reason);
void sendSessionLinked(Session *sp,int reason,int empireID);

void sendTop20List(Session *sp);
void sendGameStatistics(Session *sp);
void sendGlobalVictory(void);

extern	void sessionScanFleets(Session *sp);
extern	void sessionScanWorlds(Session *sp);
extern	void sessionHomeWorlds(Session *sp);

//***************************************************************************

MsgQueue *gameQueue;

int top20List[20];	// top 20 players

//***************************************************************************
//***************************************************************************

bool prepareGameQueue(){
	gameQueue = new MsgQueue();
	memset(top20List,0,sizeof(top20List));
	return true;
}


void cleanupGameQueue(){
	delete gameQueue;
}

//********************************************************************

void operateGameQueue(){
void *buf;

	while (!gameQueue->isEmpty()) {

		buf = gameQueue->getMessage();

	//--- message type ---
		if (buf!=NULL) switch (((byte*)buf)[1]) {

			case msJoinRequest:	takeJoinRequest(); break;
			case msTop20Query:	takeTop20Query(); break;
			case msAskForStats: takeAskForStats(); break;

			case msRebirth:		takeRebirth(); break;
			case msSessionDone:	takeSessionDone(); break;

			case msChatMessage:	takeChatMessage(); break;
			case msChatChannel: takeChatChannel(); break;

			case msRaceChange:	takeRaceChange(); break;

			case msQueryEmpire:	takeQueryEmpire(); break;
			case msQueryWorld:	takeQueryWorld(); break;
			case msQueryFleet:	takeQueryFleet(); break;

			//case msProbe:		takeProbe(); break;
			//case msScout:		takeScout(); break;
			case msFleetMove:	takeFleetMove(); break;

			case msSquadAction:		takeSquadAction(); break;

			case msBuildCommand:	takeBuildCommand(); break;
			case msFleetTransfer:	takeFleetTransfer(); break;
		}

	//--- cleanup ---
		gameQueue->pop();
	}
}

//***************************************************************************
//***************************************************************************

/*0x00 - JoinRequest
		name + password sent
0x01 - Session Granted
		empireStruct, fleetStruct
0x02 - Session Created
		empireStruct, fleetStruct
0x03 - Session Denied
		no further information
0x04 - Empire Destroyed
		empireStruct*/

void takeJoinRequest(){
char *msg,*name,*pass;
empireRec *empires,*emp;
fleetRec *fp;
Session *sp;
int count,ix,empireID,fleetID;
bool created;
char c;

	sp = (Session*)gameQueue->getSource();
	if (sp==NULL) return;

	sp->info(NULL,0);
	msg = (char*)gameQueue->getMessage();
	name = msg+2;
	pass = msg+2+MAXNAMESIZE;

//--- approve name ---
	for (ix=0;name[ix]!=0;ix++) {
		c = name[ix];
		if ((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || (c>'^' && c<'`')) continue;
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

//--- approve pass ---
	for (ix=0;pass[ix]!=0;ix++) {
		c = pass[ix];
		if ((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || (c>'^' && c<'`')) continue;
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

//--- create empire ---
	empires = (empireRec*)empireList->getList();
	count = empireList->getCount();
	for (ix=0;ix<count;ix++) if (equalsCI(empires[ix].name,name)) break;

	created = (ix==count);
	empireID = ix;

	if (created) {
		if (!CreateEmpire(name,pass)) {
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
	}
	else {
		if (!equalsCI(pass,empires[ix].pass)) {
			sendSessionDenied(sp,mfBadPassword);
			return;
		}
	}

//--- search for duplicate session ---
	if (findEmpireSession(ix)!=NULL) {
		sendSessionDenied(sp,mfEmpireInPlay);
		return;
	}

//--- collect records ---
	emp = (empireRec*)empireList->getRecord(ix);
	if (emp==NULL) {
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

	fleetID = emp->fleetID;
	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) {
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

//--- cleanup ---
	sessionSetInfo(sp,empireID,fleetID);
	
	if (fp->status==fsDead && emp->worlds==0) {
		sendSessionLinked(sp,mfEmpireDead,ix);
		sendEmpireScan(sp,ix,emp);
		return;
	}

	sendSessionLinked(sp,(created?mfSessionCreated:mfSessionGranted),empireID);
	
	sendEmpireScan(sp,empireID,emp);
	sendCombatScan(sp,fleetID,fp);
	
	sessionScanFleets(sp);
	sessionScanWorlds(sp);
	sessionHomeWorlds(sp);		// sends a list of player controlled worlds

	sendTop20List(sp);
}

//***************************************************************************

void takeTop20Query(){
Session *sp;

	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) sendTop20List(sp);
}


void takeAskForStats(){
Session *sp;

	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) sendGameStatistics(sp);
}

//***************************************************************************

void takeRebirth(){
int empireID,fleetID;
empireRec *emp;
fleetRec *fp;
Session *sp;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL || emp->worlds>0) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL || fp->status!=fsDead) return;

	emp->score = 0;
	CreateFleet(fp,empireID);

	sendSessionLinked(sp,mfSessionGranted,empireID);
	
	sendEmpireScan(sp,empireID,emp);
	sendCombatScan(sp,fleetID,fp);
	
	sessionScanFleets(sp);
	sessionScanWorlds(sp);
	sendTop20List(sp);
}


void takeSessionDone(){
Session *sp;

	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) return;

	sp->kill();
}

//***************************************************************************

extern	bool managerShowChat;
const	int MAXMSGSIZE = BUFFERSIZE-MAXNAMESIZE-1;

void takeChatMessage(){
SessionList *slp;
Session *sp;
empireRec *emp;
int len,ix,channel,empireID,fleetID;
char *buf,msg[BUFFERSIZE];

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return;

	channel = emp->channel;

//--- construct message ---
	ix = strlen(emp->name);
	strcpy(msg,emp->name);
	if (empireID==1 || empireID==2) {
	msg[ix++] = ' ';
	msg[ix++] = '*';
	msg[ix++] = 'A';
	msg[ix++] = 'd';
	msg[ix++] = 'm';
	msg[ix++] = 'i';
	msg[ix++] = 'n';
	msg[ix++] = '*';
	}
	msg[ix++] = ':';
	msg[ix++] = ' ';

	len = buf[0] - 2;
	if (len>MAXMSGSIZE) len = MAXMSGSIZE;
	memcpy(msg+ix,buf+2,len);
	
	msg[ix+=len] = 0;

//--- post message to appropriate targets ---
	slp = sroot->next();
	while (slp!=NULL) {

		if (sessionGetInfo(slp->ssn(),&empireID,&fleetID)) {
			emp = (empireRec*)empireList->getRecord(empireID);
			if (emp!=NULL && emp->channel==channel) sendMessage(slp->ssn(),msg);
		}

		slp = slp->next();
	}

//--- cleanup ---
	if (managerShowChat) printf("<CH=%d>%s\n",channel,msg);
}


void takeChatChannel(){
int empireID,fleetID;
empireRec *emp;
Session *sp;
char *buf;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp!=NULL) emp->channel = *(short*)(buf+2);
}

//***************************************************************************

void takeRaceChange(){
int empireID,fleetID;
empireRec *emp;
fleetRec *fp;
Session *sp;
char *buf;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp!=NULL && emp->changedRace==false) emp->race = *(int*)(buf+4);
	emp->changedRace = true;

	if (emp->race<0) emp->race = 0;
	if (emp->race>7) emp->race = 7;
}

//***************************************************************************

void takeQueryEmpire(){
empireRec *rec;
Session *sp;
char *buf;
int id;

	sp = (Session*)gameQueue->getSource();
	if (sp==NULL) return;

	buf = (char*)gameQueue->getMessage();
	id = *(short*)(buf+2);

	rec = (empireRec*)empireList->getRecord(id);
	if (rec==NULL) return;

	sendEmpireScan(sp,id,rec);
}


void takeQueryWorld(){
worldRec *rec;
Session *sp;
int worldID;
char *buf;

	sp = (Session*)gameQueue->getSource();
	if (!sessionInPlay(sp)) return;

	buf = (char*)gameQueue->getMessage();
	worldID = *(short*)(buf+2);

	rec = (worldRec*)worldList->getRecord(worldID);
	if (rec==NULL) return;

	sendWorldScan(sp,worldID,rec);
}


void takeQueryFleet(){
fleetRec *rec;
Session *sp;
char *buf;
int id;

	sp = (Session*)gameQueue->getSource();
	if (!sessionInPlay(sp)) return;

	buf = (char*)gameQueue->getMessage();
	id = *(short*)(buf+2);

	rec = (fleetRec*)fleetList->getRecord(id);
	if (rec==NULL) return;

	sendFleetScan(sp,id,rec);
}

//***************************************************************************

void takeFleetMove(){
fleetRec *fp,*ep;
empireRec *emp;
Session *sp;
char *buf;
int i,enemy,dest,empireID,fleetID;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) return;
	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) return;

//--- pinned = all sides are enemies ---
	if (fp->status==fsBattle) {

		for (enemy=i=0;i<sideCOUNT;i++) {
			ep = (fleetRec*)fleetList->getRecord(fp->engageID[i]);
			if (ep!=NULL && !isFriendlyFleet(ep,fp)) enemy++;
		}
		if (enemy==sideCOUNT) return;	// pinnned!

		for (i=0;i<posCOUNT;i++) setSquadAction(fp,i,actRetreat);
		return;
	}

//--- fix move ---
	buf = (char*)gameQueue->getMessage();
	dest = *(short*)(buf+2);

	setFleetDestination(fp,(fleetID==dest?-1:dest));
}

//***************************************************************************

void takeSquadAction(){
int action,enemy,squadID,empireID,fleetID;
fleetRec *fp;
Session *sp;
char *buf;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (sp==NULL) return;

	buf = (char*)gameQueue->getMessage();
	squadID = buf[2];
	if (squadID>=posCOUNT) return;

	action = buf[3];
	enemy = buf[4];
	setSquadAction(fp,squadID,action,enemy);
}

//***************************************************************************

void takeBuildCommand(){
int buildID,worldID,empireID,fleetID;
worldRec *wp;
fleetRec *fp;
buildCmd bd;
Session *sp;
char *buf;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) return;

	worldID = fp->destID;
	wp = (worldRec*)worldList->getRecord(worldID);
	if (wp==NULL || wp->empireID!=empireID) return;

	buf = (char*)gameQueue->getMessage();

	bd.repeat = (buf[3]!=0);
	bd.type = buf[4];
	bd.goal = buf[5];
	bd.built = 0;
	if (bd.type>btCOUNT) return;

	buildID = buf[2];
	if (buildID>=MAXBUILD) return;

	wp->cmd[buildID] = bd;
	sendBuildScan(sp,worldID,wp);
}


void takeFleetTransfer(){
int type,num,empireID,fleetID;
empireRec *emp;
fleetRec *fp,*ep;
Session *sp;
char *buf;
bool lift;

	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) return;

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) return;

	ep = (fleetRec*)fleetList->getRecord(fp->destID);
	if (ep==NULL || ep->empireID!=fp->empireID) return;

	buf = (char*)gameQueue->getMessage();
	num = *(ushort*)(buf+2);
	type = buf[6];
	lift = (buf[7]==1);

	emp = (empireRec*)empireList->getRecord(fp->empireID);
	if (emp->race==rtAvarian) {
		if (type>=stCOUNT) return;
	}
	else {
		if (type>=stCOUNT || type==stStation) return;
	}

//--- transfer ---
	if (lift) {
		num = pullFleetShips(ep,type,num);		// num = amount pulled
		num -= addFleetShips(fp,type,num);		// (-amount added) = left over
		if (num>0) addFleetShips(ep,type,num);	// return extra
	}
	else {
		num = pullFleetShips(fp,type,num);		// num = amount pulled
		num -= addFleetShips(ep,type,num);		// (-amount added) = left over
		if (num>0) addFleetShips(fp,type,num);	// return extra
	}

//--- cleanup ---
	sendCombatScan(sp,fleetID,fp);
	sendCombatScan(sp,fp->destID,ep);
}

//***************************************************************************
//***************************************************************************

void sendSessionLinked(Session *sp,int reason,int empireID){
char buf[BUFFERSIZE];

	buf[0] = 4;
	buf[1] = (byte)reason;
	memcpy(buf+2,&empireID,sizeof(short));
	sp->send(buf);
}


void sendSessionDenied(Session *sp,int reason){
char buf[BUFFERSIZE];

	buf[0] = 2;
	buf[1] = (byte)reason;
	sp->send(buf);
}

//***************************************************************************
//	sector  = ID, ind
//	industry  = ind, store, builds
//	scan = xloc -> name

void sendWorldScan(Session *sp,int worldID,worldRec *wp){
char buf[BUFFERSIZE];
int len,size;

	if (wp==NULL) return;

	len = 2;
	memcpy(buf+len,&worldID,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,wp,4*sizeof(int));
	len += 4*sizeof(int);
	memcpy(buf+len,&wp->minerals,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->maxMerchant,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->maxBeacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->maxStardock,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->sector,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->worldID,sizeof(int));
	len += sizeof(int);

	size = 1+strlen(wp->name);
	memcpy(buf+len,wp->name,size);
	len += size;

	buf[0] = len;
	buf[1] = mfWorldScan;
	sp->send(buf);
}


void sendFleetScan(Session *sp,int fleetID,fleetRec *fp){
char buf[BUFFERSIZE];
int len;

	if (fp==NULL) return;

	len = 2;
	memcpy(buf+len,&fleetID,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,fp,4*sizeof(int));
	len += 4*sizeof(int);
	memcpy(buf+len,&fp->Beacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->moveSpeed,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->Stardock,sizeof(int));
	len += sizeof(int);

	buf[0] = len;
	buf[1] = mfFleetScan;
	sp->send(buf);
}


//	scan = empireID, everything
void sendEmpireScan(Session *sp,int id,empireRec *ep){
char buf[BUFFERSIZE];
int len,size;

	if (ep==NULL) return;

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&ep->fleetID,10*sizeof(int));
	len += 10*sizeof(int);
	memcpy(buf+len,&ep->Merchant,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&ep->Beacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&ep->Stardock,sizeof(int));
	len += sizeof(int);

	size = 1+strlen(ep->name);
	memcpy(buf+len,ep->name,size);
	len += size;

	buf[0] = len;
	buf[1] = mfEmpireScan;
	sp->send(buf);
}


void sendCombatScan(Session *sp,int id,fleetRec *fp){
char buf[BUFFERSIZE];
int len;

	if (fp==NULL) return;

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->ecm,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->engageID,sideCOUNT*sizeof(int));
	len += sideCOUNT*sizeof(int);
	memcpy(buf+len,&fp->squad,posCOUNT*sizeof(squadRec));
	len += posCOUNT*sizeof(squadRec);

	buf[0] = len;
	buf[1] = mfCombatScan;
	sp->send(buf);
}


void sendBuildScan(Session *sp,int id,worldRec *wp){
char buf[BUFFERSIZE];
int len;

	if (wp==NULL) return;

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&(wp->ind),2*sizeof(int)+MAXBUILD*sizeof(buildCmd));
	len += 2*sizeof(int)+MAXBUILD*sizeof(buildCmd);
	memcpy(buf+len,&wp->Merchant,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->Beacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->Stardock,sizeof(int));
	len += sizeof(int);

	buf[0] = len;
	buf[1] = mfBuildScan;
	sp->send(buf);
}

//***************************************************************************

void sendEmpireMessage(int id,char *msg){
Session *sp;

	sp = findEmpireSession(id);
	if (sp!=NULL) sendMessage(sp,msg);
}


void sendMessage(Session *sp,char *msg){
char buf[BUFFERSIZE];
int len;

	len = strlen(msg);
	if (len>BUFFERSIZE-2) len = BUFFERSIZE-2;

	buf[0] = len+2;
	buf[1] = mfMessage;
	memcpy(buf+2,msg,len);
	sp->send(buf);
}


void sendStatus(Session *sp,int status){
char buf[BUFFERSIZE];
	
	buf[0] = 3;
	buf[1] = mfStatus;
	buf[2] = (char)status;

	sp->send(buf);
}


void sendGlobalMessage(char *msg){
SessionList *slp;
Session *sp;

	slp = sroot->next();
	while (slp!=NULL) {
		sp = slp->ssn();
		if (sessionInPlay(sp)) sendMessage(sp,msg);
		slp = slp->next();
	}
}


void sendTop20List(Session *sp){
char buf[BUFFERSIZE];
int len;

	len = 2;
	memcpy(buf+len,top20List,sizeof(top20List));
	len += sizeof(top20List);

	buf[0] = len;
	buf[1] = mfTop20List;

	sp->send(buf);
}

//***************************************************************************

void sendGameStatistics(Session *sp){
char buf[BUFFERSIZE];
empireRec *emp;
victoryRec vrec;
int *data;
int len;

//--- collect records ---
	len = victoryList->getCount();
	if (!victoryList->pickIndex(len-1)) return;
	victoryList->getRecord(&vrec);

	emp = (empireRec*)empireList->getRecord(top20List[0]);

//--- create message ---
	buf[2] = victoryPercent;
	if (emp==NULL)	buf[3] = 0;
	else			buf[3] = (byte)(emp->hiScore/(maxEmpireScore/100));

	data = (int*)buf;
	data[1] = worldList->getCount();
	data[2] = empireList->getCount();
	data[3] = CalcDarts(data[1]);
	data[4] = sessionCount;

	data[5] = vrec.date;
	data[6] = vrec.time;
	data[7] = todayToDays();
	data[8] = secondsSinceMidnight();

	data[9] = maxEmpireScore;
	data[10] = vrec.gameLength;

	len = 11 * sizeof(int);
	memcpy(buf+len,vrec.name,MAXNAMESIZE);
	len += MAXNAMESIZE;

	buf[0] = len;
	buf[1] = mfGameStatistics;

//--- send it ---
	sp->send(buf);
}


void sendGlobalVictory(victoryRec *vrp){
char buf[BUFFERSIZE];
SessionList *slp;
Session *sp;
int *data;
int len;

//--- create message ---
	data = (int*)buf;
	data[1] = todayToDays();
	data[2] = secondsSinceMidnight();
	data[3] = vrp->gameLength;

	data[4] = vrp->score;
	data[5] = vrp->worlds;
	data[6] = vrp->darts;

	len = 7 * sizeof(int);
	memcpy(buf+len,vrp->name,MAXNAMESIZE);
	len += MAXNAMESIZE;

	buf[0] = len;
	buf[1] = mfVictory;

//--- send it ---
	slp = sroot->next();
	while (slp!=NULL) {
		sp = slp->ssn();
		if (sessionInPlay(sp)) {		// special case - last message sent to session
			sp->send(buf);
			sp->output();
		}
		slp = slp->next();
	}
}

//***************************************************************************
