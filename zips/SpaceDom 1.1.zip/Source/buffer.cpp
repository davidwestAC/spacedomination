//************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//************************************************************************
#include <stdlib.h>
#include <stdio.h>
#include <io.h>

//************************************************************************

char *InputBuffer=NULL;

//************************************************************************

char *GetInputBuffer(){return InputBuffer;}


void FreeInputBuffer(){
	if (InputBuffer!=NULL) free(InputBuffer);
}


char *LoadInputBuffer(){
int ix,count;

	FreeInputBuffer();

	count = filelength(fileno(stdin));
	if (count<1) return NULL;

	InputBuffer = (char*)malloc(count+1);
	if (InputBuffer==NULL) return NULL;

	for (ix=0;ix<count;ix++) InputBuffer[ix] = getc(stdin);
	InputBuffer[ix] = 0;

	return InputBuffer;
}


int readString(char *buf,int max){
int ix;
char c;

	for (ix=0;ix<max-1;ix++) {
		c = getc(stdin);
		if (c==0) break;
		if (c=='\n') break;
		buf[ix] = c;
	}

	buf[ix] = 0;
	return ix;
}


int readParagraph(char *buf,int max){
int ix;
char c;

	for (ix=0;ix<max-1;ix++) {
		c = getc(stdin);
		buf[ix] = c;
		if (c==0) break;
	}

	return ix;
}


int CheckSum(char *data){
int sum,val;
int ix;

	for (sum=ix=0;data[ix]!=0;ix++) {
		val = (unsigned char)data[ix];
		if (val<32) continue;
		sum += val;
	}

	return sum;
}


//--- from '{' to '}' ---
int skipToken(char *data){		
int ix,depth;

//--- find opening '{' ---
	for (ix=0;data[ix]!='{';ix++) if (data[ix]==0) return -1;
	ix++;

//--- find matching '}' ---
	for (depth=1;depth>0;ix++) {
		if (data[ix]==0) return -1;
		if (data[ix]=='{') depth++;
		if (data[ix]=='}') depth--;
	}

	return ix;
}

//************************************************************************
