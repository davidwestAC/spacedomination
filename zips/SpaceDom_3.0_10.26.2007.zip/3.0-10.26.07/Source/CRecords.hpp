//************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//************************************************************************
#ifndef _FFI_CRECORDS_
#define	_FFI_CRECORDS_
#include "string.hpp"
#include "FFItypes.hpp"

//************************************************************************
// NOTE:
//		Records are organized by tags.
//		4 byte tag is considered an integer tag
//		tags occupy the first 'tagSize' bytes of each record.
//		tags are null terminated strings / an integer value
//		tags of zero length/value indicate empty records.
//************************************************************************

class CRecords {
	private:
		char	*file;
		void	*currentRecord;
		int		tagSize,recSize;
		int		currentIndex,count;

	public:
		CRecords(char *path,int tag,int rec);
		~CRecords();

		void clear();			// kill records file

		bool findEmpty(void);		// find first empty record
		bool pickIndex(int index);
		bool first(void);
		bool next(void);

		inline void *getRecord(void){return currentRecord;}
		inline void getRecord(void *rec){memcpy(rec,currentRecord,recSize);}
		inline char *getFile(void){return file;}
		inline int getIndex(void){return currentIndex;}
		inline int getCount(void){return count;}

		int LoadNumRecords(void *rec,int num);

		bool search(void *tag);
		bool testSearch(bool (*test)(void *record));

		bool change(int index,void *record);	// pick, replace
		bool change(void *record);	// search, replace
		bool change(void);			// replace
		bool create(void *record);	// search, append

		bool kill(void *tag);		// search, replace
		bool kill(void);			// replace
		void compact(void);			// removes all empty records.
};

//************************************************************************

const int BLOCK_RECS = 100;

class CLists {
	private:
		void	*list;
		char	*file;
		int		recSize,count,blocks;

	public:
		CLists(char *path,int rec);
		~CLists();

		inline void *getList(){return list;}
		inline int getCount(){return count;}
		void *getRecord(int index){
			if (list==NULL || index<0 || index>=count) return NULL;
			return (byte*)list+index*recSize;
		}

		void clear();				// erase file
		void save();
		void save(int index);		// save one record
		int increment();
		void expand(int num);

	private:
		void allocate(int needs);
		void load();
};

//************************************************************************
#endif	//_FFI_CRECORDS_
