#include <stdlib.h>
#include "logFilter.h"

LogFilter::LogFilter(int log_id)
	:m_pNext(NULL) {
	LogFilter(log_id, log_id); 
}

LogFilter::LogFilter(int first_id, int last_id)
	:m_pNext(NULL) {
	m_first_id = first_id;
	m_last_id = last_id;
}				   

LogFilter::~LogFilter() {
}

void LogFilter::next(LogFilter *next) {
	m_pNext = next;
}		   

LogFilter* LogFilter::next() {
	return m_pNext;
}		   

void LogFilter::getRange(int *first_id, int *last_id) {
	*first_id = m_first_id;
	*last_id = m_last_id;
}		   

bool LogFilter::matches(int log_id) {
	return (m_first_id <= log_id && log_id <= m_last_id);
}		   

LogFilterList::LogFilterList()
    :m_pRoot(NULL) {						   
}

LogFilterList::~LogFilterList() {
	if (m_pRoot != NULL) {							
        while(m_pRoot->next() != NULL) {
	       LogFilter *temp = m_pRoot;
		   m_pRoot = m_pRoot->next();
		   delete temp;
		}
		delete m_pRoot;
		m_pRoot = NULL;
	}					  
}

void LogFilterList::add(int log_id) {
	 add(log_id, log_id);
}

void LogFilterList::add(int first_id, int last_id) {
	 LogFilter *lf = new LogFilter(first_id, last_id);
	 if (m_pRoot == NULL) {
	     m_pRoot = lf;
	     return;
	 }
	 LogFilter *current = m_pRoot;
	 while(current->next() != NULL) {
	 	 current = current->next();
	 }
	 current->next(lf);
}

bool LogFilterList::contains(int log_id) {
	if (m_pRoot == NULL) {
		return false;
	}		 
	LogFilter *current = m_pRoot;
	while(current->next() != NULL) {
		if (current->matches(log_id)) {
			return true;
		}	 			   					
		current = current->next();
	}
	if (current->matches(log_id)) {
		return true;
	}	 			   					
	return false;
}
