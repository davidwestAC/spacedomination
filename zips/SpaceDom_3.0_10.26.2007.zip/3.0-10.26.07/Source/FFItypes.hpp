#ifndef _FFI_TYPES_
#define	_FFI_TYPES_
#include <stdlib.h>
#include <windows.h>

//************************************************************************************

typedef unsigned char byte;
typedef unsigned short ushort;
typedef unsigned long ulong;

#define	MAXBYTE		0xff
#define	MAXUSHORT	0xffff
#define	MAXULONG	0xffffffff

//************************************************************************************

inline int RandMax(){return rand();}		// rand auto limited to 0x7ffff (see RAND_MAX)
inline int Rand(int x){return RandMax()%x;}
inline int Rand2(){return RandMax()&0x0001;}
inline int Rand4(){return RandMax()&0x0003;}
inline int Rand8(){return RandMax()&0x0007;}
inline int Rand16(){return RandMax()&0x000f;}
inline int Rand32(){return RandMax()&0x001f;}
inline int Rand64(){return RandMax()&0x003f;}
inline int Rand128(){return RandMax()&0x007f;}
inline int Rand256(){return RandMax()&0x00ff;}
inline int Rand512(){return RandMax()&0x01ff;}
inline int Rand1024(){return RandMax()&0x03ff;}

inline int RandBig(){return (rand()<<15)|rand();}	// max value is 0x3fffffff
inline int BRand(int x){return RandBig()%x;}

//************************************************************************************

inline	void swap(int *a,int *b){int t=*a;*a=*b;*b=t;}

//************************************************************************************

class CRect {
	public:
		int x,y,w,h;	// x,y,width,height
		
		CRect(){x=y=w=h=0;}
		CRect(RECT r)
			{x=r.left;y=r.top;w=r.right-x;h=r.bottom-y;}
		CRect(int x,int y,int w,int h)
			{this->x=x;this->y=y;this->w=w;this->h=h;}
		CRect(CRect *sr)
			{x=sr->x;y=sr->y;w=sr->w;h=sr->h;}
		~CRect(){}
		bool inside(int px,int py)
			{return (px>=x && py>=y && px<x+w && py<y+h);}
		void setRect(int x,int y,int w,int h)
			{this->x=x;this->y=y;this->w=w;this->h=h;}
		void setRect(CRect *r)
			{this->x=r->x;this->y=r->y;this->w=r->w;this->h=r->h;}
		void getRECT(RECT *dr)
			{SetRect(dr,x,y,x+w,y+h);}
};


class Pt3 {
	public:
		int		x,y,z;

	public:
		Pt3(int nx,int ny,int nz){setPt3(nx,ny,nz);}
		Pt3(Pt3 *p){setPt3(p->x,p->y,p->z);}
		Pt3(void){x=y=z=0;}

		inline void setPt3(int nx,int ny,int nz){x=nx;y=ny;z=nz;}
		inline void addPt3(Pt3 *p){addPt3(p->x,p->y,p->z);}
		inline void addPt3(int ax,int ay,int az){x+=ax;y+=ay;z+=az;}

		int proximity(Pt3 *p){
		int	dx = abs(p->x - x);
		int dy = abs(p->y - y);
		int dz = abs(p->z - z);
			if (dy>dz) swap(&dy,&dz);		// dz holds larger
			if (dx>dy) swap(&dx,&dy);		// dx hols smallest
			if (dy>dz) swap(&dy,&dz);		// dz holds largest
			return dz + dy/2 + dx/4;
		}
};

//************************************************************************************
#endif //_FFI_TYPES_
