#ifndef _LOG_H
#define _LOG_H
#include "logFilter.h"

class Log {
	public:
		enum loggingLevel {LOG_NONE=0,LOG_ERROR=1,LOG_INFO=2,LOG_VERBOSE=3,LOG_DEBUG=4,LOG_DEBUG_VERBOSE=5};
		enum filterType {LOG_BLOCK=0,LOG_ALLOW=1};

	private:
		char *m_lpLogFileName;
		loggingLevel m_logLevel;
		int m_last_log_id;
		int m_last_log_count;
		LogFilterList *allowList;
		LogFilterList *blockList;

	public:
		Log(loggingLevel ll=LOG_ERROR, const char *lpFileName=NULL);
		~Log();
		void logMsg(loggingLevel ll, const int log_id, const char* lpFormatString, ...);
		void setLogFile(const char *lpFileName);
		loggingLevel setLogLevel(loggingLevel ll);
		loggingLevel getLogLevel() {return m_logLevel;}
		LogFilterList* getAllowList() {return allowList;}
		LogFilterList* getBlockList() {return blockList;}
		void addFilter(filterType ft, int log_id);
		void addFilter(filterType ft, int first_id, int last_id);
};

#endif // _LOG_H
