import java.awt.*;
import java.applet.*;

class gsIndustry extends GameState {

//--- variables ---
	Button launch,options,repeat,send,maxInd,doBuild,setBuild,setBuildConfirm,set,collect;
	Button[] build;
	Scrollbar goal;
	CheckboxGroup transferShips;
	Checkbox transferAll, transferHalf, transferOne;
	Builds gbuild = null;
	boolean autoBuildStarted = false;
	boolean autoIndStarted = false;
	boolean settingBuild = false;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final static Rectangle[] crect = {
		new Rectangle(5,249,55,70),new Rectangle(65,249,55,70),new Rectangle(125,249,55,70),
			new Rectangle(185,249,55,70),new Rectangle(245,249,55,70),
		new Rectangle(5,325,55,70),new Rectangle(65,325,55,70),new Rectangle(125,325,55,70),
			new Rectangle(185,325,55,70),new Rectangle(245,325,55,70),	
			
	//--- orbit rects ---
		new Rectangle(300,35,60,30),new Rectangle(300,65,60,30),new Rectangle(300,95,60,30),
			new Rectangle(240,20,60,30),new Rectangle(240,50,60,30),new Rectangle(240,80,60,30),

	//--- ground rects ---
		new Rectangle(430,35,60,30),new Rectangle(430,65,60,30),new Rectangle(430,95,60,30),
			new Rectangle(370,20,60,30),new Rectangle(370,50,60,30),new Rectangle(370,80,60,30),
	};
	
	Rectangle orbit = new Rectangle(240,5,120,140);
	Rectangle ground = new Rectangle(370,5,120,140);

	int select=-1,over=-1,selectSquad=-1,target=-1;
	int oldTarget=-1;
	int fromPos=-1,toPos=-1;
	int fromFleet=0,fromCount=0;
	Worlds wp=null;
	boolean initialized = false;

//--- constructors ---
	public gsIndustry() {}

	public void init() {
	int i;

		initialized=false;
		transferShips = new CheckboxGroup();
		root.add(transferAll = new Checkbox("All",(transferType==0),transferShips));
		root.add(transferHalf = new Checkbox("1/2",(transferType==1),transferShips));
		root.add(transferOne = new Checkbox("One",(transferType==2),transferShips));
		transferAll.setForeground(Color.white);
		transferAll.setBackground(SCREEN_COLOR);
		transferHalf.setForeground(Color.white);
		transferHalf.setBackground(SCREEN_COLOR);
		transferOne.setForeground(Color.white);
		transferOne.setBackground(SCREEN_COLOR);

		root.add(launch = new Button("Launch"));
		root.add(options = new Button("Options"));
		root.add(repeat = new Button("Repeat"));
		root.add(send = new Button("Send"));
		send.setVisible(false);
		root.add(maxInd = new Button("Max Ind"));
		root.add(collect = new Button("Collect"));
		root.add(doBuild = new Button("Do Build"));
		root.add(setBuild = new Button("Set Build"));
		root.add(setBuildConfirm = new Button("Done"));
		setBuildConfirm.setVisible(false);
		root.add(set = new Button("Set"));
		set.setVisible(false);

		build = new Button[Builds.BUILD_TYPES];
		for (i=0;i<Builds.BUILD_TYPES;i++) {
			/*
			** cost of 0 indicates that item not allowed in this arena
			*/
			if (Builds.cost[i] != 0) {
				root.add(build[i] = new Button(Builds.name[i]));
			}
		}
		root.add(build[Builds.BUILD_TYPES-1] = new Button(Builds.name[Builds.BUILD_TYPES-1]));

		root.add(goal = new Scrollbar(Scrollbar.HORIZONTAL,0,10,0,250));
		gbuild = new Builds();

		setBounds(transferAll,335,140,40,20);
		setBounds(transferHalf,377,140,40,20);
		setBounds(transferOne,419,140,50,20);

		setBounds(launch,9,5,50,20);
		setBounds(options,62,5,50,20);

		setBounds(goal,5,224,247,19);
		setBounds(repeat,255,224,46,20);
		setBounds(build[Builds.BUILD_PINNACE],10,200,55,20);
		setBounds(build[Builds.BUILD_CORSAIR],181,200,55,20);
		setBounds(build[Builds.BUILD_FRIGATE],238,200,55,20);
		setBounds(build[Builds.BUILD_STATION],124,200,55,20);
		setBounds(build[Builds.BUILD_RANGER],67,200,55,20);
		setBounds(build[Builds.BUILD_INDUSTRY],67,152,58,20);
		setBounds(maxInd,127,152,58,20);		// Max Ind
		setBounds(collect,187,152,50,20);		// Collect
		setBounds(doBuild,440,176,60,20);		// Do Build
		setBounds(setBuild,440,200,60,20);		// Set Build
		setBounds(setBuildConfirm,440,200,60,20);		// Done
		setBounds(build[Builds.BUILD_NOTHING],10,152,55,20);

		/*
		** Order of the following if statements will determine
		** button order on screen from left to right
		*/
		int x = 8;
		int width = 0;
		int spacing = 2;
		if (Builds.cost[Builds.BUILD_MERCHANT] != 0) {
			x += spacing+width;
			width = 65;
			setBounds(build[Builds.BUILD_MERCHANT],x,176,width,20);		// Merchant
		}
		if (Builds.cost[Builds.BUILD_BEACON] != 0) {
			x += spacing+width;
			width = 50;
			setBounds(build[Builds.BUILD_BEACON],x,176,width,20);	// Beacon
		}
		if (Builds.cost[Builds.BUILD_STARDOCK] != 0) {
			x += spacing+width;
			width = 58;
			setBounds(build[Builds.BUILD_STARDOCK],x,176,width,20);	// Stardock
		}
		if (Builds.cost[Builds.BUILD_DOOMSDAY] != 0) {
			x += spacing+width;
			width = 64;
			setBounds(build[Builds.BUILD_DOOMSDAY],x,176,width,20);	// Doomsday
		}
		if (Builds.cost[Builds.BUILD_SHIELD] != 0) {
			x += spacing+width;
			width = 55;
			setBounds(build[Builds.BUILD_SHIELD],x,176,width,20);	// Shield
		}
		if (Builds.cost[Builds.BUILD_STELLURAE] != 0) {
			x += spacing+width;
			width = 58;
			setBounds(build[Builds.BUILD_STELLURAE],x,176,width,20);	// Stellurae
		}
		initialized=true;
	}

	public void paint(Graphics g) {
		Rectangle r;
		Fleets fp,ep;
		Squadron sp;
		Builds bp;
		int i,val,count;
		int h,v;

		if (!initialized) {
			return;
		}

		wp = Worlds.get(gsFleet.destID);
		/*
		** Only attempt auto build and auto industry if the world was just captured
		*/
		if (wp != null && wp.justCaptured) {
			if (GameState.autoBuild) {
				if (GameState.autoBuild) {
					autoBuild();
				}
			}
			if (GameState.autoInd) {
				boolean foundIndustry = false;
				for (i=0; i<Builds.MAX_COMMANDS; i++) {
					if (wp.builds != null && wp.builds[i] != null && wp.builds[i].type() == Builds.BUILD_INDUSTRY) {
						foundIndustry = true;
					}
				}
				if (wp.ind() != wp.maxInd() && !foundIndustry) {
					val = wp.maxInd() - wp.ind();
					buildIndustry(val);
				}
			}
			wp.justCaptured = false;
		}

		g.setColor(SCREEN_COLOR);
		g.fillRect(0,0,500,400);

		fp = gsFleet;
		ep = Fleets.get(fp.destID);
		wp = Worlds.get(fp.destID);

		if (wp==null) {
			g.setColor(Color.black);
			g.drawString("Waiting for Info",10,10);
			g.drawString("fleet = "+fp.fleetID,10,30);
			g.drawString("world = "+fp.destID,10,50);
			return;
		}

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals

		g.setColor(Color.white);
		g.drawString(fp.empireName(),120,20);
		g.drawString("World: "+wp.name(),120,35);
		g.drawString("Type: "+wp.special(),120,50);
		g.drawString("Sector: "+wp.sector(),120,65);
		g.drawString("Population: "+wp.pop(),120,80);
		val = (wp.maxInd()-wp.ind());
		g.drawString("Industry: "+wp.ind()+(val>0?" ("+val+")":" (Max)"),120,95);
		g.drawString("Storage: "+wp.storage(),120,110);
		g.drawString("Facility: "+wp.facilityname(),120,125);
	
		h = 320;
		v = 220;
		drawEmpireStats(g,h,v);

		if (fp!=null) {
			int ox, oy;
			ox = orbit.x;
			oy = orbit.y;
			g.setColor(Color.white);
			g.drawString("Orbit",ox+5,oy+12);
			for (int pos = 0; pos < Fleets.POS_COUNT; pos++) {
				r = crect[pos+10];
				g.setColor(BOX_COLOR_FLEET);
				g.fillRect(r.x,r.y,r.width,r.height);
				fp.drawStats(g,r.x,r.y,pos);
				g.setColor(SCREEN_COLOR);
				g.drawRect(r.x,r.y,r.width,r.height);
			}
			g.setColor(Color.white);
			g.drawString("Guns="+fp.guns(),ox+5,oy+orbit.height-5);
		}
		if (ep!=null) {
			int ox, oy;
			ox = ground.x;
			oy = ground.y;
			g.setColor(Color.white);
			g.drawString("Guard",ox+5,oy+12);
			for (int pos = 0; pos < Fleets.POS_COUNT; pos++) {
				r = crect[pos+16];
				g.setColor(BOX_COLOR_FLEET);
				g.fillRect(r.x,r.y,r.width,r.height);
				ep.drawStats(g,r.x,r.y,pos);
				g.setColor(SCREEN_COLOR);
				g.drawRect(r.x,r.y,r.width,r.height);
			}
			g.setColor(Color.white);
			g.drawString("Guns="+ep.guns(),ox+5,oy+orbit.height-5);
		}

		g.setColor(Color.white);
		g.drawString("Ship Transfer: ",245,155);

	//--- builds ---
		g.setColor(BOX_COLOR);
		for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			g.fillRect(r.x,r.y,r.width,r.height);
		}

		if (select<0 || select>=10) {
			send.setVisible(false);
			set.setVisible(false);
		} else {
			r = crect[select];
			g.setColor(Color.red);
			g.drawRect(r.x-1,r.y-1,r.width+2,r.height+2);

			gbuild.setGoal(goal.getValue());

			r = crect[select];
			if (settingBuild) {
				setBounds(set,r.x+20,r.y+53,35,17);
			} else {
				setBounds(send,r.x+20,r.y+53,35,17);
			}
			if (settingBuild) {
				set.setVisible(true);
			} else {
				send.setVisible(true);
			}
		}

		g.setColor(Color.black);
		if (wp!=null) for (i=0;i<Builds.MAX_COMMANDS;i++) {
			r = crect[i];
			if (settingBuild) {
				bp = (i==select?gbuild:GameState.autoBuilds[i]);
			} else {
				bp = (i==select?gbuild:wp.builds(i));
			}
			if (bp==null) continue;
			if ((bp.type()==bp.BUILD_NOTHING || bp.goal()==0) && i!=select) continue;
			
			if (bp.type()<=bp.BUILD_INDUSTRY) {
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				g.drawString(""+bp.cost(),r.x+2,r.y+60);
			}

			if (bp.type()>=bp.BUILD_MERCHANT && bp.type()<=bp.BUILD_STARDOCK) {
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.built()+"/"+bp.goal(),r.x+2,r.y+30);
				g.drawString(""+bp.repeat(),r.x+2,r.y+45);
				if (facilityCostType == 0) {
					g.drawString(""+bp.cost(),r.x+2,r.y+60);
				}
			}
			
			if (bp.type()>=bp.BUILD_DOOMSDAY && bp.type()<=bp.BUILD_SHIELD) {
				bp.goal = 1;
				bp.repeat = false;
				g.drawString(""+bp.name(),r.x+2,r.y+15);
				g.drawString(""+bp.cost(),r.x+2,r.y+30);
			}
		}
		
		g.setColor(Color.white);
		if (over>=0) {
			r = crect[over];
			g.setColor(Color.blue);
			g.drawRect(r.x,r.y,r.width,r.height);
		}
		drawSelect(g);
		drawChatMessages(g);
	}

	void drawSelect(Graphics g){
	Rectangle rs,rt;
	int cx,cy;

		if (selectSquad<0) return;

		rs = crect[selectSquad+10];
		g.setColor(Color.blue);

		if (selectSquad==target) {
			g.drawRect(rs.x,rs.y,rs.width,rs.height);
			return;
		}

		rt = crect[target+10];
		cx = rt.x + rt.width / 2;
		cy = rt.y + rt.height / 2;
		
		g.drawLine(rs.x,rs.y,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y,cx,cy);
		g.drawLine(rs.x,rs.y+rs.height,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y+rs.height,cx,cy);
	}

//--- primary functions ---
	public void down(int x,int y,Event e){
	Squadron sp=null;
	Fleets fp=null;
	int i;

		for (i=0;i<10;i++) {
			if (!crect[i].contains(x,y)) continue;
			if (i!=select) {
				select = i;
				gbuild.copy(wp.builds(i));
				goal.setValue(gbuild.goal);
			}else {
				select = -1;
			}
			break;
		}

//		if (orbit.contains(x,y)) {
		for (i=10;i<16;i++) {
			if (!crect[i].contains(x,y)) continue;
			fromFleet = 0;
			fp=gsFleet;
			sp = fp.squads(over-10);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				target = selectSquad = over-10;
				fromPos = over-10;
			}
		}

//		if (ground.contains(x,y)) {
		for (i=16;i<22;i++) {
			if (!crect[i].contains(x,y)) continue;
			fromFleet = 1;
			fp = gsFleet.getInvade();
			sp = fp.squads(over-16);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				target = selectSquad = over-10;
				fromPos = over-16;
			}
		}
	}

	public void move(int x,int y) {
		Fleets fp;
		int i,num;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.contains(x,y);

		over = -1;
		for (i=0;i<10;i++) {
			if (crect[i].contains(x,y)) {
				over = i;
				return;
			}
		}

//		if (orbit.contains(x,y)) {
		for (i=10;i<16;i++) {
			if (!crect[i].contains(x,y)) continue;
//			for (i=10;i<16;i++) {
//				if (crect[i].contains(x,y)) {
					over=i;
					return;
//				}
//			}
		}

//		if (ground.contains(x,y)) {
		for (i=16;i<22;i++) {
			if (!crect[i].contains(x,y)) continue;
//			for (i=16;i<22;i++) {
//				if (crect[i].contains(x,y)) {
					over=i;
					return;
//				}
//			}
		}
	}
	
	public void raise(int x,int y) {
		int toFleet=-1;
		Squadron sp=null;
		Fleets fp=null;

		if (target != -1 && selectSquad != -1 && selectSquad != target) {
//			if (orbit.contains(x,y)) {
			for (int i=10;i<16;i++) {
				if (!crect[i].contains(x,y)) continue;
				toFleet = 0;
				toPos = target;
			}
//			if (ground.contains(x,y)) {
			for (int i=16;i<22;i++) {
				if (!crect[i].contains(x,y)) continue;
				toFleet = 1;
				toPos = target-6;
			}
			if (toFleet == -1) {  // no transfer, they missed the box
				selectSquad = target = -1;
				return;
			}
			if (fromFleet == 0) {
				fp=gsFleet;
			} else {
				fp = gsFleet.getInvade();
			}
			sp = fp.squads(fromPos);
			if (sp != null && sp.type != sp.SHIP_TYPES) {
				switch(transferType) {
					case 1:
						fromCount = sp.count()/2;
						break;
					case 2:
						fromCount = 1;
						break;
					default:
						fromCount = sp.count();
				}
			}
			sendTransfer(fromFleet,toFleet,fromPos,toPos,fromCount);
		}
		selectSquad = target = -1;
	}

	public void drag(int x,int y) {
		for (int i=0;i<12;i++) {
			if (!crect[i+10].contains(x,y)) {
				continue;
			}
			target = i;
			break;
		}
	}

	public void action(Event e) {
		super.action(e);
		if (e.target==launch) signalLaunch();
		if (e.target==options) setState(new gsOptions(false));
		if (e.target==repeat) gbuild.flipRepeat();
		for (int id=0;id<Builds.BUILD_TYPES;id++) {
			if (e.target==build[id]) {
				gbuild.setType(id);
				Worlds wp = Worlds.get(gsFleet.destID);
				switch(id) {
					case 0: // Sloop
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 1: // Corsair
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 2: // Frigate
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 3: // Station
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 4: // Ranger
						goal.setValue(lastBuilt[id]);
						if (gbuild.repeat() != lastRepeat[id]) gbuild.flipRepeat();
						break;
					case 6: // Merchant
						goal.setValue(wp.maxMerchant()-wp.Merchant());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
					case 7: // Beacon
						goal.setValue(wp.maxBeacon()-wp.Beacon());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
					case 8: // Stardock
						goal.setValue(wp.maxStardock()-wp.Stardock());
						if (gbuild.repeat()) gbuild.flipRepeat();
						break;
				}
			}
		}
		if (e.target==send) sendBuildMessage();
		if (e.target==transferAll) transferType=0;
		if (e.target==transferHalf) transferType=1;
		if (e.target==transferOne) transferType=2;
		if (e.target==maxInd) {
			Worlds wp = Worlds.get(gsFleet.destID);
			if(gsFleet != null && wp != null) {
				if (wp.ind() != wp.maxInd()) {
					int val = wp.maxInd() - wp.ind();
					buildIndustry(val);
				}
			}
		}
		if (e.target==collect) collectShips();
		if (e.target==doBuild) autoBuild();
		if (e.target==set) setAutoBuild();
		if (e.target==setBuild) {
			setBuild.setVisible(false);
			setBuildConfirm.setVisible(true);
			settingBuild = true;
		}
		if (e.target==setBuildConfirm) {
			setBuild.setVisible(true);
			setBuildConfirm.setVisible(false);
			settingBuild = false;
		}
	}

	public boolean handleInput(Buffer buf){
		boolean value = super.handleInput(buf);;
		Fleets fp = null;
		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.BATTLE) setState(new gsBattle());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());
		return value;
	}

	void setAutoBuild() {
		Buffer buf;
		if (select<0 || select>=10 || gbuild==null) {
			return;
		}
		GameState.autoBuilds[select].copy(gbuild);
		select = -1;
		set.setVisible(false);
	}

//--- change build values ---
	void sendBuildMessage() {
		Buffer buf;
		if (select<0 || select>=10 || gbuild==null) {
			return;
		}
		if (gbuild.type() >= 0 && gbuild.type() <= 4) {
			Worlds wp = Worlds.get(gsFleet.destID);
			switch(gbuild.type()) {
				case 0: // Sloop
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 1: // Corsair
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 2: // Frigate
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 3: // Station
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
				case 4: // Ranger
					lastBuilt[gbuild.type()] = gbuild.goal();
					lastRepeat[gbuild.type()] = gbuild.repeat();
					break;
			}
		}

		buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,BUILD_COMMAND);
		buf.set(2,select);
		buf.set(3,(gbuild.repeat()?1:0));
		buf.set(4,gbuild.type());
		buf.set(5,gbuild.goal());
		buf.send();

		select = -1;
		send.setVisible(false);
	}

	public boolean press(int key) {
		switch (key) {
			case 9:	// Tab 10 enter
				setState(new gsOptions(false));
				return false;
		}
		return super.press(key);
	}

	void buildIndustry(int val) {
		int slot = 9;
		Buffer buf;

		if (val <= 0) {
			return;
		}
		if (autoIndStarted) {
			return;
		}
		autoIndStarted=true;

		while (val > 240 && slot >= 0) {
			buf = new Buffer(6);
			buf.set(0,6);
			buf.set(1, BUILD_COMMAND);
			buf.set(2, slot);
			buf.set(3, 0);
			buf.set(4, Builds.BUILD_INDUSTRY);
			buf.set(5, 240);
			buf.send();
			val -= 240;
			slot--;
		}
		if (val > 0 && slot >= 0) {
			buf = new Buffer(6);
			buf.set(0,6);
			buf.set(1, BUILD_COMMAND);
			buf.set(2, slot);
			buf.set(3, 0);
			buf.set(4, Builds.BUILD_INDUSTRY);
			buf.set(5, val);
			buf.send();
		}
	}

	public void drawEmpireStats(Graphics g,int h,int v) {
		Empires ep;

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString("Empire Facilities",h,v);
		g.drawString("Merchants: "+ep.Merchant(),h,v+=25);
		g.drawString("Cmd Build = "+ep.commandBuild(),h,v+=15);

		g.drawString("World Build = "+ep.worldBuild(),h,v+=15);
		
		g.drawString("Beacons: "+ep.Beacon(),h,v+=25);
		g.drawString("Cmd Speed = "+ep.commandSpeed(),h,v+=15);
		
		g.drawString("Stardocks: "+ep.Stardock(),h,v+=25);
		g.drawString("Cmd Decay = 1/"+ep.commandDecay(),h,v+=15);
		g.drawString("World Decay = 1/"+ep.worldDecay(),h,v+=15);
		g.drawString("Stellurae: "+ep.Stellurae(),h,v+=25);
	}

	void autoBuild() {
		autoBuildStarted = true;
		Buffer buf = new Buffer(6);
		buf.set(0,6);
		buf.set(1,BUILD_COMMAND);
		for (int i=0; i<Builds.MAX_COMMANDS; i++) {
			int type = GameState.autoBuilds[i].type();
			/*
			** Don't build the facility if it is already built
			*/
			Worlds wp = Worlds.get(gsFleet.destID);
			if (type - Builds.BUILD_MERCHANT >= 0 && wp.facility == type - Builds.BUILD_MERCHANT) {
				type = Builds.BUILD_NOTHING;
			}
			buf.set(2,i);
			buf.set(3,(GameState.autoBuilds[i].repeat()?1:0));
			buf.set(4,type);
			buf.set(5,GameState.autoBuilds[i].goal());
			buf.send();
		}
	}

	void collectShips() {
		Fleets fpFrom=null;
		Fleets fpToo=null;
		Squadron spFrom=null;
		Squadron spToo=null;

		int count = 0;

		fpFrom = gsFleet.getInvade();
		fpToo = gsFleet;

		/*
		** Count up number of stacks for each ship type
		** so we can split them up evenly
		*/
		int[] destSlots = new int[Squadron.SHIP_TYPES];
		int[] fromSlots = new int[Squadron.SHIP_TYPES];
		for (int pos=0; pos<6; pos++) {
			spToo = fpToo.squads(pos);
			if (spToo.type != Squadron.SHIP_TYPES) {
				destSlots[spToo.type]++;
			}
/*			spFrom = fpFrom.squads(pos);
			if (spFrom.type != Squadron.SHIP_TYPES) {
				fromSlots[spFrom.type]++;
			}*/
		}
		for (int toPos=0; toPos<6; toPos++) {
			spToo = fpToo.squads(toPos);
			if (spToo.type == Squadron.SHIP_TYPES) {
				continue;
			}
			int temp = destSlots[spToo.type];
			for (int fromPos=0; fromPos<6; fromPos++) {
				if (destSlots[spToo.type] == 0) {
					continue;
				}
				spFrom = fpFrom.squads(fromPos);
				if (spToo.type == spFrom.type && spToo.type != Squadron.SHIP_TYPES) {
					switch(transferType) {
						case 1:
							count = spFrom.count()/2;
							break;
						case 2:
							count = (destSlots[spToo.type]==1)?1:0;
							break;
						default:
							/*
							** Make sure we leave at least one to preserve defense layout
							*/
							count = spFrom.count() - ((destSlots[spToo.type]==1)?1:0);
					}
					sendTransfer(1,0,fromPos,toPos,(count/destSlots[spToo.type]));
					/*
					** Need to subtract out the squad count here as the server's reply
					** won't get processed until we are done with the transfer
					*/
					spFrom.count -= (count/destSlots[spToo.type]);
					/*
					** Drop the number of dest slots remaining for this ship type
					** in order to keep the distribution even
					*/
					destSlots[spToo.type]--;
				}
				destSlots[spToo.type] = temp;
			}
		}
	}
}
