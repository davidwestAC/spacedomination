<?php
  $arena='Beta'
  $online = array();


  $numOnline=0;
?>
