import java.awt.*;
import java.applet.*;
import java.awt.image.*;

class gsOptions extends GameState {

	Button quit,launch;
	Button top10,stats;
	Button graph,classic;
	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	final int[] delta = {-100,-10,-1,1,10,100};
	
	Buffer statBuf=null;

	public gsOptions(){
		Graphics g;
	}

	public void init(){		
		sendTop20Query();
		sendStatsQuery();
		
		root.add(quit = new Button("Quit"));
		root.add(launch = new Button("Launch"));
		root.add(top10 = new Button("Top 10"));
		root.add(stats = new Button("Stats"));
		root.add(graph = new Button("Graphical View"));
		root.add(classic = new Button("Classical View"));
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

		g.setColor(new Color(0,128,0));
		g.fillRect(0,0,500,400);

		fp = gsFleet;

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals
		
		drawEmpireStats(g,300,190);
		showTop10List(g,120,20);
		showGameStats(g,20,190);
		
	//--- draw buttons ---
		reshape(launch,10,5,80,20);
		reshape(quit,440,5,50,20);
		reshape(top10,440,30,50,20);
		reshape(stats,440,55,50,20);
		reshape(graph,390,350,100,20);
		reshape(classic,390,375,100,20);

	//--- chat messages ---
		if (message.length()>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(55,380,390,15);
			g.setColor(new Color(255,128,0));
			g.drawString(gsEmpire.name+": "+message,60,392);
		}

		count = chatCount();
		if (showChat && count>0) {
			g.setColor(new Color(64,0,64));
			g.fillRect(105,5,390,count*15);
			g.setColor(new Color(255,128,0));
			for (count--;count>=0;count--) 
				g.drawString(chatLine(count),110,17+count*15);
		}
	}

	void drawEmpireStats(Graphics g,int h,int v){
	Empires ep;
	String msg;

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),h,v);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Darts: "+ep.darts(),h,v+=15);
		g.drawString("Score: "+ep.score(),h,v+=15);
		g.drawString("Build Bonus: "+ep.buildBonus(),h,v+=15);

		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
	}

	void showTop10List(Graphics g,int h,int v){
	Empires emp;
	String name;
	int i;

		g.setColor(Color.white);
		g.drawString("Top 10 List",h+20,v);
		g.drawString("Score",h+160,v);
		g.drawString("Worlds",h+220,v);
		g.drawString("Darts",h+270,v);
		v += 2;

		for (i=0;i<10;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			g.drawString(""+(i+1)+"> "+name,h,v+=14);
			emp = Empires.get(top20List[i]);
			g.drawString(""+emp.hiScore,h+165,v);
			g.drawString(""+emp.hiWorlds,h+225,v);
			g.drawString(""+emp.hiDarts,h+275,v);
		}
		
		if (i==0) g.drawString("List Empty",h,v+=14);
	}

	public void showGameStats(Graphics g,int h,int v){
	Empires emp;
	String name;
	Date date;
	int i;

		g.setColor(Color.white);
		g.drawString("Current Game Statistics",h,v);

		if (statBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.drawString("Total Planets = "+statBuf.getInt(4),h,v+=22);
		g.drawString("Total Empires = "+statBuf.getInt(8),h,v+=15);
		g.drawString("Total StarDarts = "+statBuf.getInt(12),h,v+=15);
		g.drawString("Players Online = "+statBuf.getInt(16),h,v+=15);

		g.drawString("Maximum Score = "+statBuf.getInt(36),h,v+=30);
		g.drawString("Victory When High Score = "+((int)statBuf.get(2))+"%",h,v+=15);
		g.drawString("Current High Score = "+((int)statBuf.get(3))+"%",h,v+=15);
		date = new Date(statBuf.getInt(28),statBuf.getInt(32));
		g.drawString("Current Time is "+date.toString(),h,v+=15);

		if (statBuf.get(44)==0) return;		// no immortal victor as yet
		g.drawString("Last Immortal Victor <"+statBuf.getString(44)+" Empire>",h,v+=30);
		date = new Date(statBuf.getInt(20),statBuf.getInt(24));
		g.drawString("Victory Occurred "+date.toString(),h,v+=15);
		date = new Date(0,statBuf.getInt(40));
		g.drawString("Victory Took "+date.lengthStr(),h,v+=15);
	}

	final static int MAPW = 50;
	final static Rectangle map = new Rectangle(10,40,2*MAPW,2*MAPW);

	void drawMiniMap(Graphics g){
	int cx,cy,size,x,y,dx,dy;
	Worlds wp;
	Fleets fp;
	Color c;

		g.setColor(Color.black);
		g.fillRect(map.x,map.y,map.width,map.height);

		fp = gsFleet;
		if (fp==null) return;

		cx = fp.xloc();
		cy = fp.yloc();
		dx = map.x + MAPW;
		dy = map.y + MAPW;

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {

			switch (wp.type()) {
				case 13: g.setColor(wp.NEBULAE_COLOR); size = wp.NEBULAE_SIZE; break;
				case 14: g.setColor(wp.NEUTRON_COLOR); size = wp.NEUTRON_SIZE; break;
				case 15:
					x = StarDart.cycle;
					c = new Color(
						((x&32)==0?8*(x&31):252-8*(x&31)),
						((x&16)==0?16*(x&15):248-16*(x&15)),
						((x&64)==0?4*(x&63):253-4*(x&63))	
					); 
					size = wp.WORLD_SIZE; 
					break;
				default: g.setColor(wp.WORLD_COLOR); size = wp.WORLD_SIZE; break;
			}

			x = (wp.xloc()-cx) * MAPW / wp.scale;
			if (x+size<-MAPW || x-size>MAPW) continue;
			y = (wp.yloc()-cy) * MAPW / wp.scale;
			if (y+size<-MAPW || y-size>MAPW) continue;

			size = size * MAPW / wp.scale;
			g.fillOval(dx+x-size,dy+y-size,2*size+1,2*size+1);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {

			if (fp.ghost()) continue;

			x = (fp.xloc()-cx) * MAPW / wp.scale;
			if (x<-MAPW || x>MAPW) continue;
			y = (fp.yloc()-cy) * MAPW / wp.scale;
			if (y<-MAPW || y>MAPW) continue;

			wp = Worlds.get(fp.destID);
			if (wp!=null) {
				g.setColor(Color.blue);
				g.drawLine(dx+x,dy+y,
					dx+(wp.xloc()-cx) * MAPW / wp.scale,
					dy+(wp.yloc()-cy) * MAPW / wp.scale);
			}

			g.setColor(Color.red);
			g.fillRect(dx+x-1,dy+y-2,5,3);
		}

	//--- cut rects ---
		g.setColor(new Color(0,128,0));
		g.fillRect(0,map.y+map.height,500,400-map.y-map.height);
		g.fillRect(map.x+map.width,0,500-map.x-map.width,map.y+map.height);
		g.fillRect(map.x,0,map.width,map.y);
		g.fillRect(0,0,map.x,map.y+map.height);
	}

	public boolean handleInput(Buffer buf){

		if (super.handleInput(buf)) return true;

		if (buf!=null) switch (buf.get(1)) {
			case STATS_RESULT:
				statBuf = buf;
				break;
		}

		return false;
	}

	public void action(Event e){
	int id;

		super.action(e);

		if (e.target==launch) setState(new gsMovement());
		if (e.target==quit) setState(new gsPassword());
		if (e.target==top10) sendTop20Query();
		if (e.target==stats) sendStatsQuery();
		if (e.target==graph) Worlds.graphical = true;
		if (e.target==classic) Worlds.graphical = false;
	}
}