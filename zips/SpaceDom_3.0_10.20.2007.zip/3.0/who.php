<?php
  $arena=''
  $online = array();


  $numOnline=0;
?>
