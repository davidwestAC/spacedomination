import java.awt.*;
import java.applet.*;
import java.awt.image.*;
import java.util.Vector;
import java.util.Enumeration;
import java.util.Hashtable;

class gsMovement extends GameState {

//--- variables ---
	public static Worlds selectWorld = null;
	public static Fleets selectFleet = null;
	public static Worlds homeWorld = null;
	public static int homeDist,cx,cy;

	Button options;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(405,5,390,75);

	public static Portrait fleetIcon[] = null;
	public static Portrait starsNear = null;
	public static Portrait sidebar = null;

	public static Image fieldImage = null;
	public static Graphics fieldGraph = null;

//--- constructors ---
	public gsMovement(){
	Graphics g;

		fleetIcon = new Portrait[8];
		for (int i=0; i<8; i++) {
			fleetIcon[i] = SpaceDom.ships[i][0];
		}
		
		starsNear = SpaceDom.Images[SpaceDom.StarsNear];
		sidebar = SpaceDom.Images[SpaceDom.Sidebar];

		fieldImage = root.createImage(500,500);
		fieldGraph = fieldImage.getGraphics();

		g = root.offscreen.getGraphics();
		g.setColor(Color.black);
		g.fillRect(0,0,500,500);
	}

	public void init(){
		root.add(options = new Button("Options"));
		setBounds(options,5,380,90,15);
		checkRace();
	}

//--- primary functions ---
	public void paint(Graphics g){
	long time = System.currentTimeMillis();
	Worlds wp;
	Fleets fp;
	Squadron sp;
	int v,count;
	int dx,dy;

		if (gsFleet==null) {
			cx = cy = 0;
		} else {
			gsFleet.calcLocation(time);
			cx = gsFleet.xloc();
			cy = gsFleet.yloc();
		}

		g.setColor(Color.black);
		g.fillRect(0,0,500,500);
/*		if (starsNear!=null) {
			dx = (cx/7.0) % 400;
			if (dx<0) dx += 399;
			dy = (cy/7.0) % 400;
			if (dy<0) dy += 399;
			starsNear.draw(g,(int)(100-dx),(int)(0-dy));
			starsNear.draw(g,(int)(500-dx),(int)(0-dy));
			starsNear.draw(g,(int)(100-dx),(int)(400-dy));
			starsNear.draw(g,(int)(500-dx),(int)(400-dy));
		}*/
		if (starsNear!=null) {
			dx = (cx*10/7) % 400;
			if (dx<0) dx += 399;
			dy = (cy*10/7) % 400;
			if (dy<0) dy += 399;
			starsNear.draw(g,(100-dx),(int)(0-dy));
			starsNear.draw(g,(500-dx),(int)(0-dy));
			starsNear.draw(g,(100-dx),(int)(400-dy));
			starsNear.draw(g,(500-dx),(int)(400-dy));
		}

	//--- worlds & fleets ---
		fieldGraph.setColor(Color.black);
		fieldGraph.fillRect(0,0,500,500);
//		for (wp=Worlds.start();wp!=null;wp=wp.next()) wp.drawField(fieldGraph,cx,cy);
		for (wp=Worlds.start();wp!=null;wp=wp.next()) {
			if (wp.empireID < 0) return;
			if (wp.type==Worlds.NEBULAE) {
				wp.drawNebulaeField(fieldGraph,cx,cy);
			}
		}
		for (wp=Worlds.start();wp!=null;wp=wp.next()) {
			if (wp.empireID < 0) return;
			if (wp.type==Worlds.NEUTRON) {
				wp.drawNeutronField(fieldGraph,cx,cy);
			}
		}

		g.setXORMode(Color.black);
		g.drawImage(fieldImage,100,0,root);
		g.setPaintMode();

		for (wp=Worlds.start();wp!=null;wp=wp.next()) {
			wp.draw(g,cx,cy);
			findHomeWorld(wp);
		}

		for (fp=Fleets.start();fp!=null;fp=fp.next()) {
			drawFleet(g,fp);
		}

		drawMarkers(g);

	//--- status region ---
		g.setColor(Color.blue);
		g.fillRect(0,0,100,400);

		drawSidebar(g);

		drawEmpireStatsBrief(g,5,13);
		gsFleet.drawFleetStats(g,5,115,90,120);
		drawTargetStats(g);
		drawWorldStats(g);
		
		drawChatMessages(g);

//	System.out.println("FrameTime = "+(System.currentTimeMillis()-time));
	}

	void checkRace() {
		Empires ep = gsEmpire;
		if (ep.race==8) {
			setState(new gsRace());
		}
	}	
	
	void findHomeWorld(Worlds wp) {
		int x,y,dw;

		if (wp.empireID!=gsEmpireID) return;

		if (homeWorld==null) {
			GameState.nearestWorld = new ScreenMarker(wp.worldID(), Color.magenta);
			GameState.addActiveMarker(GameState.nearestWorld);
			gsMovement.homeWorld=wp;
			return;
		}

		homeDist = calcDistance(homeWorld.xloc()-cx,homeWorld.yloc()-cy);
		dw = calcDistance(wp.xloc()-cx,wp.yloc()-cy);

		if (dw < homeDist) {
			GameState.removeActiveMarker(GameState.nearestWorld);
			GameState.nearestWorld = new ScreenMarker(wp.worldID(), Color.magenta);
			GameState.addActiveMarker(GameState.nearestWorld);
			gsMovement.homeWorld = wp;
		}
	}


	int calcDistance(int dx,int dy) {
		if (dx<0) dx = -dx;
		if (dy<0) dy = -dy;
		return (dx>dy?dx+dy/2:dy+dx/2);
	}

	void drawMarkers(Graphics g) {
		Enumeration e = activeMarkers.elements();
		int ret, nt, nb, nr, nl;

		nt= nb= nr= nl =0;
		while(e.hasMoreElements()) {
			ScreenMarker marker = (ScreenMarker)e.nextElement();
			ret = marker.draw(g,cx,cy,nr,nl,nb,nt);
			switch (ret) {
				case 0:
					nr++;
					break;
				case 1:
					nl++;
					break;
				case 2:
					nb++;
					break;
				case 3:
					nt++;
					break;
			}
		}
	}

	void drawFleet(Graphics g,Fleets fp) {
	Worlds wp;
	Fleets ep;
	Empires emp;
	int x,y,wx,wy,rad;
	int size;

		emp = gsEmpire;
		if (emp==null) return;

		if (fp.ghost()) return;

		x = 300 + (fp.xloc()-cx) * 200 / Worlds.scale;
		if (x<100 || x>500) return;
		y = 200 + (fp.yloc()-cy) * 200 / Worlds.scale;
		if (y<0 || y>400) return;

		wp = Worlds.get(fp.destID);
		if (wp!=null) {
			wx = 300 + (wp.xloc()-cx) * 200 / Worlds.scale;
			wy = 200 + (wp.yloc()-cy) * 200 / Worlds.scale;
			g.setColor(Color.blue);
			g.drawLine(x,y,wx,wy);
		} else {
			ep = Fleets.get(fp.destID);
			if (ep!=null) {
				wx = 300 + (ep.xloc()-cx) * 200 / Worlds.scale;
				wy = 200 + (ep.yloc()-cy) * 200 / Worlds.scale;
				g.setColor(Color.blue);
				g.drawLine(x,y,wx,wy);
			}
		}

		if (fp==selectFleet) {
			g.setColor(Color.blue);
			g.fillRect(x-7,y-5,15,11);
		}

		if (fleetIcon==null) {
			g.setColor(Color.red);
			g.fillRect(x-5,y-3,11,7);
		} else {
			Empires empF = Empires.get(fp.empireID);
			int raceid = 0;
			if (empF != null) {
				raceid = Empires.get(fp.empireID).race();
			}
			if (raceid < 0 || raceid > 7) {
				raceid=0;
			}
			fleetIcon[raceid].center(g,x,y);
		}
	}

	void drawSidebar(Graphics g) {
		sidebar.center(g,50,200);
	}

	void drawEmpireStatsBrief(Graphics g,int h,int v) {
	Empires ep;
	Fleets fp;
	String msg;

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),h,v);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Darts: "+ep.darts(),h,v+=15);
		g.drawString("Scr: "+ep.score(),h,v+=15);

		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
		
		fp = gsFleet;
		g.drawString("X: "+fp.xloc(),h,v+=15);
		g.drawString("Y: "+(-fp.yloc()),h,v+=15);
	}

	void drawTargetStats(Graphics g) {
		Empires emp;
		int v = 240;

		if (selectFleet==null) return;

		emp = Empires.get(selectFleet.empireID);
		if (emp==null) return;
		
		g.setColor(Color.white);
		g.drawString(selectFleet.empireName(),7,v+=14);
		g.drawString(emp.racename(),7,v+=14);
		g.drawString("-->"+selectFleet.destName(),7,v+=14);
		g.drawString("Score: "+emp.score(),7,v+=14);
	}

	void drawWorldStats(Graphics g) {
		int v = 305;
		
		if (selectWorld!=null) {
			g.setColor(Color.white);
			g.drawString(selectWorld.name()+" s"+selectWorld.sector(),7,v+=15);
			g.drawString(selectWorld.special(),7,v+=15);
			g.drawString(selectWorld.empireName(),7,v+=15);
			if (selectWorld.isPlanet()) {
				g.drawString("p"+selectWorld.pop()+" i"+selectWorld.ind(),7,v+=15);
			}
		}
	}

//--- events & actions ---
	public void action(Event e) {
		int i;
		super.action(e);
		if (e.target==options) setState(new gsOptions(true));
	}

	public boolean handleInput(Buffer buf) {
		boolean value = super.handleInput(buf);;
		Fleets fp=null;
		Empires ep;

		switch (fleetStatus) {
			case Fleets.BATTLE:
				setState(new gsBattle());
				break;
			case Fleets.INDUSTRY:
				setState(new gsIndustry());
				break;
			case Fleets.DEAD:
				setState(new gsPassword());
				break;
			default:
				break;
		}
		return value;
	}

	public void down(int x,int y,Event e) {
		Buffer buf;
		int mx,my;
		Worlds wp;
		Fleets fp;

		if (x<0 || gsFleet==null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;

		wp = Worlds.find(mx,my);
		fp = Fleets.find(mx,my);

		if (e.controlDown()) {
			if (GameState.redWorlds.containsKey(new Integer(wp.worldID))) {
				if (wp!=null) GameState.redWorlds.remove(new Integer(wp.worldID));
			} else {
				if (wp!=null) GameState.redWorlds.put(new Integer(wp.worldID), wp);
			}
			return;
		}
		if (e.shiftDown()) {
			if (GameState.greenWorlds.containsKey(new Integer(wp.worldID))) {
				if (wp!=null) GameState.greenWorlds.remove(new Integer(wp.worldID));
			} else {
				if (wp!=null) GameState.greenWorlds.put(new Integer(wp.worldID), wp);
			}
			return;
		}
		if (e.metaDown()) {
			if (fp!=null) {
				sendFleetMove(fp.fleetID());
				return;
			}
			if (wp!=null) {
				sendFleetMove(wp.worldID());
				return;
			}
		}
		if (wp!=null) {
			sendFleetMove(wp.worldID());
			return;
		}
		if (fp!=null) {
			sendFleetMove(fp.fleetID());
		}
	}

	public void move(int x,int y) {
		int mx,my;

		if (x < 100) return;
		if (gsFleet == null) return;

		mx = gsFleet.xloc() + (x-300) * Worlds.scale / 200;
		my = gsFleet.yloc() + (y-200) * Worlds.scale / 200;

		selectWorld = Worlds.find(mx,my);
		selectFleet = Fleets.find(mx,my);
		if (selectFleet!=null && selectFleet.ghost()) selectFleet = null;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.contains(x,y);
	}

	public boolean press(int key) {
		switch (key) {
			case 27:	// Escape
				sendFleetMove(-1);
				return false;
			case 9:	// Tab 10 enter
				setState(new gsOptions(true));
				return false;
		}
		return super.press(key);
	}
}