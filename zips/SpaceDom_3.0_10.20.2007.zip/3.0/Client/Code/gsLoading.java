import java.awt.*;
import java.applet.*;
import java.lang.Thread;

class gsLoading extends GameState {

	int currentImage = 0;
	int pause = 8;
	Portrait back, back2;

//--- primary functions ---
	public gsLoading() {
		Graphics g;
	}

	public void init() {
		SpaceDom.Images = new Portrait[SpaceDom.numImages];
		back = new Portrait("Loading1.jpg");
		back2 = new Portrait("Loading2.jpg");
		try {
			MediaTracker mdtTracker = new MediaTracker(GameState.root);
			mdtTracker.addImage(back.image,0);
			mdtTracker.addImage(back2.image,0);
			mdtTracker.waitForAll();
		} catch(Exception e) {
			System.err.println("Error while waiting for background images: "+e.toString());
		}
		root.repaint();
	}

	public void paint(Graphics g) {
		int percent_done;
		Portrait temp;
		int offset;

		if (currentImage < SpaceDom.numImages) {
			SpaceDom.Images[currentImage] = new Portrait(SpaceDom.imageName[currentImage]);
			back.draw(g,0,0);
			percent_done = (int)((float)currentImage / (float)SpaceDom.numImages * 100.0);
			g.setColor(Color.white);
			g.setFont(stoutFNT);
			centerStout(g,"Loading "+percent_done+"%",260,250);
			currentImage++;
		} else {
			if (pause > 0) {
				back2.draw(g,0,0);
				try {
					Thread.sleep(50L);
				} catch(Exception e){}
				pause--;
			} else {
				/*
				** Set up animations
				*/
				SpaceDom.Images[SpaceDom.OldEarth].setAnimation(SpaceDom.Images[SpaceDom.OldEarth].height(),1,false);
				SpaceDom.Images[SpaceDom.NewEarth].setAnimation(SpaceDom.Images[SpaceDom.NewEarth].height(),1,true);
				SpaceDom.Images[SpaceDom.Makluvia].setAnimation(SpaceDom.Images[SpaceDom.Makluvia].height(),1,false);
				SpaceDom.Images[SpaceDom.Kaletia].setAnimation(SpaceDom.Images[SpaceDom.Kaletia].height(),1,true);
				SpaceDom.Images[SpaceDom.Zorestia].setAnimation(SpaceDom.Images[SpaceDom.Zorestia].height(),1,false);
				SpaceDom.Images[SpaceDom.Avaria].setAnimation(SpaceDom.Images[SpaceDom.Avaria].height(),1,false);
				SpaceDom.Images[SpaceDom.Najunia].setAnimation(SpaceDom.Images[SpaceDom.Najunia].height(),1,true);
				SpaceDom.Images[SpaceDom.Cestania].setAnimation(SpaceDom.Images[SpaceDom.Cestania].height(),1,false);
				SpaceDom.Images[SpaceDom.Quarethia].setAnimation(100,1,true);
				SpaceDom.Images[SpaceDom.StarDart].setAnimation(80,1,false);
				SpaceDom.Images[SpaceDom.Gateway].setAnimation(SpaceDom.Images[SpaceDom.Gateway].height(),2,false);
				SpaceDom.Images[SpaceDom.WormHole].setAnimation(SpaceDom.Images[SpaceDom.WormHole].height(),1,false);

				offset = 0;
				SpaceDom.planets = new Portrait[28];
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 84, 70, 30, 30); // Average
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],114, 70, 30, 30); // Average
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],144, 70, 30, 30); // Average
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.OldEarth];
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],  0, 70, 42, 42); // Core
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 70, 35, 35, 35); // Poor
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],174, 70, 30, 30); // Rich
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],200, 45, 25, 25); // Small
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 42, 70, 42, 42); // Large
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],  0,  0, 34, 34); // Aquatic
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 35, 35, 35, 35); // Mountain
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 70,  0, 35, 35); // Desert
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],140, 35, 35, 35); // Tundra
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],105,  0, 35, 35); // Jungle
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],  0, 35, 35, 35); // Metallic
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],140,  0, 35, 35); // Merchant
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],175, 45, 25, 25); // Beacon
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],105, 35, 35, 35); // Stardock
//				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets], 35,  0, 35, 35); // Blaster
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.NewEarth];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Makluvia];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Kaletia];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Zorestia];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Avaria];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Najunia];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Cestania];
				SpaceDom.planets[offset++] = SpaceDom.Images[SpaceDom.Quarethia];
				SpaceDom.planets[offset++] = new Portrait(SpaceDom.Images[SpaceDom.Planets],175,  0, 45, 45); // Dead

				SpaceDom.ships = new Portrait[9][6];
				SpaceDom.ships[0][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 32,448, 16, 16); // SloopHuman
				SpaceDom.ships[0][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships],  0, 64, 64, 64); // FrigateHuman

				SpaceDom.ships[1][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 64,448, 16, 16); // SloopMakluvian
				SpaceDom.ships[1][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships],  0,128, 64, 64); // FrigateMakluvian

				SpaceDom.ships[2][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 48,448, 16, 16); // SloopKaletian
				SpaceDom.ships[2][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 64, 64, 64, 64); // FrigateKaletian

				SpaceDom.ships[3][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships],112,448, 16, 16); // SloopZorestian
				SpaceDom.ships[3][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 64,192, 64, 64); // FrigateZorestian

				SpaceDom.ships[4][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships],  0,448, 16, 16); // SloopAvarian
				SpaceDom.ships[4][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships],  0,  0, 64, 64); // FrigateAvarian

				SpaceDom.ships[5][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 80,448, 16, 16); // SloopNajunian
				SpaceDom.ships[5][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 64,128, 64, 64); // FrigateNajunian

				SpaceDom.ships[6][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 16,448, 16, 16); // SloopCestanian
				SpaceDom.ships[6][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 64,  0, 64, 64); // FrigateCestanian

				SpaceDom.ships[7][0] = new Portrait(SpaceDom.Images[SpaceDom.Ships], 96,448, 16, 16); // SloopQuarethian
				SpaceDom.ships[7][2] = new Portrait(SpaceDom.Images[SpaceDom.Ships],  0,192, 64, 64); // FrigateQuarethian

				int x,y;
				x = 0;
				y = 256;
				SpaceDom.ships[4][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationAvarian
				x += 32;
				SpaceDom.ships[6][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationCestanian
				x += 32;
				SpaceDom.ships[0][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationHuman
				x += 32;
				SpaceDom.ships[2][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationKaletian
				x = 0;
				y += 32;
				SpaceDom.ships[1][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationMakluvian
				x += 32;
				SpaceDom.ships[5][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationNajunian
				x += 32;
				SpaceDom.ships[7][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationQuarethian
				x += 32;
				SpaceDom.ships[3][3] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // StationZorestian
				x = 0;
				y += 32;
				SpaceDom.ships[4][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerAvarian
				x += 32;
				SpaceDom.ships[6][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerCestanian
				x += 32;
				SpaceDom.ships[0][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerHuman
				x += 32;
				SpaceDom.ships[2][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerKaletian
				x = 0;
				y += 32;
				SpaceDom.ships[1][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerMakluvian
				x += 32;
				SpaceDom.ships[5][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerNajunian
				x += 32;
				SpaceDom.ships[7][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerQuarethian
				x += 32;
				SpaceDom.ships[3][4] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // RangerZorestian
				x = 0;
				y += 32;
				SpaceDom.ships[4][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairAvarian
				x += 32;
				SpaceDom.ships[6][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairCestanian
				x += 32;
				SpaceDom.ships[0][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairHuman
				x += 32;
				SpaceDom.ships[2][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairKaletian
				x = 0;
				y += 32;
				SpaceDom.ships[1][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairMakluvian
				x += 32;
				SpaceDom.ships[5][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairNajunian
				x += 32;
				SpaceDom.ships[7][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairQuarethian
				x += 32;
				SpaceDom.ships[3][1] = new Portrait(SpaceDom.Images[SpaceDom.Ships], x, y, 32, 32); // CorsairZorestian

				for (int i=0; i<=8; i++) {
					SpaceDom.ships[i][5] = SpaceDom.Images[SpaceDom.StarDart];
				}

				SpaceDom.ships[8][0] = SpaceDom.ships[0][0]; // SloopHuman
				SpaceDom.ships[8][1] = SpaceDom.ships[0][1]; // CorsairHuman
				SpaceDom.ships[8][2] = SpaceDom.ships[0][2]; // FrigateHuman
				SpaceDom.ships[8][3] = SpaceDom.ships[0][3]; // StationHuman
				SpaceDom.ships[8][4] = SpaceDom.ships[0][4]; // RangerHuman

				GameState.setState(new gsPassword());
			}
		}
		root.repaint();
	}

	void centerStout(Graphics g,String msg,int h,int v) {
		g.drawString(msg,h-stoutMET.stringWidth(msg)/2,v);
	}
}