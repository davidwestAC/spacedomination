import java.awt.*;

class Squadron implements MessageValues {

	final static int STARDART = 5;
	final static int SHIP_TYPES = 6;
	final static String[] name = {
		"Sloop","Corsair","Frigate",
		"Station","Ranger","Star Dart",
		"<empty>"
	};
// todo get the guns from the server
	final static int guns[] = {1,5,20,2,5,2500,0};

	final static int INVADETOP = 0;
	final static int INVADEMID = 1;
	final static int INVADEBOT = 2;
	final static int DEFENDTOP = 3;
	final static int DEFENDMID = 4;
	final static int DEFENDBOT = 5;

//--- squadron combat actions ---
	public final static int DEFEND = 0;
	public final static int RETREAT = 1;

	public final static int MOVEUP = 2;
	public final static int MOVEDOWN = 3;
	public final static int MOVELEFT = 4;
	public final static int MOVERIGHT = 5;

	public final static int FIRE_SLOOP = 6;
	public final static int FIRE_CORSAIR = 7;
	public final static int FIRE_FRIGATE = 8;
	public final static int FIRE_STATION = 9;
	public final static int FIRE_RANGER = 10;
	public final static int FIRE_STARDART = 11;

//--- variables ---
	int position,count,type,damage,action,timer,fireNow=-1,enemy;

//--- constructors ---
	public Squadron(int pos){
		position = pos;
		type = SHIP_TYPES;
		action = DEFEND;
	}

	public int type(){return type;}
	public int count(){return count;}
	public int position(){return position;}
	public int damage(){return damage;}
	public int action(){return action;}
	public int timer()
	{
		if (timer == 0)
		{
			if (fireNow != 0)
			{
				fireNow--;
			}
		} else
		{
			fireNow = 5;
		}
		return timer;
	}
	public int fireNow(){return fireNow;}
	public String name(){return name[type];}

	public int guns(){return guns[type] * count - damage;}
	public int hits(){return guns[type];}

	public boolean isDefend(){return (action==DEFEND);}
	public boolean isRetreat(){return (action==RETREAT);}
	public boolean isMoving(){return (action>=MOVEUP && action<=MOVERIGHT);}
	public boolean isFiring(){return (action>=FIRE_SLOOP);}

//--- functions ---
	public void set(int offset,int pos,Buffer buf){
//	int offset;

//		offset = 18 + pos * 8;
		offset += pos * 8;
//System.out.println("Reading from offset "+offset);
		type = buf.unsigned(offset+0);
		action = buf.unsigned(offset+1);
		timer = buf.unsigned(offset+2);
		enemy = buf.unsigned(offset+3);
		damage = buf.getUShort(offset+4);
		count = buf.getUShort(offset+6);
//System.out.println("type = "+type+", action = "+action+", timer = "+timer+", enemy = "+enemy+", damage = "+damage+", count = "+count);
	}

//--- action functions ---
	public int Heading(){return (action-MOVEUP);}
	public int TargetType(){return (action-FIRE_SLOOP);}
	public boolean TargetInvade(){return (enemy==2);}

	public static int MakeFireAction(int type){return (FIRE_SLOOP+type);}
};