import java.awt.*;

class ScreenMarker
{

	Point drawn;
	Color color;
	int border_h;
	int border_v;
	int tx, ty;
	int id;
	long start;
	String label;
	int x_offset = 50;
	int y_offset = 15;

	ScreenMarker(int worldID, Color color)
	{
		if (worldID == 0)
		{
			this.id = 0;
			this.label = "Old Earth";
			this.color = color;
			this.tx = 0;
			this.ty = 0;
		} else
		{
			Worlds wp = Worlds.get(worldID);
			this.id = wp.worldID();
			this.label = wp.name();
			this.color = color;
			this.tx = wp.xloc();
			this.ty = wp.yloc();
		}
		this.border_h = 0;
		this.border_v = 0;
		drawn = null;
	}

	ScreenMarker(int worldID, Color color, int h, int v)
	{
		if (worldID == 0)
		{
			this.id = 0;
			this.label = "Old Earth";
			this.color = color;
			this.tx = 0;
			this.ty = 0;
		} else
		{
			Worlds wp = Worlds.get(worldID);
			this.id = wp.worldID();
			this.label = wp.name();
			this.color = color;
			this.tx = wp.xloc();
			this.ty = wp.yloc();
		}
		this.border_h = h;
		this.border_v = v;
		drawn = null;
	}

	boolean clickedInside(int x, int y)
	{
		if(drawn == null)
		{
			return false;
		}
		if(x < drawn.x - 5 || x > drawn.x + 5)
		{
			return false;
		}
		if(y < drawn.y - 5 || y > drawn.y + 5)
		{
			return false;
		}
		return true;
	}

	void draw(Graphics g, int cx, int cy)
	{
		int range,mx,my,dx,dy;
		String msg;

		range = Worlds.scale;

		mx = cx - tx;
		my = cy - ty;

		if (mx > -range && mx < range && my > -range && my < range)
		{
			return;
		}

		range = calcDistance(mx,my);
		dx = (mx<0?-mx:mx);
		dy = (my<0?-my:my);

		if (dx>dy)
		{
			dy = (my * (196-border_v)) / (1+dx);
			dx = (mx * (196-border_h)) / (1+dx);
		}
		else
		{
			dx = (mx * (196-border_h)) / (1+dy);
			dy = (my * (196-border_v)) / (1+dy);
		}

		dx = 300 - dx;
		dy = 200 - dy;
		
		g.setColor(color);
		g.drawLine(dx-4,dy,dx,dy-4);
		g.drawLine(dx,dy-4,dx+4,dy);
		g.drawLine(dx+4,dy,dx,dy+4);
		g.drawLine(dx,dy+4,dx-4,dy);

		drawn = new Point(dx, dy);

//		range = range / 10;
		range = range;

		msg = label+" "+range;
		
		if (dx > 300)
		{
			g.drawString(msg,dx-GameState.textMET.stringWidth(msg)-5,dy+5);
		}
		else
		{
			g.drawString(msg,dx+5,dy+5);
		}
	}

	int draw(Graphics g, int cx, int cy, int nr, int nl, int nb, int nt)
	{
		int range,mx,my,dx,dy;
		int return_val;
		String msg;

		range = Worlds.scale;

		mx = cx - tx;
		my = cy - ty;

		if (mx > -range && mx < range && my > -range && my < range)
		{
			return -1;
		}

		range = calcDistance(mx,my);
		dx = (mx<0?-mx:mx);
		dy = (my<0?-my:my);

		if (dx>dy)
		{
			dy = (my * (196-border_v)) / (1+dx);
			dx = (mx * (196-border_h)) / (1+dx);
			if (dx < 0)
			{
				// right side of screen
				dx += nr * x_offset;
				return_val = 0;
			} else
			{
				// left side of screen
				dx -= nl * x_offset;
				return_val = 1;
			}
		}
		else
		{
			dx = (mx * (196-border_h)) / (1+dy);
			dy = (my * (196-border_v)) / (1+dy);
			if (dy < 0)
			{
				// bottom side of screen
				dy += nb * y_offset;
				return_val = 2;
			} else
			{
				// top side of screen
				dy -= nt * y_offset;
				return_val = 3;
			}
		}

		dx = 300 - dx;
		dy = 200 - dy;

		g.setColor(color);
		g.drawLine(dx-4,dy,dx,dy-4);
		g.drawLine(dx,dy-4,dx+4,dy);
		g.drawLine(dx+4,dy,dx,dy+4);
		g.drawLine(dx,dy+4,dx-4,dy);

		drawn = new Point(dx, dy);

//		range = range / 10;
		range = range;

		msg = label+" "+range;
		
		if (dx > 300)
		{
			g.drawString(msg,dx-GameState.textMET.stringWidth(msg)-5,dy+5);
		}
		else
		{
			g.drawString(msg,dx+5,dy+5);
		}

		return return_val;
	}

	int calcDistance(int dx, int dy)
	{
		if(dx < 0)
		{
			dx = -dx;
		}
		if(dy < 0)
		{
			dy = -dy;
		}
		return dx <= dy ? dy + dx / 2 : dx + dy / 2;
	}
}
