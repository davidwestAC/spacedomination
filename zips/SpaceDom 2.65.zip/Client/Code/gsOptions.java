import java.awt.*;
import java.applet.*;
import java.awt.image.*;

class gsOptions extends GameState {

	Button restart;
	Button quit,launch;
	Button top10,stats,settings;
	Button change[];

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

	final String[] ChanStr = {"-C","-D","-I","+I","+D","+C"};
	final int[] delta = {-100,-10,-1,1,10,100};
	
	Buffer statBuf = null;
	Buffer setBuf = null;

	public gsOptions(){
		Graphics g;
	}

	public void init(){		
		sendTop20Query();
		sendStatsQuery();
		sendSettingsQuery();
		
		root.add(quit = new Button("Quit"));
		root.add(restart = new Button("Restart"));
		root.add(launch = new Button("Launch"));
		root.add(top10 = new Button("Top 10"));
		root.add(stats = new Button("Stats"));
		root.add(settings = new Button("Settings"));
		
		change = new Button[6];
		for (int i=0;i<6;i++) root.add(change[i] = new Button(ChanStr[i]));
	}

	public void paint(Graphics g){
	Rectangle r;
	Fleets fp,ep;
	Squadron sp;
	Builds bp;
	int i,val,count;

		g.setColor(new Color(0,128,0));
		g.fillRect(0,0,500,400);

		fp = gsFleet;

		drawMiniMap(g);		// need to fill, then cut to cover nebulae+neutron ovals
		
		drawEmpireStats(g,180,190);
		showTop10List(g,120,20);
		showGameStats(g,20,190);
		drawChannelStats(g,410,245);
		
	//--- draw buttons ---
		reshape(launch,10,5,80,20);
		if (GameState.gsEmpireID==1 || GameState.gsEmpireID==2) reshape(restart,10,150,50,20);
		reshape(top10,440,300,50,20);
		reshape(stats,440,325,50,20);
		reshape(settings,440,350,50,20);
		reshape(quit,440,375,50,20);
		for (i=0;i<6;i++) reshape(change[i],410+(i%3)*25+(i/3)*5,265+(i/3)*15,25,15);
		
		drawChatMessages(g);
	}

	void drawChannelStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	
		g.setColor(Color.white);
		ep = gsEmpire;
		
		msg = "Channel: "+channel;
		if (channel!=ep.channel()) msg += "*";
		g.drawString(msg,h,v+=15);
	}

	void checkRestart(){
	Empires ep;
	
		ep = gsEmpire;
		if (ep.channel()==111) sendRestart();	
	}

	public void drawEmpireStats(Graphics g,int h,int v){
	Empires ep;
	String msg;
	int val1,val2,val3,val4;

		if (setBuf==null) {
			g.drawString("waiting for server...",h+30,v+=15);
			return;
		}

		g.setColor(Color.white);
		ep = gsEmpire;
		g.drawString(ep.name(),h,v);		
		g.drawString("Race: "+ep.racename(),h,v+=15);
		g.drawString("Worlds: "+ep.worlds(),h,v+=15);
		g.drawString("Phenomena: "+ep.phenomena(),h,v+=15);
		g.drawString("Total Darts: "+ep.darts(),h,v+=15);
		g.drawString("Score Darts: "+ep.scoreDarts(),h,v+=15);
		g.drawString("Score: "+ep.score(),h,v+=15);
		g.drawString("Facilities",290,190);
		g.drawString("Merchants: "+ep.Merchant(),290,205);
		val1 = setBuf.getInt(20);
		val2 = setBuf.getInt(24);
		val3 = val1 + (val2 * ep.Merchant());
		if (ep.race==1) val3 = val3 * 23 / 20;
		g.drawString("Cmd Build = "+val3,290,220);
		
		val1 = setBuf.getInt(28);
		val2 = val1 * ep.Merchant();
		if (ep.race==1) val2 = val2 * 5 / 4;
		g.drawString("World Build = +"+val2,290,235);
		
		g.drawString("Beacons: "+ep.Beacon(),290,260);
		val1 = setBuf.getInt(32);
		val2 = setBuf.getInt(36);
		val3 = setBuf.getInt(40);
		val4 = val1 + (ep.Beacon() * val2);

		if (ep.race==2) {
			val4 = val4 * 11 / 10;
		}
		if (val4 > val3) val4 = val3;

		g.drawString("Cmd Speed = "+val4,290,275);
		
		g.drawString("Stardocks: "+ep.Stardock(),290,300);
		val1 = setBuf.getInt(44);
		val2 = setBuf.getInt(48);
		val3 = val1 + (ep.Stardock() * val2);
		if (ep.race==3) val3 = val3 * 5 / 4;
		g.drawString("Cmd Decay = 1/"+val3,290,315);
		val1 = setBuf.getInt(52);
		val2 = setBuf.getInt(56);
		val3 = val1 + (ep.Stardock() * val2);
		if (ep.race==3) val3 = val3 * 5 / 4;
		g.drawString("World Decay = 1/"+val3,290,330);
		
		g.drawString("Stellurae: "+ep.Stellurae(),290,355);
	}

	void showTop10List(Graphics g,int h,int v){
	Empires emp;
	String name;
	int i;

		g.setColor(Color.white);
		g.drawString("Top 10 List",h+20,v);
		g.drawString("Score",h+130,v);
		g.drawString("Worlds",h+200,v);
		g.drawString("Darts",h+250,v);
		g.drawString("Race",h+290,v);
		v += 2;

		for (i=0;i<10;i++) {
			name = Empires.findEmpireName(top20List[i]);
			if (Empires.UNKNOWN.equals(name)) break;
			g.drawString(""+(i+1)+"> "+name,h,v+=14);
			emp = Empires.get(top20List[i]);
			g.drawString(""+emp.hiScore,h+130,v);
			g.drawString(""+emp.hiWorlds,h+200,v);
			g.drawString(""+emp.hiDarts,h+250,v);
			g.drawString(""+emp.racename(),h+290,v);
		}
		
		if (i==0) g.drawString("List Empty",h,v+=14);
	}

	public void move(int x,int y){
	int mx,my;

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.inside(x,y);
	}

	public boolean handleInput(Buffer buf){
	Empires ep;

		ep = gsEmpire;
		if (ep!=null && ep.channel!=channel) sendChannel();

		if (super.handleInput(buf)) return true;

		if (buf!=null) switch (buf.get(1)) {
			case STATS_RESULT:
				statBuf = buf;
				break;
				
			case SETTINGS_RESULT:
				setBuf = buf;
				break;
		}

		return false;
	}

	public void action(Event e){
	int id;
	int i;

		super.action(e);

		if (e.target==restart) checkRestart();
		if (e.target==launch) setState(new gsMovement());
		if (e.target==quit) setState(new gsPassword());
		if (e.target==top10) sendTop20Query();
		if (e.target==stats) sendStatsQuery();
		if (e.target==settings) sendSettingsQuery();
		for (i=0;i<6;i++) if (e.target==change[i]) {
			channel += delta[i];
			if (channel<0) channel = 0;
			if (channel>10000) channel = 10000;
			break;
		}
	}
}