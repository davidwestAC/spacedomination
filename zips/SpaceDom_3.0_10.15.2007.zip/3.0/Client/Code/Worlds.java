import java.awt.*;
import java.util.Hashtable;

class Worlds {

	static Worlds root = null;

	public final static int NORMAL = 0;

	public final static int HOME = 1;
	public final static int CORE = 2;
	public final static int POOR = 3;
	public final static int RICH = 4;
	public final static int SMALL = 5;
	public final static int LARGE = 6;
	public final static int AQUATIC = 7;
	public final static int MOUNTAIN = 8;
	public final static int DESERT = 9;
	public final static int TUNDRA = 10;
	public final static int JUNGLE = 11;
	public final static int METALLIC = 12;
	public final static int MERCHANT = 13;
	public final static int BEACON = 14;
	public final static int STARDOCK = 15;
	public final static int NEWEARTH = 16;
	public final static int MAKLUVIA = 17;
	public final static int KALETIA = 18;
	public final static int ZORESTIA = 19;
	public final static int AVARIA = 20;
	public final static int NAJUNIA = 21;
	public final static int CESTANIA = 22;
	public final static int QUARETHIA = 23;
	
	public final static int NEBULAE = 24;
	public final static int NEUTRON = 25;
	public final static int GATEWAY = 26;
	public final static int WORMHOLE = 27;
	public final static int DEAD = 28;

//	public final static int NEBULAE_SIZE = 2000;
//	public final static int NEUTRON_SIZE = 1500;
//	public final static int RED_GIANT_SIZE = 1800;
//	public final static int BLUE_DWARF_SIZE = 1400;
//	public final static int WORLD_SIZE = 100;
	public final static int NEBULAE_SIZE = 200;
	public final static int NEUTRON_SIZE = 150;
	public final static int RED_GIANT_SIZE = 180;
	public final static int BLUE_DWARF_SIZE = 140;
	public final static int WORLD_SIZE = 10;
//	public final static Color NEBULAE_COLOR = new Color(64,64,64);
	public final static Color NEBULAE_COLOR = new Color(64,150,64);
	public final static Color NEUTRON_COLOR = new Color(128,128,64);
//	public final static Color RED_GIANT_COLOR = new Color(128,32,32);
//	public final static Color BLUE_DWARF_COLOR = new Color(32,32,128);

//	public static int scale = 2250;
	public static int scale = 225;

	final static String[] special = {
		"Average",
		"Home World","Core World",
		"Poor","Rich",
		"Small","Large",
		"Aquatic","Mountain",
		"Desert","Tundra",
		"Jungle","Metallic",
		"Merchant","Beacon","Stardock",
		"Home World","Home World","Home World",
		"Home World","Home World","Home World",
		"Home World","Home World",
		"Nebulae","Neutron Star","Gateway","Wormhole","Dead"
	};
	
//	final static int[] maxInd = {4,6,6,4,4,2,6,4,4,4,4,4,4,4,4,4,6,6,6,6,6,6,6,6,0,0,0,0,0,0,0};

// Added Merchant,Beacon,Stardock,Blaster
	public final static String[] facilityname = {
		"Merchant","Beacon",
		"Stardock","Doomsday",
		"Stellurae","Shield",
		"Nothing",
	};
	
	Portrait wormhole = null;
	Portrait gateway = null;
	Portrait neutron = null;
	Portrait nebulae = null;

//--- variables ---
	int worldID,x,y,type,empireID,pop,ind,maxInd,storage;
	int Merchant,maxMerchant,Beacon,maxBeacon,Stardock,maxStardock,sector;
	int facility,facilityTime;
	Builds[] builds;
	String name;
	Worlds next;

//--- constructors ---
	public Worlds() {
		builds = null;
		storage = 0;
		next = null;
		
		neutron = SpaceDom.Images[SpaceDom.Neutron];
		nebulae = SpaceDom.Images[SpaceDom.Nebulae];

		//
		// Load animations
		//
		wormhole = SpaceDom.Images[SpaceDom.WormHole];
		gateway = SpaceDom.Images[SpaceDom.Gateway];
	}

	public void init() {}

	public boolean isPlanet(){return type<NEBULAE;}
	public boolean isZone(){return (type==NEBULAE || type==NEUTRON);}

	public Portrait portrait() {
		switch (type) {
			case DEAD:
				return SpaceDom.planets[27];
			case NORMAL:
				return SpaceDom.planets[worldID%3];
		}
		return SpaceDom.planets[type+2];
	}

	public int worldID() {return worldID;}
	public int xloc() {return x;}
	public int yloc() {return y;}
	public int type() {return type;}
	public int pop() {return pop;}
	public int ind() {return ind;}
//	public int maxInd() {return pop*maxInd[type];}
	public int maxInd() {return maxInd;}
	public String name() {return name;}
	public String special() {return special[type];}
	public int storage() {return storage;}
	public int Merchant() {return Merchant;}
	public int maxMerchant() {return maxMerchant;}
	public int Beacon() {return Beacon;}
	public int maxBeacon() {return maxBeacon;}
	public int Stardock() {return Stardock;}
	public int maxStardock() {return maxStardock;}
	public int sector() {return sector;}
	public int facility() {return facility;}
	public String facilityname() {return facilityname[facility];}
	public int facilityTime() {return facilityTime;}
	public static Worlds start() {return root;} 
	public Worlds next() {return next;}
	public int empireID() {return empireID;}
	public String empireName() {return Empires.findEmpireName(empireID);}

//--- statistics ---
	public void drawField(Graphics g,int cx,int cy) {
		if (empireID < 0) return;
		switch (type) {
			case NEBULAE: drawNebulaeField(g,cx,cy); break;
			case NEUTRON: drawNeutronField(g,cx,cy); break;
		}
	}


	public void draw(Graphics g,int cx,int cy) {
		if (empireID < 0) return;
		switch (type) {
			case NEBULAE: drawNebulae(g,cx,cy); break;
			case NEUTRON: drawNeutron(g,cx,cy); break;
			case GATEWAY: drawGateway(g,cx,cy); break;
			case WORMHOLE: drawWormhole(g,cx,cy); break;
			default: drawPlanet(g,cx,cy); break;
		}
	}

	
	void drawNebulae(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 300 + (x - cx) * 200 / scale;
		if (dx + NEBULAE_SIZE < 100 || dx - NEBULAE_SIZE > 500) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + NEBULAE_SIZE < 0 || dy - NEBULAE_SIZE > 400) return;

		drawStatistics(g,dx,dy);
	}


	void drawNeutron(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 300 + (x - cx) * 200 / scale;
		if (dx + NEUTRON_SIZE < 100 || dx - NEUTRON_SIZE > 500) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + NEUTRON_SIZE < 0 || dy - NEUTRON_SIZE > 400) return;

		drawStatistics(g,dx,dy);
	}

	void drawNebulaeField(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 200 + (x - cx) * 200 / scale;
		if (dx + NEBULAE_SIZE < 0 || dx - NEBULAE_SIZE > 400) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + NEBULAE_SIZE < 0 || dy - NEBULAE_SIZE > 400) return;

		g.setColor(NEBULAE_COLOR);
//		int rad = NEBULAE_SIZE * 200 / scale;
		
		nebulae.center(g,dx,dy);
//		g.drawOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
	}


	void drawNeutronField(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 200 + (x - cx) * 200 / scale;
		if (dx + NEUTRON_SIZE < 0 || dx-NEUTRON_SIZE > 400) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + NEUTRON_SIZE < 0 || dy - NEUTRON_SIZE > 400) return;

		g.setColor(NEUTRON_COLOR);
//		int rad = NEUTRON_SIZE * 200 / scale;

		neutron.center(g,dx,dy);
//		g.drawOval(dx-rad,dy-rad,2*rad+1,2*rad+1);
	}

	void drawGateway(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 300 + (x - cx) * 200 / scale;
		if (dx + WORLD_SIZE < 100 || dx - WORLD_SIZE > 500) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + WORLD_SIZE < 0 || dy - WORLD_SIZE > 400) return;

		gateway.center(g,dx,dy);
		drawStatistics(g,dx,dy);
	}

	void drawWormhole(Graphics g,int cx,int cy) {
		int dx,dy;

		dx = 300 + (x - cx) * 200 / scale;
		if (dx + WORLD_SIZE < 100 || dx - WORLD_SIZE > 500) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + WORLD_SIZE < 0 || dy - WORLD_SIZE > 400) return;

		wormhole.center(g,dx,dy);
		drawStatistics(g,dx,dy);
	}

	void drawPlanet(Graphics g,int cx,int cy) {
/*		double dx,dy;

		dx = 300.0 + (x - cx) * 200.0 / scale;
		if (dx + WORLD_SIZE < 100 || dx - WORLD_SIZE > 500) return;
		dy = 200.0 + (y - cy) * 200.0 / scale;
		if (dy + WORLD_SIZE < 0 || dy - WORLD_SIZE > 400) return;
*/
		int dx,dy;

		dx = 300 + (x - cx) * 200 / scale;
		if (dx + WORLD_SIZE < 100 || dx - WORLD_SIZE > 500) return;
		dy = 200 + (y - cy) * 200 / scale;
		if (dy + WORLD_SIZE < 0 || dy - WORLD_SIZE > 400) return;

		portrait().center(g,dx,dy);
		drawStatistics(g,(int)dx,(int)dy);
	}

	void drawFlag(Graphics g,int x,int y) {
		int[] xp = {0,12,0};
		int[] yp = {-5,0,5};

		for (int i=0;i<3;i++) {
			xp[i] += x;
			yp[i] += y;
		}
		g.drawPolygon(xp,yp,3);
	}


	void drawStatistics(Graphics g,int dx,int dy){
		int w=36;
		if (empireID==GameState.gsEmpireID) {
			g.setColor(Color.yellow);
			drawFlag(g,dx+6,dy-12);
		} else if (empireID>0){
//			g.setColor(Color.cyan);
//			drawFlag(g,dx+6,dy-12);
// Draw the enemy player's name instead of a blue flag
			g.setColor(Color.black);
			g.drawString(Empires.findEmpireName(empireID), dx + 7, dy - 13);
			g.setColor(Color.cyan);
			g.drawString(Empires.findEmpireName(empireID), dx + 6, dy - 12);
		}
		if (isPlanet()) {
			w = portrait().width();
		}
		if (this==gsMovement.selectWorld) {
			g.setColor(Color.cyan);
			g.drawOval(dx-(w/2),dy-(w/2),w,w);
		}
		if (GameState.redWorlds.containsKey(new Integer(worldID))) {
			g.setColor(Color.red);
			g.drawOval(dx-(w/2)-1,dy-(w/2)-1,w+2,w+2);
		}
		if (GameState.greenWorlds.containsKey(new Integer(worldID))) {
			g.setColor(Color.green);
			g.drawOval(dx-(w/2)+1,dy-(w/2)+1,w-2,w-2);
		}
		if (this==gsMovement.selectWorld) {
			g.setColor(Color.cyan);
			g.drawOval(dx-(w/2),dy-(w/2),w,w);
		}
		if (name!=null) {
			g.setColor(Color.black);
			g.drawString(name,dx+13,dy+7);
			g.setColor(Color.red);
			g.drawString(name,dx+12,dy+6);
		}
	}

//--- functions ---
	public static void add(Buffer buf) {
		Worlds temp,wp;
		boolean found;
		int id, offset;

		offset = 2;
		id = buf.getInt(offset);
		wp = get(id);

		found = (wp!=null);
		temp = (found?wp:new Worlds());

//		temp.worldID = id;

		temp.x = buf.getInt(offset+=4);
		temp.y = buf.getInt(offset+=4);
		temp.type = buf.getInt(offset+=4);
		temp.pop = buf.getInt(offset+=4);
		temp.maxMerchant= buf.getInt(offset+=4);
		temp.maxBeacon = buf.getInt(offset+=4);
		temp.maxStardock = buf.getInt(offset+=4);
		temp.sector = buf.getInt(offset+=4);
		temp.worldID = buf.getInt(offset+=4);

		temp.name = buf.getString(offset+=4);

//		if (found) remove(temp);
//		insert(temp);
		if (!found) insert(temp);

		/*if (temp.x<-scale) scale = -temp.x;
		if (temp.x>scale) scale = temp.x;
		if (temp.y<-scale) scale = -temp.y;
		if (temp.y>scale) scale = temp.y;*/
	}

	public static void scan(Buffer buf) {
		Worlds temp,wp;
		int id,length,ix;

	//--- check against list ---
		length = buf.length()-12;
		temp = root;

		while (temp!=null) {

			for (ix=2;ix<=length;ix+=12) {
				id = buf.getInt(ix);
				if (id==temp.worldID) break;
			}

			if (ix<=length){
				temp.empireID = buf.getInt(ix+4);
				temp.ind = buf.getInt(ix+8);
				buf.setInt(ix,-1);
			}

			temp = temp.next;
		}

	//--- add new ones to list ---
		for (ix=2;ix<=length;ix+=12) {
			id = buf.getInt(ix);
			if (id<0) continue;

			wp = new Worlds();
			wp.worldID = id;
			wp.empireID = buf.getInt(ix+4);
			wp.ind = buf.getInt(ix+8);
			wp.x = wp.y = wp.type = wp.pop = wp.storage = 0;
			insert(wp);
		}

	//--- query names for the unknowns ---
		wp = root;
		while (wp!=null) {
			if (wp.pop==0) GameState.sendWorldQuery(wp.worldID);
			wp = wp.next;
		}
	}

	public static Worlds get(int testID) {
		Worlds wp;

		wp = root;
		while (wp!=null) {
			if (wp.worldID==testID) break;
			wp = wp.next;
		}
		return wp;
	}

	public static Worlds find(int mx,int my) {
		Rectangle scan;
		Worlds wp;

		scan = new Rectangle(mx-10*scale/200,my-10*scale/200,20*scale/200,20*scale/200);
		wp = root;

		while (wp!=null) {
			if (wp.isPlanet()) {
				int w = wp.portrait().width();
				int h = wp.portrait().height();
				scan = new Rectangle(mx-((w/2)*scale/200),my-((w/2)*scale/200),w*scale/200,w*scale/200);
			}
			if (scan.contains(wp.x,wp.y)) break;
			wp = wp.next;
		}
		return wp;
	}

//--- build functions ---
	public static void build(Buffer buf) {
		Worlds wp;
		int i, offset;

		offset = 2;
		wp = get(buf.getInt(offset));
		if (wp==null) {
			GameState.sendWorldQuery(buf.getInt(2));
			return;
		}

		wp.ind = buf.getInt(offset+=4);
		wp.maxInd = buf.getInt(offset+=4);
		wp.storage = buf.getInt(offset+=4);
		wp.Merchant = buf.getInt(offset+=4);
		wp.Beacon = buf.getInt(offset+=4);
		wp.Stardock = buf.getInt(offset+=4);
		wp.facility = buf.getInt(offset+=4);
		wp.facilityTime = buf.getInt(offset+=4);
		offset+=4;

		wp.builds = new Builds[Builds.MAX_COMMANDS];
		for (i=0;i<Builds.MAX_COMMANDS;i++) {
			wp.builds[i] = new Builds();
			wp.builds[i].set(i,offset,buf);
		}
	}

	public Builds builds(int i) {
		if (builds==null) return null;
		return builds[i];
	}

//--- private functions ---
// NOTE: keep worlds ordered so that Nebulae are first, Neutrons second, then regular worlds.
	static void insert(Worlds wp) {
		Worlds temp;

	//--- put at top of list ---
		wp.next = root;
		root = wp;
		if (!root.sort()) return;

		temp = root;
		root = temp.next;
		temp.next = root.next;
		root.next = temp;
		
	//--- list sort ---
		temp = root;

		while (wp.sort()) {
			temp.next = wp.next;
			wp.next = temp.next.next;
			temp.next.next = wp;
			temp = temp.next;
		}
	}

	static void remove(Worlds wp) {
		Worlds temp;

		if (root==wp) {
			root = wp.next;
			return;
		}

		temp = root;
		while (temp.next!=null) {
			if (temp.next==wp) {
				temp.next = wp.next;
				return;
			}
			temp = temp.next;
		}
	}

	boolean sort() {
		if (next==null) {
			return false;
		} else if (type==NEBULAE) {
			return false;
		} else if (type==NEUTRON) {
			if (next.type()!=NEBULAE) return false;
		}
		return (!next.isPlanet());
	}
};