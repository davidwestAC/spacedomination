import java.awt.*;
import java.applet.*;
import java.util.Random;

class gsBattle extends GameState {

	/*
	** region layout:
	**   ____         ____         ____
	**  |    |____   |    |____   |    |____
	**  |  3 |    |  |  9 |    |  | 15 |    |
	**  |____|  0 |  |____|  6 |  |____| 12 |
	**  |    |____|  |    |____|  |    |____|
	**  |  4 |    |  | 10 |    |  | 16 |    |
	**  |____|  1 |  |____|  7 |  |____| 13 |
	**  |    |____|  |    |____|  |    |____|
	**  |  5 |    |  | 11 |    |  | 17 |    |
	**  |____|  2 |  |____|  8 |  |____| 14 |
	**       |____|       |____|       |____|
	*/

	static Rectangle[] region = {
		new Rectangle(80,160,80,80),	new Rectangle(80,240,80,80),	new Rectangle(80,320,80,80),
		new Rectangle(0,130,80,80),		new Rectangle(0,210,80,80),		new Rectangle(0,290,80,80),

		new Rectangle(250,160,80,80),	new Rectangle(250,240,80,80),	new Rectangle(250,320,80,80),
		new Rectangle(170,130,80,80),	new Rectangle(170,210,80,80),	new Rectangle(170,290,80,80),

		new Rectangle(420,160,80,80),	new Rectangle(420,240,80,80),	new Rectangle(420,320,80,80),
		new Rectangle(340,130,80,80),	new Rectangle(340,210,80,80),	new Rectangle(340,290,80,80),
	};

	int select=-1,target=-1;

	Button retreat;

	Portrait[] animStarDart = null;
	Portrait battlebar = null;
	Portrait battlescreen = null;

	boolean showChat=true;
	Rectangle chatRect = new Rectangle(105,5,390,75);

//--- constructors ---
	public gsBattle(){
		battlebar = SpaceDom.Images[SpaceDom.Battlebar];
		battlescreen = SpaceDom.Images[SpaceDom.BattleScreen];
	}

	public void init(){
		root.add(retreat = new Button("Retreat"));
	}

	public void paint(Graphics g){
		Fleets fp;
		int count;

		g.setColor(Color.black);
		g.fillRect(0,100,500,300);
		g.setColor(Color.blue);
		g.fillRect(0,0,500,100);

		drawBattlebar(g);
		drawBattleScreen(g);

		fp = gsFleet;
		drawFleet(g,0,fp.getDefend());
		drawFleet(g,1,fp);
		drawFleet(g,2,fp.getInvade());

		drawSelect(g);

	//--- tools ---
		setBounds(retreat,210,80,80,15);

		drawChatMessages(g);
	}

	void drawBattlebar(Graphics g) {
		
		battlebar.center(g,250,50);
	}

	void drawBattleScreen(Graphics g) {
		
		battlescreen.center(g,250,250);
	}

	void drawFleet(Graphics g,int which,Fleets fp){
		Squadron sp;
		int pos,val;
		String msg;
	
		if (fp==null) return;

		pos = 50 + which * 150;
		g.setColor(Color.white);
		g.drawString(fp.empireName(),pos,30);
		g.drawString("Guns = "+fp.guns(),pos,45);

		val = fp.ecm();
		msg = "ECM = " + (val/100) + ".";
		if (val<0) val = -val;
		msg += ((val%100)/10);
		msg += (val%10);
		g.drawString(msg,pos,60);
	
		for (pos=0;pos<Fleets.POS_COUNT;pos++) drawSquad(g,fp,which,pos);
	}

	void drawSquad(Graphics g,Fleets fp,int which,int pos) {
		boolean invade;
		Rectangle r;
		Squadron sp,esp;
		Fleets ep,ip;
		Empires emp;
		int enemy;

		/*
		** pos is relative position within a given fleet location
		**   valid range from 0 to 5
		** which is fleet location, valid range from 0-2
		**
		**  region layout:
		**   ____         ____         ____
		**  |    |____   |    |____   |    |____
		**  |  3 |    |  |  9 |    |  | 15 |    |
		**  |____|  0 |  |____|  6 |  |____| 12 |
		**  |    |____|  |    |____|  |    |____|
		**  |  4 |    |  | 10 |    |  | 16 |    |
		**  |____|  1 |  |____|  7 |  |____| 13 |
		**  |    |____|  |    |____|  |    |____|
		**  |  5 |    |  | 11 |    |  | 17 |    |
		**  |____|  2 |  |____|  8 |  |____| 14 |
		**       |____|       |____|       |____|
		**
		**  pos layout:                        which layout:
		**   ___        ___        ___          ___        ___        ___     
		**  |   |___   |   |___   |   |___     |   |___   |   |___   |   |___ 
		**  | 3 |   |  | 3 |   |  | 3 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 0 |  |___| 0 |  |___| 0 |    |___| 0 |  |___| 1 |  |___| 2 |
		**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
		**  | 4 |   |  | 4 |   |  | 4 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 1 |  |___| 1 |  |___| 1 |    |___| 0 |  |___| 1 |  |___| 2 |
		**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
		**  | 5 |   |  | 5 |   |  | 5 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 2 |  |___| 2 |  |___| 2 |    |___| 0 |  |___| 1 |  |___| 2 |
		**      |___|      |___|      |___|        |___|      |___|      |___|
		*/

		r = region[which*6+pos];
		g.setColor(Color.white);
		g.drawRect(r.x,r.y,r.width,r.height);

		emp = Empires.get(fp.empireID);
		if (emp==null) return;

		sp = fp.squads(pos);
		if (sp==null || sp.type()==sp.SHIP_TYPES) return;
	
		if (SpaceDom.ships!=null && SpaceDom.ships[sp.type()]!=null && fp.empireID!=0) {
			if (which == 2)
			{
				SpaceDom.ships[emp.race()][sp.type()].centerFlip(g,r.x+r.width/2,r.y+r.height/2);
			} else
			{
				SpaceDom.ships[emp.race()][sp.type()].center(g,r.x+r.width/2,r.y+r.height/2);
			}
		}
		
		else if (SpaceDom.ships!=null && SpaceDom.ships[sp.type()]!=null && fp.empireID==0) {
			if (which == 2)
			{
				SpaceDom.ships[0][sp.type()].centerFlip(g,r.x+r.width/2,r.y+r.height/2);
			} else
			{
				SpaceDom.ships[0][sp.type()].center(g,r.x+r.width/2,r.y+r.height/2);
			}
		}

	//--- fleet icon, count, damage,timer;
		g.drawString(sp.name(),r.x+10,r.y+15);
		g.drawString(""+sp.count(),r.x+10,r.y+30);
		g.setColor(Color.red);
if (sp.damage() > sp.hits())
{
	System.out.println("Damage taken >= guns per ship, damage="+sp.damage()+" guns="+sp.hits()+" for squad position "+pos);
}
		g.fillRect(r.x,r.y+r.height-8,sp.damage()*r.width/sp.hits(),4);
		g.setColor(Color.yellow);
		g.fillRect(r.x,r.y+r.height-4,sp.timer()*r.width/20,4);
		boolean fireNow = (sp.fireNow() == 0);
		
	//--- move actions ---
		if (sp.isDefend()) return;

		if (sp.isRetreat()) {
			drawRetreatArrow(g,r);
			return;
		}

		if (sp.isMoving()){
			drawMoveArrow(g,r,sp.Heading());
			return;
		}

	//--- fire action ---
		invade = sp.TargetInvade();
		ep = (invade?fp.getInvade():fp.getDefend());
		if (ep==null) return;

//		sp = ep.findSquad(sp.TargetType());
//		if (sp==null) return;
		esp = ep.squads[sp.action - Squadron.FIRE_SLOOP];
		if (esp==null) return;

		enemy = (which+((invade)?1:-1))*6 + esp.position();
		drawFireArrow(g,which*6+pos,enemy,fireNow,emp.race(),esp.type());
	}


	void drawMoveArrow(Graphics g,Rectangle r,int heading){
		int cx,cy;

		switch (heading) {
			case 0:
				g.setColor(Color.yellow);
				cx = r.x + r.width/2;
				cy = r.y;
				g.drawLine(cx,cy-8,cx+8,cy);
				g.drawLine(cx+8,cy,cx-8,cy);
				g.drawLine(cx-8,cy,cx,cy-8);
				break;
			case 1:
				g.setColor(Color.yellow);
				cx = r.x + r.width/2;
				cy = r.y+r.height;
				g.drawLine(cx,cy+8,cx+8,cy);
				g.drawLine(cx+8,cy,cx-8,cy);
				g.drawLine(cx-8,cy,cx,cy+8);
				break;
			case 2:
				g.setColor(Color.yellow);
				cx = r.x;
				cy = r.y+r.height/2;
				g.drawLine(cx-8,cy,cx,cy-8);
				g.drawLine(cx,cy-8,cx,cy+8);
				g.drawLine(cx,cy+8,cx-8,cy);
				break;
			case 3:
				g.setColor(Color.yellow);
				cx = r.x+r.width;
				cy = r.y+r.height/2;
				g.drawLine(cx+8,cy,cx,cy-8);
				g.drawLine(cx,cy-8,cx,cy+8);
				g.drawLine(cx,cy+8,cx+8,cy);
				break;
		}
	}


	void drawRetreatArrow(Graphics g,Rectangle r){
		int x,y;

		x = r.x;
		y = r.y + r.height/2;

		g.setColor(Color.red);
		g.drawLine(x,y-4,x,y+4);
		g.drawLine(x,y+4,x-8,y+4);
		g.drawLine(x-8,y+4,x-8,y+8);
		g.drawLine(x-8,y+8,x-16,y);
		g.drawLine(x-16,y,x-8,y-8);
		g.drawLine(x-8,y-8,x-8,y-4);
		g.drawLine(x-8,y-4,x,y-4);
	}

	void drawFireArrow(Graphics g,int from,int to, boolean fireNow, int race, int type){
		int sx,sy,dx,dy;
		
		if (from < 0 || from > 17 || to < 0 || to > 17)
		{
			return;
		}
		sx = region[from].x+region[from].width/2;
		sy = region[from].y+region[from].height/2;
		dx = region[to].x+region[to].width/2 + (region[to].x>region[from].x?-20:20);
		dy = region[to].y+region[to].height/2 - 10 + (from%3)*10;

		if (!fireNow)
		{
			g.setColor(Color.gray);
			g.drawLine(sx,sy-10,dx,dy);
			g.drawLine(sx,sy+10,dx,dy);
		} else
		{
			if (race < 0 || race > 7)
			{
				race = 0;
			}

			int outer = 6;
			int inner = 4;
			switch (type)
			{
			case 0:		//sloop
				outer = 2;
				inner = 2;
				break;
			case 1:		//Corsair
				outer = 4;
				inner = 3;
				break;
			case 2:		//Frigate
				outer = 6;
				inner = 4;
				break;
			case 3:		//Station
				outer = 4;
				inner = 3;
				break;
			case 4:		//Ranger
				outer = 4;
				inner = 3;
				break;
			case 5:		//Star Dart
				outer = 6;
				inner = 4;
				break;
			}

			int raceRed1 = gsRace.red1[race];
			int raceGreen1 = gsRace.green1[race];
			int raceBlue1 = gsRace.blue1[race];
			int raceRed2 = gsRace.red2[race];
			int raceGreen2 = gsRace.green2[race];
			int raceBlue2 = gsRace.blue2[race];

			int deltaRed = (raceRed2 - raceRed1) / outer;
			int deltaGreen = (raceGreen2 - raceGreen1) / outer;
			int deltaBlue = (raceBlue2 - raceBlue1) / outer;
			for (int i=outer; i>0; i-- )
			{
				int red = raceRed2 - (deltaRed * i);
				int green = raceGreen2 - (deltaGreen * i);
				int blue = raceBlue2 - (deltaBlue * i);
				g.setColor(new Color(red, green, blue));
				g.drawLine(sx, sy - (i+4), dx, dy);
				g.drawLine(sx, sy + (i+4), dx, dy);
			}

			deltaRed = (255 - raceRed2) / inner;
			deltaGreen = (255 - raceGreen2) / inner;
			deltaBlue = (255 - raceBlue2) / inner;
			for (int i=inner; i>=0; i-- )
			{
				int red = 255 - (deltaRed * i);
				int green = 255 - (deltaGreen * i);
				int blue = 255 - (deltaBlue * i);
				g.setColor(new Color(red, green, blue));
				g.drawLine(sx, sy - i, dx, dy);
				g.drawLine(sx, sy + i, dx, dy);
			}
		}
	}


	void drawSelect(Graphics g){
		Rectangle rs,rt;
		int cx,cy;

		if (select<0) return;

		rs = region[select];
		g.setColor(Color.red);

		if (select==target) {
			g.drawRect(rs.x,rs.y,rs.width,rs.height);
			return;
		}

		rt = region[target];
		cx = rt.x + rt.width / 2;
		cy = rt.y + rt.height / 2;
		
		g.drawLine(rs.x,rs.y,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y,cx,cy);
		g.drawLine(rs.x,rs.y+rs.height,cx,cy);
		g.drawLine(rs.x+rs.width,rs.y+rs.height,cx,cy);
	}


//--- primary functions ---
	public void action(Event e){
		super.action(e);
		if (e.target==retreat) signalLaunch();
	}

	public void down(int x,int y,Event e){
		Fleets fp;
		int i;

		/*
		** region layout:
		**   ____         ____         ____
		**  |    |____   |    |____   |    |____
		**  |  3 |    |  |  9 |    |  | 15 |    |
		**  |____|  0 |  |____|  6 |  |____| 12 |
		**  |    |____|  |    |____|  |    |____|
		**  |  4 |    |  | 10 |    |  | 16 |    |
		**  |____|  1 |  |____|  7 |  |____| 13 |
		**  |    |____|  |    |____|  |    |____|
		**  |  5 |    |  | 11 |    |  | 17 |    |
		**  |____|  2 |  |____|  8 |  |____| 14 |
		**       |____|       |____|       |____|
		**
		** There are 18 regions, but you can only
		** move/fire from regions 6-11
		*/
		select = target = -1;
		for (i=6;i<12;i++)  if (region[i].contains(x,y)) {
			select = target = i;
			break;
		}
	}

	public void raise(int x,int y){
		/*
		** region layout:
		**   ____         ____         ____
		**  |    |____   |    |____   |    |____
		**  |  3 |    |  |  9 |    |  | 15 |    |
		**  |____|  0 |  |____|  6 |  |____| 12 |
		**  |    |____|  |    |____|  |    |____|
		**  |  4 |    |  | 10 |    |  | 16 |    |
		**  |____|  1 |  |____|  7 |  |____| 13 |
		**  |    |____|  |    |____|  |    |____|
		**  |  5 |    |  | 11 |    |  | 17 |    |
		**  |____|  2 |  |____|  8 |  |____| 14 |
		**       |____|       |____|       |____|
		**
		** target/6 will only be 1 for our own fleet
		** in regions 6-11
		*/
/*
if (target/6==1)	MoveSquad();
else				TargetSquad();
*/

		SendSquadAction();

		target = select= -1;
	}

	public void move(int x,int y){

		chatRect.height = chatCount() * 15;
		showChat = !chatRect.contains(x,y);
	}

	public void drag(int x,int y){
		int i;

		for (i=0;i<18;i++)  {
			if (!region[i].contains(x,y)) continue;
			target = i;
			break;
		}
	}

	public boolean handleInput(Buffer buf){
		boolean value;
		Fleets fp;
		Worlds wp;

		fp=null;

		value = super.handleInput(buf);

		if (isMovingStatus()) setState(new gsMovement());
		if (fleetStatus==fp.INDUSTRY) setState(new gsIndustry());
		if (fleetStatus==fp.DEAD) setState(new gsPassword());
		
		return value;
	}

//--- communications ---
	void MoveSquad(){
	int action;
	Buffer buf;

		if (target==select)			action = Squadron.DEFEND;
		else if (target==select-1)	action = Squadron.MOVEUP;
		else if (target==select+1)	action = Squadron.MOVEDOWN;
		else if (target>select)		action = Squadron.MOVELEFT;
		else						action = Squadron.MOVERIGHT;

		buf = new Buffer(4);
		buf.set(0,4);
		buf.set(1,SQUAD_ACTION);
		buf.set(2,select-6);
		buf.set(3,action);
		buf.send();
	}


	void TargetSquad(){
	boolean invade;
	Squadron sp;
	Fleets fp;
	Buffer buf;
	int action;

		invade = (target/6==2);

		fp = gsFleet;
		fp = (invade?fp.getInvade():fp.getDefend());
		if (fp==null) return;

		sp = fp.squads(target%6);
		if (sp==null) return;

		action = Squadron.MakeFireAction(sp.type());

		buf = new Buffer(5);
		buf.set(0,5);
		buf.set(1,SQUAD_ACTION);
		buf.set(2,select-6);
		buf.set(3,action);
		buf.set(4,(invade?1:0));
		buf.send();
	}

	void SendSquadAction(){
		Squadron sp;
		Fleets fp;
		Buffer buf;
		int which;
		int action;
		int pos;

		/*
		**  pos layout:                        which layout:
		**   ___        ___        ___          ___        ___        ___     
		**  |   |___   |   |___   |   |___     |   |___   |   |___   |   |___ 
		**  | 3 |   |  | 3 |   |  | 3 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 0 |  |___| 0 |  |___| 0 |    |___| 0 |  |___| 1 |  |___| 2 |
		**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
		**  | 4 |   |  | 4 |   |  | 4 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 1 |  |___| 1 |  |___| 1 |    |___| 0 |  |___| 1 |  |___| 2 |
		**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
		**  | 5 |   |  | 5 |   |  | 5 |   |    | 0 |   |  | 1 |   |  | 2 |   |
		**  |___| 2 |  |___| 2 |  |___| 2 |    |___| 0 |  |___| 1 |  |___| 2 |
		**      |___|      |___|      |___|        |___|      |___|      |___|
		*/
		which = target/6;
		pos = target%6;

		/*
		** Is this a move action?
		*/
		if (which == 1)
		{
			if (target==select)			action = Squadron.DEFEND;
			else if (target==select-1)	action = Squadron.MOVEUP;
			else if (target==select+1)	action = Squadron.MOVEDOWN;
			else if (target>select)		action = Squadron.MOVELEFT;
			else						action = Squadron.MOVERIGHT;
		} else
		{
			fp = gsFleet;
			fp = (which==2?fp.getInvade():fp.getDefend());
			if (fp==null) return;

			sp = fp.squads(pos);
			if (sp==null) return;

			action = pos;
		}

		buf = new Buffer(5);
		buf.set(0,5);
		buf.set(1,SQUAD_ACTION);
		buf.set(2,select-6);
		buf.set(3,action);
		buf.set(4,which);
		buf.send();
	}
}
/*
** current action values
** Needs to be changed to be relative
** position targeted for fire/move (0-5)
** with invade being 0, 1, 2 depending
** on which fleet position target is in.
**
** DEFEND = 0;
** RETREAT = 1;
** 
** MOVEUP = 2;
** MOVEDOWN = 3;
** MOVELEFT = 4;
** MOVERIGHT = 5;
** 
** FIRE_SLOOP = 6;
** FIRE_CORSAIR = 7;
** FIRE_FRIGATE = 8;
** FIRE_STATION = 9;
** FIRE_RANGER = 10;
** FIRE_STARDART = 11;
*/