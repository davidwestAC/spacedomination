//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"
#include "log.h"

bool gamePaused=false;
//***************************************************************************
// NOTE: clock() processer ticks since startup - expressed in milliseconds 
//***************************************************************************

void initialize(void);
void cleanup(void);

//***************************************************************************

int main(int argc,char **argv) {
	gLog.logMsg(Log::LOG_DEBUG, 1000, "#################### Enter main() ####################");

	initialize();

	while (true) {

		if (!operateManager()) break;

		operateSockets();
		if (!gamePaused) {
			operateWorlds();
			operateFleets();
			operateSessions();
			operateGameQueue();
//			operateCapture();
		} else {
			operateGameQueue();
			if (time(NULL) >= resumeTime) {
				gamePaused = false;
				broadcastSessionResume();
			} else {
				broadcastSessionSuspend();
			}
		}

		Sleep(100);
	}

	cleanup();
	gLog.logMsg(Log::LOG_DEBUG, 1010, "Leave main()");
	system("PAUSE");
	return EXIT_SUCCESS;
}


void ErrorResult(char *msg) {
	gLog.logMsg(Log::LOG_ERROR, 1020, msg);
	exit(-1);
}

//***************************************************************************

void initialize() {
	gLog.logMsg(Log::LOG_DEBUG, 1030, "Enter initialize()");
	if (!readInitFile()) {
		ErrorResult("Can't Read Init File");
	}
	if (!prepareGalaxy(Rand(highWorlds - minWorlds) + minWorlds)) {
		ErrorResult("Failure in Prepare Worlds");
	}
	if (!prepareManager()) {
		ErrorResult("Failure in Prepare Manager");
	}
	if (!prepareGameQueue()) {
		ErrorResult("Failure in Prepare MessageQueue");
	}
	if (!prepareSockets()) {
		ErrorResult("Failure in Prepare Sockets");
	}
	gLog.logMsg(Log::LOG_DEBUG, 1040, "Leave initialize()");
}


void cleanup() {
	gLog.logMsg(Log::LOG_DEBUG, 1050, "Enter cleanup()");
	cleanupSockets();
	cleanupGameQueue();
	cleanupManager();
	cleanupGalaxy();
	gLog.logMsg(Log::LOG_DEBUG, 1060, "Leave cleanup()");
}

//***************************************************************************



