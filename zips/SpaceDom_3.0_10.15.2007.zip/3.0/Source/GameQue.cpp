//***************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//***************************************************************************
#include "SDserver.hpp"
#include "Worlds.hpp"			// redundant
#include "md5.h"
#include "mysql.h"

//***************************************************************************
//***************************************************************************

void takeJoinRequest(void);
void takeTop20Query(void);
void takeAskForStats(void);
void takeSettingsQuery(void);
void takeRebirth(void);
void takeSessionDone(void);

void takeChatMessage(void);
void takeChatChannel(void);

void takeRaceChange(void);

void takeQuit(void);

void takeQueryEmpire(void);
void takeQueryWorld(void);
void takeQueryFleet(void);

void takeProbe(void);
void takeScout(void);
void takeFleetMove(void);

void takeSquadAction(void);

void takeBuildCommand(void);
void takeFleetTransfer(void);

void sendSessionDenied(Session *sp,int reason);
void sendSessionLinked(Session *sp,int reason,int empireID);

void sendTop20List(Session *sp);
void sendGameStatistics(Session *sp);
void sendFacilityStatistics(Session *sp);
void sendFacilityInfo(Session *sp);
void broadcastSessionSuspend();
void broadcastSessionResume();
void sendSessionSuspended(Session *sp);
void sendSessionResume(Session *sp);
void sendGlobalVictory(void);

extern	void sessionScanFleets(Session *sp);
extern	void sessionScanWorlds(Session *sp);
extern	void sessionHomeWorlds(Session *sp);

//***************************************************************************

MsgQueue *gameQueue;

int top20List[20];	// top 20 players

//***************************************************************************
//***************************************************************************

bool prepareGameQueue(){
	gameQueue = new MsgQueue();
	memset(top20List,0,sizeof(top20List));
	return true;
}


void cleanupGameQueue(){
	delete gameQueue;
}

//********************************************************************

void operateGameQueue(){
void *buf;
Session *sp;

	while (!gameQueue->isEmpty()) {

		buf = gameQueue->getMessage();

	//--- message type ---
		if (buf!=NULL) {
			switch (((byte*)buf)[1]) {
				case msJoinRequest:	takeJoinRequest(); break;
				case msTop20Query:	takeTop20Query(); break;
				case msAskForStats: takeAskForStats(); break;
				case msSettingsQuery:takeSettingsQuery(); break;
			}

			if (gamePaused) {
				sp = (Session*)gameQueue->getSource();
				if (sp==NULL) continue;
				sendSessionSuspended(sp);
			} else {
				switch (((byte*)buf)[1]) {
					case msRebirth:		takeRebirth(); break;
					case msSessionDone:	takeSessionDone(); break;
					case msChatMessage:	takeChatMessage(); break;
					case msChatChannel: takeChatChannel(); break;
					case msRaceChange:	takeRaceChange(); break;
					case msQuit:		takeQuit(); break;
					case msQueryEmpire:	takeQueryEmpire(); break;
					case msQueryWorld:	takeQueryWorld(); break;
					case msQueryFleet:	takeQueryFleet(); break;
					//case msProbe:		takeProbe(); break;
					//case msScout:		takeScout(); break;
					case msFleetMove:	takeFleetMove(); break;
					case msSquadAction:		takeSquadAction(); break;
					case msBuildCommand:	takeBuildCommand(); break;
					case msFleetTransfer:	takeFleetTransfer(); break;
				}
			}
		}

	//--- cleanup ---
		gameQueue->pop();
	}
}

//***************************************************************************
//***************************************************************************

/*0x00 - JoinRequest
		name + password sent
0x01 - Session Granted
		empireStruct, fleetStruct
0x02 - Session Created
		empireStruct, fleetStruct
0x03 - Session Denied
		no further information
0x04 - Empire Destroyed
		empireStruct*/

void takeJoinRequest() {
	char *msg,*name,*pass;
	empireRec *empires,*emp;
	fleetRec *fp;
	Session *sp;
	int count,ix,i,empireID,fleetID;
	bool created, player_validated = false;
	char c;
	struct MD5Context md5c;
	unsigned char signature[16];
	char *hexfmt = "%02X";
	char passMD5[33], tmp[3], *query;
	MYSQL dbHandle;
	MYSQL_RES *result;
	unsigned int num_fields;
	my_ulonglong num_rows;
	passMD5[0] = '\0';
	tmp[0] = '\0';

//todo: make configurable as to how long into a round new accounts can be created

	sp = (Session*)gameQueue->getSource();
	if (sp==NULL) return;

	sp->info(NULL,0);
	msg = (char*)gameQueue->getMessage();
	name = msg+2;
	pass = msg+2+MAXNAMESIZE;

//--- find empire if it already exists
	empires = (empireRec*)empireList->getList();
	count = empireList->getCount();
	for (ix=0;ix<count;ix++) {
		if (equalsCI(empires[ix].name,name)) {
			break;
		}
	}
	created = (ix==count);
	empireID = ix;

	if (strcmp(dbHost, "__NONE__") == 0) {
		gLog.logMsg(Log::LOG_INFO, 4000, "Password check, not using MySQL.");
		/*
		** Not using mySQL for name/pass validation
		*/
	//--- approve name ---
		for (i=0;name[i]!=0;i++) {
			c = name[i];
			if ((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || (c>'^' && c<'`')) {
				continue;
			}
			gLog.logMsg(Log::LOG_ERROR, 4010, "Invalid characters in name for user \"%s\".", name);
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
	//--- approve pass ---
		for (i=0;pass[i]!=0;i++) {
			c = pass[i];
			if ((c>='a' && c<='z') || (c>='A' && c<='Z') || (c>='0' && c<='9') || (c>'^' && c<'`')) {
				continue;
			}
			gLog.logMsg(Log::LOG_ERROR, 4020, "Invalid characters in password \"%s\" for user \"%s\".", pass, name);
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
		if (!created && !equalsCI(pass,empires[empireID].pass)) {
			gLog.logMsg(Log::LOG_ERROR, 4030, "Incorrect password for user \"%s\".", name);
			sendSessionDenied(sp,mfBadPassword);
			return;
		}
	} else {
		gLog.logMsg(Log::LOG_INFO, 4040, "Password check, using MySQL.");
		/*
		** Sanitize name and password to avoid SQL injections
		*/
		for (i=0;name[i]!=0;i++) {
			c = name[i];
			if ((c=='\'') || (c=='\"') || (c==';')) {
				gLog.logMsg(Log::LOG_ERROR, 4010, "Invalid characters in name for user \"%s\".", name);
				sendSessionDenied(sp,mfRecordsError);
				return;
			}
		}
		for (i=0;pass[i]!=0;i++) {
			c = pass[i];
			if ((c=='\'') || (c=='\"') || (c==';')) {
				gLog.logMsg(Log::LOG_ERROR, 4020, "Invalid characters in password \"%s\" for user \"%s\".", pass, name);
				sendSessionDenied(sp,mfRecordsError);
				return;
			}
		}
		MD5Init(&md5c);
		MD5Update(&md5c, (unsigned char *) (pass), strlen(pass));
		MD5Final(signature, &md5c);
		for (int i=0 ; i < sizeof(signature); i++) {
			sprintf(tmp, hexfmt, signature[i]);
			strcat(passMD5, tmp);
		}
		mysql_init(&dbHandle);
		if (!mysql_real_connect(&dbHandle, dbHost, dbUser, dbPasswd, dbName, dbPort, NULL, 0)) {
			gLog.logMsg(Log::LOG_ERROR, 4050, "Failed to connect to database: %s", mysql_error(&dbHandle));
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
		query = new char[strlen("select username from  where username=  ")+strlen(name)+strlen(dbTable)+2];
		sprintf(query, "select username from %s where username=\"%s\"", dbTable, name);
		if (mysql_query(&dbHandle,query)) {
			// error
			delete (query);
			gLog.logMsg(Log::LOG_ERROR, 4060, "Failed to issue database query: %s", mysql_error(&dbHandle));
			sendSessionDenied(sp,mfRecordsError);
			return;
		} else {
			delete (query);
			result = mysql_store_result(&dbHandle);
			if (result) {  // there are rows
				num_fields = mysql_num_fields(result);
				num_rows = mysql_num_rows(result);
				if (num_rows == 0) {
					// Error, no such user
					gLog.logMsg(Log::LOG_ERROR, 4070, "User \"%s\" does not exist in database.", name);
					sendSessionDenied(sp,mfRecordsError);
					return;
				}
				mysql_free_result(result);
				query = new char[strlen("select username, user_password from  where username=   AND user_password=  ")+strlen(name)+strlen(passMD5)+strlen(dbTable)+2];
				sprintf(query, "select username, user_password from %s where username=\"%s\" AND user_password=\"%s\"", dbTable, name, passMD5);
				if (mysql_query(&dbHandle,query)) {
					// error
					delete (query);
					gLog.logMsg(Log::LOG_ERROR, 4080, "Failed checking password for user \"%s\".", name);
					sendSessionDenied(sp,mfRecordsError);
					return;
				} else {
					delete (query);
					result = mysql_store_result(&dbHandle);
					if (result) {  // there are rows
						num_fields = mysql_num_fields(result);
						num_rows = mysql_num_rows(result);
						if (num_rows == 0) {
							// Error, incorrect password
							gLog.logMsg(Log::LOG_ERROR, 4090, "Incorrect password(%s) for user \"%s\".", passMD5, name);
							sendSessionDenied(sp,mfBadPassword);
							return;
						}
						mysql_free_result(result);
					}
					else {  // mysql_store_result() returned nothing; should it have?
						if(mysql_field_count(&dbHandle) != 0) {
							// mysql_store_result() should have returned data
							gLog.logMsg(Log::LOG_ERROR, 4100, "Database error: %s\n", mysql_error(&dbHandle));
							sendSessionDenied(sp,mfRecordsError);
							return;
						}
					}
				}
			} else {  // mysql_store_result() returned nothing; should it have?
				if(mysql_field_count(&dbHandle) != 0) {
					// mysql_store_result() should have returned data
					gLog.logMsg(Log::LOG_ERROR, 4110, "Database error: %s\n", mysql_error(&dbHandle));
					sendSessionDenied(sp,mfRecordsError);
					return;
				}
			}
		}
		/*
		** Check to see if this player exists in the sd_players table of spacedomination database
		** and add them if they are not there
		*/
		mysql_close(&dbHandle);
		mysql_init(&dbHandle);
		if (!mysql_real_connect(&dbHandle, dbHost, dbUser, dbPasswd, "spacedomination", dbPort, NULL, 0)) {
			gLog.logMsg(Log::LOG_ERROR, 4115, "Failed to connect to database: %s", mysql_error(&dbHandle));
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
		query = new char[strlen("select username from sd_players where username=  ")+strlen(name)+2];
		sprintf(query, "select username from sd_players where username=\"%s\"", name);
		if (mysql_query(&dbHandle,query)) {
			// error
			delete (query);
			gLog.logMsg(Log::LOG_ERROR, 4114, "Failed checking for user \"%s\".", name);
			sendSessionDenied(sp,mfRecordsError);
			return;
		} else {
			delete (query);
			result = mysql_store_result(&dbHandle);
			if (result) {  // there are rows
				num_fields = mysql_num_fields(result);
				num_rows = mysql_num_rows(result);
				if (num_rows == 0) {
					/*
					** Add them to the table
					*/
					query = new char[strlen("insert into sd_players (username) values ()")+strlen(name)+2];
					sprintf(query, "insert into sd_players (username) values ('%s')", name);
					if (mysql_query(&dbHandle,query)) {
						// error
						gLog.logMsg(Log::LOG_ERROR, 4116, "Failed inserting new user(%s) into sd_player table with query(%s).", name, query);
						delete (query);
					}
				}
				mysql_free_result(result);
			} else {  // mysql_store_result() returned nothing; should it have?
				if(mysql_field_count(&dbHandle) != 0) {
					// mysql_store_result() should have returned data
					gLog.logMsg(Log::LOG_ERROR, 4118, "Database error: %s\n", mysql_error(&dbHandle));
					sendSessionDenied(sp,mfRecordsError);
					return;
				}
			}
		}
		mysql_close(&dbHandle);
		strcpy(pass, "P4S5");
	}

//--- create empire ---
	gLog.logMsg(Log::LOG_INFO, 4120, "Creating empire for %s.", name);

	if (created) {
		if (!CreateEmpire(name,pass)) {
			gLog.logMsg(Log::LOG_ERROR, 4130, "Session denied for %s, CreateEmpire failed.", name);
			sendSessionDenied(sp,mfRecordsError);
			return;
		}
	}

//--- search for duplicate session ---
	if (findEmpireSession(empireID)!=NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4140, "Session denied for %s, already in play.", name);
		sendSessionDenied(sp,mfEmpireInPlay);
		return;
	}

//--- collect records ---
	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4150, "Session denied for %s, no record in empireList.", name);
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

	fleetID = emp->fleetID;
	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4160, "Session denied for %s, no record in fleetList.", name);
		sendSessionDenied(sp,mfRecordsError);
		return;
	}

//--- cleanup ---
	sessionSetInfo(sp,empireID,fleetID);
	
	if (fp->status==fsDead && emp->worlds==0) {
		sendSessionLinked(sp,mfEmpireDead,empireID);
		sendEmpireScan(sp,empireID,emp);
		gLog.logMsg(Log::LOG_INFO, 4170, "Session denied for %s, rebirthed.", name);
		return;
	}

	gLog.logMsg(Log::LOG_INFO, 4180, "Player \"%s\" successfully logged into game.", name);
	sendSessionLinked(sp,(created?mfSessionCreated:mfSessionGranted),empireID);

	sendFacilityInfo(sp);
	
	sendEmpireScan(sp,empireID,emp);
	sendCombatScan(sp,fleetID,fp);
	
	sessionScanFleets(sp);
	sessionScanWorlds(sp);
	sessionHomeWorlds(sp);		// sends a list of player controlled worlds

	sendTop20List(sp);
}

//***************************************************************************

void takeTop20Query() {
	Session *sp;
	gLog.logMsg(Log::LOG_DEBUG, 4190, "Taking Top 20 query.");
	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) sendTop20List(sp);
}


void takeAskForStats() {
	Session *sp;
	gLog.logMsg(Log::LOG_DEBUG, 4200, "Taking stats query.");
	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) sendGameStatistics(sp);
}

void takeSettingsQuery() {
	Session *sp;
	gLog.logMsg(Log::LOG_DEBUG, 4210, "Taking settings query.");
	sp = (Session*)gameQueue->getSource();
	if (sp!=NULL) sendFacilityStatistics(sp);
}

//***************************************************************************

void takeRebirth() {
	int empireID,fleetID;
	empireRec *emp;
	fleetRec *fp;
	Session *sp;

	gLog.logMsg(Log::LOG_INFO, 4220, "Taking rebirth request.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4230, "No session info for rebirth request.");
		return;
	}

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL || emp->worlds>0) {
		gLog.logMsg(Log::LOG_ERROR, 4240, "Empire is null or still has worlds for rebirth request.");
		return;
	}

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL || fp->status!=fsDead) {
		gLog.logMsg(Log::LOG_ERROR, 4250, "Fleet is null or still has ships for rebirth request.");
		return;
	}
//todo: make configurable as to whether or not rebirths are allowed in a round
	gLog.logMsg(Log::LOG_INFO, 4260, "Successfully rebirthed player.");
	emp->score = 0;
	emp->numRebirths++;
	CreateFleet(fp,empireID);

	sendSessionLinked(sp,mfSessionGranted,empireID);
	
	sendEmpireScan(sp,empireID,emp);
	sendCombatScan(sp,fleetID,fp);
	
	sessionScanFleets(sp);
	sessionScanWorlds(sp);
	sendTop20List(sp);
}


void takeSessionDone() {
	Session *sp;
	gLog.logMsg(Log::LOG_INFO, 4270, "Session killed.");
	sp = (Session*)gameQueue->getSource();
	if (sp == NULL) {
		return;
	}
	sp->kill();
}

//***************************************************************************

extern	bool managerShowChat;
const int MAXMSGSIZE = BUFFERSIZE-MAXNAMESIZE-1;

void takeChatMessage() {
	SessionList *slp;
	Session *sp;
	empireRec *emp;
	int len,ix,channel,empireID,fleetID;
	char *buf,msg[BUFFERSIZE];

	gLog.logMsg(Log::LOG_DEBUG, 4280, "Taking chat message.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4290, "No session info for chat message.");
		return;
	}

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4300, "Empire sending chat message is null.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL || strlen(buf)>100) {
		gLog.logMsg(Log::LOG_ERROR, 4310, "Chat message too long %d > 100.", strlen(buf));
		return;
	}

	channel = emp->channel;

//--- construct message ---
	ix = strlen(emp->name);
	strcpy(msg,emp->name);
	msg[ix++] = ':';
	msg[ix++] = ' ';

	len = buf[0] - 2;
	if (len>MAXMSGSIZE) {
		gLog.logMsg(Log::LOG_ERROR, 4320, "Chat message still too long %d > %d.  Truncating down to %d", strlen(buf),MAXMSGSIZE,MAXMSGSIZE);
		len = MAXMSGSIZE;
	}
	memcpy(msg+ix,buf+2,len);
	
	msg[ix+=len] = 0;

//--- post message to appropriate targets ---
	gLog.logMsg(Log::LOG_DEBUG, 4330, "Sending chat message <CH=%d>\"%s\".",channel,msg);
	slp = sroot->next();
	while (slp!=NULL) {
		if (sessionGetInfo(slp->ssn(),&empireID,&fleetID)) {
			emp = (empireRec*)empireList->getRecord(empireID);
			if (emp!=NULL && emp->channel==channel) {
				sendMessage(slp->ssn(),msg);
			}
		}
		slp = slp->next();
	}

//--- cleanup ---
	if (managerShowChat) printf("<CH=%d>%s\n",channel,msg);
}


void takeChatChannel() {
	int empireID,fleetID;
	empireRec *emp;
	Session *sp;
	char *buf;
	gLog.logMsg(Log::LOG_VERBOSE, 4340, "Taking channel change request.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4350, "No session info for channel change request.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4360, "Input buffer null for channel change request.");
		return;
	}

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp!=NULL) {
		emp->channel = *(short*)(buf+2);
		gLog.logMsg(Log::LOG_VERBOSE, 4370, "Channel changed to %d.", emp->channel);
	}
}

//***************************************************************************

void takeRaceChange() {
	int empireID,fleetID;
	empireRec *emp;
	Session *sp;
	char *buf;

	gLog.logMsg(Log::LOG_VERBOSE, 4380, "Taking race selection.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4390, "No session info for race selection.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4400, "Input buffer null for race selection.");
		return;
	}

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp!=NULL && emp->changedRace==false) {
		emp->race = *(int*)(buf+4);
	} else {
		gLog.logMsg(Log::LOG_ERROR, 4410, "Empire is null or race already changed for race selection.");
	}
	emp->changedRace = true;

	if (emp->race<0) {
		gLog.logMsg(Log::LOG_ERROR, 4420, "Selected race %d, less than zero. Set to 0.", emp->race);
		emp->race = 0;
	}
	if (emp->race>7) {
		gLog.logMsg(Log::LOG_ERROR, 4430, "Selected race %d, greater than seven. Set to 7", emp->race);
		emp->race = 7;
	}
}

//***************************************************************************

void takeQuit() {
	int empireID,fleetID;
	Session *sp;
	char *buf;

	gLog.logMsg(Log::LOG_VERBOSE, 4440, "Taking quit request.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4450, "No session info for quit request.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4460, "Input buffer null for quit request.");
		return;
	}

	sp->kill();
}

//***************************************************************************

void takeQueryEmpire() {
	empireRec *rec;
	Session *sp;
	char *buf;
	int id;

	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4470, "Taking empire query.");
	sp = (Session*)gameQueue->getSource();
	if (sp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4480, "Session null for empire query.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4490, "Input buffer null for empire query.");
		return;
	}

	id = *(short*)(buf+2);

	rec = (empireRec*)empireList->getRecord(id);
	if (rec==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4500, "Empire null for empire query.");
		return;
	}

	sendEmpireScan(sp,id,rec);
}


void takeQueryWorld() {
	worldRec *rec;
	Session *sp;
	int worldID;
	char *buf;

	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4510, "Taking world query.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionInPlay(sp)) {
		gLog.logMsg(Log::LOG_ERROR, 4520, "Session not in play for world query.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	if (buf==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4530, "Input buffer null for world query.");
		return;
	}
	worldID = *(short*)(buf+2);

	rec = (worldRec*)worldList->getRecord(worldID);
	if (rec==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4540, "Empire null for world query.");
		return;
	}

	sendWorldScan(sp,worldID,rec);
}


void takeQueryFleet() {
	fleetRec *rec;
	Session *sp;
	char *buf;
	int id;

	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4550, "Taking fleet query.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionInPlay(sp)) {
		gLog.logMsg(Log::LOG_ERROR, 4560, "Session not in play for fleet query.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	id = *(short*)(buf+2);

	rec = (fleetRec*)fleetList->getRecord(id);
	if (rec==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4570, "Empire null for fleet query.");
		return;
	}

	sendFleetScan(sp,id,rec);
}

//***************************************************************************

void takeFleetMove() {
	fleetRec *fp,*ep;
	empireRec *emp;
	Session *sp;
	char *buf;
	int i,enemy,dest,empireID,fleetID;

	gLog.logMsg(Log::LOG_VERBOSE, 4580, "Taking fleet move.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4590, "No session info for fleet move.");
		return;
	}

	emp = (empireRec*)empireList->getRecord(empireID);
	if (emp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4600, "Empire null for fleet move.");
		return;
	}
	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4610, "Fleet null for fleet move.");
		return;
	}

//--- pinned = all sides are enemies ---
	if (fp->status==fsBattle) {
		for (enemy=i=0;i<sideCOUNT;i++) {
			ep = (fleetRec*)fleetList->getRecord(fp->engageID[i]);
			if (ep!=NULL && !isFriendlyFleet(ep,fp)) {
				enemy++;
			}
		}
		if (enemy==sideCOUNT) {
			gLog.logMsg(Log::LOG_INFO, 4620, "Fleet pinned, cannot retreat from battle.");
			return;	// pinned!
		}
		for (i=0;i<posCOUNT;i++) {
			setSquadAction(fp,i,actRetreat);
		}
		gLog.logMsg(Log::LOG_INFO, 4630, "Fleet retreating from battle.");
		return;
	}

//--- fix move ---
	buf = (char*)gameQueue->getMessage();
	dest = *(short*)(buf+2);

	setFleetDestination(fp,(fleetID==dest?-1:dest));
}

//***************************************************************************

void takeSquadAction() {
	int pos,which,squadID,empireID,fleetID;
	fleetRec *fp;
	Session *sp;
	char *buf;

	gLog.logMsg(Log::LOG_DEBUG, 4640, "Taking squad action.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4650, "No session info for squad action.");
		return;
	}

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (sp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4660, "Fleet null for squad action.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	squadID = buf[2]; // squad ID (pos) performing the action
	if (squadID>=posCOUNT) {
		gLog.logMsg(Log::LOG_ERROR, 4670, "%d is not a valid position for squad performing action.", squadID);
		return;
	}

	/*
	**  pos layout:                        which layout:
	**   ___        ___        ___          ___        ___        ___     
	**  |   |___   |   |___   |   |___     |   |___   |   |___   |   |___ 
	**  | 3 |   |  | 3 |   |  | 3 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 0 |  |___| 0 |  |___| 0 |    |___| 0 |  |___| 1 |  |___| 2 |
	**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
	**  | 4 |   |  | 4 |   |  | 4 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 1 |  |___| 1 |  |___| 1 |    |___| 0 |  |___| 1 |  |___| 2 |
	**  |   |___|  |   |___|  |   |___|    |   |___|  |   |___|  |   |___|
	**  | 5 |   |  | 5 |   |  | 5 |   |    | 0 |   |  | 1 |   |  | 2 |   |
	**  |___| 2 |  |___| 2 |  |___| 2 |    |___| 0 |  |___| 1 |  |___| 2 |
	**      |___|      |___|      |___|        |___|      |___|      |___|
	*/
	pos = buf[3];   // slot that is the target of the action
	which = buf[4]; // which fleet position is target in 0, 1, or 2
	if (which != 1) {
		pos = MakeFireAction(pos);
	}
	setSquadAction(fp,squadID,pos,which);
}

//***************************************************************************

void takeBuildCommand() {
	int buildID,worldID,empireID,fleetID;
	worldRec *wp;
	fleetRec *fp;
	buildCmd bd;
	Session *sp;
	char *buf;

	gLog.logMsg(Log::LOG_DEBUG, 4680, "Taking build command.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4690, "No session info for build command.");
		return;
	}

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4700, "Fleet null for build command.");
		return;
	}

	worldID = fp->destID;
	wp = (worldRec*)worldList->getRecord(worldID);
	if (wp==NULL || wp->empireID!=empireID) {
		gLog.logMsg(Log::LOG_ERROR, 4710, "World null or empire is not world owner for build command.");
		return;
	}

	buf = (char*)gameQueue->getMessage();

	bd.repeat = (buf[3]!=0);
	bd.type = buf[4];
	bd.goal = buf[5];
	bd.built = 0;
	if (bd.type>btCOUNT) {
		gLog.logMsg(Log::LOG_ERROR, 4720, "Invalid build type (%d) for build command.", bd.type);
		return;
	}

	buildID = buf[2];
	if (buildID>=MAXBUILD) {
		gLog.logMsg(Log::LOG_ERROR, 4730, "Invalid build ID (%d) for build command.", buildID);
		return;
	}

	wp->cmd[buildID] = bd;
	sendBuildScan(sp,worldID,wp);
}


void takeFleetTransfer() {
	int fromFleet,toFleet,fromPos,toPos,fromType,toType,type,num,empireID,fleetID;
	int numFrom, numTo;
	empireRec *emp;
	fleetRec *fp,*ep, *from, *to;
	Session *sp;
	char *buf;

	gLog.logMsg(Log::LOG_DEBUG, 4740, "Taking fleet transfer.");
	sp = (Session*)gameQueue->getSource();
	if (!sessionGetInfo(sp,&empireID,&fleetID)) {
		gLog.logMsg(Log::LOG_ERROR, 4750, "No session info for fleet transfer.");
		return;
	}

	fp = (fleetRec*)fleetList->getRecord(fleetID);
	if (fp==NULL) {
		gLog.logMsg(Log::LOG_ERROR, 4760, "Fleet null for fleet transfer.");
		return;
	}

	ep = (fleetRec*)fleetList->getRecord(fp->destID);
	if (ep==NULL || ep->empireID!=fp->empireID) {
		gLog.logMsg(Log::LOG_ERROR, 4770, "Empire null or empire not owner for fleet transfer.");
		return;
	}

	buf = (char*)gameQueue->getMessage();
	num = *(ushort*)(buf+2);
	if (num <= 0) {
		gLog.logMsg(Log::LOG_ERROR, 4780, "Attempt to transfer %d ships which is less than or equal to zero.", num);
		return;
	}
	fromFleet = buf[6];
	fromPos = buf[7];
	toFleet = buf[8];
	toPos = buf[9];
	
	if (fromFleet == 0) {
		type = fromType = fp->squad[fromPos].type;
		from = fp;
	} else {
		type = fromType = ep->squad[fromPos].type;
		from = ep;
	}
	if (toFleet == 0) {
		toType = fp->squad[toPos].type;
		to = fp;
	} else {
		toType = ep->squad[toPos].type;
		to = ep;
	}
	/*
	** Only Avarians can move stations from one fleet to another
	** Have to check toType as well to make sure stations are not being
	** swapped into a fleet that is not allowed to have them
	*/
	emp = (empireRec*)empireList->getRecord(fp->empireID);
	if (type>=stCOUNT || ((type==stStation || toType==stStation) && from!=to && emp->race!=rtAvarian)) {
		return;
	}

	/*
	** If the ship types are different and all of them are being moved, just
	** swap the ship stacks
	*/
	numFrom = from->squad[fromPos].count;
	numTo = to->squad[toPos].count;
	if (numTo != 0 && fromType != toType) {
		if (numFrom != num) {
			return;	// not moving all of them, so do nothing
		}
		int numPulledFrom = pullFleetShips(from,fromPos,numFrom);
		int numPulledTo = pullFleetShips(to,toPos,numTo);
		addFleetShips(to,fromType,toPos,numPulledFrom);
		addFleetShips(from,toType,fromPos,numPulledTo);
		sendCombatScan(sp,fleetID,fp);
		sendCombatScan(sp,fp->destID,ep);
		return;
	}

//--- transfer ---
	num = pullFleetShips(from,fromPos,num);
	num -= addFleetShips(to,type,toPos,num);
	if (num > 0) {
		addFleetShips(from,type,fromPos,num);
	}

//--- cleanup ---
	sendCombatScan(sp,fleetID,fp);
	sendCombatScan(sp,fp->destID,ep);
}

//***************************************************************************
//***************************************************************************

void sendSessionLinked(Session *sp,int reason,int empireID){
char buf[BUFFERSIZE];

	buf[0] = 4;
	buf[1] = (byte)reason;
	memcpy(buf+2,&empireID,sizeof(short));
	sp->send(buf);
}


void sendSessionDenied(Session *sp,int reason){
char buf[BUFFERSIZE];

	buf[0] = 2;
	buf[1] = (byte)reason;
	sp->send(buf);
}

void sendLastAttacked(Session *sp,int worldID){
char buf[BUFFERSIZE];
int len;

	len = 2;

	memcpy(buf+len,&worldID,sizeof(int));
	len += sizeof(int);

	buf[0] = len;
	buf[1] = mfLastAttacked;
	sp->send(buf);
}

void sendLastCaptured(Session *sp,int worldID){
char buf[BUFFERSIZE];
int len;

	len = 2;

	memcpy(buf+len,&worldID,sizeof(int));
	len += sizeof(int);

	buf[0] = len;
	buf[1] = mfLastCaptured;
	sp->send(buf);
}

//***************************************************************************
//	sector  = ID, ind
//	industry  = ind, store, builds
//	scan = xloc -> name

void sendWorldScan(Session *sp,int worldID,worldRec *wp){
	char buf[BUFFERSIZE];
	int len,size;

	if (wp==NULL) {
		return;
	}
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4790, "Sending world scan.");

	len = 2;
	memcpy(buf+len,&worldID,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,wp,4*sizeof(int));
	len += 4*sizeof(int);
	memcpy(buf+len,&wp->maxMerchant,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->maxBeacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->maxStardock,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->sector,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&wp->worldID,sizeof(int));
	len += sizeof(int);

	size = 1+strlen(wp->name);
	memcpy(buf+len,wp->name,size);
	len += size;

	buf[0] = len;
	buf[1] = mfWorldScan;
	sp->send(buf);
}


void sendFleetScan(Session *sp,int fleetID,fleetRec *fp){
	char buf[BUFFERSIZE];
	int len;

	if (fp==NULL) {
		return;
	}
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4800, "Sending fleet scan.");

	len = 2;
	memcpy(buf+len,&fleetID,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,fp,4*sizeof(int));
	len += 4*sizeof(int);
	memcpy(buf+len,&fp->Beacon,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->moveSpeed,sizeof(int));
	len += sizeof(int);
	memcpy(buf+len,&fp->Stardock,sizeof(int));
	len += sizeof(int);

	buf[0] = len;
	buf[1] = mfFleetScan;
	sp->send(buf);
}


//	scan = empireID, everything
void sendEmpireScan(Session *sp,int id,empireRec *ep){
	char buf[BUFFERSIZE];
	int len,size;
	Session *ssn;
	int online = 0;
	int worldBuild, comBuild, comSpeed, worldDecay, comDecay;
	
	if (ep==NULL) {
		return;
	}
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4810, "Sending empire scan.");
	ssn = findEmpireSession(id);
	if (ssn!=NULL) {
		online=1;
	}

	if (merchantBonusType == 1) {
		worldBuild = (int)(((ep->Merchant * merchantBonus) / 1000.0) * raceBuildModifier[ep->race]);
	} else {
		worldBuild = (int)((ep->Merchant * merchantBonus) * raceBuildModifier[ep->race]);
	}
	comBuild = (int)((commandBuild + ep->Merchant * commandBonus) * raceCommandModifier[ep->race]);
	worldDecay = (int)(((ep->Stardock * stardockWorldBonus) + worldDecayRate) * raceDecayModifier[ep->race]);
	comDecay = (int)(((ep->Stardock * stardockFleetBonus) + fleetDecayRate) * raceDecayModifier[ep->race]);
	comSpeed = (int)(((ep->Beacon * beaconBonus) + movePixels) * raceBeaconModifier[ep->race]);
	if (comSpeed > maxSpeed * raceBeaconModifier[ep->race]) {
		comSpeed = (int)(maxSpeed * raceBeaconModifier[ep->race]);
	}

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->fleetID,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->channel,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->ruler,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->race,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->worlds,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->phenom,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->darts,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->score,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->hiWorlds,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->hiDarts,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->hiScore,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->Merchant,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&worldBuild,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&comBuild,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->Beacon,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&comSpeed,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->Stardock,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&worldDecay,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&comDecay,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->Stellurae,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&ep->scoreDarts,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&online,sizeof(int));
	len+=sizeof(int);

	size = 1+strlen(ep->name);
	memcpy(buf+len,ep->name,size);
	len += size;

	buf[0] = len;
	buf[1] = mfEmpireScan;
	sp->send(buf);
}


void sendCombatScan(Session *sp,int id,fleetRec *fp){
	char buf[BUFFERSIZE];
	int len;

	if (fp==NULL) {
		return;
	}
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4820, "Sending combat scan.");

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&fp->ecm,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&fp->engageID,sideCOUNT*sizeof(int));
	len+=sideCOUNT*sizeof(int);
	memcpy(buf+len,&fp->squad,posCOUNT*sizeof(squadRec));
//printf("Sqadron data begins at offset %d\n",len);
//for (int i=0; i < posCOUNT; i++)
//{
//	c = buf[len+i];
//	printf("buf[%d]=%d ",i,c);
//}
//printf("\n");
	len += posCOUNT*sizeof(squadRec);
	buf[0] = len;
	buf[1] = mfCombatScan;
	sp->send(buf);
}


void sendBuildScan(Session *sp,int id,worldRec *wp){
	char buf[BUFFERSIZE];
	int len;

	if (wp==NULL) {
		return;
	}
	gLog.logMsg(Log::LOG_DEBUG_VERBOSE, 4830, "Sending build scan.");

	len = 2;
	memcpy(buf+len,&id,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->ind,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->maxInd,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->storage,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->Merchant,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->Beacon,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->Stardock,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->facility,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&wp->facilityTime,sizeof(int));
	len+=sizeof(int);
	memcpy(buf+len,&wp->cmd,MAXBUILD*sizeof(buildCmd));
	len += MAXBUILD*sizeof(buildCmd);

	buf[0] = len;
	buf[1] = mfBuildScan;
	sp->send(buf);
}

//***************************************************************************

void sendEmpireMessage(int id,char *msg) {
	Session *sp;

	sp = findEmpireSession(id);
	if (sp!=NULL) {
		sendMessage(sp,msg);
	}
}


void sendMessage(Session *sp,char *msg) {
	char buf[BUFFERSIZE];
	int len;

	len = strlen(msg);
	if (len>BUFFERSIZE-2) {
		len = BUFFERSIZE-2;
	}

	buf[0] = len+2;
	buf[1] = mfMessage;
	memcpy(buf+2,msg,len);
	sp->send(buf);
}


void sendStatus(Session *sp,int status) {
	char buf[BUFFERSIZE];
	
	buf[0] = 3;
	buf[1] = mfStatus;
	buf[2] = (char)status;

	sp->send(buf);
}


void sendGlobalMessage(char *msg) {
	SessionList *slp;
	Session *sp;

	slp = sroot->next();
	while (slp!=NULL) {
		sp = slp->ssn();
		if (sessionInPlay(sp)) {
			sendMessage(sp,msg);
		}
		slp = slp->next();
	}
}


void sendTop20List(Session *sp) {
	char buf[BUFFERSIZE];
	int len;

	len = 2;
	memcpy(buf+len,top20List,sizeof(top20List));
	len += sizeof(top20List);

	buf[0] = len;
	buf[1] = mfTop20List;

	sp->send(buf);
}

void sendFacilityInfo(Session *sp) {
	char buf[BUFFERSIZE];
	int len;

	gLog.logMsg(Log::LOG_INFO, 4840, "Sending facility info.");
//--- create message ---
	len = 2;
	memcpy(buf+len,&allowMultipleFacilities,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&facilityCostType,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&merchantCost,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&beaconCost,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&stardockCost,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&doomsdayCost,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&stelluraeCost,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&shieldCost,sizeof(int));
	len+=sizeof(int);

	buf[0] = len;
	buf[1] = mfFacilityInfo;

	sp->send(buf);
}

void broadcastSessionSuspend() {	
	SessionList *slp;
	empireRec *emp;
	int empireID,fleetID;

	gLog.logMsg(Log::LOG_INFO, 4850, "Sending session suspend.");
	slp = sroot->next();
	while (slp!=NULL) {
		if (sessionGetInfo(slp->ssn(),&empireID,&fleetID)) {
			emp = (empireRec*)empireList->getRecord(empireID);
			if (emp!=NULL) {
				sendSessionSuspended(slp->ssn());
			}
		}
		slp = slp->next();
	}
}

void broadcastSessionResume() {	
	SessionList *slp;
	empireRec *emp;
	int empireID,fleetID;

	gLog.logMsg(Log::LOG_INFO, 4860, "Sending session resume.");
	slp = sroot->next();
	while (slp!=NULL) {
		if (sessionGetInfo(slp->ssn(),&empireID,&fleetID)) {
			emp = (empireRec*)empireList->getRecord(empireID);
			if (emp!=NULL) {
				sendSessionResume(slp->ssn());
			}
		}

		slp = slp->next();
	}
}

void sendSessionSuspended(Session *sp) {
	char buf[BUFFERSIZE];
	int len;
	int data;
	long deltaTime;

	deltaTime = resumeTime - time(NULL);
	if (deltaTime < 0) {
		gamePaused = false;
		return;
	}
//--- create message ---
	len = 2;
	data = deltaTime / 86400;                 // days
	memcpy(buf+len,&data,sizeof(int));
	data = (deltaTime % 86400) / 3600;        // hours
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = ((deltaTime % 86400) % 3600) / 60; // minutes
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = ((deltaTime % 86400) % 3600) % 60; // seconds
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	len+=sizeof(int);

	buf[0] = len;
	buf[1] = mfSessionSuspended;

	sp->send(buf);
}

void sendSessionResume(Session *sp) {
	char buf[BUFFERSIZE];
	int *data;
	int len;
	int pos;

//--- create message ---
	pos = 1;
	data = (int*)buf;

	len = pos * sizeof(int);

	buf[0] = len;
	buf[1] = mfSessionResume;

	sp->send(buf);
}

//***************************************************************************

void sendGameStatistics(Session *sp) {
	char buf[BUFFERSIZE];
	empireRec *emp;
	victoryRec vrec;
	int len;
	time_t secs;
	int data;

	gLog.logMsg(Log::LOG_DEBUG, 4870, "Sending game statistics.");
//--- collect records ---
	len = victoryList->getCount();
	if (victoryList->pickIndex(len-1)) {
		victoryList->getRecord(&vrec);
	}

	emp = (empireRec*)empireList->getRecord(top20List[0]);

//--- create message ---
	len = 2;
	data = worldList->getCount();
	memcpy(buf+len,&data,sizeof(int));
	data = CalcNeutron(worldList->getCount()) + CalcNebulae(worldList->getCount()) + CalcGates(worldList->getCount()) + CalcWormholes(worldList->getCount());		// gets us the number of phenomena
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = empireList->getCount();
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
//	data = CalcDarts(worldList->getCount());
	data = totalDarts;
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&sessionCount,sizeof(int));
	secs = time(NULL);
	memcpy(buf+(len+=sizeof(time_t)),&secs,sizeof(time_t));
	memcpy(buf+(len+=sizeof(int)),&maxEmpireScore,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&victoryPercent,sizeof(int));

	if (emp==NULL) {
		data = 0;
		memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
		memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	} else {
		memcpy(buf+(len+=sizeof(int)),&emp->hiScore,sizeof(int));
		data = emp->hiScore/(maxEmpireScore/100);
		memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	}

	data = estTimeRemaining / 86400;               // days
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = (estTimeRemaining % 86400) / 3600;      // hours
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = ((estTimeRemaining % 86400)%3600) / 60; // minutes
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	data = ((estTimeRemaining % 86400)%3600)%60;   // seconds
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));

	memcpy(buf+(len+=sizeof(int)),&gameHours,sizeof(int));

	memcpy(buf+(len+=sizeof(int)),&vrec.date,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrec.time,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrec.gameLength,sizeof(int));
	len+=sizeof(int);

	memcpy(buf+len,vrec.name,MAXNAMESIZE);
	len += MAXNAMESIZE;

	buf[0] = len;
	buf[1] = mfGameStatistics;

//--- send it ---
	sp->send(buf);
}

void sendFacilityStatistics(Session *sp) {
	char buf[BUFFERSIZE];
	empireRec *emp;
	victoryRec vrec;
	int len;

	gLog.logMsg(Log::LOG_DEBUG, 4880, "Sending facility statistics.");
//--- collect records ---
	len = victoryList->getCount();
	if (!victoryList->pickIndex(len-1)) {
		return;
	}
	victoryList->getRecord(&vrec);

	emp = (empireRec*)empireList->getRecord(top20List[0]);

//--- create message ---
	len = 2;
	memcpy(buf+len,&minWorlds,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&highWorlds,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&victoryBase,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&dropHours,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&gameHours,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&timeShiftSessionHours,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&timeShiftSkipDays,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&commandBuild,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&commandBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&merchantBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&merchantBonusType,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&beaconBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&stardockWorldBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&stardockFleetBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&shieldBonus,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&movePixels,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&maxSpeed,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&fleetDecayRate,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&worldDecayRate,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&facilityUpdate,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&firstEarthDeclareRatio,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&firstPhenomenaDeclareRatio,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&laterEarthDeclareRatio,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&laterPhenomenaDeclareRatio,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&firstHomeDeclareRatio,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&firstHomePhenomenaDeclareRatio,sizeof(int));
	len+=sizeof(int);

	memcpy(buf+len,vrec.name,MAXNAMESIZE);
	len += MAXNAMESIZE;

	buf[0] = len;
	buf[1] = mfFacilityStatistics;

//--- send it ---
	sp->send(buf);
}

void sendGlobalVictory(victoryRec *vrp) {
	char buf[BUFFERSIZE];
	SessionList *slp;
	Session *sp;
	int data;
	int len;

	gLog.logMsg(Log::LOG_INFO, 4890, "Sending global victory.");

//--- create message ---
	len = 2;
	data = todayToDays();
	memcpy(buf+len,&data,sizeof(int));
	data = secondsSinceMidnight();
	memcpy(buf+(len+=sizeof(int)),&data,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrp->gameLength,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrp->score,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrp->worlds,sizeof(int));
	memcpy(buf+(len+=sizeof(int)),&vrp->darts,sizeof(int));
	len+=sizeof(int);

	memcpy(buf+len,vrp->name,MAXNAMESIZE);
	len += MAXNAMESIZE;

	buf[0] = len;
	buf[1] = mfVictory;

//--- send it ---
	slp = sroot->next();
	while (slp!=NULL) {
		sp = slp->ssn();
		if (sessionInPlay(sp)) {		// special case - last message sent to session
			sp->send(buf);
			sp->output();
		}
		slp = slp->next();
	}
}

//***************************************************************************
