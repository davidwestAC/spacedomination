//****************************************************************************
//	copyright 1998, Fred's Friends, Inc.
//****************************************************************************
#include "SDserver.hpp"
#include "mysql.h"

//****************************************************************************
//****************************************************************************

extern	void sendGlobalVictory(victoryRec *vrp);

void fixVictoryList(int date,int secs,empireRec *erp);
void fixVictoryHtml(int date,int secs,empireRec *erp);

//****************************************************************************

char *editPoint = "<!-- Top of List -->";

char *startVictoryHtml =
	"<html>\r\n"
	"<head><title>Space Domination Immortal Victors</title>\r\n"
	"</head>\r\n"
	"<body bgcolor=880088><center>\r\n"
	"<font size=8 color=yellow>Star Dart<br>\r\n"
	"Immortal Victors!</font><p>\r\n"
	"<font size=4 color=white>\r\n"
	"<!-- Top of List -->\r\n"
	"</center></body>\r\n"
	"</html>\r\n";

// todayStr, hour, 10min, 1min, AM/PM, name, 
// score, score%, worlds, worlds%, darts, darts% 

char *victoryStr = 
	"\r\n[%s %d:%d%d %s] <big>%s Empire</big> Race: <big>%s </big> Score: <big>%d (%d%%)</big>"
	"\r\n\tWorlds: <big>%d (%d%%)</big> Darts: <big>%d (%d%%)</big> Merchants: <big>%d </big> Beacons: <big>%d </big> Stardocks: <big>%d </big> Stellurae: <big>%d </big><p>";

char *ampmStr[2] = {"AM","PM"};

char *raceStr[8] = {"Human","Makluvian","Kaletian","Zorestian","Avarian","Najunian","Cestanian","Quarethian"};

//****************************************************************************
//****************************************************************************

void RecordVictory() {
	empireRec *erp;
	int date,secs;
	char query[1024];
	char date_str[256];
	MYSQL dbHandle;
	MYSQL_RES *result;
	int hours,minutes,ampm;

	query[0] = '\0';

	date = todayToDays();
	victoryDate = dateIndex();
	secs = secondsSinceMidnight();

	setTodaysDate();
	minutes = (secs / 60) % 60;
	hours = secs / 3600;
	ampm = hours / 12;
	hours = hours % 12;
	sprintf(date_str,"%s %d:%d%d %s",todayStr,hours,minutes/10,minutes%10,ampmStr[ampm]);

	erp = (empireRec*)empireList->getRecord(top20List[0]);
	if (erp==NULL) return;

	if (strcmp(dbHost, "__NONE__") == 0) {
		/*
		** Not using mySQL
		*/
		fixVictoryList(date,secs,erp);
		fixVictoryHtml(date,secs,erp);
	} else {
		mysql_init(&dbHandle);
		if (!mysql_real_connect(&dbHandle, dbHost, dbUser, dbPasswd, "spacedomination", dbPort, NULL, 0)) {
			fprintf(stderr, "Failed to connect to database: Error: %s\n", mysql_error(&dbHandle));
			return;
		}
		sprintf(query, "insert into sd_game_data (worlds, empires, darts, max_score, server_version, arena, arena_version, elapsed_time, end_time) values (%d, %d, %d, %d, '%s', '%s', %d, %ld, '%s')"
			,worldList->getCount()
			,empireList->getCount()-1
			,totalDarts
			,maxEmpireScore
			,"3.0"
			,arenaName
			,arenaVersion
			,elapsedTime
			,date_str);
		if (mysql_query(&dbHandle,query)) {
			// error
			fprintf(stderr, "Failed to issue database query(%s): Error: %s\n", query, mysql_error(&dbHandle));
			return;
		} else {
			for (int i=3; i < empireList->getCount(); i++) {
				int winner = (i == top20List[0])?1:0;
				int game_id = 0;
				int race_id = 0;
				int user_id = 0;

				erp = (empireRec*)empireList->getRecord(i);

				/*
				** Populate game_id from table sd_game_data
				*/
				sprintf(query, "select @g_id:=MAX(game_id) from sd_game_data");
				if (mysql_query(&dbHandle,query)) {
					// error
					fprintf(stderr, "Failed to issue database query(%s): Error: %s\n", query, mysql_error(&dbHandle));
					return;
				}
				result = mysql_store_result(&dbHandle);
				mysql_free_result(result);
				/*
				** Populate race_id from table sd_races
				*/
				sprintf(query, "select (@r_id:=race_id) as r from sd_races where race_name='%s'", raceStr[erp->race]);
				if (mysql_query(&dbHandle,query)) {
					// error
					fprintf(stderr, "Failed to issue database query(%s): Error: %s\n", query, mysql_error(&dbHandle));
					return;
				}
				result = mysql_store_result(&dbHandle);
				mysql_free_result(result);
				/*
				** Populate user_id from table sd_players
				*/
				sprintf(query, "select (@u_id:=user_id) as u from sd_players where username='%s'", erp->name);
				if (mysql_query(&dbHandle,query)) {
					// error
					fprintf(stderr, "Failed to issue database query(%s): Error: %s\n", query, mysql_error(&dbHandle));
					return;
				}
				result = mysql_store_result(&dbHandle);
				mysql_free_result(result);
				/*
				** Update player record in table sd_player_game
				*/
				//todo add score darts
				sprintf(query, "insert into sd_player_game (user_id, game_id, race_id, score, worlds, darts, merchants, beacons, stardocks, stellurae, worldguns, fleetguns, rebirths, winner) values (@u_id, @g_id, @r_id, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d)",
					erp->hiScore,
					erp->hiWorlds,
					erp->hiDarts,
					erp->Merchant,
					erp->Beacon,
					erp->Stardock,
					erp->Stellurae,
					erp->worldGuns,
					erp->fleetGuns,
					erp->numRebirths,
					winner);
				if (mysql_query(&dbHandle,query)) {
					// error
					fprintf(stderr, "Failed to issue database query(%s): Error: %s\n", query, mysql_error(&dbHandle));
					return;
				}
			}
		}
		mysql_close(&dbHandle);
	}
}


void FirstVictoryRecord(){
victoryRec vrec;

	memset(&vrec,0,sizeof(vrec));
	vrec.date = todayToDays();
	vrec.time = secondsSinceMidnight();
	victoryList->create(&vrec);
}

//****************************************************************************

void fixVictoryList(int date,int secs,empireRec *erp){
victoryRec vrec,*vrp;
int worlds,num;


	memset(&vrec,0,sizeof(vrec));
	strncpy(vrec.name,erp->name,MAXNAMESIZE);
	vrec.date = date;
	vrec.time = secs;

	vrec.worlds = erp->hiWorlds;
	vrec.darts = erp->hiDarts;
	vrec.score = erp->hiScore;
	vrec.race = erp->race;

	worlds = worldList->getCount();
	vrec.maxWorlds = worlds;
	vrec.maxDarts = totalDarts;
	vrec.maxScore = maxEmpireScore;

	num = victoryList->getCount();
	if (victoryList->pickIndex(num-1)) {
		vrp = (victoryRec*)victoryList->getRecord();
		vrec.gameLength = (date - vrp->date) * 24 * 3600 + (secs - vrp->time);
	}

//--- cleanup ---
	victoryList->create(&vrec);
	sendGlobalVictory(&vrec);
}


void fixVictoryHtml(int date,int secs,empireRec *erp){
char *data,buf[512];
int split,length,maxWorlds,maxDarts,hours,minutes,ampm;
FILEID fd;

	data = loadFile(htmlPath);
	if (data==NULL || data[0]==0) clone(&data,startVictoryHtml);
	if (data==NULL) return;

	fd = openForReplace(htmlPath);
	if (badFileIndex(fd)) {
		free(data);
		return;
	}

//--- split file ---
	length = strlen(data);
	split = searchCI(data,editPoint);

	if (split>0) {
		fileWrite(fd,data,split);

		setTodaysDate();
		maxWorlds = worldList->getCount();
		maxDarts = totalDarts;

		minutes = (secs / 60) % 60;
		hours = secs / 3600;
		ampm = hours / 12;
		hours = hours % 12;

		sprintf(buf,victoryStr,
			todayStr,hours,minutes/10,minutes%10,ampmStr[ampm],
			erp->name,			raceStr[erp->race],
			erp->hiScore,		erp->hiScore / (maxEmpireScore/100),
			erp->hiWorlds,		erp->hiWorlds * 100 / maxWorlds,
			erp->hiDarts,		erp->hiDarts * 100 / maxDarts,
			erp->Merchant,
			erp->Beacon,
			erp->Stardock,
			erp->Stellurae);

		fileWrite(fd,buf,strlen(buf));
		
		fileWrite(fd,data+split,length-split);
	}

//--- cleanup ---
	fileClose(fd);
	free(data);
}

//****************************************************************************

